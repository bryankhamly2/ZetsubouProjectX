﻿using UnityEngine;
using System.Collections.Generic;

namespace SpriteFactory {

    [System.Serializable]
    public class ColliderInfo {

        // VARIABLES

        [HideInInspector, SerializeField]
        private Component _colliderComponent;
        [HideInInspector, SerializeField]
        private bool _is2D;
        [HideInInspector, SerializeField]
        private ColliderType _type;
        [HideInInspector, SerializeField]
        private Collider _collider3D; // cache 3D collider accesses so we don't do so much unboxing, cannot do the same for 2D because we cannot expose the Collider2D classes to keep compatiblity with < Unity 4.3

        // PROPERTIES
        
        public Component colliderComponent { get { return _colliderComponent; } }
        public bool is2D { get { return _is2D; } }
        public ColliderType type { get { return _type; } }
        public bool enabled {
            get {
                if(_is2D) {
                    return GetEnabled2D();
                } else return GetEnabled3D();
            }
            set {
                if(_is2D) {
                    SetEnabled2D(value);
                } else SetEnabled3D(value);
            }
        }
        public Collider collider3D {
            get {
                if(is2D) return null;
                if(_collider3D == null) _collider3D = (Collider)_colliderComponent;
                return _collider3D;
            }
        }

        // CONSTRUCTORS

        public ColliderInfo(Component colliderComponent, ColliderType type, bool is2D) {
            this._colliderComponent = colliderComponent;
            this._type = type;
            this._is2D = is2D;
            if(_is2D) Utils.UnityTools.FailIfNo2DSupport();
        }

        public ColliderInfo(ColliderInfo colliderInfo) { // clone
            _colliderComponent = colliderInfo._colliderComponent;
            _type = colliderInfo._type;
            _is2D = colliderInfo.is2D;
            _collider3D = colliderInfo._collider3D;
        }

        // METHODS

        public TCollider GetCollider<TCollider>() where TCollider : Component {
            if(!Utils.UnityTools.IsColliderOrCollider2D(typeof(TCollider), _is2D)) throw new System.ArgumentException("TCollider must be equal to or derrived from Collider or Collider2D!");
            return (TCollider)colliderComponent;
        }

        /*
        public System.Type GetColliderType() {
            if(_colliderComponent == null) return null;
            return _colliderComponent.GetType();
        }

        public System.Type GetColliderBaseType() {
            if(_colliderComponent == null) return null;
            if(_is2D) return Utils.UnityTools.GetVersionRestrictedType(Enums.VersionRestrictedType.Collider2D);
            return typeof(Collider);
        }
        */

        private bool GetEnabled3D() {
            return collider3D.enabled;
        }

        private bool GetEnabled2D() {
            return ((Collider2D)_colliderComponent).enabled;
        }

        private void SetEnabled3D(bool state) {
            collider3D.enabled = state;
        }

        private void SetEnabled2D(bool state) {
            ((Collider2D)_colliderComponent).enabled = state;
        }
    }

    [System.Serializable]
    public class RigidbodyInfo {

        // VARIABLES

        [HideInInspector][SerializeField] private Component _rigidbodyComponent;
        [HideInInspector][SerializeField] private bool _is2D;
        [HideInInspector][SerializeField] private Rigidbody _rigidbody3D; // cache 3D rigidbody accesses so we don't do so much unboxing, cannot do the same for 2D because we cannot expose the Collider2D classes to keep compatiblity with < Unity 4.3

        // PROPERTIES
        
        public Component rigidbodyComponent { get { return _rigidbodyComponent; } }
        public bool is2D { get { return _is2D; } }
        public Rigidbody rigidbody3D {
            get {
                if(is2D) return null;
                if(_rigidbody3D == null) _rigidbody3D = (Rigidbody)_rigidbodyComponent;
                return _rigidbody3D;
            }
        }

        // CONSTRUCTORS

        public RigidbodyInfo(Component rigidbodyComponent, bool is2D) {
            this._rigidbodyComponent = rigidbodyComponent;
            this._is2D = is2D;
            if(_is2D) Utils.UnityTools.FailIfNo2DSupport();
        }

        public RigidbodyInfo(RigidbodyInfo rigidbodyInfo) { // clone
            _rigidbodyComponent = rigidbodyInfo._rigidbodyComponent;
            _is2D = rigidbodyInfo.is2D;
            _rigidbody3D = rigidbodyInfo._rigidbody3D;
        }

        // METHODS

        public TRigidbody GetRigidbody<TRigidbody>() where TRigidbody : Component {
            if(!Utils.UnityTools.IsRigidbodyOrRigidbody2D(typeof(TRigidbody), _is2D)) throw new System.ArgumentException("TRigidbody must be equal to or derrived from Rigidbody or Rigidbody2D!");
            return (TRigidbody)rigidbodyComponent;
        }

        public void WakeUp() {
            if(_is2D) WakeUp2D();
            else rigidbody3D.WakeUp();
        }
        
        private void WakeUp2D() {
            ((Rigidbody2D)_rigidbodyComponent).WakeUp();
        }
    }

    [System.Serializable]
    public class Collision2DTracker {

        // Enums
        private enum EventType { Enter, Stay, Exit };

        // Consts
        private const int maxCollisionsToTrack = 15;

        // Passed in vars
        [SerializeField] private GameObject target;
        [SerializeField] private string spriteColliderName;
        [SerializeField] private string spriteColliderTag;
        [SerializeField] private int spriteColliderId;
        [SerializeField] private string spriteColliderGroupName;

        // List vars
        [SerializeField] private Data[] list;
        [SerializeField] private int _Length; // acts as filled count
        [SerializeField] private int _MaxLength; // the length of the internal array

        private System.Action<string, object, CollisionType> sendMessageCallback; // cannot be serialized

        public Collision2DTracker(GameObject target, string spriteColliderName, int spriteColliderId, string spriteColliderTag, string spriteColliderGroupName) {
            this.target = target;
            this.spriteColliderName = spriteColliderName;
            this.spriteColliderId = spriteColliderId;
            this.spriteColliderTag = spriteColliderTag;
            this.spriteColliderGroupName = spriteColliderGroupName;
            sendMessageCallback = SendMessage;
            
            // Initialize array
            list = new Data[maxCollisionsToTrack]; // create the list at maximum size
            // do not instantiate objects until needed
            _Length = 0;
            _MaxLength = maxCollisionsToTrack;
        }

        public void Update() {
            if(sendMessageCallback == null) sendMessageCallback = SendMessage; // recreate callback if necessary to survive asset imports
            for(int i = 0; i < _Length; i++) {
                list[i].Update(sendMessageCallback);
            }
        }

        public void TriggerEnter(object col) {
            Add(col, CollisionType.Trigger, EventType.Enter);
        }

        public void TriggerStay(object col) {
            Add(col, CollisionType.Trigger, EventType.Stay);
        }

        public void TriggerExit(object col) {
            Add(col, CollisionType.Trigger, EventType.Exit);
        }

        public void CollisionEnter(object col) {
            Add(col, CollisionType.Collider, EventType.Enter);
        }

        public void CollisionStay(object col) {
            Add(col, CollisionType.Collider, EventType.Stay);
        }

        public void CollisionExit(object col) {
            Add(col, CollisionType.Collider, EventType.Exit);
        }

        private void SendMessage(string message, object obj, CollisionType collisionType) {
            if(target == null) return;
            SpriteCollider.CollisionData data = new SpriteCollider.CollisionData(spriteColliderName, spriteColliderId, spriteColliderTag, spriteColliderGroupName, obj, collisionType, true);
            target.SendMessage(message, data, SendMessageOptions.DontRequireReceiver); // send the message
        }

        private int Add(object item, CollisionType collisionType, EventType eventType) {
            if(item == null) return -1;

            // Check if item is already in queue
            int index = IndexOf(item, collisionType);
            if(index >= 0) { // already in queue
                // update the data
                list[index].Event(item, collisionType, eventType);
                return index;
            }

            // Not in queue yet
            index = GetNextSpace(); // find a usable object in the list
            if(index == -1) return -1; // list is full

            Data entry = list[index]; // get the data object
            entry.Clear(); // clear the object first
            entry.Event(item, collisionType, eventType); // register the event
            return index;
        }

        private int GetNextSpace() {
            // Search entries for an open space
            for(int i = 0; i < _Length; i++) {
                if(list[i].isOpen) return i;
            }

            // Did not find an open one, see if there's room to expand the list
            if(_Length < _MaxLength) { // we have room to expand
                int index = _Length;
                list[index] = new Data(); // instantiate the object
                _Length++; // expand
                return index; // expand
            }
                
            // No room left
            return -1;
        }

        private int IndexOf(object item, CollisionType type) {
            if(item == null) return -1;
            for(int i = 0; i < _Length; i++) {
                if(list[i].Equals(item, type)) return i;
            }
            return -1;
        }
            
        private void ClearList() {
            for(int i = 0; i < _MaxLength; i++) {
                list[i].Clear();
            }
            _Length = 0; // reset the filled count
        }

        public void Disabled() { // clear any entries we're tracking
            for(int i = 0; i < _Length; i++) {
                list[i].ExitIfTracking(SendMessage);
            }
        }

        /* OLD QUEUE-STYLE VERSION
        [System.Serializable]
        public class CollisionQueue {
            [SerializeField]private Data[] list;
            [SerializeField]private int _Length; // acts as filled count
            [SerializeField]private int _MaxLength; // the length of the internal array
            [SerializeField]private int _Position;

            [SerializeField]private System.Action<string, object> sendMessageCallback;

            // Properties
            public int Length { get { return _Length; } }
            public int MaxLength { get { return _MaxLength; } }
            public int FreeSpace { get { return _MaxLength - _Length; } }
            public int Position { get { return _Position; } }
            private int backIndex { // the index of the last entry in queue
                get {
                    if(_Length == 0) return -1;
                    // _Position is the front of the list
                    // if list is wrapped, back is _Position + 1
                    // if !wrapped, back is 0
                    if(_Position < _Length - 1) // list is wrapped
                        return _Position + 1;
                    else // list is not wrapped
                        return 0;
                }
            }

            public CollisionQueue(int maximumLength, System.Action<string, object> sendMessageCallback) {
                list = new Data[maximumLength]; // create the list at maximum size
                // Initialize array
                for(int i = 0; i < maximumLength; i++) {
                    list[i] = new Data();
                }
                _Length = 0;
                _MaxLength = maximumLength;
                _Position = -1;

                this.sendMessageCallback = sendMessageCallback;
            }

            private Data this[int index] {
                get {
                    if(index >= _Length) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                    return list[index];
                }
                set {
                    // SET DOES NOT AFFECT POSITION, this is handled separately
                    if(index > _Length) throw new System.IndexOutOfRangeException(); // prevent skipping of unassigned indices
                    list[index] = value;
                    if(index >= _Length) // we've added in an index at or higher than the filled count
                        _Length = index + 1; // increase the filled count
                }
            }

            public void Update() {
                for(int i = 0; i < _Length; i++) {
                    list[i].Update(sendMessageCallback);
                }
            }

            public int Add(object item, CollisionType collisionType, EventType eventType) {
                if(item == null) return -1;

                // Check if item is already in queue
                int index = IndexOf(item, collisionType);
                if(index >= 0) { // already in queue
                    
                    // update the data
                    list[index].Event(item, collisionType, eventType);

                    // move this entry to front of queue to renew its importance
                    index = Requeue(index);
                    return index;
                }

                // Not in queue yet
                index = FindNextUsableEntry(); // find a usable object in the list
                Data entry = list[index];
                entry.Clear(); // clear the object first
                entry.Event(item, collisionType, eventType); // register the event
                index = Requeue(index); // reorder the item to the front of the queue
                return index;
            }

            private int FindNextUsableEntry() {
                if(_Length == 0) return 0; // no items in list yet, just use the first space

                // Search entries for an open space
                int index = this.backIndex;
                for(int i = 0; i < _Length; i++) {
                    if(list[index].isOpen) return index;
                    index = GetNext(index);
                }

                // Did not find an open one, see if there's room to expand the list
                if(_Length < _MaxLength) { // we have room to expand
                    return _Length;
                }
                
                // No room to expand, just get the last one from the list and overwrite it
                return this.backIndex;
            }

            private int Queue(Data entry) { // add to front of queue
                Insert(entry, GetNext(_Position)); // add item to list at next position
                return _Position; // return index of added item
            }

            private int Requeue(int index) { // reposition an item in the list to the front
                if(index == _Position) return index; // already at front of list
                Data entry = list[index];
                RemoveAt(index);
                return Queue(entry);
            }

            private void RemoveAt(int index) {
                // Actually removes the object -- only to be using in requeue operations!
                if(index < 0 || index >= _MaxLength) throw new System.IndexOutOfRangeException();
        
                int lastIndex = _MaxLength - 1;

                // Move entries after this one down
                for(int i = index; i < lastIndex; i++) {
                    list[i] = list[i + 1]; // move the next entry into this space
                }

                // Clear the last entry
                list[lastIndex] = null; // clear the entry

                // Adjust list length and queue position
                if(index <= _Length - 1) { // item we removed was within the valid range of the queue
                    _Length--; // reduce size of the list
                    RewindPosition(); // adjust position index
                }
            }

            private void Insert(Data entry, int index) {
                // Actually adds the object -- only to be using in requeue operations!
                if(index < 0 || index >= _MaxLength) throw new System.IndexOutOfRangeException();
                
                // Check if inserting into the last space
                int lastIndex = _MaxLength - 1;
                if(index == lastIndex) { // this is the last space in the array
                    list[lastIndex] = entry; // just overwrite last index
                
                } else { // not in the last space

                    // Move entries after this one up
                    for(int i = lastIndex - 1; i >= index; i--) {
                        list[i + 1] = list[i]; // move this entry into next space
                    }

                    // Fill the current entry
                    list[index] = entry;
                }

                // Adjust list length and queue position
                if(index <= _Length) { // item we added was within the valid range of the queue or was added on to the end
                    _Length++; // increase size of list
                    AdvancePosition(); // adjust position index
                }
            }

            public bool Contains(object item, CollisionType type) {
                if(item == null) return false;
                for(int i = 0; i < _Length; i++) {
                    if(list[i].Equals(item, type)) return true;
                }
                return false;
            }

            public int IndexOf(object item, CollisionType type) {
                if(item == null) return -1;
                for(int i = 0; i < _Length; i++) {
                    if(list[i].Equals(item, type)) return i;
                }
                return -1;
            }

            private int AdvancePosition() {
                _Position = GetNext(_Position);
                return _Position;
            }

            private int RewindPosition() {
                _Position = GetPrevious(_Position);
                return _Position;
            }

            private int GetNext(int index) {
                if(index + 1 >= _MaxLength) index = 0; // wrap back to beginning
                else index++;
                return index;
            }

            private int GetPrevious(int index) {
                if(index == 0) {
                    if(_Length > 0) // we still have entries
                        index = _Length - 1; // wrap to end
                    else // no more entries
                        index = -1;
                }
                else index--;
                return index;
            }

            public void Clear() {
                for(int i = 0; i < _MaxLength; i++) {
                    list[i].Clear();
                }
                _Length = 0; // reset the filled count
                _Position = -1; // reset position
            }
        } 
        */

        [System.Serializable]
        private class Data {

            public bool entered;
            public bool enteredPrev;
            public bool stayed;
            public bool stayedPrev;
            public bool exited;
            public object data;
            public object collider;
            public CollisionType type;

            public bool isOpen {
                get {
                    if(collider == null) return true;
                    return false;
                }
            }

            public void Update(System.Action<string, object, CollisionType> sendMessageCallback) {
                if(collider == null) return; // nothing to do

                bool collided = entered || stayed;
                bool collidedPrev = enteredPrev || stayedPrev;

                if(collided) { // collided
                    if(!collidedPrev) // Collision/Trigger Enter
                        SendMessage(EventType.Enter, sendMessageCallback);
                    else // Collision/Trigger Stay
                        SendMessage(EventType.Stay, sendMessageCallback);
                } else if(collidedPrev) { // Collision/Trigger Exit
                    // ARTIFACT - Collision2D.contactPoints may contain points even on an OnCollisionExit because we can't clear it
                    SendMessage(EventType.Exit, sendMessageCallback);
                    Clear(); // once exited, clear the entry because we no longer need to track it
                    return;
                }

                // Store current states as previous for next time
                enteredPrev = entered;
                stayedPrev = stayed;

                // Clear momentary vars
                if(entered) entered = false;
                if(stayed) stayed = false;
                if(exited) exited = false;
            }

            public void Event(object item, CollisionType collisionType, EventType eventType) {
                if(collisionType != type) { // collider type on target or source may have been changed, clear it
                    Clear();
                    type = collisionType; // store collision type between these two colliders
                }

                // Take action based on event type
                if(collisionType == CollisionType.Collider) {
                    if(eventType == EventType.Enter) CollisionEnter(item);
                    else if(eventType == EventType.Stay) CollisionStay(item);
                    else CollisionExit(item);
                } else { // trigger
                    if(eventType == EventType.Enter) TriggerEnter(item);
                    else if(eventType == EventType.Stay) TriggerStay(item);
                    else TriggerExit(item);
                }
            }

            private void CollisionEnter(object item) {
                StoreCollisionData(item);
                entered = true;
            }

            private void CollisionStay(object item) {
                StoreCollisionData(item);
                stayed = true;
            }

            private void CollisionExit(object item) {
                StoreCollisionData(item);
                exited = true;
            }

            private void TriggerEnter(object item) {
                StoreTriggerData(item);
                entered = true;
            }

            private void TriggerStay(object item) {
                StoreTriggerData(item);
                stayed = true;
            }

            private void TriggerExit(object item) {
                StoreTriggerData(item);
                exited = true;
            }

            private void StoreCollisionData(object item) {
                // Store information from the collision
                data = item;
                Collision2D col2D = (Collision2D)item;
                collider = col2D.collider; // store the collider for comparison
            }

            private void StoreTriggerData(object item) {
                data = item;
                collider = item;
            }

            public bool Equals(object item, CollisionType type) {
                if(collider == null) return false; // no collider to compare

                if(type == CollisionType.Trigger) {
                    if(collider == item) return true;
                } else if(((Collision2D)item).collider == (Collider2D)collider) return true;
                return false;
            }

            private void SendMessage(EventType eventType, System.Action<string, object, CollisionType> sendMessageCallback) {
                string collisionType;
                if(type == CollisionType.Collider) collisionType = "Collision";
                else collisionType = "Trigger";

                // Send the message
                sendMessageCallback(string.Format("On{0}{1}Sprite", collisionType, eventType.ToString()), data, type);
            }

            public void Clear() {
                if(entered) entered = false;
                if(enteredPrev) enteredPrev = false;
                if(stayed) stayed = false;
                if(stayedPrev) stayedPrev = false;
                if(exited) exited = false;
                if(data != null) data = null;
                if(collider != null) collider = null;
            }

            public void ExitIfTracking(System.Action<string, object, CollisionType> sendMessageCallback) {
                if(collider == null) return;

                bool collidedPrev = enteredPrev || stayedPrev;

                if(collidedPrev) { // Collision/Trigger Exit
                    // ARTIFACT - Collision2D.contactPoints may contain points even on an OnCollisionExit because we can't clear it
                    SendMessage(EventType.Exit, sendMessageCallback);
                }

                Clear();
            }
        }
    }

}
