using UnityEngine;
using System.Collections;

namespace SpriteFactory {

    public class Settings : ScriptableObject {

        // Consts
        public const int minAutoMeshExtrude = 3;
        public const int minAutoMeshEdgeVertexReductionDistance = 3;

        // Editor settings
        [SerializeField]
        private int _pixelsPerUnit = 100;
        [SerializeField]
        private bool _trimSprites = true;
        [SerializeField]
        private int _framePadding = 4;
        [SerializeField]
        private int _maxAtlasSize = 4096;
        [SerializeField]
        private bool _forceSquareAtlases = false;
        [SerializeField]
        private bool _useMipMaps = false;
        [SerializeField]
        private bool _useTextureCompression = false;
        //[SerializeField]
        //private AtlasPackingMethod _atlasPackingMethod = AtlasPackingMethod.Default;
        [SerializeField]
        private Enums.ResolutionTarget _resolutionTarget = Enums.ResolutionTarget.One;
        [SerializeField]
        private Enums.ImageResamplingMode _resolutionTargetResamplingMode = Enums.ImageResamplingMode.Mitchell;
        [SerializeField]
        private string _defaultMaterialGUID;
        [SerializeField]
        private FilterMode _defaultFilterMode = FilterMode.Bilinear;
        [SerializeField]
        private int _defaultAnisoLevel = 1;
        [SerializeField]
        private bool _defaultUseTwoSidedMesh = false;
        [SerializeField]
        private SpriteFactory.Enums.SpriteMeshType _defaultMeshType = SpriteFactory.Enums.SpriteMeshType.Rectangle;
        [SerializeField]
        private SpriteFactory.Enums.TransparencyChannel _defaultAutoMeshTransparencyChannel = SpriteFactory.Enums.TransparencyChannel.Alpha;
        [SerializeField]
        private int _defaultAutoMeshEdgeExtrude = 8;
        [SerializeField]
        private int _defaultAutoMeshVertexReductionDistance = 5;
        [SerializeField]
        private bool _defaultUse2DColliders = false;
        [SerializeField]
        private AutomaticActionPolicy _rebuildSpriteOnSave = AutomaticActionPolicy.Always;
        [SerializeField]
        private AutomaticActionPolicy _rebuildSpriteGroupOnSave = AutomaticActionPolicy.Always;

        public int pixelsPerUnit {
            get {
                return _pixelsPerUnit;
            }
            set {
                _pixelsPerUnit = value;
            }
        }
        public bool trimSprites {
            get {
                return _trimSprites;
            }
            set {
                _trimSprites = value;
            }
        }
        public int framePadding {
            get {
                return _framePadding;
            }
            set {
                _framePadding = value;
            }
        }
        public int maxAtlasSize {
            get {
                return _maxAtlasSize;
            }
            set {
                _maxAtlasSize = value;
            }
        }
        public bool forceSquareAtlases {
            get {
                return _forceSquareAtlases;
            }
            set {
                _forceSquareAtlases = value;
            }
        }
        public bool useMipMaps {
            get {
                return _useMipMaps;
            }
            set {
                _useMipMaps = value;
            }
        }
        public bool useTextureCompression {
            get {
                return _useTextureCompression;
            }
            set {
                _useTextureCompression = value;
            }
        }
        //public AtlasPackingMethod atlasPackingMethod {
        //    get {
        //        return _atlasPackingMethod;
        //    }
        //    set {
        //        _atlasPackingMethod = value;
        //    }
        //}
        public Enums.ResolutionTarget resolutionTarget {
            get {
                return _resolutionTarget;
            }
            set {
                _resolutionTarget = value;
            }
        }
        public Enums.ImageResamplingMode resolutionTargetResamplingMode {
            get {
                return _resolutionTargetResamplingMode;
            }
            set {
                _resolutionTargetResamplingMode = value;
            }
        }
        // Defaults
        public string defaultMaterialGUID {
            get { return _defaultMaterialGUID; }
            set { _defaultMaterialGUID = value; }
        }
        public FilterMode defaultFilterMode {
            get { return _defaultFilterMode; }
            set { _defaultFilterMode = value; }
        }
        public int defaultAnisoLevel {
            get { return _defaultAnisoLevel; }
            set { _defaultAnisoLevel = value; }
        }
        public bool defaultUseTwoSidedMesh {
            get { return _defaultUseTwoSidedMesh; }
            set { _defaultUseTwoSidedMesh = value; }
        }
        public SpriteFactory.Enums.SpriteMeshType defaultMeshType {
            get { return _defaultMeshType; }
            set { _defaultMeshType = value; }
        }
        public SpriteFactory.Enums.TransparencyChannel defaultAutoMeshTransparencyChannel {
            get { return _defaultAutoMeshTransparencyChannel; }
            set { _defaultAutoMeshTransparencyChannel = value; }
        }
        public int defaultAutoMeshEdgeExtrude {
            get { return _defaultAutoMeshEdgeExtrude; }
            set { _defaultAutoMeshEdgeExtrude = value; }
        }
        public int defaultAutoMeshVertexReductionDistance {
            get { return _defaultAutoMeshVertexReductionDistance; }
            set { _defaultAutoMeshVertexReductionDistance = value; }
        }
        public bool defaultUse2DColliders {
            get { return _defaultUse2DColliders; }
            set { _defaultUse2DColliders = value; }
        }

        // Preferences
        public AutomaticActionPolicy rebuildSpriteOnSave {
            get { return _rebuildSpriteOnSave; }
            set { _rebuildSpriteOnSave = value; }
        }
        public AutomaticActionPolicy rebuildSpriteGroupOnSave {
            get { return _rebuildSpriteGroupOnSave; }
            set { _rebuildSpriteGroupOnSave = value; }
        }

        // Calculated properties
        public bool isResolutionTargetScaled {
            get {
                float scale = resolutionTargetScale;
                if(scale <= 0.0f || scale == 1.0f) return false;
                return true;
            }
        }
        public float resolutionTargetScale {
            get {
                return SpriteFactory.Utils.MiscTools.ResolutionTargetScale(_resolutionTarget);
            }
        }
        public float resolutionTargetScaleInverseMultiplier {
            get {
                return SpriteFactory.Utils.MiscTools.ResolutionTargetInverseScale(_resolutionTarget);
            }
        }
        public int scaledDefaultAutoMeshEdgeExtrude {
            get {
                // Scale extrusion if scaled
                float resolutionTargetScale = this.resolutionTargetScale;
                if(resolutionTargetScale > 0.0f && resolutionTargetScale != 1.0f) {
                    return ScaleAutoMeshEdgeExtrude(_defaultAutoMeshEdgeExtrude);
                }
                return _defaultAutoMeshEdgeExtrude;
            }
        }
        public int scaledDefaultAutoMeshVertexReductionDistance {
            get {
                // Scale extrusion if scaled
                float resolutionTargetScale = this.resolutionTargetScale;
                if(resolutionTargetScale > 0.0f && resolutionTargetScale != 1.0f) {
                    return ScaleAutoMeshEdgeVertexReductionDistance(_defaultAutoMeshVertexReductionDistance);
                }
                return _defaultAutoMeshVertexReductionDistance;
            }
        }

        // Public methods
        public int ScaleAutoMeshEdgeExtrude(int extrudeAmount) {
            return Mathf.Max(minAutoMeshExtrude, Mathf.CeilToInt(extrudeAmount * resolutionTargetScale)); // always make extrusion bigger if fractional, clamp to minimum 2 pixels
        }

        public int ScaleAutoMeshEdgeVertexReductionDistance(double distance) {
            return Mathf.Max(minAutoMeshEdgeVertexReductionDistance, Mathf.CeilToInt((float)distance * resolutionTargetScale)); // always make extrusion bigger if fractional, clamp to minimum 2 pixels
        }
                
    }
}