using UnityEngine;
using System.Collections;

namespace SpriteFactory {

    [AddComponentMenu("")]
    public class SpriteLocator : MonoBehaviour {

        // Working
        [HideInInspector, SerializeField]
        new private GameObject gameObject;
        [HideInInspector, SerializeField]
        private Sprite sprite;
        [HideInInspector, SerializeField]
        private int locatorIndex;
        [HideInInspector, SerializeField]
        private bool initialized;
        [HideInInspector, SerializeField]
        private bool calledByAnimation; // momentary flag so we know whether OnEnable was called by this or something else

        public void Initialize(Sprite inSprite, GameObject thisGameObject, int inLocatorIndex) {
            gameObject = thisGameObject;
            sprite = inSprite;
            locatorIndex = inLocatorIndex;
            initialized = true;
        }

        private void OnEnable() {
            if(!initialized) return; // prevent this from running in the editor

            if(!calledByAnimation) { // called by an external force
                // User Activation
                // Instantiation
                // Scene load/play

                // Undo if it was enabled directly by user or SetActiveRecursively
                // If SetActiveRecursively(true) is called, all child locators will be enabled, which is not correct
                // The locator must turn itself off again so SetActiveRecursively will work as intended to enable a nested sprite hierarchy.
                sprite.LocatorEnabled(locatorIndex);
                // locator is not supposed to be enabled this frame according to Sprite

                // Note: The object in Hierarchy and checkbox in Inspector will not update correctly for some reason and it will show it enabled even though it is not.
            }
        }

        public void SetActive(bool state) { // this is called by Sprite.Locator when activating/deactivating. SHOULD NOT BE CALLED DIRECTLY because it doesn't handle recursives and children
            if(gameObject == null) return;
            if(Utils.UnityTools.IsActiveInHierarchy(gameObject) == state) return; // already in same state
            calledByAnimation = true;
            Utils.UnityTools.SetActive(gameObject, state);
            calledByAnimation = false;
        }
    }
}