using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace SpriteFactory {

    public partial class Sprite : MonoBehaviour {

        #region // ENUMS

        public enum WrapMode { Once = 0, Loop = 1, Clamp = 2, PingPong = 3 }
        public enum BillboardUpAxis { WorldX, WorldY, WorldZ, WorldNegX, WorldNegY, WorldNegZ, CameraX, CameraY, CameraZ, CameraNegX, CameraNegY, CameraNegZ };

        #endregion

        // SPRITE COMPONENT CLASSES /////////////////

        #region // SharedData

        [System.Serializable]
        public class SharedData {
            // This data is shared among all instances of a sprite
            // DO NOT EVER change any data contained in these during runtime or data on disk will change

            public MeshFrame[] meshFrames;
            public int meshFramesMaxVertexCount; // this is serialized on save in editor
            public int meshFramesMaxUVCount {
                get {
                    if(meshFrames == null) return 0;
                    int maxCount = 0;
                    for(int i = 0; i < meshFrames.Length; i++) {
                        if(meshFrames[i] == null) continue;
                        int count = meshFrames[i].uvCount;
                        if(count > maxCount) maxCount = count;
                    }
                    return maxCount;
                }
            }
            public int meshFramesMaxTriangleCount {
                get {
                    if(meshFrames == null) return 0;
                    int maxCount = 0;
                    for(int i = 0; i < meshFrames.Length; i++) {
                        if(meshFrames[i] == null) continue;
                        int count = meshFrames[i].triangleCount;
                        if(count > maxCount) maxCount = count;
                    }
                    return maxCount;
                }
            }
        }

        #endregion

        #region // Data

        [System.Serializable]
        public abstract class Data_Base {

            public string name = "";
            public bool isStaticSprite;
            public bool twoSidedMesh;
            public int defaultAnimationIndex = 0;
            public ColliderSet[] colliderSets;
            public ColliderGroup[] colliderGroups;
            public LocatorSet[] locatorSets;
            public Mesh[] editorPreviewMeshes;
            public GameSettings gameSettings; // links to prefabs

            public void CopyDataVars(Data_Base source, Data_Base destination) {
                destination.editorPreviewMeshes = SpriteFactory.Utils.ArrayTools.Clone<Mesh>(source.editorPreviewMeshes); // clone the editor preview meshes
                destination.gameSettings = source.gameSettings; // copy the actual object instead of making a copy

                // Collider Sets
                Sprite.ColliderSet[] sourceColliderSets = source.colliderSets;
                if(sourceColliderSets != null) {
                    int count = sourceColliderSets.Length;
                    destination.colliderSets = new Sprite.ColliderSet[count];
                    for(int i = 0; i < count; i++) {
                        destination.colliderSets[i] = sourceColliderSets[i].DeepCopy();
                    }
                } else
                    destination.colliderSets = null;

                // Collider Groups
                Sprite.ColliderGroup[] sourceColliderGroups = source.colliderGroups;
                if(sourceColliderGroups != null) {
                    int count = sourceColliderGroups.Length;
                    destination.colliderGroups = new Sprite.ColliderGroup[count];
                    for(int i = 0; i < count; i++) {
                        destination.colliderGroups[i] = sourceColliderGroups[i].DeepCopy(sourceColliderGroups[i].id);
                    }
                } else
                    destination.colliderGroups = null;

                // Locator Sets
                Sprite.LocatorSet[] sourceLocatorSets = source.locatorSets;
                if(sourceLocatorSets != null) {
                    int count = sourceLocatorSets.Length;
                    destination.locatorSets = new Sprite.LocatorSet[count];
                    for(int i = 0; i < count; i++) {
                        destination.locatorSets[i] = sourceLocatorSets[i].DeepCopy();
                    }
                } else
                    destination.locatorSets = null;

                // values
                destination.name = source.name;
                destination.isStaticSprite = source.isStaticSprite;
                destination.defaultAnimationIndex = source.defaultAnimationIndex;
                destination.twoSidedMesh = source.twoSidedMesh;
            }
        }

        [System.Serializable]
        public class Data : Data_Base { // the main sprite save data

            [System.NonSerialized]public SharedData sharedData; // this cannot be serialized or it will double store it
            
            // Data
            public Animation[] animations;
            public MaterialSet[] materialSets;
            public Atlas[] atlases;
            public int parentColliderIndex = -1;
            public int materialSetCount;
            public int colliderCount;
            public int locatorCount;
            public bool hasAnimatedColliders;
            public int defaultMaterialSetIndex = 0;
            public int animationCount;
            public bool useCustomMesh;

            // Properties to shared data
            /*
            public MeshFrame[] meshFrames {
                get {
                    if(sharedData == null) return null;
                    return sharedData.meshFrames;
                }
            }*/

            public int maxVertexCount { get { return sharedData != null ? sharedData.meshFramesMaxVertexCount : 0; } }

            public int maxUVCount { get { return sharedData != null ? sharedData.meshFramesMaxUVCount : 0; } }

            public int maxTriangleCount { get { return sharedData != null ? sharedData.meshFramesMaxTriangleCount : 0; } }


            public Data() { }

            public Data(Sprite.Data spriteData) { // called when sprite runs Awake
                CopyDataVars(spriteData, this); // copy data into self (
            }

            #region Get Information

            public string[] GetAnimationNames() {
                if(animationCount <= 0) return null;
                string[] names = new string[animationCount];
                for(int i = 0; i < animationCount; i++) {
                    names[i] = animations[i].name;
                }
                return names;
            }

            public string[] GetMaterialSetNames() {
                if(materialSets == null) return null;
                int setCount = materialSets.Length;
                if(setCount == 0) return null;
                string[] names = new string[setCount];
                for(int i = 0; i < setCount; i++)
                    names[i] = materialSets[i].name;
                return names;
            }

            public int[] GetAnimationFrameCounts() {
                if(animationCount <= 0) return null;
                int[] frameCounts = new int[animationCount];
                for(int i = 0; i < animationCount; i++) {
                    Sprite.Animation anim = animations[i];
                    frameCounts[i] = anim.frameCount;
                }
                return frameCounts;
            }

            public string[] GetColliderSetNames() {
                if(colliderCount <= 0) return null;
                string[] names = new string[colliderCount];
                for(int i = 0; i < colliderCount; i++) {
                    names[i] = colliderSets[i].name;
                }
                return names;
            }

            public string[] GetLocatorSetNames() {
                if(locatorCount <= 0) return null;
                string[] names = new string[locatorCount];
                for(int i = 0; i < locatorCount; i++) {
                    names[i] = locatorSets[i].name;
                }
                return names;
            }

            public Frame GetEditorPreviewFrame() {
                if(animations == null || animations.Length <= 0) return null;
                if(defaultAnimationIndex < 0 || defaultAnimationIndex >= animations.Length) return null;
                Animation anim = animations[defaultAnimationIndex];
                if(anim == null) return null;
                Frame[] frames = anim.frames;
                if(frames == null || frames.Length == 0) return null;
                if(frames[0] == null) return null;
                return frames[0];
            }

            public Texture2D GetEditorPreviewAtlasTexture() {
                if(atlases == null || atlases.Length == 0) return null;
                Frame editorPreviewFrame = GetEditorPreviewFrame();
                if(editorPreviewFrame == null) return null;
                int atlasIndex = editorPreviewFrame.atlasIndex;
                if(atlasIndex < 0) return null;
                return atlases[atlasIndex].textureMap;
            }

            public ColliderGroup GetColliderGroup(int id) {
                if(colliderGroups == null || colliderGroups.Length == 0) return null;
                for(int i = 0; i < colliderGroups.Length; i++) {
                    if(colliderGroups[i] == null) continue;
                    if(colliderGroups[i].id == id) return colliderGroups[i];
                }
                return null;
            }

            #endregion

            #region Utilities

            protected void CopyDataVars(Data source, Data destination) {
                base.CopyDataVars((Data_Base)source, (Data_Base)destination); // copy the data vars in the base class

                // Animations
                Sprite.Animation[] sourceAnimations = source.animations;
                if(sourceAnimations != null) {
                    int count = sourceAnimations.Length;
                    destination.animations = new Sprite.Animation[count];
                    for(int i = 0; i < count; i++) {
                        destination.animations[i] = sourceAnimations[i].DeepCopy();
                    }
                } else
                    destination.animations = null;
                if(destination.animations != null) destination.animationCount = animations.Length; // save animation count

                // Material Sets
                Sprite.MaterialSet[] sourceMaterialSets = source.materialSets;
                if(sourceMaterialSets != null) {
                    int count = sourceMaterialSets.Length;
                    destination.materialSets = new Sprite.MaterialSet[count];
                    for(int i = 0; i < count; i++) {
                        destination.materialSets[i] = sourceMaterialSets[i].DeepCopy();
                    }
                } else
                    destination.materialSets = null;

                // Atlases
                Sprite.Atlas[] sourceAtlases = source.atlases;
                if(sourceAtlases != null) {
                    int count = sourceAtlases.Length;
                    destination.atlases = new Sprite.Atlas[count];
                    for(int i = 0; i < count; i++) {
                        destination.atlases[i] = sourceAtlases[i].DeepCopy();
                    }
                } else
                    destination.atlases = null;

                // Values
                destination.animationCount = source.animationCount;
                destination.defaultMaterialSetIndex = source.defaultMaterialSetIndex;
                destination.parentColliderIndex = source.parentColliderIndex;
                destination.materialSetCount = source.materialSetCount;
                destination.colliderCount = source.colliderCount;
                destination.locatorCount = source.locatorCount;
                destination.hasAnimatedColliders = source.hasAnimatedColliders;
                destination.useCustomMesh = source.useCustomMesh;
            }

            public Sprite.Data DeepCopy() {
                return new Sprite.Data(this);
            }

            #endregion

            public void CalculateCountsAndFlags() {
                // Count animations
                if(animations != null) animationCount = animations.Length;
                else animationCount = 0;

                // Count material sets
                if(materialSets != null) materialSetCount = materialSets.Length;
                else materialSetCount = 0;

                // Count colliders, find parent, find out if any are animated
                if(colliderSets != null) colliderCount = colliderSets.Length;
                else colliderCount = 0;

                for(int i = 0; i < colliderCount; i++) {
                    if(!hasAnimatedColliders && colliderSets[i].isAnimated) hasAnimatedColliders = true;
                    if(colliderSets[i].isParent) parentColliderIndex = i;
                }

                // Count locators sets
                if(locatorSets != null) locatorCount = locatorSets.Length;
                else locatorCount = 0;
            }

        }

        #endregion

        #region // Animation

        [System.Serializable]
        public abstract class Animation_Base {
            public string name = "Animation0";
            public Sprite.WrapMode wrapMode;
            public int loopCount = 0; // <= 0 = infinite
            public int loopRestartFrame = 0;
            [SerializeField]
            protected int _frameRate;

            public Animation_Base() { }

            public Animation_Base(int frameRate, Sprite.WrapMode wrapMode) {
                _frameRate = frameRate;
                this.wrapMode = wrapMode;
            }

            protected void CopyDataVars(Animation_Base source, Animation_Base destination) {
                destination.name = source.name;
                destination._frameRate = source._frameRate;
                destination.wrapMode = source.wrapMode;
                destination.loopCount = source.loopCount;
                destination.loopRestartFrame = source.loopRestartFrame;
            }
        }

        [System.Serializable]
        public class Animation : Animation_Base {
            #region Variables

            public Frame[] frames = new Frame[0];
            public int frameCount;

            // In-game variables
            // Working
            [SerializeField]
            private SpriteFactory.Utils.FrameTimer frameTimer;
            [SerializeField]
            private int _currentFrame;
            [SerializeField]
            private int _prevFrame = -1;
            [SerializeField]
            private int currentLoop;
            [SerializeField]
            private bool _isPlayingForward = true;
            [SerializeField]
            private bool _playBackwards = false;
            [SerializeField]
            private bool _isPlaying;
            [SerializeField]
            private float _speed = 1.0f;
            [SerializeField]
            private bool hasFrameEvents;
            
            private System.Action callback_animStarted;
            private System.Action callback_animFinished;
            private System.Action callback_animEnded;

            // Caches
            [SerializeField]
            private Sprite parentSprite;
            [SerializeField]
            private int animationId;

            // Properties
            public bool isPlaying { get { return _isPlaying; } set { _isPlaying = value; } }
            public int currentFrame { get { return _currentFrame; } }
            public Frame currentFrameObject {
                get {
                    if(frameCount == 0) return null;
                    return frames[currentFrame];
                }
            }
            public float speed {
                get {
                    return _speed;
                }
                set {
                    _speed = value;
                }
            }
            public bool playBackwards { get { return _playBackwards; } }

            private Rect frameCoords { get { return frames[_currentFrame].uvCoords; } }
            //private float frameDuration { get { return frames[_currentFrame].duration; } } // optimization

            #endregion

            #region Constructors

            public Animation() { }

            public Animation(int frameRate, Sprite.WrapMode wrapMode) {
                _frameRate = frameRate;
                this.wrapMode = wrapMode;
            }

            public Animation(Sprite.Animation animation) { // clone a sprite animation
                CopyDataVars(animation, this); // copy data from object into this
            }

            #endregion

            #region In-Game Functions

            public void Initialize(Sprite inSprite, int inAnimationId) {
                parentSprite = inSprite; // set up reciprocal link
                animationId = inAnimationId;
                frameTimer = new SpriteFactory.Utils.FrameTimer();

                // Check if we have frame events and set flag
                for(int i = 0; i < frameCount; i++) {
                    if(frames[i].hasEvent) {
                        hasFrameEvents = true;
                        break;
                    }
                }
            }

            // Animation control ////////////

            public void Animate(float deltaTime, float playbackSpeed) {
                if(playbackSpeed <= 0.0f || _speed <= 0.0f) return;

                // Play the frame and advance to next when duration is finished
                if(frameTimer.Update(deltaTime, playbackSpeed * _speed)) { // frame just finished
                    if(NextFrame()) {// advance to next frame, loop, ping-pong, or finish
                        PlayFrame(); // play the frame
                    }
                }
            }

            public void Play(bool playBackwards) {
                if(frameCount <= 0) return; // no frames to play

                _isPlaying = true;
                _playBackwards = playBackwards;
                // do not store prev frame here. It should always be -1 since Finished() will clear it

                // Set the starting frame index
                if(playBackwards) {
                    _currentFrame = frameCount - 1; // set current frame to last frame so playback happens backwards
                } else {
                    _currentFrame = 0; // set current frame to 0 every time play is called
                }

                UserAction();
                if(callback_animStarted != null) callback_animStarted(); // invoke callback
                PlayFrame(); // play the current frame
            }

            public void Play(int frameIndex, bool playBackwards) {
                if(frameCount <= 0) return; // no frames to play
                if(frameIndex < 0 || frameIndex >= frameCount) return; // invalid frame index

                _isPlaying = true;
                _playBackwards = playBackwards;
                // do not store prev frame here. It should always be -1 since Finished() will clear it
                _currentFrame = frameIndex; // set current frame to incoming every time play is called
                UserAction();
                if(callback_animStarted != null) callback_animStarted(); // invoke callback
                PlayFrame(); // play the frame
            }

            public void Reverse() {
                _playBackwards = !_playBackwards;
                _isPlayingForward = !_isPlayingForward;
            }

            private bool NextFrame() {

                // Advance to next frame
                if(_isPlayingForward) {
                    int lastFrame = frameCount - 1;
                    if(_currentFrame < lastFrame) { // still have frames left to play
                        _prevFrame = _currentFrame; // store prev frame
                        _currentFrame++; // advance frame
                        return true; // play
                    }
                } else { // playing in reverse
                    if(_currentFrame > 0) { // still have frames left to play
                        _prevFrame = _currentFrame; // store prev frame
                        _currentFrame--; // advance frame
                        return true; // play
                    }
                }

                // We've played the last frame, so finish or continue playing based on wrap mode
                if(wrapMode == Sprite.WrapMode.Once) {
                    Finished(false); // done playing
                    return false; // don't play

                } else if(wrapMode == Sprite.WrapMode.Clamp) {

                    return false; // keep displaying same frame, don't play

                } else if(wrapMode == Sprite.WrapMode.Loop) {
                    // Check for loop end
                    if(loopCount > 0) { // this is a finite loop
                        currentLoop++; // increment loop counter if not infinite
                        if(currentLoop >= loopCount) { // finished last loop
                            Finished(false); // done playing
                            return false; // don't play
                        }
                    }
                    _prevFrame = _currentFrame; // store prev frame
                    _currentFrame = GetLoopRestartFrame(); // start animation over
                    return true; // play

                } else if(wrapMode == Sprite.WrapMode.PingPong) {
                    // Check for loop end
                    if(loopCount > 0) { // this is a finite loop
                        currentLoop++; // increment loop counter if not infinite
                        if(currentLoop >= loopCount) { // finished last loop
                            Finished(false); // done playing
                            return false; // don't play
                        }
                    }

                    _isPlayingForward = !_isPlayingForward; // toggle play direction
                    // Start on next frame in the proper direction
                    if(_isPlayingForward) { // now moving forward
                        _prevFrame = _currentFrame; // store prev frame
                        _currentFrame++;
                    } else { // now moving backwards
                        _prevFrame = _currentFrame; // store prev frame
                        _currentFrame--;
                    }
                    return true; // play
                } else
                    throw new System.Exception("Unsupported WrapMode!");
            }

            private void PlayFrame() {
                
                // Play the current frame

                // Frame rate syncing - reduce duration of next frame to make up for lost time, skip frames if necessary. Events WILL play regardless.
                float timeOverrun = frameTimer.overrunBuffer;
                if(timeOverrun > 0.0f) { 

                    // This will lead to a studder, but it seems okay - every other frame will play at the correct speed
                    // Also, first frame will ALWAYS play full length, even it should have been skipped. We could add prediction and cut off
                    // frames before they run too long, but this may not be accurate or noticeable anyway.
                    
                    // Play frames in succession until we have no more overrun left to make up for
                    float overallSpeed = parentSprite.playbackSpeed * _speed;

                    while(timeOverrun > 0.0f) { // frame was displayed too long because of framerate sync issues
                        float frameDuration = frames[_currentFrame].duration;
                        float finalFrameDuration = overallSpeed > 0.0f ? frameDuration / overallSpeed : frameDuration; // get frame duration adjusted by current overall speed (avoid /0)
                        //float finalFrameDuration = frameDuration;

                        // Skip frame
                        if(timeOverrun >= finalFrameDuration) { // overrun is too great, skip this frame

                            // Skip frames (just play them super quickly)
                            PlayFrameNow(true); // play the frame immediately - it will never be visible but it will play and its events will play
                            
                            if(timeOverrun == finalFrameDuration) timeOverrun = 0.0f;
                            else timeOverrun -= finalFrameDuration;

                            if(!NextFrame()) { // advance to the next frame
                                parentSprite.DisplayFrame(frames[_currentFrame], false); // always play the last frame to avoid problems when mode is set to clamp, but don't play events again
                                return; // the animation finished while we were skipping frames, we're done
                            }

                        } else { // don't skip this frame, just shorten it
                            
                            frameTimer.overrunBuffer = timeOverrun; // store remaining overrun back in timer
                            break;
                        }
                    }
                }

                // Play the current frame
                PlayFrameNow(false);
            }

            private void PlayFrameNow(bool isSkipFrame) {

                Frame frame = frames[_currentFrame];

                // Start frame display timer
                frameTimer.Start(frame.duration); // start the timer

                // Send the update to sprite for display
                parentSprite.DisplayFrame(frame, isSkipFrame);

                // Report frame events
                if(hasFrameEvents) {
                    if(_prevFrame >= 0) {
                        Frame prevFrame = frames[_prevFrame];
                        if(prevFrame.hasEvent) parentSprite.ReportFrameEndEvent(new FrameEvent(animationId, name, _prevFrame, prevFrame.eventString)); // previous frame ended when this frame started, send event
                    }
                    if(frame.hasEvent) parentSprite.ReportFrameStartEvent(new FrameEvent(animationId, name, _currentFrame, frame.eventString)); // send event that this frame started playing
                }
            }

            public void Finished(bool interrupted) { // always run when an animation finishes or is interrupted by playing someting else
                _isPlaying = false;
                frameTimer.Clear();
                _prevFrame = -1;
                
                // Send frame end event
                if(hasFrameEvents) {
                    Frame frame = frames[_currentFrame];
                    if(frame.hasEvent) {
                        parentSprite.ReportFrameEndEvent(new FrameEvent(animationId, name, _currentFrame, frame.eventString)); // this frame ended when animation finished or was interrupted, send end event
                    }
                }

                // Invoke callbacks
                if(!interrupted && callback_animFinished != null) callback_animFinished(); // send animation completed callback
                if(callback_animEnded != null) callback_animEnded(); // send animation ended callback
            }

            private void ResetLoopVars() {
                _isPlayingForward = !playBackwards; ; // reset play direction
                currentLoop = 0; // reset loop counter
            }

            private void UserAction() {
                ResetLoopVars(); // make sure loop is restarted
                frameTimer.Clear(); // make sure no timer overrun is left over
            }

            public void Rewind() {
                if(_isPlaying) { // animation is currently playing - replay the animation from beginning
                    Finished(true); // make sure frame end events are sent
                    Play(_playBackwards); // restart the animation
                } else { // animation was stopped - just rewind to frame 0 and don't play
                    UserAction();
                    Finished(true); // make sure frame end events are sent
                    _currentFrame = 0; // reset to frame 0
                    PlayFrame(); // play the frame
                }
            }

            public void SetStartedCallback(System.Action callback) {
                callback_animStarted = callback;
            }

            public void SetFinishedCallback(System.Action callback) {
                callback_animFinished = callback;
            }

            public void SetEndedCallback(System.Action callback) {
                callback_animEnded = callback;
            }

            private int GetLoopRestartFrame() {
                if(frameCount == 0) return 0;
                if(playBackwards && loopRestartFrame == 0) return frameCount - 1; // get the last frame instead of the first if playing backwards and is a perfect loop
                // This will not handle loop restarts that are not at the beginning. That requires another animation.
                return loopRestartFrame;
            }

            #endregion

            #region Utilities

            protected void CopyDataVars(Animation source, Animation destination) {
                base.CopyDataVars((Animation_Base)source, (Animation_Base)destination); // copy vars from base
                
                // Copy SpriteFrames
                Sprite.Frame[] sourceFrames = source.frames;
                if(sourceFrames != null) {
                    int count = sourceFrames.Length;
                    Sprite.Frame[] newFrames = new Frame[count];
                    for(int i = 0; i < count; i++) {
                        newFrames[i] = sourceFrames[i].DeepCopy();
                    }
                    destination.frames = newFrames;
                } else
                    destination.frames = null;

                // Values
                destination.frameCount = source.frameCount;
            }

            public Sprite.Animation DeepCopy() {
                return new Sprite.Animation(this);
            }

            public void SetFrames(Sprite.Frame[] frames) {
                this.frames = frames;
                // calculate frame count
                if(frames == null) frameCount = 0;
                else frameCount = frames.Length;

                // Validate loop restart frame when setting new frames
                if(loopRestartFrame < 0 || loopRestartFrame >= frameCount)
                    loopRestartFrame = 0;
            }

            #endregion
        }

        #endregion

        #region // Frame

        [System.Serializable]
        public abstract class Frame_Base {
            // Public vars
            public int atlasIndex = -1; // index of atlas in main sprite data
            public ColliderFrame[] colliderFrames;
            public LocatorFrame[] locatorFrames;
            public string eventString = "";
            public bool hasEvent;
            public int pixelWidth; // non-padded, trimmed pixel width (final pixel width of actual displayed sprite, except if restarget scaled! Does not include that.)
            public int pixelHeight;
            public Rect uvCoords;
            public Vector2 frameOffset; // frame offset
            public Vector2 meshExtents;
            
            // Private vars
            [SerializeField]
            private int _frameRate; // cached from parent
            [SerializeField]
            private int _frameHold = 1;
            [SerializeField]
            private float _duration;

            // Properties
            public int frameRate {
                get { return _frameRate; }
                set {
                    if(value < 1) value = 1; // clamp value
                    _frameRate = value;
                    CalculateDuration();
                }
            } // updated by SpriteAnimation when frameRate is changed
            public int frameHold {
                get { return _frameHold; }
                set {
                    if(value < 1) value = 1; // clamp value
                    else if(value > 1000) value = 1000;
                    _frameHold = value;
                    CalculateDuration();
                }
            }
            public float duration { get { return _duration; } }

            public Frame_Base() { }

            protected void CalculateDuration() {
                _duration = (float)_frameHold / (float)_frameRate;
            }

            protected void CopyDataVars(Frame_Base source, Frame_Base destination) {
                // Objects
                destination.uvCoords = source.uvCoords; // struct so just copy
                destination.frameOffset = source.frameOffset; // struct so just copy
                destination.meshExtents = source.meshExtents; // struct so just copy

                // Collider Frames
                ColliderFrame[] sourceColliderFrames = source.colliderFrames;
                if(sourceColliderFrames != null) {
                    int colliderFrameCount = sourceColliderFrames.Length;
                    ColliderFrame[] destColliderFrames = new ColliderFrame[colliderFrameCount];
                    for(int i = 0; i < colliderFrameCount; i++) {
                        destColliderFrames[i] = sourceColliderFrames[i].DeepCopy();
                    }
                    destination.colliderFrames = destColliderFrames;
                } else
                    destination.colliderFrames = null;

                // Locator Frames
                LocatorFrame[] sourceLocatorFrames = source.locatorFrames;
                if(sourceLocatorFrames != null) {
                    int locatorFrameCount = sourceLocatorFrames.Length;
                    LocatorFrame[] destLocatorFrames = new LocatorFrame[locatorFrameCount];
                    for(int i = 0; i < locatorFrameCount; i++) {
                        destLocatorFrames[i] = sourceLocatorFrames[i].DeepCopy();
                    }
                    destination.locatorFrames = destLocatorFrames;
                } else
                    destination.locatorFrames = null;

                // Values
                destination.atlasIndex = source.atlasIndex;
                destination.pixelWidth = source.pixelWidth;
                destination.pixelHeight = source.pixelHeight;
                destination._frameRate = source._frameRate;
                destination._frameHold = source._frameHold;
                destination._duration = source._duration;
                destination.eventString = source.eventString;
                destination.hasEvent = source.hasEvent;
            }
        }

        [System.Serializable]
        public class Frame : Frame_Base {

            public bool useCustomMesh;
            public int meshFrameIndex = -1;

            // Properties
            public Frame() { }
            public Frame(int frameRate) {
                this.frameRate = frameRate;
            }

            public Frame(Sprite.Frame spriteFrame) { // clone frame
                CopyDataVars(spriteFrame, this); // copy the variables from incoming to self
            }

            #region Utilities

            protected void CopyDataVars(Frame source, Frame destination) {
                base.CopyDataVars((Frame_Base)source, (Frame_Base)destination); // copy vars from base

                // Copy variables from this class
                destination.useCustomMesh = source.useCustomMesh;
                destination.meshFrameIndex = source.meshFrameIndex;
            }

            public Frame DeepCopy() {
                return new Sprite.Frame(this);
            }

            #endregion
        }

        #endregion

        #region // Atlas

        [System.Serializable]
        public abstract class Atlas_Base {
            public int width;
            public int height;
            public bool trim;
            public int padding;

            public Atlas_Base() { }

            #region Utilities

            protected void CopyDataVars(Atlas_Base source, Atlas_Base destination) {
                destination.width = source.width;
                destination.height = source.height;
                destination.trim = source.trim;
                destination.padding = source.padding;
              }

            #endregion
        }

        [System.Serializable]
        public class Atlas : Atlas_Base{
            public Texture2D textureMap; // the main sprite atlas textMOure file
            public Material[] materials; // material for this atlas

            public Atlas() { }

            public Atlas(Atlas atlas) {
                CopyDataVars(atlas, this);
            }

            #region Utilities

            public Atlas DeepCopy() {
                return new Atlas(this);
            }

            protected void CopyDataVars(Atlas source, Atlas destination) {
                base.CopyDataVars(source, destination);

                destination.textureMap = source.textureMap;
                if(source.materials != null) destination.materials = (Material[])source.materials.Clone();
                else destination.materials = null;
            }

            #endregion
        }

        #endregion

        #region // MaterialSet

        [System.Serializable]
        public class MaterialSet {

            public string name = "";

            public MaterialSet() { }

            public MaterialSet(string setName) {
                name = setName;
            }

            #region // Utilities

            protected void CopyDataVars(MaterialSet source, MaterialSet destination) {
                // Copy vars from this class
                destination.name = source.name;
            }

            public MaterialSet DeepCopy() {
                return new MaterialSet(name);
            }

            #endregion
        }

        #endregion

        #region // Colliders

        [System.Serializable]
        public class ColliderSet {

            // Storage
            public Sprite.ColliderFrame staticColliderFrame; // static colliders store their frame data here, not in the sprite frame

            // Data vars
            public string name = "";
            public string tag = "";
            public int groupId = -1;
            public Color previewColor;
            public int layer = -1;
            public bool inheritLayer = true;
            public bool isParent;
            public bool is2D;

            // Collider vars
            public ColliderType colliderType;
            public bool isAnimated = true;
            public bool enableInNewFrames;
            public float sizeZ = 1.0f;
            public float centerZ; // start centered, +/- amount to align how they like
            public bool isTrigger;
            public PhysicMaterial material;
            public Object material2D;

            // Rigidbody vars
            public bool hasRigidbody;
            public float mass = 1.0f;
            public float drag = 0.0f;
            public float angularDrag = 0.05f;
            public bool useGravity = false;
            public bool isKinematic;
            public RigidbodyInterpolation interpolation;
            public CollisionDetectionMode collisionDetectionMode;
            public RigidbodyConstraints constraints;

            // Rigidbody 2D vars
            public float mass2D = 1.0f;
            public float linearDrag2D = 0.0f;
            public float angularDrag2D = 0.05f;
            public float gravityScale = 0;
            public bool fixedAngle = true;
            public int interpolation2D;
            public int sleepMode2D;
            public int collisionDetectionMode2D;

            // Properties
            public bool constraintPosX {
                get {
                    if((constraints & RigidbodyConstraints.FreezePositionX) == RigidbodyConstraints.FreezePositionX) return true;
                    return false;
                }
                set {
                    if(value) constraints |= RigidbodyConstraints.FreezePositionX;
                    else constraints &= ~RigidbodyConstraints.FreezePositionX;
                }
            }
            public bool constraintPosY {
                get {
                    if((constraints & RigidbodyConstraints.FreezePositionY) == RigidbodyConstraints.FreezePositionY) return true;
                    return false;
                }
                set {
                    if(value) constraints |= RigidbodyConstraints.FreezePositionY;
                    else constraints &= ~RigidbodyConstraints.FreezePositionY;
                }
            }
            public bool constraintPosZ {
                get {
                    if((constraints & RigidbodyConstraints.FreezePositionZ) == RigidbodyConstraints.FreezePositionZ) return true;
                    return false;
                }
                set {
                    if(value) constraints |= RigidbodyConstraints.FreezePositionZ;
                    else constraints &= ~RigidbodyConstraints.FreezePositionZ;
                }
            }
            public bool constraintRotX {
                get {
                    if((constraints & RigidbodyConstraints.FreezeRotationX) == RigidbodyConstraints.FreezeRotationX) return true;
                    return false;
                }
                set {
                    if(value) constraints |= RigidbodyConstraints.FreezeRotationX;
                    else constraints &= ~RigidbodyConstraints.FreezeRotationX;
                }
            }
            public bool constraintRotY {
                get {
                    if((constraints & RigidbodyConstraints.FreezeRotationY) == RigidbodyConstraints.FreezeRotationY) return true;
                    return false;
                }
                set {
                    if(value) constraints |= RigidbodyConstraints.FreezeRotationY;
                    else constraints &= ~RigidbodyConstraints.FreezeRotationY;
                }
            }
            public bool constraintRotZ {
                get {
                    if((constraints & RigidbodyConstraints.FreezeRotationZ) == RigidbodyConstraints.FreezeRotationZ) return true;
                    return false;
                }
                set {
                    if(value) constraints |= RigidbodyConstraints.FreezeRotationZ;
                    else constraints &= ~RigidbodyConstraints.FreezeRotationZ;
                }
            }


            public ColliderSet(bool is2D, string inName) {
                this.is2D = is2D;
                name = inName;
                AutoUpdateColliderType();
            }

            public ColliderSet(ColliderSet colliderSet) { // clone
                CopyDataVars(colliderSet, this); // copy vars from incoming set
            }

            public void ChangeColliderMode(bool is2D) {
                if(is2D && !SpriteFactory.Utils.UnityTools.supports2DColliders) return;
                ChangeColliderMode_U43(is2D); // wrap the function so it is never even entered in versions lower so we don't have to use reflection
            }

            private void ChangeColliderMode_U43(bool is2D) {
                this.is2D = is2D;

                if(is2D) { // converting to a 2D collider

                    AutoUpdateColliderType();

                    // copy certain 3D vars to 2D versions

                    // convert rigidbody vars to rigidbody2d vars
                    if(hasRigidbody) {
                        
                        // convert values
                        mass2D = Mathf.Clamp(mass, 0.0001f, 1000000.0f);
                        linearDrag2D = Mathf.Clamp(drag, 0.0f, 1000000.0f);
                        angularDrag2D = Mathf.Clamp(angularDrag, 0.0f, 1000000.0f);

                        // convert enums
                        try {
                            // Interpolation
                            RigidbodyInterpolation2D interpolation2DTemp;
                            if(!SpriteFactory.Utils.EnumTools.ConvertByName<RigidbodyInterpolation, RigidbodyInterpolation2D>(interpolation, out interpolation2DTemp)) { // failed to find an equivalent name 
                                Debug.LogWarning("No equivalent 2D rigidbody interpolation mode found for RigidbodyInterpolation." + interpolation.ToString() + ". Interpolation mode will be set to " + default(RigidbodyInterpolation2D).ToString());
                            }
                            interpolation2D = (int)interpolation2DTemp; // store as an int

                            // Collision detection mode
                            CollisionDetectionMode2D collisionDetectionMode2DTemp;
                            if(!SpriteFactory.Utils.EnumTools.ConvertByName<CollisionDetectionMode, CollisionDetectionMode2D>(collisionDetectionMode, out collisionDetectionMode2DTemp)) { // failed to find an equivalent name 
                                Debug.LogWarning("No equivalent 2D rigidbody collision detection mode found for CollisionDetectionMode." + collisionDetectionMode.ToString() + ". CollisionDetectionMode will be set to " + default(CollisionDetectionMode2D).ToString());
                            }
                            collisionDetectionMode2D = (int)collisionDetectionMode2DTemp; // store as an int

                        } catch { // class was not found or it is not an enum
                            throw new System.Exception("Error! 2D Colliders are only compatible with Unity 4.3+!");
                        }

                        
                    }

                    // Clear some vars that may have been leftover
                    material = null;
                
                } else { // converting to a 3D collider

                    AutoUpdateColliderType();

                    // copy certain 2D vars to 3D versions
                    
                    // convert rigidbody2D vars to rigidbody
                    if(hasRigidbody) {

                        // convert values
                        mass = mass2D;
                        drag = linearDrag2D;
                        angularDrag = angularDrag2D;

                        // convert enums
                        try {
                            // Interpolation
                            if(!SpriteFactory.Utils.EnumTools.ConvertByName<RigidbodyInterpolation2D, RigidbodyInterpolation>((RigidbodyInterpolation2D)interpolation2D, out interpolation)) { // failed to find an equivalent name 
                                Debug.LogWarning("No equivalent 3D rigidbody interpolation mode found for RigidbodyInterpolation2D." + ((RigidbodyInterpolation2D)interpolation2D).ToString() + ". Interpolation mode will be set to " + default(RigidbodyInterpolation).ToString());
                            }

                            // Collision detection mode
                            if(!SpriteFactory.Utils.EnumTools.ConvertByName<CollisionDetectionMode2D, CollisionDetectionMode>((CollisionDetectionMode2D)collisionDetectionMode2D, out collisionDetectionMode)) { // failed to find an equivalent name 
                                Debug.LogWarning("No equivalent 3D rigidbody collision detection mode found for CollisionDetectionMode2D." + ((CollisionDetectionMode2D)collisionDetectionMode2D).ToString() + ". CollisionDetectionMode will be set to " + default(CollisionDetectionMode).ToString());
                            }

                        } catch { // class was not found or it is not an enum
                            throw new System.Exception("Error! 2D Colliders are only compatible with Unity 4.3+!");
                        }

                    }

                    // Clear some vars that may have been leftover
                    material2D = null;
                }
            }

            private void AutoUpdateColliderType() {
                // Always make collider type box
                if(is2D) {
                    colliderType = ColliderType.Box2D;
                } else {
                    colliderType = ColliderType.Box;
                }
            }

            public bool UpgradeCheck() {
                bool changed = false;
                if(staticColliderFrame != null) {
                    if(staticColliderFrame.UpgradeCheck()) changed = true;
                }
                return changed;
            }

            public delegate bool ValidateColliderGroupId(int id);
            public bool VerifyData(ValidateColliderGroupId isValidColliderGroupId) {
                bool changed = false;
                
                // Collider group selection
                if(groupId >= 0 && !isValidColliderGroupId(groupId)) { // not a valid group id
                    groupId = -1; // clear
                    changed = true;
                }

                // Rigidbody2D mass
                if(mass2D < 0.0001f) {
                    mass2D = 0.0001f; // clamp minimum mass
                    changed = true;
                }

                return changed;
            }

            #region // Utilities

            private void CopyDataVars(ColliderSet source, ColliderSet destination) {
                // storage
                if(source.staticColliderFrame != null) destination.staticColliderFrame = source.staticColliderFrame.DeepCopy();
                else destination.staticColliderFrame = null;

                // data vars
                destination.name = source.name;
                destination.tag = source.tag;
                destination.groupId = source.groupId;
                destination.previewColor = source.previewColor;
                destination.layer = source.layer;
                destination.inheritLayer = source.inheritLayer;
                destination.isParent = source.isParent;
                destination.is2D = source.is2D;

                // collider vars
                destination.colliderType = source.colliderType;
                destination.isAnimated = source.isAnimated;
                destination.enableInNewFrames = source.enableInNewFrames;
                destination.sizeZ = source.sizeZ;
                destination.centerZ = source.centerZ;
                destination.isTrigger = source.isTrigger;
                destination.material = source.material;
                destination.material2D = source.material2D;

                // rigidbody vars
                destination.hasRigidbody = source.hasRigidbody;
                destination.mass = source.mass;
                destination.drag = source.drag;
                destination.angularDrag = source.angularDrag;
                destination.useGravity = source.useGravity;
                destination.isKinematic = source.isKinematic;
                destination.interpolation = source.interpolation;
                destination.collisionDetectionMode = source.collisionDetectionMode;
                destination.constraints = source.constraints;

                // rigidbody2d vars
                destination.mass2D = source.mass2D;
                destination.linearDrag2D = source.linearDrag2D;
                destination.angularDrag2D = source.angularDrag2D;
                destination.gravityScale = source.gravityScale;
                destination.fixedAngle = source.fixedAngle;
                destination.interpolation2D = source.interpolation2D;
                destination.sleepMode2D = source.sleepMode2D;
                destination.collisionDetectionMode2D = source.collisionDetectionMode2D;
            }

            public ColliderSet DeepCopy() {
                return new ColliderSet(this);
            }

            public void ExportToRigidbody(Component rigidbodyComponent) {
                // Export to 2D rigidbody - Unity 4.3+ only
                if(is2D) {
                    Utils.UnityTools.FailIfNo2DSupport();
                    ExportToRigidbody2D(rigidbodyComponent);
                    return;
                }

                // Export to 3D rigidbody
                ExportToRigidbody3D((Rigidbody)rigidbodyComponent);
            }

            public void ExportToRigidbody3D(Rigidbody rigidbody) {
                rigidbody.mass = mass;
                rigidbody.drag = drag;
                rigidbody.angularDrag = angularDrag;
                rigidbody.useGravity = useGravity;
                rigidbody.isKinematic = isKinematic;
                rigidbody.interpolation = interpolation;
                rigidbody.collisionDetectionMode = collisionDetectionMode;
                rigidbody.constraints = constraints;
            }

            public void ExportToRigidbody2D(Component rigidbody2DComponent) {
                Rigidbody2D rigidbody2D = (Rigidbody2D)rigidbody2DComponent;
                rigidbody2D.mass = mass;
                rigidbody2D.drag = drag;
                rigidbody2D.angularDrag = angularDrag;
                rigidbody2D.isKinematic = isKinematic;

                rigidbody2D.fixedAngle = fixedAngle;
                rigidbody2D.gravityScale = gravityScale;
                rigidbody2D.interpolation = (RigidbodyInterpolation2D)interpolation2D;
                rigidbody2D.collisionDetectionMode = (UnityEngine.CollisionDetectionMode2D)collisionDetectionMode2D;
                rigidbody2D.sleepMode = (RigidbodySleepMode2D)sleepMode2D;
            }

            public void ExportToCollider(Component colliderComponent) {
                // Export to 2D collider - Unity 4.3+ only
                if(is2D) {
                    Utils.UnityTools.FailIfNo2DSupport();
                    ExportToCollider2D(colliderComponent);
                    return;
                }
                
                // Export to 3D collider
                ExportToCollider3D(colliderComponent);
            }

            private void ExportToCollider3D(Component colliderComponent) {
                if(colliderType == ColliderType.Box) {
                    ExportToBoxCollider((BoxCollider)colliderComponent);
                    return;
                }

                throw new System.Exception("Unknown or unsupported Collider type: " + colliderType.ToString());
            }

            private void ExportToCollider2D(Component collider2DComponent) {
                if(colliderType == ColliderType.Box2D) {
                    BoxCollider2D collider = (BoxCollider2D)collider2DComponent;
                    collider.isTrigger = isTrigger;
                    if(material2D != null) collider.sharedMaterial = (PhysicsMaterial2D)material2D;
                    // center and size are handled by colliderFrame
                    return;
                }

                throw new System.Exception("Unknown or unsupported Collider2D type: " + colliderType.ToString());
            }

            public void ExportToBoxCollider(BoxCollider boxCollider) {
                boxCollider.isTrigger = isTrigger;
                boxCollider.material = material;
                // center and size are handled by colliderFrame
            }

            #endregion

        }

        [System.Serializable]
        public class ColliderFrame {
            public bool enabled;
            public Vector2 size2D;
            public Vector2 center2D;
            public float rotation; // rotation on Z axis

            // final calculated data on save -- this is calculated from rect, depth, and depth offset
            public Vector3 center;
            public Vector3 size;

            // old -- kept for backwards compatibility
            public SpriteFactory.Utils.DataClasses.IntVector2 startPosition;
            public SpriteFactory.Utils.DataClasses.IntVector2 endPosition;

            public ColliderFrame() {
                center2D = new Vector2();
                size2D = new Vector2(40.0f, 40.0f);
            }

            public ColliderFrame(ColliderFrame colliderFrame) { // clone
                CopyDataVars(colliderFrame, this); // copy data into self
            }

            public void CalculateFinalVars(int pixelsPerUnit, ColliderSet colliderSet) {
                float fPixelsPerUnit = (float)pixelsPerUnit;
                float centerX = center2D.x / fPixelsPerUnit;
                float centerY = center2D.y / fPixelsPerUnit;
                float centerZ = colliderSet.centerZ; // stored as units not pixels
                float sizeX = size2D.x / fPixelsPerUnit;
                float sizeY = size2D.y / fPixelsPerUnit;
                float sizeZ = colliderSet.sizeZ;
                center = new Vector3(centerX, centerY, centerZ);
                size = new Vector3(sizeX, sizeY, sizeZ);
            }

            public bool UpgradeCheck() {
                bool changed = false;

                if(startPosition != null && endPosition != null) {
                    if(startPosition.x != 0 || startPosition.y != 0 || endPosition.x != 0 || endPosition.y != 0) { // we have old data, convert

                        //Debug.Log("Converting old collider animation data to new format!");
                        size2D.x = Mathf.Abs(endPosition.x - startPosition.x);
                        size2D.y = Mathf.Abs(endPosition.y - startPosition.y);
                        center2D.x = (float)(startPosition.x + endPosition.x) * 0.5f;
                        center2D.y = (float)(startPosition.y + endPosition.y) * 0.5f;
                        
                        // Clear old data
                        startPosition.x = 0;
                        startPosition.y = 0;
                        endPosition.x = 0;
                        endPosition.y = 0;

                        changed = true;
                    }
                }

                return changed;
            }

            #region // Utilities

            private void CopyDataVars(ColliderFrame source, ColliderFrame destination) {
                destination.enabled = source.enabled;
                destination.size2D = source.size2D;
                destination.center2D = source.center2D;
                destination.rotation = source.rotation;
                destination.center = source.center;
                destination.size = source.size;

                // old
                destination.startPosition = source.startPosition != null ? source.startPosition.Clone() : null;
                destination.endPosition = source.endPosition != null ? source.endPosition.Clone() : null;
            }

            public ColliderFrame DeepCopy() {
                return new ColliderFrame(this);
            }

            #endregion
        }

        [System.Serializable]
        public class ColliderGroup {

            public int id;
            public string name;
            //public bool useGroupCollisions;

            public ColliderGroup(string name, int id) {
                this.name = name;
                this.id = id;
            }
            
            public ColliderGroup(ColliderGroup colliderGroup, int id) { // clone
                CopyDataVars(colliderGroup, this); // copy data into self
                this.id = id;
            }

            #region // Utilities

            private void CopyDataVars(ColliderGroup source, ColliderGroup destination) {
                
                destination.name = source.name;
                //destination.useGroupCollisions = source.useGroupCollisions;
            }

            public ColliderGroup DeepCopy(int id) {
                return new ColliderGroup(this, id);
            }

            #endregion
        }
        
        #endregion

        #region // Locators

        [System.Serializable]
        public class LocatorSet {
            public string name = "";
            public Color previewColor;
            public bool defaultToPosXIsForward = true;
            public float defaultOffsetZ;

            public LocatorSet(string inName) {
                name = inName;
            }

            public LocatorSet(LocatorSet locator) { // clone
                CopyDataVars(locator, this); // copy vars from incoming set
            }

            #region // Utilities

            private void CopyDataVars(LocatorSet source, LocatorSet destination) {
                destination.name = source.name;
                destination.previewColor = source.previewColor;
                destination.defaultToPosXIsForward = source.defaultToPosXIsForward;
                destination.defaultOffsetZ = source.defaultOffsetZ;
            }

            public LocatorSet DeepCopy() {
                return new LocatorSet(this);
            }

            #endregion
        }

        [System.Serializable]
        public class LocatorFrame {
            public bool enabled;
            public SpriteFactory.Utils.DataClasses.IntVector2 pixelPosition;
            public float offsetZ;
            public float facing;
            public bool flipForwardVector;
            public string eventString = "";

            // final calculated data on save
            public Vector3 unitPosition;
            public Quaternion unitRotation;
            public float unitOffsetZ;


            public LocatorFrame() {
                pixelPosition = new SpriteFactory.Utils.DataClasses.IntVector2();
            }

            public LocatorFrame(LocatorFrame locatorFrame) { // clone
                CopyDataVars(locatorFrame, this); // copy data into self
            }


            public void CalculateFinalVars(int pixelsPerUnit) {
                float fPixelsPerUnit = (float)pixelsPerUnit;
                unitPosition = pixelPosition / fPixelsPerUnit;
                float yRot;
                if(flipForwardVector) {
                    yRot = 180.0f;
                } else {
                    yRot = 0.0f;
                }
                unitOffsetZ = offsetZ;
                unitPosition.z = unitOffsetZ;
                unitRotation = Quaternion.Euler(new Vector3(0.0f, yRot, facing));
            }

            #region // Utilities

            private void CopyDataVars(LocatorFrame source, LocatorFrame destination) {
                destination.enabled = source.enabled;
                destination.pixelPosition = source.pixelPosition.Clone();
                destination.offsetZ = source.offsetZ;
                destination.facing = source.facing;
                destination.flipForwardVector = source.flipForwardVector;
                destination.eventString = source.eventString;
                destination.unitPosition = source.unitPosition;
                destination.unitRotation = source.unitRotation;
            }

            public LocatorFrame DeepCopy() {
                return new LocatorFrame(this);
            }

            #endregion
        }

        [System.Serializable]
        public class Locator {

            // Variables
            [HideInInspector, SerializeField]
            private Sprite _parent;
            [HideInInspector, SerializeField]
            private string _name = "";
            [HideInInspector, SerializeField]
            private GameObject _gameObject;
            [HideInInspector, SerializeField]
            private Transform _transform;
            [HideInInspector, SerializeField]
            private SpriteLocator _spriteLocator;
            [HideInInspector, SerializeField]
            private List<Child> _children = null;

            // Properties
            public string name {
                get {
                    return _name;
                }
            }
            public bool active {
                get {
                    if(_gameObject == null) return false;
                    return SpriteFactory.Utils.UnityTools.IsActiveInHierarchy(_gameObject);
                }
            }
            public GameObject gameObject { get { return _gameObject; } }
            public Transform transform { get { return _transform; } }

            #region // Transform Wrappers

            // Transform property wrappers
            public Vector3 eulerAngles {
                get {
                    return _transform.eulerAngles;
                }
                set {
                    _transform.eulerAngles = value;
                }
            }
            public Vector3 localEulerAngles {
                get {
                    return _transform.localEulerAngles;
                }
                set {
                    _transform.localEulerAngles = value;
                }
            }
            public Vector3 right {
                get {
                    return _transform.right;
                }
            }
            public Vector3 up {
                get {
                    return _transform.up;
                }
            }
            public Vector3 forward {
                get {
                    return _transform.forward;
                }
            }
            public Matrix4x4 worldToLocalMatrix {
                get {
                    return _transform.worldToLocalMatrix;
                }
            }
            public Matrix4x4 localToWorldMatrix {
                get {
                    return _transform.localToWorldMatrix;
                }
            }
            public Vector3 localPosition {
                get {
                    return _transform.localPosition;
                }
                set {
                    _transform.localPosition = value;
                }
            }
            public Quaternion localRotation {
                get {
                    return _transform.localRotation;
                }
                set {
                    _transform.localRotation = value;
                }
            }
            public Vector3 localScale {
                get {
                    return _transform.localScale;
                }
                set {
                    _transform.localScale = value;
                }
            }
            public Vector3 position {
                get {
                    return _transform.position;
                }
                set {
                    _transform.position = value;
                }
            }
            public Quaternion rotation {
                get {
                    return _transform.rotation;
                }
                set {
                    _transform.rotation = value;
                }
            }
            public Vector3 lossyScale {
                get {
                    return _transform.lossyScale;
                }
            }

            // Transform method wrappers (only the useful ones)
            public Vector3 TransformDirection(Vector3 direction) {
                return _transform.TransformDirection(direction);
            }
            public Vector3 TransformDirection(float x, float y, float z) {
                return _transform.TransformDirection(x, y, z);
            }
            public Vector3 InverseTransformDirection(Vector3 direction) {
                return _transform.InverseTransformDirection(direction);
            }
            public Vector3 InverseTransformDirection(float x, float y, float z) {
                return _transform.InverseTransformDirection(x, y, z);
            }
            public Vector3 TransformPoint(Vector3 position) {
                return _transform.TransformPoint(position);
            }
            public Vector3 TransformPoint(float x, float y, float z) {
                return _transform.TransformPoint(x, y, z);
            }
            public Vector3 InverseTransformPoint(Vector3 position) {
                return _transform.InverseTransformPoint(position);
            }
            public Vector3 InverseTransformPoint(float x, float y, float z) {
                return _transform.InverseTransformPoint(x, y, z);
            }
            public void DetachChildren() {
                _transform.DetachChildren();
                _children.Clear();
            }

            #endregion


            public Locator(Sprite parent, string name, GameObject gameObject, Transform transform, SpriteLocator spriteLocator) {
                _parent = parent;
                _name = name;
                _gameObject = gameObject;
                _transform = transform;
                _spriteLocator = spriteLocator;
            }

            public int AttachChild(GameObject child, bool resetPosition = true, bool resetRotation = true, bool resetScale = true) {
                if(child == null) return -1;
                return AttachChild(child.transform, resetPosition, resetRotation, resetScale);
            }

            public int AttachChild(Transform child, bool resetPosition = true, bool resetRotation = true, bool resetScale = true) {
                if(_transform == null) return -1; // transform is missing
                if(child == null) return -1;
                if(ContainsChild(child)) return -1; // already a child

                Vector3 origScale = child.localScale; // store original scale
                child.parent = _transform; // make locator the parent
                if(resetPosition) child.localPosition = new Vector3(0.0f, 0.0f, 0.0f);
                if(resetRotation) child.localRotation = Quaternion.identity;

                // Scale child
                if(_parent.useBatchScaling) { // sprite uses batch scaling
                    Vector3 scale;
                    if(resetScale) scale = origScale;
                    else scale = child.localScale;
                    child.localScale = Vector3.Scale(scale, _parent._batchScale); // scale transform to match batch scale of parent sprite

                } else { // normal scaling
                    if(resetScale) child.localScale = origScale;
                }

                if(_children == null) _children = new System.Collections.Generic.List<Child>(1); // initialize the children list if first one
                Child newChild = new Child(child); // create the new child object
                _children.Add(newChild); // add the child to the list
                GameObject newChildGO = newChild.gameObject; // get the child's game object

                // Make sure new child's active state matches the locator's
                bool activeState = SpriteFactory.Utils.UnityTools.IsActiveInHierarchy(_gameObject);
                if(_parent.activateLocatorsRecursively) { // recursive activation
                    SpriteFactory.Utils.UnityTools.SetActiveRecursively(newChildGO, activeState); // set enabled state in child recursively
                } else { // non-recursive activation
                    if(SpriteFactory.Utils.UnityTools.IsActiveInHierarchy(newChildGO) != activeState) { // child is in the wrong state
                        SpriteFactory.Utils.UnityTools.SetActive(newChildGO, activeState);
                    }
                }

                return _children.Count - 1; // return the index of the new child
            }

            public void DetachChild(Transform child) {
                if(child == null) return;
                if(_children == null || _children.Count == 0) return;

                if(!RemoveChild(child)) return; // child was not in the list
                child.parent = null; // unparent the child
            }

            public void DetachChild(int index) {
                if(index < 0) return;
                if(_children == null) return;
                int childCount = _children.Count;
                if(index >= childCount) return;
                Child child = _children[index];
                if(child != null && child.transform != null) child.transform.parent = null; // unparent the child
                _children.RemoveAt(index); // remove child from list
            }

            public void ScaleChild(Transform child, Vector3 scale) { // for scaling a child, handles batch scaling if necessary
                if(child == null) return;
                if(_children == null || _children.Count == 0) return;
                int index = IndexOfChild(child);
                if(index == -1) return;

                Child c = _children[index];
                Transform xform = c.transform;
                if(xform == null) return;

                if(_parent.useBatchScaling) { // we are batch scaling
                    // update the transform scale of the child to account for batch scaling
                    c.originalScale = scale;
                    xform.localScale = Vector3.Scale(c.originalScale, _parent._batchScale); // scale the child
                    xform.localPosition = Vector3.Scale(c.originalPosition, _parent._batchScale); // scale the child's position
                } else {
                    xform.localScale = scale; // set scale directly
                }
            }

            public void ScaleChild(Transform child, Vector3 scale, Vector3 position) { // for scaling a child, handles batch scaling if necessary
                if(child == null) return;
                if(_children == null || _children.Count == 0) return;
                int index = IndexOfChild(child);
                if(index == -1) return;

                Child c = _children[index];
                Transform xform = c.transform;
                if(xform == null) return;

                if(_parent.useBatchScaling) { // we are batch scaling
                    // update the transform scale of the child to account for batch scaling
                    c.originalScale = scale;
                    c.originalPosition = position;
                    xform.localScale = Vector3.Scale(c.originalScale, _parent._batchScale); // scale the child
                    xform.localPosition = Vector3.Scale(c.originalPosition, _parent._batchScale); // scale the child's position
                } else {
                    xform.localScale = scale; // set scale directly
                }
            }

            public void ScaleChild(int index, Vector3 scale) {
                if(index < 0) return;
                if(_children == null) return;
                int childCount = _children.Count;
                if(index >= childCount) return;

                Child c = _children[index];
                Transform xform = c.transform;
                if(xform == null) return;

                if(_parent.useBatchScaling) { // we are batch scaling
                    // update the transform scale of the child to account for batch scaling
                    c.originalScale = scale;
                    xform.localScale = Vector3.Scale(c.originalScale, _parent._batchScale); // scale the child
                    xform.localPosition = Vector3.Scale(c.originalPosition, _parent._batchScale); // scale the child's position
                } else {
                    xform.localScale = scale; // set scale directly
                }
            }

            public void ScaleChild(int index, Vector3 scale, Vector3 position) {
                if(index < 0) return;
                if(_children == null) return;
                int childCount = _children.Count;
                if(index >= childCount) return;

                Child c = _children[index];
                Transform xform = c.transform;
                if(xform == null) return;

                if(_parent.useBatchScaling) { // we are batch scaling
                    // update the transform scale of the child to account for batch scaling
                    c.originalScale = scale;
                    c.originalPosition = position;
                    xform.localScale = Vector3.Scale(c.originalScale, _parent._batchScale); // scale the child
                    xform.localPosition = Vector3.Scale(c.originalPosition, _parent._batchScale); // scale the child's position
                } else {
                    xform.localScale = scale; // set scale directly
                }
            }

            public void SetActive(bool active, bool setActiveOnFirstLevelChildren = true) {
                if(_spriteLocator == null) return;

                // set active state on the locator itself
                _spriteLocator.SetActive(active);

                // activate/deactivate locator and first tier child objects (for old activation system)
                if(SpriteFactory.Utils.UnityTools.isSupportedVersion3) { // unity 3.5.0 - 3.5.7
                    if(setActiveOnFirstLevelChildren) { // using old system, set active on first level children
                        if(_children != null) {
                            int childCount = _children.Count;
                            for(int i = 0; i < childCount; i++) {
                                Child child = _children[i];
                                if(child.gameObject == null) continue;
                                SpriteFactory.Utils.UnityTools.SetActive(child.gameObject, active);
                            }
                        }
                    }
                }
            }

            public void SetActiveRecursively(bool state) {
                if(_gameObject == null) return;

                // _gameObject.SetActiveRecursively(active); // FAILS WITH BUG -- ignore collisions fail when called by OnEnable during a recursive activation!
                SpriteFactory.Utils.UnityTools.SetActiveRecursively(_gameObject, state, false); // substitute our version
            }

            public void BatchScaleChildren(Vector3 scale) {
                if(_children == null) return;
                int childCount = _children.Count;
                if(childCount == 0) return;

                for(int i = 0; i < childCount; i++) {
                    Child child = _children[i];
                    Transform xform = child.transform;
                    if(xform == null) continue;
                    xform.localScale = Vector3.Scale(child.originalScale, scale); // scale the child
                    xform.localPosition = Vector3.Scale(child.originalPosition, scale); // scale the child's position
                }
            }

            public void Refresh() { // store current original transform settings of children
                if(_children == null) return; // no children
                int childCount = _children.Count;
                if(childCount == 0) return; // no children

                for(int i = 0; i < childCount; i++) {
                    Child child = _children[i];
                    child.Refresh(); // update the transform settings
                }
            }

            private bool ContainsChild(Transform child) {
                if(child == null || _children == null) return false;
                int childCount = _children.Count;

                for(int i = 0; i < childCount; i++) {
                    Child c = _children[i];
                    if(c == null) continue;
                    if(c.transform == child) return true;
                }
                return false;
            }

            private int IndexOfChild(Transform child) {
                if(child == null || _children == null) return -1;
                int childCount = _children.Count;

                for(int i = 0; i < childCount; i++) {
                    Child c = _children[i];
                    if(c == null) continue;
                    if(c.transform == child) return i;
                }
                return -1;
            }

            private bool RemoveChild(Transform child) {
                if(child == null || _children == null) return false;
                int childCount = _children.Count;

                for(int i = 0; i < childCount; i++) {
                    Child c = _children[i];
                    if(c == null) continue;
                    if(c.transform == child) {
                        _children.RemoveAt(i);
                        return true;
                    }
                }
                return false;
            }

            // Private Classes //

            [System.Serializable]
            private class Child {

                public GameObject gameObject;
                public Transform transform;
                public Vector3 originalScale;
                public Vector3 originalPosition;

                public Child(Transform inTransform) {
                    transform = inTransform;
                    gameObject = transform.gameObject;
                    originalScale = transform.localScale;
                    originalPosition = transform.localPosition;
                }

                public void Refresh() {
                    if(transform == null) return;
                    originalScale = transform.localScale; // save the original scale
                    originalPosition = transform.localPosition; // save the original position
                }
            }
        }

        #endregion

        #region // Sprite Material

        [System.Serializable]
        public class SpriteMaterial {

            [SerializeField]
            private Sprite _sprite;
            [SerializeField]
            private Material[] _materials;
            internal Material[] materials { get { return _materials; } set { _materials = value; } }

            public bool isMaterialOverridden {
                get {
                    return _sprite.IsMaterialOverridden();
                }
            }

            public SpriteMaterial(Sprite sprite, int materialCount) {
                _sprite = sprite;
                _materials = new Material[materialCount];
            }

            // Private Methods

            private void PrepareForMaterialChange() {
                _sprite.PrepareForSpriteMaterialChange();
            }

            public void SetBuffer_U4(string propertyName, object buffer) {
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetBuffer(propertyName, (ComputeBuffer)buffer);
                }
            }

            // Public Properties

            // Shadows are not really part of the material
            /*public bool castShadows {
                get { return _sprite.castShadows; }
                set { _sprite.castShadows = value; }
            }
            public bool receiveShadows {
                get { return _sprite.receiveShadows; }
                set { _sprite.receiveShadows = value; }
            }*/

            // Public Methods

            public void Revert() {
                if(!isMaterialOverridden) return;
                _sprite.SpriteMaterial_Revert();
            }

            // Sprite Wrapper Methods

            public void SetMaterialOverride(Material material) {
                _sprite.SetMaterialOverride(material);
            }

            public void EnableMaterialOverride() {
                _sprite.EnableMaterialOverride();
            }

            public void DisableMaterialOverride() {
                _sprite.DisableMaterialOverride();
            }

            public void ChangeMaterialSet(string materialSetName) {
                _sprite.ChangeMaterialSet(materialSetName);
            }

            public void ChangeMaterialSet(int materialSetIndex) {
                _sprite.ChangeMaterialSet(materialSetIndex);
            }

            // Material Wrapper Methods

            public void CopyPropertiesFromMaterial(Material mat) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].CopyPropertiesFromMaterial(mat);
                }
            }
            public void DisableKeyword(string keyword) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].DisableKeyword(keyword);
                }
            }
            public void EnableKeyword(string keyword) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].EnableKeyword(keyword);
                }
            }
            public Color GetColor(string propertyName) {
                if(_materials[0] == null) return new Color();
                return _materials[0].GetColor(propertyName);
            }
            public Color GetColor(int nameID) {
                if(_materials[0] == null) return new Color();
                return _materials[0].GetColor(nameID);
            }
            public float GetFloat(string propertyName) {
                if(_materials[0] == null) return 0;
                return _materials[0].GetFloat(propertyName);
            }
            public float GetFloat(int nameID) {
                if(_materials[0] == null) return 0;
                return _materials[0].GetFloat(nameID);
            }
            public int GetInt(string propertyName) {
                if(_materials[0] == null) return 0;
                return _materials[0].GetInt(propertyName);
            }
            public int GetInt(int nameID) {
                if(_materials[0] == null) return 0;
                return _materials[0].GetInt(nameID);
            }
            public Matrix4x4 GetMatrix(string propertyName) {
                if(_materials[0] == null) return new Matrix4x4();
                return _materials[0].GetMatrix(propertyName);
            }
            public Matrix4x4 GetMatrix(int nameID) {
                if(_materials[0] == null) return new Matrix4x4();
                return _materials[0].GetMatrix(nameID);
            }
            public string GetTag(string tag, bool searchFallbacks, string defaultValue = "") {
                if(_materials[0] == null) return string.Empty;
                return _materials[0].GetTag(tag, searchFallbacks, defaultValue);
            }
            public Texture GetTexture(string propertyName) {
                if(_materials[0] == null) return null;
                return _materials[0].GetTexture(propertyName);
            }
            public Texture GetTexture(int nameID) {
                if(_materials[0] == null) return null;
                return _materials[0].GetTexture(nameID);
            }
            public Vector2 GetTextureOffset(string propertyName) {
                if(_materials[0] == null) return new Vector2();
                return _materials[0].GetTextureOffset(propertyName);
            }
            public Vector2 GetTextureScale(string propertyName) {
                if(_materials[0] == null) return new Vector2();
                return _materials[0].GetTextureScale(propertyName);
            }
            public Vector4 GetVector(string propertyName) {
                if(_materials[0] == null) return new Vector4();
                return _materials[0].GetVector(propertyName);
            }
            public Vector4 GetVector(int nameID) {
                if(_materials[0] == null) return new Vector4();
                return _materials[0].GetVector(nameID);
            }
            public bool HasProperty(string propertyName) {
                if(_materials[0] == null) return false;
                return _materials[0].HasProperty(propertyName);
            }
            public bool HasProperty(int nameID) {
                if(_materials[0] == null) return false;
                return _materials[0].HasProperty(nameID);
            }
            public void Lerp(Material start, Material end, float t) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].Lerp(start, end, t);
                }
            }

            // ComputeBuffer not supported until 4.0 and cannot expose it or will crash < 4.0, use object instead
            public void SetBuffer(string propertyName, object buffer) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                if(Utils.UnityTools.unityVersion < Utils.UnityTools.UnityVersion.UNITY_4_0) {
                    Debug.LogWarning("Unity version 4.0+ is required to use this feature.");
                    return;
                }
                SetBuffer_U4(propertyName, buffer);
            }

            public void SetColor(string propertyName, Color color) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetColor(propertyName, color);
                }
            }
            public void SetColor(int nameID, Color color) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetColor(nameID, color);
                }
            }
            public void SetFloat(string propertyName, float value) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetFloat(propertyName, value);
                }
            }
            public void SetFloat(int nameID, float value) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetFloat(nameID, value);
                }
            }
            public void SetInt(string propertyName, int value) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetInt(propertyName, value);
                }
            }
            public void SetInt(int nameID, int value) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetInt(nameID, value);
                }
            }
            public void SetMatrix(string propertyName, Matrix4x4 matrix) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetMatrix(propertyName, matrix);
                }
            }
            public void SetMatrix(int nameID, Matrix4x4 matrix) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetMatrix(nameID, matrix);
                }
            }
            /*public void SetPass() {

            }*/
            public void SetTexture(string propertyName, Texture texture) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetTexture(propertyName, texture);
                }
            }
            public void SetTexture(int nameID, Texture texture) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetTexture(nameID, texture);
                }
            }
            public void SetTextureOffset(string propertyName, Vector2 offset) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetTextureOffset(propertyName, offset);
                }
            }
            public void SetTextureScale(string propertyName, Vector2 scale) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetTextureScale(propertyName, scale);
                }
            }
            public void SetVector(string propertyName, Vector4 vector) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetVector(propertyName, vector);
                }
            }
            public void SetVector(int nameID, Vector4 vector) {
                PrepareForMaterialChange();
                if(_materials == null || _materials.Length == 0) return;
                for(int i = 0; i < _materials.Length; i++) {
                    if(_materials[i] == null) continue;
                    _materials[i].SetVector(nameID, vector);
                }
            }
        }

        #endregion

        //////////////////////////////////////////////

        #region // Data structs

        public struct FrameEvent {
            public int animationId;
            public string animationName;
            public int frameId;
            public string eventString;

            public FrameEvent(int animationId, string animationName, int frameId, string eventString) {
                this.animationId = animationId;
                this.animationName = animationName;
                this.frameId = frameId;
                this.eventString = eventString;
            }
        }

        [System.Serializable]
        public abstract class MeshFrame_Base {

            public int[] triangles;
            public Vector2[] uvs;

            public int triangleCount { get { return triangles != null ? triangles.Length : 0; } }
            public int uvCount { get { return uvs != null ? uvs.Length : 0; } }

            public MeshFrame_Base() {}

            protected void CopyDataVars(MeshFrame_Base source, MeshFrame_Base destination) {
                destination.triangles = Utils.ArrayTools.Clone<int>(source.triangles);
                destination.uvs = Utils.ArrayTools.Clone<Vector2>(source.uvs);
            }
        }

        [System.Serializable]
        public class MeshFrame : MeshFrame_Base {

            public Vector3[] vertices;

            public int vertexCount { get { return vertices != null ? vertices.Length : 0; } }

            // Double-sided meshes should store all verts/uvs in here precalculated
            // Offsets: Offsets must be baked into vertex positions

            // OPTIMIZATION: Should we store all flipped versions too so there is no vertex copying? // NOT FOR NOW!
            // OPTIMIZATION: Make it draw this info from a SHARED master sprite, not copy it to all sprites -- WOULD THIS MESS UP shaders that move verts? No!
            
            public MeshFrame() { }

            public MeshFrame(MeshFrame meshFrame) {
                CopyDataVars(meshFrame, this);
            }

            public void CopyMeshDataToWorkingArrays(Vector3[] workingVertices, Vector2[] workingUVs, int[] workingTriangles) {

                // Copy verts
                if(vertices == null || workingVertices == null) return;
                int vertexCount = vertices.Length;
                int workingVertexCount = workingVertices.Length;

                if(workingVertexCount < vertexCount) {
                    Debug.LogError("More vertices found than expected!");
                } else {
                    
                    for(int i = 0; i < vertexCount; i++) {
                        workingVertices[i].x = vertices[i].x;
                        workingVertices[i].y = vertices[i].y;
                        workingVertices[i].z = vertices[i].z;
                    }

                    // Clear extra verts
                    if(vertexCount < workingVertexCount) {
                        for(int i = vertexCount; i < workingVertexCount; i++) {
                            workingVertices[i].x = 0.0f;
                            workingVertices[i].y = 0.0f;
                            workingVertices[i].z = 0.0f;
                        }
                    }
                }

                // Copy UVs
                if(uvs != null && workingUVs != null) {
                    int uvCount = vertices.Length;
                    int workingUVCount = workingUVs.Length;

                    if(workingUVCount < uvCount) {
                        Debug.LogError("More UVs found than expected!");
                    } else {

                        for(int i = 0; i < uvCount; i++) {
                            workingUVs[i].x = uvs[i].x;
                            workingUVs[i].y = uvs[i].y;
                        }

                        // Clear extra uvs
                        if(uvCount < workingUVCount) {
                            for(int i = uvCount; i < workingUVCount; i++) {
                                workingUVs[i].x = 0.0f;
                                workingUVs[i].y = 0.0f;
                            }
                        }
                    }
                }

                // Copy Triangles
                if(triangles != null && workingTriangles != null) {
                    
                    int triangleCount = triangles.Length;
                    int workingTriangleCount = workingTriangles.Length;

                    if(triangleCount > workingTriangleCount) {
                        Debug.LogError("More triangles found than expected!");
                        return;
                    }

                    for(int i = 0; i < triangleCount; i++) {
                        workingTriangles[i] = triangles[i];
                    }

                    // Clear extra triangles
                    if(triangleCount < workingTriangleCount) {
                        int emptyVertIndex = (workingTriangleCount / 3) + 1;
                        for(int i = triangleCount; i < workingTriangleCount; i++) {
                            workingTriangles[i] = emptyVertIndex;
                        }
                    }
                }
            }

            protected void CopyDataVars(MeshFrame source, MeshFrame destination) {
                base.CopyDataVars(source, destination); // copy vars in the base

                // Copy vars from this class
                destination.vertices = Utils.ArrayTools.Clone<Vector3>(source.vertices);
            }

            public static MeshFrame Clone(MeshFrame meshFrame) {
                if(meshFrame == null) return null;
                return new MeshFrame(meshFrame);
            }
        }
        #endregion
    }
}