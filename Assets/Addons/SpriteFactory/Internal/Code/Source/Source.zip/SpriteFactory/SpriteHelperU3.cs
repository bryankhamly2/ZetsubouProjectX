﻿using UnityEngine;
using System.Collections;

/*
 * This class is to fix Unity 3 bugs with colliders and ignore collisions.
 * This component is added to Sprites in Unity3 if they have any colliders.
 * This class being separate keeps Sprites without parent colliders and all Sprites in Unity 4 faster because they don't have to have a FixedUpdate
 * 
 * Parent colliders: Collider.enabled state changes done in OnEnable are deferred until FixedUpdate.
 * Child colliders: GameObject.active and consequently Physics.IgnoreCollision calls done in OnEnable are deferred until FixedUpdate.
*/

namespace SpriteFactory {
    [AddComponentMenu("")]
    public class SpriteHelperU3 : MonoBehaviour {

        private bool initialized;
        private Sprite sprite;
        private int colliderCount;

        // Deferred collider enabled state change
        private bool deferredParentColliderStateChange;
        private bool deferredParentColliderStateChange_state;
        private bool deferredChildColliderStateChange;
        private Utils.DataClasses.Workpool_int deferredChildColliderStateChange_indices;
        private Utils.DataClasses.Workpool_bool deferredChildColliderStateChange_states;

        private void OnEnable() { // handle recompiles
            if(!initialized) return;
            
            if(colliderCount > 0) {
                deferredChildColliderStateChange_indices = new Utils.DataClasses.Workpool_int(colliderCount);
                deferredChildColliderStateChange_states = new Utils.DataClasses.Workpool_bool(colliderCount);
            }
        }
        
        public void Initialize(Sprite sprite, int colliderCount) {
            initialized = true;
            this.sprite = sprite;
            this.colliderCount = colliderCount;
            deferredChildColliderStateChange_indices = new Utils.DataClasses.Workpool_int(colliderCount);
            deferredChildColliderStateChange_states = new Utils.DataClasses.Workpool_bool(colliderCount);
        }

        private void FixedUpdate() {
            // According to docs, FixedUpdate should run before physics and collisions so this should always complete the state change before collisions.
            if(!initialized) return;

            // Deferred state change for child colliders
            if(deferredChildColliderStateChange) {
                sprite.DoDeferredChildColliderStateChange(deferredChildColliderStateChange_indices, deferredChildColliderStateChange_states);
                deferredChildColliderStateChange = false;
                deferredChildColliderStateChange_indices.Clear();
                deferredChildColliderStateChange_states.Clear();
            }

            // Deferred state change for parent collider
            if(deferredParentColliderStateChange) {
                sprite.DoDeferredParentColliderStateChange(deferredParentColliderStateChange_state); // do the state change
                deferredParentColliderStateChange = false; // clear flag
            }
        }

        private void OnDisable() {
            // If deferred update is interrupted by deactivation, clear all the update vars cancelling the update
            Clear();
        }

        public void DeferParentColliderStateChange(bool state) {
            if(!initialized) return;
            deferredParentColliderStateChange = true;
            deferredParentColliderStateChange_state = state;
        }

        public void DeferChildColliderStateChange(bool state, int colliderIndex) {
            if(!initialized) return;
            deferredChildColliderStateChange = true;
            deferredChildColliderStateChange_indices.Add(colliderIndex);
            deferredChildColliderStateChange_states.Add(state);
        }

        private void Clear() {
            if(deferredParentColliderStateChange) deferredParentColliderStateChange = false;
            if(deferredParentColliderStateChange_state) deferredParentColliderStateChange_state = false;
            if(deferredChildColliderStateChange) {
                deferredChildColliderStateChange = false;
                deferredChildColliderStateChange_indices.Clear();
                deferredChildColliderStateChange_states.Clear();
            }
        }
    }
}
