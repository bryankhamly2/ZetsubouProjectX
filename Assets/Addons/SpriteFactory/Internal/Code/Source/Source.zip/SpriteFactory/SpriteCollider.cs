using UnityEngine;
using System.Collections;
using SpriteFactory;

namespace SpriteFactory {

    [AddComponentMenu("")]
    public class SpriteCollider : MonoBehaviour {

        // inspector vars
        new public GameObject gameObject;
        new public Transform transform;
        public ColliderInfo colliderInfo;
        public RigidbodyInfo rigidbodyInfo;

        // vars set by sprite on instantiation
        [HideInInspector, SerializeField]
        internal Sprite _sprite;
        [HideInInspector, SerializeField]
        internal GameObject _spriteRoot;
        [HideInInspector, SerializeField]
        internal string _spriteColliderName;
        [HideInInspector, SerializeField]
        internal int _spriteColliderId;
        [HideInInspector, SerializeField]
        internal string _spriteColliderTag;
        [HideInInspector, SerializeField]
        internal string _spriteColliderGroupName;
        [HideInInspector, SerializeField]
        internal bool _isParent;

        public Sprite sprite { get { return _sprite; } }
        public GameObject spriteRoot { get { return _spriteRoot; } }
        public string spriteColliderName { get { return _spriteColliderName; } }
        public int spriteColliderId { get { return _spriteColliderId; } }
        public string spriteColliderTag { get { return _spriteColliderTag; } }
        public string spriteColliderGroupName { get { return _spriteColliderGroupName; } }
        public bool isParent { get { return _isParent; } }

        // working
        [HideInInspector, SerializeField]
        private bool initialized;
        [HideInInspector, SerializeField]
        private bool useHelper2D;
        [HideInInspector, SerializeField]
        private SpriteCollider2DHelper helper2D;

        public void Initialize(Sprite sprite, GameObject spriteRoot, Component colliderComponent, Component rigidbodyComponent, Sprite.ColliderSet colliderSet, Sprite.ColliderGroup colliderGroup, int id, bool isParent) {
            this._sprite = sprite;
            this._spriteRoot = spriteRoot;
            _spriteColliderName = colliderSet.name;
            _spriteColliderTag = colliderSet.tag;
            if(colliderGroup != null) _spriteColliderGroupName = colliderGroup.name;
            else _spriteColliderGroupName = "";
            _spriteColliderId = id;
            this._isParent = isParent;
            colliderInfo = new ColliderInfo(colliderComponent, colliderSet.colliderType, colliderSet.is2D); // fill out collider info
            if(rigidbodyComponent != null) rigidbodyInfo = new RigidbodyInfo(rigidbodyComponent, colliderSet.is2D); // fill out rigidbody info
            else rigidbodyInfo = null; // clear any pre-existing serialized rigidbodyInfo so it returns a null
            
            // Create collision tracker for all 2D colliders, animated and static
            if(colliderSet.is2D) {
                helper2D = gameObject.AddComponent<SpriteCollider2DHelper>();
                helper2D.Initialize(new Collision2DTracker(spriteRoot, _spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName));
                useHelper2D = true;
            }

            initialized = true;
        }

        #region // Colliders

        private Component FindCollider() {
            // Get 2D collider - Unity 4.3+ only
            if(colliderInfo.is2D) {
                Utils.UnityTools.FailIfNo2DSupport();
                return GetCollider2D();
            }

            // Get 3D collider
            return GetCollider3D();
        }

        private Component GetCollider3D() {
            return GetComponent(typeof(Collider));
        }

        private Component GetCollider2D() {
            return GetComponent(typeof(Collider2D));
        }

        #endregion

        #region // Events

        private void OnEnable() { // Runs when this game object has been activated, not when component is enabled
            if(!initialized) return; // prevent this from running in the editor

            // PARENT COLLIDERS BUG UNITY 3.x
            // In Unity 3.5.x, there is a collider bug when a GameObject is enabled that has a Collider component:
            // COLLIDERS are ENABLED when GameObject.active = true is set even if collider.enabled = false.
            // Inspector shows collider is disabled, even collider.enabled returns false, but COLLIDER STILL COLLIDES.
            // THIS DOES NOT HAPPEN IN UNITY 4.0+
            
            // ULIMATELY, THE PROBLEM IS THIS
            // Unity 3 cannot reliably enable/disable colliders in ANY OnEnable downstream code path
            // The collider enabled state will be set to whatever you tell it to, but the actual collisions on it
            // can be different. So it's really not setting the enabled state, it's just setting some visual enabled state and even the flag
            // but it doesn't really get enabled/disabled.

            // Patch solution:
            // DO NOT set enabled state in any OnEnable event
            // DEFER the setting of the state until the next update cycle
            // This WILL NOT solve the problem where the character hits himself
            // BUT it will solve the problem of leaving the collider in a false state permanently

            // UNITY 3.x BUG!!!
            // IGNORE COLLISION cannot be reliably called in any OnEnable downstream code in Unity3.x
            // The above bug extends to ALL IGNORE COLLISIONS so it affects even child colliders that use activate/deactivate!
            // All ignore collisions have to be deferred until FixedUpdate using SpriteHelperU3
            
            // THIS BUG EXPANDED ALL THE WAY TO CHILD COLLIDERS AS WELL
            // GameObject.active may return false but the collider will still collide sometimes, so ALL collider enable/disabling is now deferred to FixedUpdate()

            if(Utils.UnityTools.isSupportedVersion3) { // unity 3.5.0 - 3.5.7
                if(_isParent) return; // do not call ColliderEnabled for parent collider in Unity 3
            }

            // Report collider enabled to sprite
            _sprite.ColliderEnabled(_spriteColliderId);
        }

        #endregion

        #region // OnMouse Events

        // OnMouse events are called by SFSpriteColliderEventReporter which exists as a script in the Unity project. This allows us to
        // use preprocessor directives in SFSpriteColliderEventReporter so OnMouse events are not generated for mobile platforms.

        public void Send_MouseEnter() {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, null, CollisionType.Mouse, false);
            _spriteRoot.SendMessage("OnMouseEnterSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        public void Send_MouseOver() {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, null, CollisionType.Mouse, false);
            _spriteRoot.SendMessage("OnMouseOverSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        public void Send_MouseExit() {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, null, CollisionType.Mouse, false);
            _spriteRoot.SendMessage("OnMouseExitSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        public void Send_MouseDown() {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, null, CollisionType.Mouse, false);
            _spriteRoot.SendMessage("OnMouseDownSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        public void Send_MouseUpAsButton() {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, null, CollisionType.Mouse, false);
            _spriteRoot.SendMessage("OnMouseUpAsButtonSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        public void Send_MouseDrag() {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, null, CollisionType.Mouse, false);
            _spriteRoot.SendMessage("OnMouseDragSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        #endregion

        #region // OnTrigger/OnCollider Events

        // Collider event handlers are handled directly here.

        private void OnTriggerEnter(object other) {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, other, CollisionType.Trigger, false);
            _spriteRoot.SendMessage("OnTriggerEnterSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        private void OnTriggerStay(object other) {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, other, CollisionType.Trigger, false);
            _spriteRoot.SendMessage("OnTriggerStaySprite", data, SendMessageOptions.DontRequireReceiver);
        }

        private void OnTriggerExit(object other) {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, other, CollisionType.Trigger, false);
            _spriteRoot.SendMessage("OnTriggerExitSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        private void OnCollisionEnter(object collisionInfo) {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, collisionInfo, CollisionType.Collider, false);
            _spriteRoot.SendMessage("OnCollisionEnterSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        private void OnCollisionStay(object collisionInfo) {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, collisionInfo, CollisionType.Collider, false);
            _spriteRoot.SendMessage("OnCollisionStaySprite", data, SendMessageOptions.DontRequireReceiver);
        }

        private void OnCollisionExit(object collisionInfo) {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, collisionInfo, CollisionType.Collider, false);
            _spriteRoot.SendMessage("OnCollisionExitSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        private void OnParticleCollision(object other) {
            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, other, CollisionType.Particle, false);
            _spriteRoot.SendMessage("OnParticleCollisionSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        // 2D

        private void OnTriggerEnter2D(object other) {
            if(useHelper2D) { // track collisions using collision tracker instead
                helper2D.collision2DTracker.TriggerEnter(other);
                return;
            }

            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, other, CollisionType.Trigger, true);
            _spriteRoot.SendMessage("OnTriggerEnterSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        private void OnTriggerStay2D(object other) {
            if(useHelper2D) { // track collisions using collision tracker instead
                helper2D.collision2DTracker.TriggerStay(other);
                return;
            }

            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, other, CollisionType.Trigger, true);
            _spriteRoot.SendMessage("OnTriggerStaySprite", data, SendMessageOptions.DontRequireReceiver);
        }

        private void OnTriggerExit2D(object other) {
            if(useHelper2D) { // track collisions using collision tracker instead
                helper2D.collision2DTracker.TriggerExit(other);
                return;
            }

            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, other, CollisionType.Trigger, true);
            _spriteRoot.SendMessage("OnTriggerExitSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        private void OnCollisionEnter2D(object collision) {
            if(useHelper2D) { // track collisions using collision tracker instead
                helper2D.collision2DTracker.CollisionEnter(collision);
                return;
            }

            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, collision, CollisionType.Collider, true);
            _spriteRoot.SendMessage("OnCollisionEnterSprite", data, SendMessageOptions.DontRequireReceiver);
        }

        private void OnCollisionStay2D(object collision) {
            if(useHelper2D) { // track collisions using collision tracker instead
                helper2D.collision2DTracker.CollisionEnter(collision);
                return;
            }

            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, collision, CollisionType.Collider, true);
            _spriteRoot.SendMessage("OnCollisionStaySprite", data, SendMessageOptions.DontRequireReceiver);
        }

        private void OnCollisionExit2D(object collision) {
            if(useHelper2D) { // track collisions using collision tracker instead
                helper2D.collision2DTracker.CollisionEnter(collision);
                return;
            }

            CollisionData data = new CollisionData(_spriteColliderName, _spriteColliderId, _spriteColliderTag, _spriteColliderGroupName, collision, CollisionType.Collider, true);
            _spriteRoot.SendMessage("OnCollisionExitSprite", data, SendMessageOptions.DontRequireReceiver);
        }
        
        #endregion

        #region // Classes

        // Used for sending collision information in SendMessage
        public struct CollisionData {

            public string spriteColliderName { get { return _spriteColliderName; } }
            public int spriteColliderId { get { return _spriteColliderId; } }
            public string spriteColliderTag { get { return _spriteColliderTag; } }
            public string spriteColliderGroupName { get { return _spriteColliderGroupName; } }
            public object objectValue { get { return _objectValue; } }
            public CollisionType collisionType { get { return _collisionType; } }
            public bool is2D { get { return _is2D; } }
            public Sprite otherSprite { get { if(_otherSprite != null) return _otherSprite; return GetOtherSprite(_objectValue); } }
            public GameObject otherColliderGameObject { get { return GetOtherColliderGameObject(_objectValue); } }

            private string _spriteColliderName;
            private int _spriteColliderId;
            private string _spriteColliderTag;
            private string _spriteColliderGroupName;
            private object _objectValue;
            private CollisionType _collisionType;
            private bool _is2D;
            private Sprite _otherSprite;

            public CollisionData(string name, int id, string tag, string groupName, object value, CollisionType collisionType, bool is2D) {
                _spriteColliderName = name;
                _spriteColliderGroupName = groupName;
                _spriteColliderId = id;
                _spriteColliderTag = tag;
                _objectValue = value;
                _collisionType = collisionType;
                _is2D = is2D;
                if(_is2D) Utils.UnityTools.FailIfNo2DSupport();
                _otherSprite = null;
            }

            public TCollider GetCollider<TCollider>() where TCollider : Component {
                if(!Utils.UnityTools.IsColliderOrCollider2D(typeof(TCollider), _is2D)) throw new System.ArgumentException("TCollider must be equal to or derrived from Collider or Collider2D!");

                if(_collisionType == CollisionType.Collider) {
                    if(_is2D) return Get2DCollision<TCollider>();
                    else return (TCollider)(Component)(((Collision)_objectValue).collider);
                } else if(_collisionType == CollisionType.Trigger) {
                    return (TCollider)_objectValue; // just cast straight to final type
                } else { // this type has no collider
                    Debug.LogWarning("Collisions of type \"" + collisionType.ToString() + "\" do not pass a collider.");
                    return null;
                }
            }

            private TCollider Get2DCollision<TCollider>() where TCollider : Component {
                return (TCollider)(Component)(((Collision2D)_objectValue).collider);
            }

            private Sprite GetOtherSprite(object objectValue) {
                switch(_collisionType) {
                    case CollisionType.Collider:
                        _otherSprite = GetOtherSprite_Collider(objectValue);
                        return _otherSprite;
                    case CollisionType.Trigger:
                        _otherSprite = GetOtherSprite_Trigger(objectValue);
                        return _otherSprite;
                    case CollisionType.Particle:
                        return null;
                    case CollisionType.Mouse:
                        return null;
                }
                return null;
            }

            private Sprite GetOtherSprite_Collider(object objectValue) {
                if(_is2D) {
                    return GetOtherSprite_Collider2D(objectValue);
                } else {
                    SpriteCollider sc = ((Collision)objectValue).gameObject.GetComponent<SpriteCollider>();
                    if(sc == null) return null;
                    return sc.sprite;
                }
            }

            private Sprite GetOtherSprite_Trigger(object objectValue) {
                if(_is2D) {
                    return GetOtherSprite_Trigger2D(objectValue);
                } else {
                    SpriteCollider sc = ((Collider)objectValue).gameObject.GetComponent<SpriteCollider>();
                    if(sc == null) return null;
                    return sc.sprite;
                }
            }

            private Sprite GetOtherSprite_Collider2D(object objectValue) {
                SpriteCollider sc = ((Collision2D)objectValue).gameObject.GetComponent<SpriteCollider>();
                if(sc == null) return null;
                return sc.sprite;
            }

            private Sprite GetOtherSprite_Trigger2D(object objectValue) {
                SpriteCollider sc = ((Collider2D)objectValue).gameObject.GetComponent<SpriteCollider>();
                if(sc == null) return null;
                return sc.sprite;
            }

            private GameObject GetOtherColliderGameObject(object objectValue) {
                switch(_collisionType) {
                    case CollisionType.Collider:
                        return GetOtherColliderGameObject_Collider(objectValue);
                    case CollisionType.Trigger:
                        _otherSprite = GetOtherSprite_Trigger(objectValue);
                        return GetOtherColliderGameObject_Trigger(objectValue);
                    case CollisionType.Particle:
                        return (GameObject)objectValue;
                    case CollisionType.Mouse:
                        return null;
                }
                return null;
            }

            private GameObject GetOtherColliderGameObject_Collider(object objectValue) {
                if(_is2D) {
                    return GetOtherColliderGameObject_Collider2D(objectValue);
                } else {
                    return ((Collision)objectValue).gameObject;
                }
            }

            private GameObject GetOtherColliderGameObject_Trigger(object objectValue) {
                if(_is2D) {
                    return GetOtherColliderGameObject_Trigger2D(objectValue);
                } else {
                    return ((Collider)objectValue).gameObject;
                }
            }

            private GameObject GetOtherColliderGameObject_Collider2D(object objectValue) {
                return ((Collision2D)objectValue).gameObject;
            }

            private GameObject GetOtherColliderGameObject_Trigger2D(object objectValue) {
                return ((Collider2D)objectValue).gameObject;
            }
        }

        #endregion
    }
}