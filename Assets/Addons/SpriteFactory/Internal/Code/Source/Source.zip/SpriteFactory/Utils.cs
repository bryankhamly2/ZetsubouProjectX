using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

namespace SpriteFactory {

    public static class Utils {

        #region // DATA CLASSES

        public static class DataClasses {

            [System.Serializable]
            public class IntVector2 { // was a struct but couldn't serialize it
                public int x;
                public int y;

                public IntVector2() {
                    x = 0;
                    y = 0;
                }

                public IntVector2(int inX, int inY) {
                    x = inX;
                    y = inY;
                }

                public IntVector2 Clone() {
                    return new IntVector2(x, y);
                }

                public static IntVector2 Clone(IntVector2 intVector2) {
                    if(intVector2 == null) return null;
                    return intVector2.Clone();
                }

                // Operators

                // + - * / by IntVector2
                public static IntVector2 operator +(IntVector2 value1, IntVector2 value2) {
                    return new IntVector2(value1.x + value2.x, value1.y + value2.y);
                }

                public static IntVector2 operator -(IntVector2 value1, IntVector2 value2) {
                    return new IntVector2(value1.x - value2.x, value1.y - value2.y);
                }

                public static IntVector2 operator *(IntVector2 value1, IntVector2 value2) {
                    return new IntVector2(value1.x * value2.x, value1.y * value2.y);
                }

                public static IntVector2 operator /(IntVector2 value1, IntVector2 value2) {
                    return new IntVector2(value1.x / value2.x, value1.y / value2.y);
                }

                // + - * / by int
                public static IntVector2 operator +(IntVector2 value1, int value2) {
                    return new IntVector2(value1.x + value2, value1.y + value2);
                }

                public static IntVector2 operator -(IntVector2 value1, int value2) {
                    return new IntVector2(value1.x - value2, value1.y - value2);
                }

                public static IntVector2 operator *(IntVector2 value1, int value2) {
                    return new IntVector2(value1.x * value2, value1.y * value2);
                }

                public static IntVector2 operator /(IntVector2 value1, int value2) {
                    return new IntVector2(value1.x / value2, value1.y / value2);
                }

                // + - * / by float
                public static Vector2 operator +(IntVector2 value1, float value2) {
                    return new Vector2((float)value1.x + value2, (float)value1.y + value2);
                }

                public static Vector2 operator -(IntVector2 value1, float value2) {
                    return new Vector2((float)value1.x - value2, (float)value1.y - value2);
                }

                public static Vector2 operator *(IntVector2 value1, float value2) {
                    return new Vector2((float)value1.x * value2, (float)value1.y * value2);
                }

                public static Vector2 operator /(IntVector2 value1, float value2) {
                    return new Vector2((float)value1.x / value2, (float)value1.y / value2);
                }
            }

            [System.Serializable]
            public class IntVector3 { // was a struct but couldn't serialize it
                public int x;
                public int y;
                public int z;

                public IntVector3() {
                    x = 0;
                    y = 0;
                    z = 0;
                }

                public IntVector3(int inX, int inY, int inZ) {
                    x = inX;
                    y = inY;
                    z = inZ;
                }

                public IntVector3 Clone() {
                    return new IntVector3(x, y, z);
                }

                // Operators

                // + - * / by IntVector3
                public static IntVector3 operator +(IntVector3 value1, IntVector3 value2) {
                    return new IntVector3(value1.x + value2.x, value1.y + value2.y, value1.z + value2.z);
                }

                public static IntVector3 operator -(IntVector3 value1, IntVector3 value2) {
                    return new IntVector3(value1.x - value2.x, value1.y - value2.y, value1.z - value2.z);
                }

                public static IntVector3 operator *(IntVector3 value1, IntVector3 value2) {
                    return new IntVector3(value1.x * value2.x, value1.y * value2.y, value1.z * value2.z);
                }

                public static IntVector3 operator /(IntVector3 value1, IntVector3 value2) {
                    return new IntVector3(value1.x / value2.x, value1.y / value2.y, value1.z / value2.z);
                }

                // + - * / by int
                public static IntVector3 operator +(IntVector3 value1, int value2) {
                    return new IntVector3(value1.x + value2, value1.y + value2, value1.z + value2);
                }

                public static IntVector3 operator -(IntVector3 value1, int value2) {
                    return new IntVector3(value1.x - value2, value1.y - value2, value1.z - value2);
                }

                public static IntVector3 operator *(IntVector3 value1, int value2) {
                    return new IntVector3(value1.x * value2, value1.y * value2, value1.z * value2);
                }

                public static IntVector3 operator /(IntVector3 value1, int value2) {
                    return new IntVector3(value1.x / value2, value1.y / value2, value1.z / value2);
                }

                // + - * / by float
                public static Vector3 operator +(IntVector3 value1, float value2) {
                    return new Vector3((float)value1.x + value2, (float)value1.y + value2, (float)value1.z + value2);
                }

                public static Vector3 operator -(IntVector3 value1, float value2) {
                    return new Vector3((float)value1.x - value2, (float)value1.y - value2, (float)value1.z - value2);
                }

                public static Vector3 operator *(IntVector3 value1, float value2) {
                    return new Vector3((float)value1.x * value2, (float)value1.y * value2, (float)value1.z * value2);
                }

                public static Vector3 operator /(IntVector3 value1, float value2) {
                    return new Vector3((float)value1.x / value2, (float)value1.y / value2, (float)value1.z / value2);
                }
            }

            [System.Serializable]
            public class IntVector4 { // was a struct but couldn't serialize it
                public int x;
                public int y;
                public int z;
                public int q;

                public IntVector4() {
                    x = 0;
                    y = 0;
                    z = 0;
                    q = 0;
                }

                public IntVector4(int inX, int inY, int inZ, int inQ) {
                    x = inX;
                    y = inY;
                    z = inZ;
                    q = inQ;
                }

                public IntVector4 Clone() {
                    return new IntVector4(x, y, z, q);
                }

                // Operators

                // + - * / by IntVector4
                public static IntVector4 operator +(IntVector4 value1, IntVector4 value2) {
                    return new IntVector4(value1.x + value2.x, value1.y + value2.y, value1.z + value2.z, value1.q + value2.q);
                }

                public static IntVector4 operator -(IntVector4 value1, IntVector4 value2) {
                    return new IntVector4(value1.x - value2.x, value1.y - value2.y, value1.z - value2.z, value1.q - value2.q);
                }

                public static IntVector4 operator *(IntVector4 value1, IntVector4 value2) {
                    return new IntVector4(value1.x * value2.x, value1.y * value2.y, value1.z * value2.z, value1.q * value2.q);
                }

                public static IntVector4 operator /(IntVector4 value1, IntVector4 value2) {
                    return new IntVector4(value1.x / value2.x, value1.y / value2.y, value1.z / value2.z, value1.q / value2.q);
                }

                // + - * / by int
                public static IntVector4 operator +(IntVector4 value1, int value2) {
                    return new IntVector4(value1.x + value2, value1.y + value2, value1.z + value2, value1.q + value2);
                }

                public static IntVector4 operator -(IntVector4 value1, int value2) {
                    return new IntVector4(value1.x - value2, value1.y - value2, value1.z - value2, value1.q - value2);
                }

                public static IntVector4 operator *(IntVector4 value1, int value2) {
                    return new IntVector4(value1.x * value2, value1.y * value2, value1.z * value2, value1.q * value2);
                }

                public static IntVector4 operator /(IntVector4 value1, int value2) {
                    return new IntVector4(value1.x / value2, value1.y / value2, value1.z / value2, value1.q / value2);
                }

                // + - * / by float
                public static Vector4 operator +(IntVector4 value1, float value2) {
                    return new Vector4((float)value1.x + value2, (float)value1.y + value2, (float)value1.z + value2, (float)value1.q + value2);
                }

                public static Vector4 operator -(IntVector4 value1, float value2) {
                    return new Vector4((float)value1.x - value2, (float)value1.y - value2, (float)value1.z - value2, (float)value1.q - value2);
                }

                public static Vector4 operator *(IntVector4 value1, float value2) {
                    return new Vector4((float)value1.x * value2, (float)value1.y * value2, (float)value1.z * value2, (float)value1.q * value2);
                }

                public static Vector4 operator /(IntVector4 value1, float value2) {
                    return new Vector4((float)value1.x / value2, (float)value1.y / value2, (float)value1.z / value2, (float)value1.q / value2);
                }
            }

            [System.Serializable]
            public class IntRect {
                public int x;
                public int y;
                public int width;
                public int height;

                public int yMin {
                    get {
                        return y;
                    }
                    set {
                        y = value;
                    }
                }
                public int yMax {
                    get {
                        return y + height - 1;
                    }
                    set {
                        height = value - 1;
                    }
                }
                public int xMin {
                    get {
                        return x;
                    }
                    set {
                        x = value;
                    }
                }
                public int xMax {
                    get {
                        return x + width - 1;
                    }
                    set {
                        width = value - 1;
                    }
                }
                public int top {
                    get {
                        return y;
                    }
                    set {
                        y = value;
                    }
                }
                public int bottom {
                    get {
                        return y + height - 1;
                    }
                    set {
                        height = value - 1;
                    }
                }
                public int left {
                    get {
                        return x;
                    }
                    set {
                        x = value;
                    }
                }
                public int right {
                    get {
                        return x + width - 1;
                    }
                    set {
                        width = value - 1;
                    }
                }

                public IntRect() { }
                public IntRect(int inX, int inY, int inWidth, int inHeight) {
                    x = inX;
                    y = inY;
                    width = inWidth;
                    height = inHeight;
                }

                public IntRect Clone() {
                    return new IntRect(x, y, width, height);
                }

                public static IntRect Clone(IntRect intRect) {
                    if(intRect == null) return null;
                    return intRect.Clone();
                }
            }

            [System.Serializable]
            public class IntPadding { // was a struct but couldn't serialize it
                public int top;
                public int right;
                public int bottom;
                public int left;

                public IntPadding() {
                    top = 0;
                    right = 0;
                    bottom = 0;
                    left = 0;
                }

                public IntPadding(int inTop, int inRight, int inBottom, int inLeft) {
                    top = inTop;
                    right = inRight;
                    bottom = inBottom;
                    left = inLeft;
                }

                public IntPadding Clone() {
                    return new IntPadding(top, right, bottom, left);
                }

                // Operators

                // + - * / by Padding
                public static IntPadding operator +(IntPadding value1, IntPadding value2) {
                    return new IntPadding(value1.top + value2.top, value1.right + value2.right, value1.bottom + value2.bottom, value1.left + value2.left);
                }

                public static IntPadding operator -(IntPadding value1, IntPadding value2) {
                    return new IntPadding(value1.top - value2.top, value1.right - value2.right, value1.bottom - value2.bottom, value1.left - value2.left);
                }

                public static IntPadding operator *(IntPadding value1, IntPadding value2) {
                    return new IntPadding(value1.top * value2.top, value1.right * value2.right, value1.bottom * value2.bottom, value1.left * value2.left);
                }

                public static IntPadding operator /(IntPadding value1, IntPadding value2) {
                    return new IntPadding(value1.top / value2.top, value1.right / value2.right, value1.bottom / value2.bottom, value1.left / value2.left);
                }

                // + - * / by int
                public static IntPadding operator +(IntPadding value1, int value2) {
                    return new IntPadding(value1.top + value2, value1.right + value2, value1.bottom + value2, value1.left + value2);
                }

                public static IntPadding operator -(IntPadding value1, int value2) {
                    return new IntPadding(value1.top - value2, value1.right - value2, value1.bottom - value2, value1.left - value2);
                }

                public static IntPadding operator *(IntPadding value1, int value2) {
                    return new IntPadding(value1.top * value2, value1.right * value2, value1.bottom * value2, value1.left * value2);
                }

                public static IntPadding operator /(IntPadding value1, int value2) {
                    return new IntPadding(value1.top / value2, value1.right / value2, value1.bottom / value2, value1.left / value2);
                }

                // + - * / by float
                public static Vector4 operator +(IntPadding value1, float value2) {
                    return new Vector4((float)value1.top + value2, (float)value1.right + value2, (float)value1.bottom + value2, (float)value1.left + value2);
                }

                public static Vector4 operator -(IntPadding value1, float value2) {
                    return new Vector4((float)value1.top - value2, (float)value1.right - value2, (float)value1.bottom - value2, (float)value1.left - value2);
                }

                public static Vector4 operator *(IntPadding value1, float value2) {
                    return new Vector4((float)value1.top * value2, (float)value1.right * value2, (float)value1.bottom * value2, (float)value1.left * value2);
                }

                public static Vector4 operator /(IntPadding value1, float value2) {
                    return new Vector4((float)value1.top / value2, (float)value1.right / value2, (float)value1.bottom / value2, (float)value1.left / value2);
                }
            }

            #region // COLLECTIONS

            /// <summary>
            /// An expandable array pool.
            /// Searches for first empty element before expanding.
            /// NOTE: DOES NOT WORK FOR INT or FLOAT since Default(T) = 0!!!
            /// </summary>
            /// <typeparam name="T"></typeparam>
            public class Pool<T> where T : class {
                protected T[] list;
                protected int _maxExpansions;
                protected int _startingLength;
                protected int _length;
                protected int _maxLength;
                protected int _increment;
                protected int _filledCount;
                protected bool _allowExpansion;

                // Properties
                public int Length { get { return _filledCount; } }
                //public int MaxLength { get { return _maxLength; } }
                //public int FreeSpace { get { return _maxLength - _length; } }

                public Pool(int startingLength, bool allowExpansion, int increment = 0, int maxExpansions = 0) {
                    if(startingLength < 0) throw new System.Exception("Starting Length must be greater than or equal to zero!");
                    if(maxExpansions < 0) throw new System.Exception("Maximum Expansions must be greater than or equal to zero!");
                    if(increment < 0) throw new System.Exception("Increment must be greater than or equal to zero!");

                    _startingLength = startingLength;
                    _allowExpansion = allowExpansion;
                    _maxExpansions = maxExpansions;
                    _increment = increment;
                    _length = startingLength;
                    _maxLength = startingLength + (increment * maxExpansions);
                    _filledCount = 0;

                    list = new T[_length]; // create the array at starting size
                }

                public T this[int index] {
                    get {
                        if(index >= _filledCount) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                        return list[index];
                    }
                    set {
                        if(index >= _filledCount) throw new System.IndexOutOfRangeException(); // prevent skipping of unassigned indices
                        list[index] = value;
                    }
                }

                public int Add(T item) {
                    int index = FindSpace();
                    if(index == -1) return -2; // no space, cannot expand any more
                    list[index] = item; // add item to array
                    if(index >= _filledCount) _filledCount = index + 1;
                    return index; // return index of added item
                }

                public int AddIfUnique(T item) {
                    for(int i = 0; i < _filledCount; i++) {
                        if(object.Equals(list[i], item)) return -1; // already in list
                    }
                    int index = FindSpace();
                    if(index == -1) return -2; // no space, cannot expand any more
                    list[index] = item; // add item to array
                    if(index >= _filledCount) _filledCount = index + 1;
                    return index; // return index of added item
                }

                public void Remove(T item, bool removeAllInstances = false) {
                    for(int i = 0; i < _filledCount; i++) {
                        if(object.Equals(list[i], item)) {
                            list[i] = default(T);
                            if(i == _filledCount - 1) // adjust filled count if removing last item
                                _filledCount--;
                            if(!removeAllInstances) return;
                        }
                    }
                }

                public void RemoveAt(int index) {
                    if(index < 0 || index > _length) throw new System.NullReferenceException();
                    list[index] = default(T);
                    if(index == _filledCount - 1) // adjust filled count if removing last item
                        _filledCount--;
                }

                private int FindSpace() {
                    // Find space in the list
                    for(int i = 0; i < _length; i++) {
                        if(object.Equals(list[i], default(T))) {
                            return i; // cell is empty
                        }
                    }

                    // Expand the list
                    if(!_allowExpansion) return -1; // not expandable, no space
                    if(_maxExpansions > 0 && _length >= _maxLength) return -1; // not unlimited size, already max size, no space

                    int newIndex = _length;
                    int newLength = _length + _increment;
                    T[] newList = new T[newLength];
                    for(int i = 0; i < _length; i++) { // copy old list to new
                        newList[i] = list[i];
                    }
                    list = newList; // replace the list
                    _length = newLength; // update the length var
                    return newIndex;
                }

                public void Clear() {
                    System.Array.Clear(list, 0, list.Length); // clear the data from the array, but don't reset its size
                    _length = 0;
                    _filledCount = 0; // reset the filled count
                }

                public void Reset() {
                    list = new T[_startingLength]; // reset the whole array, collapsing it back to starting size
                    _length = 0;
                    _filledCount = 0; // reset the filled count
                }
            }

            /// <summary>
            /// A fixed-length array that is more efficient because it only works on entries that have been filled.
            /// </summary>
            /// <typeparam name="T"></typeparam>
            public class Workpool<T> {
                private T[] list;
                private int _Length; // acts as filled count
                private int _MaxLength; // the length of the internal array

                // Properties
                public int Length { get { return _Length; } }
                public int MaxLength { get { return _MaxLength; } }
                public int FreeSpace { get { return _MaxLength - _Length; } }
                public T Random {
                    get {
                        if(_Length == 0) return default(T);
                        return list[UnityEngine.Random.Range(0, _Length)];
                    }
                }

                public Workpool(int maximumLength) {
                    list = new T[maximumLength]; // create the list at maximum size
                    _Length = 0;
                    _MaxLength = maximumLength;
                }

                public T this[int index] {
                    get {
                        if(index >= _Length) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                        return list[index];
                    }
                    set {
                        if(index > _Length) throw new System.IndexOutOfRangeException(); // prevent skipping of unassigned indices
                        list[index] = value;
                        if(index >= _Length) // we've added in an index at or higher than the filled count
                            _Length = index + 1; // increase the filled count
                    }
                }

                public int Add(T item) {
                    if(_Length == _MaxLength) return -1; // list is full, return failed
                    this[_Length] = item; // add item to end of list
                    return _Length - 1; // return index of added item
                }

                public bool Add(T[] items, bool allowPartialAdd = false) {
                    if(_Length == _MaxLength) return false; // list is full, return failed
                    bool success = true;
                    int count = items.Length; // get count of items we want to add

                    // Check if there's enough space to add the items
                    int freeSpace = _MaxLength - _Length; // get free space remaining in the array
                    if(count > freeSpace) {
                        if(!allowPartialAdd) return false; // failed
                        count = freeSpace; // add only as many items as will fit
                        success = false; // flag a failure because we only filled it partially
                    }
                    for(int i = 0; i < count; i++) { // add the items to the array
                        list[_Length++] = items[i]; // add item to end of list
                    }
                    return success;
                }

                public int AddIfUnique(T item) {
                    int index = this.IndexOf(item);
                    if(index >= 0) return index;
                    return Add(item);
                }

                public bool Insert(int index, T item) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();
                    if(_Length == _MaxLength) return false; // list is full, return failed

                    int newLastIndex = _Length; // one larger than current

                    // Copy the entries forward in the list from end to insert point
                    for(int i = newLastIndex; i > index; i--) {
                        list[i] = list[i - 1]; // copy the lower entry into this higher space
                    }

                    // Store the item at the insert point
                    list[index] = item;

                    _Length++; // increase list size
                    return true;
                }

                public bool Remove(T item) {
                    if(_Length <= 0) return false; // no entries to search

                    int index = IndexOf(item); // find the item in the list
                    if(index < 0) return false; // not in list

                    RemoveAt(index); // remove the item
                    return true;
                }

                public void RemoveAt(int index) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();

                    int lastIndex = _Length - 1;

                    // Move entries after this one down
                    for(int i = index; i < lastIndex; i++) {
                        list[i] = list[i + 1]; // move the next entry into this space
                    }

                    // Clear the last entry
                    list[lastIndex] = default(T); // clear the entry

                    _Length--; // reduce size of the list
                }

                public bool Contains(T item) {
                    for(int i = 0; i < _Length; i++) {
                        if(EqualityComparer<T>.Default.Equals(list[i], item)) return true;
                    }
                    return false;
                }

                public int IndexOf(T item) {
                    for(int i = 0; i < _Length; i++) {
                        if(EqualityComparer<T>.Default.Equals(list[i], item)) return i;
                    }
                    return -1;
                }

                public void Clear() {
                    System.Array.Clear(list, 0, _Length); // clear the data from the array
                    _Length = 0; // reset the filled count
                }
            }

            /// <summary>
            /// A fixed-length array that is more efficient because it only works on entries that have been filled.
            /// Type: int
            /// </summary>
            /// <typeparam name="T"></typeparam>
            public class Workpool_int {
                private int[] list;
                private int _Length; // acts as filled count
                private int _MaxLength; // the length of the internal array

                // Properties
                public int Length { get { return _Length; } }
                public int MaxLength { get { return _MaxLength; } }
                public int FreeSpace { get { return _MaxLength - _Length; } }

                public Workpool_int(int maximumLength) {
                    list = new int[maximumLength]; // create the list at maximum size
                    _Length = 0;
                    _MaxLength = maximumLength;
                }

                public int this[int index] {
                    get {
                        if(index >= _Length) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                        return list[index];
                    }
                    set {
                        if(index > _Length) throw new System.IndexOutOfRangeException(); // prevent skipping of unassigned indices
                        list[index] = value;
                        if(index >= _Length) // we've added in an index at or higher than the filled count
                            _Length = index + 1; // increase the filled count
                    }
                }

                public int Add(int item) {
                    if(_Length == _MaxLength) return -1; // list is full, return failed
                    this[_Length] = item; // add item to end of list
                    return _Length - 1; // return index of added item
                }

                public bool Add(int[] items, bool allowPartialAdd = false) {
                    if(_Length == _MaxLength) return false; // list is full, return failed
                    bool success = true;
                    int count = items.Length; // get count of items we want to add

                    // Check if there's enough space to add the items
                    int freeSpace = _MaxLength - _Length; // get free space remaining in the array
                    if(count > freeSpace) {
                        if(!allowPartialAdd) return false; // failed
                        count = freeSpace; // add only as many items as will fit
                        success = false; // flag a failure because we only filled it partially
                    }
                    for(int i = 0; i < count; i++) { // add the items to the array
                        list[_Length++] = items[i]; // add item to end of list
                    }
                    return success;
                }

                public int AddIfUnique(int item) {
                    int index = this.IndexOf(item);
                    if(index >= 0) return index;
                    return Add(item);
                }

                public bool Insert(int index, int item) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();
                    if(_Length == _MaxLength) return false; // list is full, return failed

                    int newLastIndex = _Length; // one larger than current

                    // Copy the entries forward in the list from end to insert point
                    for(int i = newLastIndex; i > index; i--) {
                        list[i] = list[i - 1]; // copy the lower entry into this higher space
                    }

                    // Store the item at the insert point
                    list[index] = item;

                    _Length++; // increase list size
                    return true;
                }

                public bool Remove(int item) {
                    if(_Length <= 0) return false; // no entries to search

                    int index = IndexOf(item); // find the item in the list
                    if(index < 0) return false; // not in list

                    RemoveAt(index); // remove the item
                    return true;
                }

                public void RemoveAt(int index) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();

                    int lastIndex = _Length - 1;

                    // Move entries after this one down
                    for(int i = index; i < lastIndex; i++) {
                        list[i] = list[i + 1]; // move the next entry into this space
                    }

                    // No need to clear the last entry

                    _Length--; // reduce size of the list
                }

                public bool Contains(int item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return true;
                    }
                    return false;
                }

                public int IndexOf(int item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return i;
                    }
                    return -1;
                }

                public void Clear() {
                    //System.Array.Clear(list, 0, _Length); // clear the data from the array
                    // No need to clear since there's no danger of object persistance
                    _Length = 0; // reset the filled count
                }
            }

            /// <summary>
            /// A fixed-length array that is more efficient because it only works on entries that have been filled.
            /// Type: float
            /// </summary>
            public class Workpool_float {
                private float[] list;
                private int _Length; // acts as filled count
                private int _MaxLength; // the length of the internal array

                // Properties
                public int Length { get { return _Length; } }
                public int MaxLength { get { return _MaxLength; } }
                public int FreeSpace { get { return _MaxLength - _Length; } }

                public Workpool_float(int maximumLength) {
                    list = new float[maximumLength]; // create the list at maximum size
                    _Length = 0;
                    _MaxLength = maximumLength;
                }

                public float this[int index] {
                    get {
                        if(index >= _Length) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                        return list[index];
                    }
                    set {
                        if(index > _Length) throw new System.IndexOutOfRangeException(); // prevent skipping of unassigned indices
                        list[index] = value;
                        if(index >= _Length) // we've added in an index at or higher than the filled count
                            _Length = index + 1; // increase the filled count
                    }
                }

                public int Add(float item) {
                    if(_Length == _MaxLength) return -1; // list is full, return failed
                    this[_Length] = item; // add item to end of list
                    return _Length - 1; // return index of added item
                }

                public bool Add(float[] items, bool allowPartialAdd = false) {
                    if(_Length == _MaxLength) return false; // list is full, return failed
                    bool success = true;
                    int count = items.Length; // get count of items we want to add

                    // Check if there's enough space to add the items
                    int freeSpace = _MaxLength - _Length; // get free space remaining in the array
                    if(count > freeSpace) {
                        if(!allowPartialAdd) return false; // failed
                        count = freeSpace; // add only as many items as will fit
                        success = false; // flag a failure because we only filled it partially
                    }
                    for(int i = 0; i < count; i++) { // add the items to the array
                        list[_Length++] = items[i]; // add item to end of list
                    }
                    return success;
                }

                public int AddIfUnique(float item) {
                    int index = this.IndexOf(item);
                    if(index >= 0) return index;
                    return Add(item);
                }

                public bool Insert(int index, float item) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();
                    if(_Length == _MaxLength) return false; // list is full, return failed

                    int newLastIndex = _Length; // one larger than current

                    // Copy the entries forward in the list from end to insert point
                    for(int i = newLastIndex; i > index; i--) {
                        list[i] = list[i - 1]; // copy the lower entry into this higher space
                    }

                    // Store the item at the insert point
                    list[index] = item;

                    _Length++; // increase list size
                    return true;
                }

                public bool Remove(float item) {
                    if(_Length <= 0) return false; // no entries to search

                    int index = IndexOf(item); // find the item in the list
                    if(index < 0) return false; // not in list

                    RemoveAt(index); // remove the item
                    return true;
                }

                public void RemoveAt(int index) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();

                    int lastIndex = _Length - 1;

                    // Move entries after this one down
                    for(int i = index; i < lastIndex; i++) {
                        list[i] = list[i + 1]; // move the next entry into this space
                    }

                    // No need to clear the last entry

                    _Length--; // reduce size of the list
                }

                public bool Contains(float item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return true;
                    }
                    return false;
                }

                public int IndexOf(float item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return i;
                    }
                    return -1;
                }

                public void Clear() {
                    //System.Array.Clear(list, 0, _Length); // clear the data from the array
                    // No need to clear since there's no danger of object persistance
                    _Length = 0; // reset the filled count
                }
            }

            /// <summary>
            /// A fixed-length array that is more efficient because it only works on entries that have been filled.
            /// Type: bool
            /// </summary>
            public class Workpool_bool {
                private bool[] list;
                private int _Length; // acts as filled count
                private int _MaxLength; // the length of the internal array

                // Properties
                public int Length { get { return _Length; } }
                public int MaxLength { get { return _MaxLength; } }
                public int FreeSpace { get { return _MaxLength - _Length; } }

                public Workpool_bool(int maximumLength) {
                    list = new bool[maximumLength]; // create the list at maximum size
                    _Length = 0;
                    _MaxLength = maximumLength;
                }

                public bool this[int index] {
                    get {
                        if(index >= _Length) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                        return list[index];
                    }
                    set {
                        if(index > _Length) throw new System.IndexOutOfRangeException(); // prevent skipping of unassigned indices
                        list[index] = value;
                        if(index >= _Length) // we've added in an index at or higher than the filled count
                            _Length = index + 1; // increase the filled count
                    }
                }

                public int Add(bool item) {
                    if(_Length == _MaxLength) return -1; // list is full, return failed
                    this[_Length] = item; // add item to end of list
                    return _Length - 1; // return index of added item
                }

                public bool Add(bool[] items, bool allowPartialAdd = false) {
                    if(_Length == _MaxLength) return false; // list is full, return failed
                    bool success = true;
                    int count = items.Length; // get count of items we want to add

                    // Check if there's enough space to add the items
                    int freeSpace = _MaxLength - _Length; // get free space remaining in the array
                    if(count > freeSpace) {
                        if(!allowPartialAdd) return false; // failed
                        count = freeSpace; // add only as many items as will fit
                        success = false; // flag a failure because we only filled it partially
                    }
                    for(int i = 0; i < count; i++) { // add the items to the array
                        list[_Length++] = items[i]; // add item to end of list
                    }
                    return success;
                }

                public int AddIfUnique(bool item) {
                    int index = this.IndexOf(item);
                    if(index >= 0) return index;
                    return Add(item);
                }

                public bool Insert(int index, bool item) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();
                    if(_Length == _MaxLength) return false; // list is full, return failed

                    int newLastIndex = _Length; // one larger than current

                    // Copy the entries forward in the list from end to insert point
                    for(int i = newLastIndex; i > index; i--) {
                        list[i] = list[i - 1]; // copy the lower entry into this higher space
                    }

                    // Store the item at the insert point
                    list[index] = item;

                    _Length++; // increase list size
                    return true;
                }

                public bool Remove(bool item) {
                    if(_Length <= 0) return false; // no entries to search

                    int index = IndexOf(item); // find the item in the list
                    if(index < 0) return false; // not in list

                    RemoveAt(index); // remove the item
                    return true;
                }

                public void RemoveAt(int index) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();

                    int lastIndex = _Length - 1;

                    // Move entries after this one down
                    for(int i = index; i < lastIndex; i++) {
                        list[i] = list[i + 1]; // move the next entry into this space
                    }

                    // No need to clear the last entry

                    _Length--; // reduce size of the list
                }

                public bool Contains(bool item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return true;
                    }
                    return false;
                }

                public int IndexOf(bool item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return i;
                    }
                    return -1;
                }

                public void Clear() {
                    //System.Array.Clear(list, 0, _Length); // clear the data from the array
                    // No need to clear since there's no danger of object persistance
                    _Length = 0; // reset the filled count
                }
            }

            /// <summary>
            /// A fixed-length array that is more efficient because it only works on entries that have been filled.
            /// Type: Vector3
            /// </summary>
            public class Workpool_Vector3 {
                private Vector3[] list;
                private int _Length; // acts as filled count
                private int _MaxLength; // the length of the internal array

                // Properties
                public int Length { get { return _Length; } }
                public int MaxLength { get { return _MaxLength; } }
                public int FreeSpace { get { return _MaxLength - _Length; } }

                public Workpool_Vector3(int maximumLength) {
                    list = new Vector3[maximumLength]; // create the list at maximum size
                    _Length = 0;
                    _MaxLength = maximumLength;
                }

                public Vector3 this[int index] {
                    get {
                        if(index >= _Length) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                        return list[index];
                    }
                    set {
                        if(index > _Length) throw new System.IndexOutOfRangeException(); // prevent skipping of unassigned indices
                        list[index] = value;
                        if(index >= _Length) // we've added in an index at or higher than the filled count
                            _Length = index + 1; // increase the filled count
                    }
                }

                public int Add(Vector3 item) {
                    if(_Length == _MaxLength) return -1; // list is full, return failed
                    this[_Length] = item; // add item to end of list
                    return _Length - 1; // return index of added item
                }

                public bool Add(Vector3[] items, bool allowPartialAdd = false) {
                    if(_Length == _MaxLength) return false; // list is full, return failed
                    bool success = true;
                    int count = items.Length; // get count of items we want to add

                    // Check if there's enough space to add the items
                    int freeSpace = _MaxLength - _Length; // get free space remaining in the array
                    if(count > freeSpace) {
                        if(!allowPartialAdd) return false; // failed
                        count = freeSpace; // add only as many items as will fit
                        success = false; // flag a failure because we only filled it partially
                    }
                    for(int i = 0; i < count; i++) { // add the items to the array
                        list[_Length++] = items[i]; // add item to end of list
                    }
                    return success;
                }

                public int AddIfUnique(Vector3 item) {
                    int index = this.IndexOf(item);
                    if(index >= 0) return index;
                    return Add(item);
                }

                public bool Insert(int index, Vector3 item) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();
                    if(_Length == _MaxLength) return false; // list is full, return failed

                    int newLastIndex = _Length; // one larger than current

                    // Copy the entries forward in the list from end to insert point
                    for(int i = newLastIndex; i > index; i--) {
                        list[i] = list[i - 1]; // copy the lower entry into this higher space
                    }

                    // Store the item at the insert point
                    list[index] = item;

                    _Length++; // increase list size
                    return true;
                }

                public bool Remove(Vector3 item) {
                    if(_Length <= 0) return false; // no entries to search

                    int index = IndexOf(item); // find the item in the list
                    if(index < 0) return false; // not in list

                    RemoveAt(index); // remove the item
                    return true;
                }

                public void RemoveAt(int index) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();

                    int lastIndex = _Length - 1;

                    // Move entries after this one down
                    for(int i = index; i < lastIndex; i++) {
                        list[i] = list[i + 1]; // move the next entry into this space
                    }

                    // No need to clear the last entry

                    _Length--; // reduce size of the list
                }

                public bool Contains(Vector3 item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return true;
                    }
                    return false;
                }

                public int IndexOf(Vector3 item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return i;
                    }
                    return -1;
                }

                public void Clear() {
                    //System.Array.Clear(list, 0, _Length); // clear the data from the array
                    // No need to clear since there's no danger of object persistance
                    _Length = 0; // reset the filled count
                }
            }

            /// <summary>
            /// A fixed-length array that is more efficient because it only works on entries that have been filled.
            /// Type: object
            /// </summary>
            public class Workpool_object {
                private object[] list;
                private int _Length; // acts as filled count
                private int _MaxLength; // the length of the internal array

                // Properties
                public int Length { get { return _Length; } }
                public int MaxLength { get { return _MaxLength; } }
                public int FreeSpace { get { return _MaxLength - _Length; } }

                public Workpool_object(int maximumLength) {
                    list = new object[maximumLength]; // create the list at maximum size
                    _Length = 0;
                    _MaxLength = maximumLength;
                }

                public object this[int index] {
                    get {
                        if(index >= _Length) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                        return list[index];
                    }
                    set {
                        if(index > _Length) throw new System.IndexOutOfRangeException(); // prevent skipping of unassigned indices
                        list[index] = value;
                        if(index >= _Length) // we've added in an index at or higher than the filled count
                            _Length = index + 1; // increase the filled count
                    }
                }

                public int Add(object item) {
                    if(_Length == _MaxLength) return -1; // list is full, return failed
                    this[_Length] = item; // add item to end of list
                    return _Length - 1; // return index of added item
                }

                public bool Add(object[] items, bool allowPartialAdd = false) {
                    if(_Length == _MaxLength) return false; // list is full, return failed
                    bool success = true;
                    int count = items.Length; // get count of items we want to add

                    // Check if there's enough space to add the items
                    int freeSpace = _MaxLength - _Length; // get free space remaining in the array
                    if(count > freeSpace) {
                        if(!allowPartialAdd) return false; // failed
                        count = freeSpace; // add only as many items as will fit
                        success = false; // flag a failure because we only filled it partially
                    }
                    for(int i = 0; i < count; i++) { // add the items to the array
                        list[_Length++] = items[i]; // add item to end of list
                    }
                    return success;
                }

                public int AddIfUnique(object item) {
                    int index = this.IndexOf(item);
                    if(index >= 0) return index;
                    return Add(item);
                }

                public bool Insert(int index, object item) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();
                    if(_Length == _MaxLength) return false; // list is full, return failed

                    int newLastIndex = _Length; // one larger than current

                    // Copy the entries forward in the list from end to insert point
                    for(int i = newLastIndex; i > index; i--) {
                        list[i] = list[i - 1]; // copy the lower entry into this higher space
                    }

                    // Store the item at the insert point
                    list[index] = item;

                    _Length++; // increase list size
                    return true;
                }

                public bool Remove(object item) {
                    if(_Length <= 0) return false; // no entries to search

                    int index = IndexOf(item); // find the item in the list
                    if(index < 0) return false; // not in list

                    RemoveAt(index); // remove the item
                    return true;
                }

                public void RemoveAt(int index) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();

                    int lastIndex = _Length - 1;

                    // Move entries after this one down
                    for(int i = index; i < lastIndex; i++) {
                        list[i] = list[i + 1]; // move the next entry into this space
                    }

                    // Clear the last entry
                    list[lastIndex] = null; // clear the entry

                    _Length--; // reduce size of the list
                }

                public bool Contains(object item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return true;
                    }
                    return false;
                }

                public int IndexOf(object item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return i;
                    }
                    return -1;
                }

                public void Clear() {
                    System.Array.Clear(list, 0, _Length); // clear the data from the array
                    _Length = 0; // reset the filled count
                }
            }

            /// <summary>
            /// A Workpool which uses objects to hold data.
            /// Creates an object for every entry. These objects remain even when Clear is called, but the contents are cleared.
            /// Data is added by padding another instance of T object from which the contents are copied to the internal object.
            /// The passed object itself is not added, but objects contained in the passer object are stored by reference (not cloned).
            /// You cannot add objects to the list directly, only data witin the object.
            /// Your T must implement the Workpool_DataContainer<T>.IEntry interface.
            /// </summary>
            /// <typeparam name="T"></typeparam>
            public class Workpool_DataContainer<T> where T : class, Workpool_DataContainer<T>.IEntry, new() {

                public T injector; // an instance of T to use for data ferrying

                private T[] list;
                private int _Length; // acts as filled count
                private int _MaxLength; // the length of the internal array
                private bool clearData; // do we run the Clear() function in every object or not, not necessary for data types that only hold value data

                // Properties
                public int Length { get { return _Length; } }
                public int MaxLength { get { return _MaxLength; } }
                public int FreeSpace { get { return _MaxLength - _Length; } }

                public Workpool_DataContainer(int maximumLength, bool clearData = true) {
                    injector = new T();

                    list = new T[maximumLength]; // create the list at maximum size
                    _Length = 0;
                    _MaxLength = maximumLength;
                    this.clearData = clearData;

                    // instantiate the data container objects
                    for(int i = 0; i < _MaxLength; i++)
                        list[i] = new T();
                }

                public T this[int index] {
                    get {
                        if(index >= _Length) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                        return list[index];
                    }
                }

                // Methods for dealing with data in the objects

                public int Inject() {
                    int index = AddData(injector); // add data from built-in ferry object
                    if(clearData) injector.Clear(); // clear the injector after we inject in case objects are left in it
                    return index;
                }

                public int AddData(T item) {
                    if(_Length >= _MaxLength) return -1; // list is full, return failed

                    // add item to end of list and return the index
                    int index = _Length; // use the next space
                    list[index].Set(item); // store the data in the entry object

                    // we've added in an index at or higher than the filled count
                    _Length = index + 1; // increase the filled count

                    return index; // return the index we saved the data in
                }

                public bool ContainsData(T item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i].Equals(item)) return true;
                    }
                    return false;
                }

                public int IndexOfData(T item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i].Equals(item)) return i;
                    }
                    return -1;
                }

                public void Clear() {
                    if(clearData) { // clear the data from all objects using the Clear() method in the object
                        injector.Clear(); // clear the injector
                        for(int i = 0; i < _Length; i++) // clear the data from the objects
                            list[i].Clear(); // clear using the method defined in the object
                    }
                    _Length = 0; // reset the filled count
                }

                // Interfaces

                public interface IEntry {
                    void Set(T item);
                    bool Equals(T item);
                    void Clear();
                }
            }

            /// <summary>
            /// A fixed-length array that is more efficient because it only works on entries that have been filled.
            /// It behaves like a queue where older items scroll off the list as new ones are added.
            /// However, instead of pushing every item down in the list when an entry is added, we advance the
            /// current position each time and wrap back to 0 when the end is reached.
            /// </summary>
            /// <typeparam name="T"></typeparam>
            public class WorkQueue<T> {
                private T[] list;
                private int _Length; // acts as filled count
                private int _MaxLength; // the length of the internal array
                private int _Position;

                // Properties
                public int Length { get { return _Length; } }
                public int MaxLength { get { return _MaxLength; } }
                public int FreeSpace { get { return _MaxLength - _Length; } }
                public int Position { get { return _Position; } }

                public WorkQueue(int maximumLength) {
                    list = new T[maximumLength]; // create the list at maximum size
                    _Length = 0;
                    _MaxLength = maximumLength;
                    _Position = -1;
                }

                public T this[int index] {
                    get {
                        if(index >= _Length) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                        return list[index];
                    }
                    set {
                        if(index > _Length) throw new System.IndexOutOfRangeException(); // prevent skipping of unassigned indices
                        list[index] = value;
                        if(index >= _Length) // we've added in an index at or higher than the filled count
                            _Length = index + 1; // increase the filled count
                    }
                }

                public int Add(T item) {
                    this[AdvancePosition()] = item; // add item to list at next position
                    return _Position; // return index of added item
                }

                public int AddIfUnique(T item) {
                    int index = this.IndexOf(item);
                    if(index >= 0) return index;
                    return Add(item);
                }

                public bool Contains(T item) {
                    for(int i = 0; i < _Length; i++) {
                        if(EqualityComparer<T>.Default.Equals(list[i], item)) return true;
                    }
                    return false;
                }

                public int IndexOf(T item) {
                    for(int i = 0; i < _Length; i++) {
                        if(EqualityComparer<T>.Default.Equals(list[i], item)) return i;
                    }
                    return -1;
                }

                private int AdvancePosition() {
                    if(_Position + 1 >= _MaxLength) _Position = 0; // wrap back to beginning
                    else _Position++;
                    return _Position;
                }

                public void Clear() {
                    System.Array.Clear(list, 0, list.Length); // clear the data from the array
                    _Length = 0; // reset the filled count
                    _Position = -1; // reset position
                }
            }

            public class WorkQueue_Int {
                private int[] list;
                private int _Length; // acts as filled count
                private int _MaxLength; // the length of the internal array
                private int _Position;

                // Properties
                public int Length { get { return _Length; } }
                public int MaxLength { get { return _MaxLength; } }
                public int FreeSpace { get { return _MaxLength - _Length; } }
                public int Position { get { return _Position; } }

                public WorkQueue_Int(int maximumLength) {
                    list = new int[maximumLength]; // create the list at maximum size
                    _Length = 0;
                    _MaxLength = maximumLength;
                    _Position = -1;
                }

                public int this[int index] {
                    get {
                        if(index >= _Length) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                        return list[index];
                    }
                    set {
                        if(index > _Length) throw new System.IndexOutOfRangeException(); // prevent skipping of unassigned indices
                        list[index] = value;
                        if(index >= _Length) // we've added in an index at or higher than the filled count
                            _Length = index + 1; // increase the filled count
                    }
                }

                public int Add(int item) {
                    this[AdvancePosition()] = item; // add item to list at next position
                    return _Position; // return index of added item
                }

                public int AddIfUnique(int item) {
                    int index = this.IndexOf(item);
                    if(index >= 0) return index;
                    return Add(item);
                }

                public bool Contains(int item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return true;
                    }
                    return false;
                }

                public int IndexOf(int item) {
                    for(int i = 0; i < _Length; i++) {
                        if(list[i] == item) return i;
                    }
                    return -1;
                }

                private int AdvancePosition() {
                    if(_Position + 1 >= _MaxLength) _Position = 0; // wrap back to beginning
                    else _Position++;
                    return _Position;
                }

                public void Clear() {
                    System.Array.Clear(list, 0, list.Length); // clear the data from the array
                    _Length = 0; // reset the filled count
                    _Position = -1; // reset position
                }
            }

            /// <summary>
            /// A fixed-length list. New items are added at the end. When Process is called, the first item is taken out of the queue and the list collapsed.
            /// </summary>
            /// <typeparam name="T"></typeparam>
            public class Queue<T> {
                private T[] list;
                private int _Length; // acts as filled count
                private int _MaxLength; // the length of the internal array

                // Properties
                public int Length { get { return _Length; } }
                public int MaxLength { get { return _MaxLength; } }
                public int FreeSpace { get { return _MaxLength - _Length; } }

                public Queue(int maximumLength) {
                    list = new T[maximumLength]; // create the list at maximum size
                    _Length = 0;
                    _MaxLength = maximumLength;
                }

                public T this[int index] {
                    get {
                        if(index >= _Length) throw new System.IndexOutOfRangeException(); // make sure only assigned indices are accessed
                        return list[index];
                    }
                }

                public int Add(T item) {
                    if(_Length == _MaxLength) return -1; // no space in queue

                    int index = _Length;
                    list[index] = item;
                    _Length = _Length + 1; // increase the filled count

                    return index; // return index of added item
                }

                public int AddIfUnique(T item) {
                    int index = this.IndexOf(item);
                    if(index >= 0) return index;
                    return Add(item);
                }

                public bool Contains(T item) {
                    for(int i = 0; i < _Length; i++) {
                        if(EqualityComparer<T>.Default.Equals(list[i], item)) return true;
                    }
                    return false;
                }

                public int IndexOf(T item) {
                    for(int i = 0; i < _Length; i++) {
                        if(EqualityComparer<T>.Default.Equals(list[i], item)) return i;
                    }
                    return -1;
                }

                public void RemoveAt(int index) {
                    if(index < 0 || index >= _Length) throw new System.IndexOutOfRangeException();

                    int lastIndex = _Length - 1;

                    // Move entries after this one down
                    for(int i = index; i < lastIndex; i++) {
                        list[i] = list[i + 1]; // move the next entry into this space
                    }

                    // Clear the last entry
                    list[lastIndex] = default(T); // clear the entry

                    _Length--; // reduce size of the list
                }

                public bool Process(out T item) {
                    if(_Length == 0) {
                        item = default(T);
                        return false;
                    }
                    item = list[0];
                    RemoveAt(0); // remove the first entry and collapse list
                    return true;
                }

                public void Clear() {
                    System.Array.Clear(list, 0, list.Length); // clear the data from the array
                    _Length = 0; // reset the filled count
                }

            }

            #endregion

            [System.Serializable]
            public class SerializableULong {
                [SerializeField]
                private int ulong_32BitLow; // 1st 32 bits of long
                [SerializeField]
                private int ulong_32BitHigh; // 2nd 32 bits of long
                public ulong value {
                    get {
                        return ConvertIntsToLong(ulong_32BitLow, ulong_32BitHigh);
                    }
                    set {
                        ConvertLongToInts(value, out ulong_32BitLow, out ulong_32BitHigh);
                    }
                }

                public SerializableULong() { }

                public SerializableULong(SerializableULong sULong) { // used for cl
                    ulong_32BitLow = sULong.ulong_32BitLow;
                    ulong_32BitHigh = sULong.ulong_32BitHigh;
                }

                private void ConvertLongToInts(ulong int64, out int int32Low, out int int32High) {
                    int32Low = (int)(int64); // just get the high 32 bits, dropping the first 32 (low is on the right side of the bits)
                    int32High = (int)(int64 >> 32); // shift over so we get the high 32 bits in the low area (right) so int will take them
                }

                private ulong ConvertIntsToLong(int int32Low, int int32High) {
                    ulong int64_low = (ulong)int32Low; // converting will put the int32 bits into the low area (right side)
                    int64_low &= 0x00000000ffffffff; // wipe out any 111's on the left side (happens when we have a negative int 32 and convert to long)
                    ulong int64_high = (ulong)int32High << 32; // shift bits to left to put them in high position
                    return int64_low | int64_high; // or them together and we have the combined bits
                }

                public SerializableULong Clone() {
                    SerializableULong newSULong = new SerializableULong();
                    newSULong.ulong_32BitLow = ulong_32BitLow;
                    newSULong.ulong_32BitHigh = ulong_32BitHigh;
                    return newSULong;
                }
            }
        }

        #endregion

        #region // ARRAY TOOLS

        public static class ArrayTools {

            public static int[] ConvertToIntArray(System.Array array) {
                if(array == null || array.Length == 0) return null;
                int[] returnArray = new int[array.Length];
                IEnumerable eArray = (IEnumerable)array;
                int count = 0;
                foreach(object e in eArray) {
                    returnArray[count++] = System.Convert.ToInt32(e);
                }
                return returnArray;
            }

            static public byte[] CopyRange(byte[] inArray, int startPos, int length) {
                if(inArray == null || length < 1 || startPos < 0) return null;

                byte[] returnArray = new byte[length];
                for(int i = 0; i < length; i++) {
                    returnArray[i] = inArray[startPos + i];
                }
                return returnArray;
            }

            static public int[] CopyRange(int[] inArray, int startPos, int length) {
                if(inArray == null || length < 1 || startPos < 0) return null;

                int[] returnArray = new int[length];
                for(int i = 0; i < length; i++) {
                    returnArray[i] = inArray[startPos + i];
                }
                return returnArray;
            }

            static public float[] CopyRange(float[] inArray, int startPos, int length) {
                if(inArray == null || length < 1 || startPos < 0) return null;

                float[] returnArray = new float[length];
                for(int i = 0; i < length; i++) {
                    returnArray[i] = inArray[startPos + i];
                }
                return returnArray;
            }

            static public string[] CopyRange(string[] inArray, int startPos, int length) {
                if(inArray == null || length < 1 || startPos < 0) return null;

                string[] returnArray = new string[length];
                for(int i = 0; i < length; i++) {
                    returnArray[i] = inArray[startPos + i];
                }
                return returnArray;
            }

            static public byte[] Combine(byte[] inArray1, byte[] inArray2) {
                byte[] returnArray = null;
                int length1;
                int length2;

                if(inArray1 == null) length1 = 0;
                else length1 = inArray1.Length;
                if(inArray2 == null) length2 = 0;
                else length2 = inArray2.Length;
                if(length1 == 0 && length2 == 0) return returnArray;

                returnArray = new byte[length1 + length2];
                int count = 0;

                for(int i = 0; i < inArray1.Length; i++) {
                    returnArray[count] = inArray1[i];
                    count++;
                }
                for(int i = 0; i < inArray2.Length; i++) {
                    returnArray[count] = inArray2[i];
                    count++;
                }
                return returnArray;
            }

            static public int[] Combine(int[] inArray1, int[] inArray2) {
                int[] returnArray = null;
                int length1;
                int length2;

                if(inArray1 == null) length1 = 0;
                else length1 = inArray1.Length;
                if(inArray2 == null) length2 = 0;
                else length2 = inArray2.Length;
                if(length1 == 0 && length2 == 0) return returnArray;

                returnArray = new int[length1 + length2];
                int count = 0;

                for(int i = 0; i < inArray1.Length; i++) {
                    returnArray[count] = inArray1[i];
                    count++;
                }
                for(int i = 0; i < inArray2.Length; i++) {
                    returnArray[count] = inArray2[i];
                    count++;
                }
                return returnArray;
            }

            static public float[] Combine(float[] inArray1, float[] inArray2) {
                float[] returnArray = null;
                int length1;
                int length2;

                if(inArray1 == null) length1 = 0;
                else length1 = inArray1.Length;
                if(inArray2 == null) length2 = 0;
                else length2 = inArray2.Length;
                if(length1 == 0 && length2 == 0) return returnArray;

                returnArray = new float[length1 + length2];
                int count = 0;

                for(int i = 0; i < inArray1.Length; i++) {
                    returnArray[count] = inArray1[i];
                    count++;
                }
                for(int i = 0; i < inArray2.Length; i++) {
                    returnArray[count] = inArray2[i];
                    count++;
                }
                return returnArray;
            }

            static public string[] Combine(string[] inArray1, string[] inArray2) {
                string[] returnArray = null;
                int length1;
                int length2;

                if(inArray1 == null) length1 = 0;
                else length1 = inArray1.Length;
                if(inArray2 == null) length2 = 0;
                else length2 = inArray2.Length;
                if(length1 == 0 && length2 == 0) return returnArray;

                returnArray = new string[length1 + length2];
                int count = 0;

                for(int i = 0; i < inArray1.Length; i++) {
                    returnArray[count] = inArray1[i];
                    count++;
                }
                for(int i = 0; i < inArray2.Length; i++) {
                    returnArray[count] = inArray2[i];
                    count++;
                }
                return returnArray;
            }

            static public T[] ParseArray<T>(string line) {
                line = line.Replace("{", "");
                line = line.Replace("}", "");
                string[] values = line.Split(',');
                T[] returnVal = new T[values.Length];
                int valueCount = values.Length;

                // Check for null array
                if(valueCount == 1) {
                    string value = values[0].Trim().ToLower();
                    if(value == "" || value == "null")
                        return null;
                }

                // Get convert values to array
                for(int i = 0; i < valueCount; i++) {
                    string value = values[i].Trim();
                    returnVal[i] = (T)System.Convert.ChangeType(value, typeof(T));
                }
                return returnVal;
            }

            static public T[] SortAscending<T>(T[] array, out int[] sortedIndices) where T : System.IComparable<T> {
                if(array == null) {
                    sortedIndices = null;
                    return null; // invalid
                }
                int arrayLength = array.Length;
                if(arrayLength == 0) {
                    sortedIndices = new int[0];
                    return array; // just return the same array
                } else if(arrayLength == 1) {
                    sortedIndices = new int[1] { 0 };
                    return array; // just return the same array
                }

                T[] sortedValues = new T[arrayLength];
                sortedIndices = new int[arrayLength];
                bool[] alreadySorted = new bool[arrayLength];

                // Sort
                for(int i = 0; i < arrayLength; i++) {
                    T lowestValue = default(T);
                    int lowestIndex = -1;
                    for(int j = 0; j < arrayLength; j++) {
                        if(alreadySorted[j]) continue; // skip indices we've already sorted
                        T value = array[j];
                        if(lowestIndex == -1 || value.CompareTo(lowestValue) < 0) {
                            lowestValue = value;
                            lowestIndex = j;
                        }
                    }
                    sortedValues[i] = lowestValue;
                    sortedIndices[i] = lowestIndex; // store the old index of the lowest
                    alreadySorted[lowestIndex] = true; // flag it so we don't count it again
                }
                return sortedValues;
            }

            static public T[] SortDescending<T>(T[] array, out int[] sortedIndices, bool ascending = true) where T : System.IComparable<T> {
                if(array == null) {
                    sortedIndices = null;
                    return null; // invalid
                }
                int arrayLength = array.Length;
                if(arrayLength == 0) {
                    sortedIndices = new int[0];
                    return array; // just return the same array
                } else if(arrayLength == 1) {
                    sortedIndices = new int[1] { 0 };
                    return array; // just return the same array
                }

                T[] sortedValues = new T[arrayLength];
                sortedIndices = new int[arrayLength];
                bool[] alreadySorted = new bool[arrayLength];

                for(int i = 0; i < arrayLength; i++) {
                    T lowestValue = default(T);
                    int lowestIndex = -1;
                    for(int j = 0; j < arrayLength; j++) {
                        if(alreadySorted[j]) continue; // skip indices we've already sorted
                        T value = array[j];
                        if(lowestIndex == -1 || value.CompareTo(lowestValue) < 0) {
                            lowestValue = value;
                            lowestIndex = j;
                        }
                    }
                    sortedValues[i] = lowestValue;
                    sortedIndices[i] = lowestIndex; // store the old index of the lowest
                    alreadySorted[lowestIndex] = true; // flag it so we don't count it again
                }
                return sortedValues;
            }

            static public int Add<T>(ref T[] array, T item) {
                int oldSize;
                if(array == null) oldSize = 0;
                else oldSize = array.Length;
                int newSize = oldSize + 1;
                T[] newArray = new T[newSize];
                int i;
                for(i = 0; i < oldSize; i++) {
                    newArray[i] = (T)array[i];
                }
                newArray[i] = item; // insert new item into last space
                array = newArray; // replace array
                return i;
            }

            static public int AddIfUnique<T>(ref T[] array, T item) {
                if(array == null || array.Length == 0 || !Contains<T>(array, item)) return Add<T>(ref array, item);
                return -1; // already in list
            }

            static public int Insert<T>(ref T[] array, int index, T item) {
                if(index < 0) index = 0;
                int oldSize;
                if(array == null) oldSize = 0;
                else oldSize = array.Length;
                int lastIndex = oldSize - 1;
                if(index > lastIndex) { // inserting past end of array, just do an add instead
                    return Add<T>(ref array, item);
                }

                int newSize = oldSize + 1;
                T[] newArray = new T[newSize];
                int i;
                for(i = 0; i < index; i++) { // copy half up to new insertion
                    newArray[i] = array[i];
                }
                newArray[i] = item; // insert the new item
                int count = index;
                for(i = i + 1; i < newSize; i++) { // copy second half
                    newArray[i] = array[count];
                    count++;
                }
                array = newArray; // replace array
                return index;
            }

            static public bool RemoveAt<T>(ref T[] array, int index) {
                if(array == null) return false;
                if(index < 0) index = 0;
                int oldSize = array.Length;
                int lastIndex = oldSize - 1;
                if(index > lastIndex) index = lastIndex;

                int newSize = oldSize - 1;
                T[] newArray = new T[newSize];
                int i;
                for(i = 0; i < index; i++) { // copy half up to removal
                    newArray[i] = array[i];
                }
                for(i = index + 1; i < oldSize; i++) { // copy second half skipping removal
                    newArray[i - 1] = array[i];
                }
                array = newArray; // replace array
                return true;
            }

            static public bool Remove<T>(ref T[] array, T item) { // remove the first instance found only
                if(array == null) return false;
                for(int i = 0; i < array.Length; i++) {
                    if(object.Equals(array[i], item)) {
                        RemoveAt(ref array, i);
                        return true;
                    }
                }
                return false;
            }

            static public void Combine<T>(ref T[] array1, T[] array2) {
                if(array1 == null) {
                    if(array2 == null) return; // nothing to append, just leave array 1 alone
                    array1 = (T[])array2.Clone(); // just return a clone of array 2
                    return;
                } else if(array1.Length == 0) {
                    if(array2 == null || array2.Length == 0) return; // nothing to append, just leave array 1 alone
                }
                if(array2 == null || array2.Length == 0) return;

                int a1Length = array1.Length;
                int a2Length = array2.Length;
                int totalSize = a1Length + a2Length;
                T[] newArray = new T[totalSize];
                int count = 0;

                for(int i = 0; i < a1Length; i++) // copy array 1 data
                    newArray[count++] = array1[i];

                for(int i = 0; i < a2Length; i++) // copy array 2 data
                    newArray[count++] = array2[i];

                array1 = newArray; // replace array
            }

            static public int IndexOf<T>(T[] array, T item) {
                if(array == null) return -1;
                for(int i = 0; i < array.Length; i++) {
                    if(object.Equals(array[i], item)) return i;
                }
                return -1;
            }

            static public bool Contains<T>(T[] array, T item) {
                if(array == null) return false;
                for(int i = 0; i < array.Length; i++) {
                    if(object.Equals(array[i], item)) return true;
                }
                return false;
            }

            static public T[] Clone<T>(T[] array) {
                if(array == null) return null;
                return (T[])array.Clone();
            }

            static public void Trim(string[] array) {
                if(array == null) return;
                int length = array.Length;
                if(length == 0) return;

                for(int i = 0; i < length; i++) {
                    array[i].Trim();
                }
            }

            static public RaycastHit[] SortNearToFar(RaycastHit[] hits) {
                int hitCount = hits.Length;
                if(hits == null || hitCount == 0) return null;

                float[] distTemp = new float[hitCount];
                int[] sortedDistancesIndices = new int[hitCount];

                // First get all the distances into an array for working
                for(int i = 0; i < hitCount; i++)
                    distTemp[i] = hits[i].distance;

                // Sort lowest to highest distance
                for(int i = 0; i < hitCount; i++) {
                    // Find the lowest distance
                    bool firstRun = true;
                    float lowestDistance = -1.0f;
                    int lowestIndex = -1;

                    for(int j = 0; j < hitCount; j++) {
                        float dist = distTemp[j];
                        if(dist < 0.0f) continue; // skip empty spaces
                        if(firstRun || dist < lowestDistance) {
                            if(firstRun) firstRun = false; // clear flag
                            lowestDistance = dist;
                            lowestIndex = j;
                        }
                    }
                    sortedDistancesIndices[i] = lowestIndex; // store the index of the lowest
                    distTemp[lowestIndex] = -1.0f; // clear the space so we don't count it again
                }

                // Create sorted array of raycast hits
                RaycastHit[] sortedHits = new RaycastHit[hitCount];
                for(int i = 0; i < hitCount; i++) {
                    sortedHits[i] = hits[sortedDistancesIndices[i]];
                }

                return sortedHits;
            }

            static public void MoveEntryUp<T>(T[] array, int index) {
                if(array == null) return;
                int size = array.Length;
                if(size <= 1) return;
                if(index <= 0 || index >= size) return;

                int newIndex = index - 1;
                T temp = array[newIndex];
                array[newIndex] = array[index];
                array[index] = temp;
            }

            static public void MoveEntryDown<T>(T[] array, int index) {
                if(array == null) return;
                int size = array.Length;
                if(size <= 1) return;
                if(index < 0 || index >= size - 1) return;

                int newIndex = index + 1;
                T temp = array[newIndex];
                array[newIndex] = array[index];
                array[index] = temp;
            }

            static public void Compact<T>(ref T[] array) where T : class { // only works with nullable classes
                if(array == null || array.Length == 0) return;

                T[] newArray = null;
                for(int i = 0; i < array.Length; i++) {
                    if(array[i] == null) continue;
                    Add<T>(ref newArray, array[i]);
                }
                array = newArray;
            }

            // String arrays

            static public bool Contains(string[] array, string item, bool ignoreCase) {
                if(array == null) return false;
                if(ignoreCase) item = item.ToLower();
                for(int i = 0; i < array.Length; i++) {
                    if(ignoreCase) {
                        if(array[i].ToLower() == item) return true;
                    } else {
                        if(array[i] == item) return true;
                    }
                }
                return false;
            }

            static public int AddIfUnique(ref string[] array, string item, bool ignoreCase) {
                if(array == null || array.Length == 0 || !Contains(array, item, ignoreCase)) return Add<string>(ref array, item);
                return -1; // already in list
            }

            static public void RemoveDuplicates(ref string[] array, bool ignoreCase) {
                if(array == null || array.Length == 0) return;

                string[] newArray = null;
                for(int i = 0; i < array.Length; i++) {
                    AddIfUnique(ref newArray, array[i], ignoreCase);
                }
                array = newArray; // replace array
            }

            static public bool Remove(ref string[] array, string item, bool ignoreCase) { // remove the first instance found only
                if(array == null) return false;

                if(item == null) {
                    for(int i = 0; i < array.Length; i++) {
                        if(array[i] == null) {
                            RemoveAt(ref array, i);
                            return true;
                        }
                    }

                } else {

                    for(int i = 0; i < array.Length; i++) {
                        if(ignoreCase) {
                            if(array[i] != null && array[i].ToLower() == item.ToLower()) {
                                RemoveAt(ref array, i);
                                return true;
                            }
                        } else {
                            if(array[i] == item) {
                                RemoveAt(ref array, i);
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
        }

        #endregion

        #region // STRING TOOLS

        public static class StringTools {

            private static string stripFileNameCharsString;

            static StringTools() {
                char[] invalidChars = System.IO.Path.GetInvalidFileNameChars();
                stripFileNameCharsString = System.Text.RegularExpressions.Regex.Escape(new string(invalidChars));
            }

            public static string CleanUpName(string name) {
                name = name.Trim();
                string illegalChars = @"[ ~`,:;'\.\$\^\{\}\[\]\(\|\)\*\+\?\\" + stripFileNameCharsString + "]";
                name = System.Text.RegularExpressions.Regex.Replace(name, illegalChars, "_"); // replace illegal chars with underscore
                return name;
            }

            public static string StripTrailingNumbers(string name) {
                int waste;
                return StripTrailingNumbers(name, out waste);
            }

            public static string StripTrailingNumbers(string name, out int number) {
                System.Text.RegularExpressions.Match match = System.Text.RegularExpressions.Regex.Match(name, "[0-9]+$");
                if(!match.Success) { // no numbers at end of name
                    number = -1;
                    return name;
                }
                // convert number string to int
                if(!System.Int32.TryParse(match.Value, out number)) { throw new System.Exception("Could not parse string to Int32! " + match.Value); }
                int index = match.Index;
                if(index == 0) { // name is all numbers
                    return "";
                }
                return name.Substring(0, index); // return prefix
            }

            public static string VerifyName(string name, int indexInNameList, string[] names) {
                name = Utils.StringTools.CleanUpName(name);
                if(name == "") name = "0"; // make sure name cannot be blank

                if(names == null || names.Length == 0) return name; // no names to compare to

                // make sure name isn't already in use by any of the sets
                string lcaseName = name.ToLower();
                for(int i = 0; i < names.Length; i++) {
                    if(i == indexInNameList) continue; // don't check against self
                    if(names[i] == null) continue; // skip nulls
                    if(lcaseName == names[i].ToLower()) { // name already exists in set!
                        return IterateName(name, indexInNameList, names); // find the next increment for this name and return it
                    }
                }
                return name; // name was ok
            }

            public static string IterateName(string name, int indexInNameList = -1, string[] names = null) {
                int inNumberSuffix;
                string inNamePrefix = Utils.StringTools.StripTrailingNumbers(name, out inNumberSuffix);

                if(names != null) { // iterate to next number available in list
                    string inNamePrefixLCase = inNamePrefix.ToLower();
                    int newNumber = -1;
                    for(int i = 0; i < names.Length; i++) {
                        if(i == indexInNameList) continue; // don't check against self
                        if(names[i] == null) continue; // skip nulls

                        int numberSuffix;
                        string namePrefixLCase = names[i].ToLower();
                        namePrefixLCase = Utils.StringTools.StripTrailingNumbers(namePrefixLCase, out numberSuffix);
                        if(inNamePrefixLCase == namePrefixLCase && numberSuffix > newNumber) { // names match and there is a suffix
                            newNumber = numberSuffix; // record highest number found
                        }
                    }
                    newNumber++; // increment to one after highest found
                    return inNamePrefix + newNumber;
                } else { // no names list, just iterate the number
                    return inNamePrefix + (inNumberSuffix + 1); // add one to starting number
                }
            }

            public static string ToString(Rect rect) {
                return string.Format("{0}, {1}, {2}, {3}", rect.x, rect.y, rect.width, rect.height);
            }
        }

        #endregion

        #region // MATH TOOLS

        public class MathTools {

            private const float nearThreshold = 0.0001f;

            static public float ClampAngle360(float angle) { // Convert a euler angle in degrees to 0 - <+360
                float absAngle = Mathf.Abs(angle);
                if(absAngle >= 360.0f) {
                    float amount = absAngle / 360.0f;
                    float whole = Mathf.Floor(amount);
                    amount -= whole; // all we're left with is the decimals
                    if(amount == 0.0f) // evenly divisble so its 0
                        return 0.0f;
                    else if(amount > 0.0f) { // number was not evenly divisible by 360.0f
                        float remaining = absAngle - (whole * 360.0f); // get degrees remaining
                        angle = remaining * Mathf.Sign(angle); // convert to negative if angle was negative
                    }
                }
                if(angle < 0.0f) // convert negatives to positive angles
                    angle = 360.0f + angle;
                return angle;
            }

            static public float ReverseAngleRotationDirection(float angle) { // keep the same absolute direction, but change the rotation direction
                if(angle == 0.0f) return 180.0f;
                if(angle == 180.0f) return 0.0f;
                return 360.0f - angle + 180.0f;
            }

            static public bool RectContains(Rect rect, Vector2 pos, float rotation = 0.0f) {
                if(rotation == 0.0f) return rect.Contains(pos); // not rotated, done

                // Rect is rotated
                // rotate the point in the opposite direction around the rect center
                Vector2 unrotatedPoint = RotateWorldPoint(pos, rect.center, -rotation);

                // Compare to original unrotated rect
                return rect.Contains(unrotatedPoint);
            }

            static public Vector2 RotateWorldPoint(Vector2 point, Vector2 center, float angle) {
                // Get point as a vector relative to center
                float x = point.x - center.x;
                float y = point.y - center.y;

                // Rotate
                float theta = Mathf.Deg2Rad * ClampAngle360(angle);
                float cs = Mathf.Cos(theta);
                float sn = Mathf.Sin(theta);
                float px = x * cs - y * sn;
                float py = x * sn + y * cs;

                // Convert the point back to absolute position
                return new Vector2(center.x + px, center.y + py);
            }

            static public Vector2 RotateLocalPoint(Vector2 point, float angle) {
                float x = point.x;
                float y = point.y;

                // Rotate
                float theta = Mathf.Deg2Rad * ClampAngle360(angle);
                float cs = Mathf.Cos(theta);
                float sn = Mathf.Sin(theta);
                float px = x * cs - y * sn;
                float py = x * sn + y * cs;

                return new Vector2(px, py);
            }

            static public bool IsNearOrWholeNumber(float value, float threshold = nearThreshold) {
                float absValue = Mathf.Abs(value);
                if(Mathf.Ceil(absValue) - absValue <= threshold) return true;
                return false;
            }

            static public float RoundOffIfNearWholeNumber(float value, float threshold = nearThreshold) {
                if(IsNearOrWholeNumber(value)) return Mathf.Round(value);
                return value;
            }
        }

        #endregion

        #region // REFLECTION
        /* // CANNOT INCLUDE THESE BECAUSE WINDOWS 8 APP STORE COMPILE CHOKES ON REFLECTION
        public static class Reflection {
            public static bool TypeExists(string className) {
                System.Reflection.Assembly[] assemblies = System.AppDomain.CurrentDomain.GetAssemblies();
                for(int i = 0; i < assemblies.Length; i++) {
                    if(assemblies[i].GetType().Name == className) return true;
                }
                return false;
            }

            public static System.Type GetType(string className) {
                System.Reflection.Assembly[] assemblies = System.AppDomain.CurrentDomain.GetAssemblies();
                for(int i = 0; i < assemblies.Length; i++) {
                    System.Type type = assemblies[i].GetType();
                    if(type.Name == className) return type;
                }
                return null;
            }

            public static bool ConvertEnum<TEnum>(TEnum enumA, string enumTypeB, out int enumAIntValue) where TEnum : struct, System.IConvertible, System.IComparable, System.IFormattable {
                if(!typeof(TEnum).IsEnum) throw new System.ArgumentException("T must be an enumerated type");

                System.Type reflType;

                reflType = SpriteFactory.Utils.Reflection.GetType(enumTypeB);
                if(reflType == null) throw new System.Exception("No Enum named " + enumTypeB + " found in the assemblies!");
                if(!reflType.IsEnum) throw new System.Exception("Class " + enumTypeB + " is not type System.Enum!");

                string[] reflNames = System.Enum.GetNames(reflType);

                int index = System.Array.IndexOf(reflNames, enumA.ToString());
                if(index < 0) { // no equivalent name found
                    enumAIntValue = 0;
                    return false;
                }

                enumAIntValue = (int)System.Enum.Parse(reflType, reflNames[index]);
                return true;
            }

            public static bool ConvertEnum<TEnum>(string enumTypeA, object enumValueA, out object enumBValue) where TEnum : struct, System.IConvertible, System.IComparable, System.IFormattable {
                if(!typeof(TEnum).IsEnum) throw new System.ArgumentException("T must be an enumerated type");

                System.Type reflType;

                reflType = SpriteFactory.Utils.Reflection.GetType(enumTypeA);
                if(reflType == null) throw new System.Exception("No Enum named " + enumTypeA + " found in the assemblies!");
                if(!reflType.IsEnum) throw new System.Exception("Class " + enumTypeA + " is not type System.Enum!");

                // Find the name of the value

                // Find the value in the reflected list first
                System.Array reflValues = System.Enum.GetValues(reflType);
                IEnumerable enumerable = (IEnumerable)reflValues;
                int count = 0;
                int valueIndex = -1;
                if(enumerable != null) {
                    foreach(object value in enumerable) {
                        if(object.Equals(value, enumValueA)) {
                            valueIndex = count;
                            break;
                        }
                        count++;
                    }
                }
                if(valueIndex == -1) { // value not found
                    enumBValue = null;
                    return false;
                }

                // Now get the name
                string[] reflNames = System.Enum.GetNames(typeof(TEnum));
                string reflEnumValueName = reflNames[valueIndex];

                // See if known enum list has the name
                string[] knownNames = System.Enum.GetNames(typeof(TEnum));
                int reflNameInKnownIndex = System.Array.IndexOf(knownNames, reflEnumValueName);
                if(reflNameInKnownIndex == -1) { // no equivalent name found
                    enumBValue = null;
                    return false;
                }

                enumBValue = System.Enum.Parse(reflType, reflEnumValueName);
                return true;
            }
        }
        */
        #endregion

        #region // ENUM TOOLS

        public static class EnumTools {

            public static string GetName<TEnum>(TEnum value) where TEnum : struct, System.IConvertible, System.IComparable, System.IFormattable {
                // Can no longer check if is type enum because Windows 8 Store does not have type.isEnum. Moved to TypeInfo.isEnum which does not exist in 3.5! No way to wrap this!
                //if(!typeof(TEnum).IsEnum) throw new System.ArgumentException("TEnum must be an enumerated type");
                try {
                    return System.Enum.GetName(typeof(TEnum), value);
                } catch {
                    return null;
                }
            }

            public static bool ConvertByName<TEnumFrom, TEnumTo>(TEnumFrom convertFrom, out TEnumTo value)
                where TEnumFrom : struct, System.IConvertible, System.IComparable, System.IFormattable
                where TEnumTo : struct, System.IConvertible, System.IComparable, System.IFormattable {

                // Can no longer check if is type enum because Windows 8 Store does not have type.isEnum. Moved to TypeInfo.isEnum which does not exist in 3.5! No way to wrap this!
                //if(!typeof(TEnumFrom).IsEnum) throw new System.ArgumentException("TEnumFrom must be an enumerated type");
                //if(!typeof(TEnumTo).IsEnum) throw new System.ArgumentException("TEnum must be an enumerated type");

                string[] convertToNames = System.Enum.GetNames(typeof(TEnumTo));

                int index = System.Array.IndexOf(convertToNames, convertFrom.ToString());
                if(index < 0) { // no equivalent name found
                    value = default(TEnumTo);
                    return false;
                }

                value = (TEnumTo)System.Enum.Parse(typeof(TEnumTo), convertToNames[index]);
                return true;
            }

            public static int[] GetIntValues(System.Type enumType) {
                // Can no longer check if is type enum because Windows 8 Store does not have type.isEnum. Moved to TypeInfo.isEnum which does not exist in 3.5! No way to wrap this!
                //if(!enumType.IsEnum) throw new System.ArgumentException("enumType must be an enumerated type");
                return SpriteFactory.Utils.ArrayTools.ConvertToIntArray(System.Enum.GetValues(enumType));
            }

            public static int GetColorChannelIndex(SpriteFactory.Enums.TransparencyChannel channel) {
                int index;
                if(channel == SpriteFactory.Enums.TransparencyChannel.Alpha) index = 3;
                else if(channel == SpriteFactory.Enums.TransparencyChannel.Red) index = 0;
                else if(channel == SpriteFactory.Enums.TransparencyChannel.Green) index = 1;
                else if(channel == SpriteFactory.Enums.TransparencyChannel.Blue) index = 2;
                else index = -1;
                return index;
            }
        }

        #endregion

        #region // UNITY TOOLS

        public static class UnityTools {

            // Determine the Unity version in a way we can compare if current version is newer or older
            public enum UnityVersion {
                UNITY_2_6 = 0,
                UNITY_2_6_1 = 1,
                UNITY_3_0 = 2,
                UNITY_3_0_0 = 3,
                UNITY_3_1 = 4,
                UNITY_3_2 = 5,
                UNITY_3_3 = 6,
                UNITY_3_4 = 7,
                UNITY_3_5 = 8,
                UNITY_3_5_2 = 9,
                UNITY_3_5_7 = 10,
                UNITY_4_0 = 11,
                UNITY_4_0_1 = 12,
                UNITY_4_1 = 13,
                UNITY_4_2 = 14,
                UNITY_4_3 = 15,
                UNITY_4_4 = 16,
                UNITY_4_5 = 17,
                UNITY_4_6 = 18,
                UNITY_4_7 = 19,
                UNITY_4_8 = 20,
                UNITY_4_9 = 21,
                UNITY_5_0 = 22,
                UNITY_5_1 = 23,
                UNITY_5_2 = 24,
                UNITY_5_3 = 25,
                UNITY_5_4 = 26,
                UNITY_5_5 = 27,
                UNITY_5_6 = 28,
                UNITY_5_7 = 29,
                UNITY_5_8 = 30,
                UNITY_5_9 = 31,
                UNITY_6_0 = 32,
                UNITY_6_1 = 33,
                UNITY_6_2 = 34,
                UNITY_6_3 = 35,
                UNITY_6_4 = 36,
                UNITY_6_5 = 37,
                UNITY_6_6 = 38,
                UNITY_6_7 = 39,
                UNITY_6_8 = 40,
                UNITY_6_9 = 41,
                UNITY_7_0 = 42,

                Unknown = 1000
            }

            private static UnityVersion _unityVersion = UnityVersion.Unknown;
            public static UnityVersion unityVersion { get { return _unityVersion; } }
            private static bool _isSupportedVersion3;
            private static bool _isSupportedVersion4;

            public static bool isSupportedVersion3 { get { return _isSupportedVersion3; } }
            public static bool isSupportedVersion4 { get { return _isSupportedVersion4; } }
            public static bool supports2DColliders { get { return _unityVersion >= UnityVersion.UNITY_4_3; } }
            public static bool supportsSortingLayers { get { return _unityVersion >= UnityVersion.UNITY_4_3; } }

            public static bool supports2DIgnoreCollisions { get { return _unityVersion >= UnityVersion.UNITY_4_5; } }

            static UnityTools() { // static constructor - runs the first time any method is called in this class
                GetUnityVersion(); // get the unity version
            }

            private static void GetUnityVersion() {
                _unityVersion = DetermineUnityVersion(); // determine the version of unity running

                // Set supported flags
                if(_unityVersion >= UnityVersion.UNITY_3_5 && _unityVersion < UnityVersion.UNITY_4_0) { // unity 3.5 to 3.5.7
                    _isSupportedVersion3 = true;
                } else if(_unityVersion >= UnityVersion.UNITY_4_0) { // Unity 4.0 or greater
                    _isSupportedVersion4 = true;
                }

                // Check version and error
                if(_unityVersion < UnityVersion.UNITY_3_5)
                    throw new System.Exception(string.Format("Unity version {0} is not supported! Sprite Factory supports Unity 3.5.0 or higher.", Application.unityVersion));
            }

            private static UnityVersion DetermineUnityVersion() {
                // Determine unity version from the version string
                string[] split = Application.unityVersion.Split(new char[1] { '.' });
                if(split.Length >= 2) {
                    int majorVersion;
                    int minorVersion;
                    int revision = -1;
                    int.TryParse(split[0], out majorVersion);
                    int.TryParse(split[1], out minorVersion);
                    if(split.Length >= 3) {
                        if(split[2] != string.Empty) {
                            string firstChar = "" + split[2][0]; // get the first char from the 3rd piece
                            int.TryParse(firstChar, out revision);
                        }
                    }

                    if(majorVersion == 2) {
                        if(minorVersion == 6) {
                            if(revision == 1)
                                return UnityVersion.UNITY_2_6_1;
                            else
                                return UnityVersion.UNITY_2_6;
                        }
                    } else if(majorVersion == 3) {
                        if(minorVersion == 0) {
                            if(revision == 0)
                                return UnityVersion.UNITY_3_0_0;
                            else
                                return UnityVersion.UNITY_3_0;
                        } else if(minorVersion == 1) {
                            return UnityVersion.UNITY_3_1;
                        } else if(minorVersion == 2) {
                            return UnityVersion.UNITY_3_2;
                        } else if(minorVersion == 3) {
                            return UnityVersion.UNITY_3_3;
                        } else if(minorVersion == 4) {
                            return UnityVersion.UNITY_3_4;
                        } else if(minorVersion == 5) {
                            if(revision == 2) return UnityVersion.UNITY_3_5_2;
                            else if(revision == 7) return UnityVersion.UNITY_3_5_7;
                            return UnityVersion.UNITY_3_5;
                        } else {
                            return UnityVersion.UNITY_3_5_7; // default to 3.5.7 in case there are more releases
                        }
                    } else if(majorVersion == 4) {
                        if(minorVersion == 0) {
                            if(revision == 1) {
                                return UnityVersion.UNITY_4_0_1;
                            } else {
                                return UnityVersion.UNITY_4_0;
                            }
                        } else if(minorVersion == 1) {
                            return UnityVersion.UNITY_4_1;
                        } else if(minorVersion == 2) {
                            return UnityVersion.UNITY_4_2;
                        } else if(minorVersion == 3) {
                            return UnityVersion.UNITY_4_3;
                        } else if(minorVersion == 4) {
                            return UnityVersion.UNITY_4_4;
                        } else if(minorVersion == 5) {
                            return UnityVersion.UNITY_4_5;
                        } else if(minorVersion == 6) {
                            return UnityVersion.UNITY_4_6;
                        } else if(minorVersion == 7) {
                            return UnityVersion.UNITY_4_7;
                        } else if(minorVersion == 8) {
                            return UnityVersion.UNITY_4_8;
                        } else if(minorVersion == 9) {
                            return UnityVersion.UNITY_4_9;
                        } else {
                            return UnityVersion.UNITY_4_0;
                        }
                    } else if(majorVersion == 5) {
                        if(minorVersion == 0) {
                            return UnityVersion.UNITY_5_0;
                        } else if(minorVersion == 1) {
                            return UnityVersion.UNITY_5_1;
                        } else if(minorVersion == 2) {
                            return UnityVersion.UNITY_5_2;
                        } else if(minorVersion == 3) {
                            return UnityVersion.UNITY_5_3;
                        } else if(minorVersion == 4) {
                            return UnityVersion.UNITY_5_4;
                        } else if(minorVersion == 5) {
                            return UnityVersion.UNITY_5_5;
                        } else if(minorVersion == 6) {
                            return UnityVersion.UNITY_5_6;
                        } else if(minorVersion == 7) {
                            return UnityVersion.UNITY_5_7;
                        } else if(minorVersion == 8) {
                            return UnityVersion.UNITY_5_8;
                        } else if(minorVersion == 9) {
                            return UnityVersion.UNITY_5_9;
                        } else {
                            return UnityVersion.UNITY_5_0;
                        }
                    } else if(majorVersion == 6) {
                        if(minorVersion == 0) {
                            return UnityVersion.UNITY_6_0;
                        } else if(minorVersion == 1) {
                            return UnityVersion.UNITY_6_1;
                        } else if(minorVersion == 2) {
                            return UnityVersion.UNITY_6_2;
                        } else if(minorVersion == 3) {
                            return UnityVersion.UNITY_6_3;
                        } else if(minorVersion == 4) {
                            return UnityVersion.UNITY_6_4;
                        } else if(minorVersion == 6) {
                            return UnityVersion.UNITY_6_5;
                        } else if(minorVersion == 6) {
                            return UnityVersion.UNITY_6_6;
                        } else if(minorVersion == 7) {
                            return UnityVersion.UNITY_6_7;
                        } else if(minorVersion == 8) {
                            return UnityVersion.UNITY_6_8;
                        } else if(minorVersion == 9) {
                            return UnityVersion.UNITY_6_9;
                        } else {
                            return UnityVersion.UNITY_6_0;
                        }
                    }
                }
                return UnityVersion.Unknown;
            }

            public static System.Type GetVersionRestrictedType(Enums.VersionRestrictedType type) {
                if(_unityVersion >= UnityVersion.UNITY_4_3) {
                    return GetVersionRestrictedType_U43(type);
                }
                return null;
            }

            private static System.Type GetVersionRestrictedType_U43(Enums.VersionRestrictedType type) {
                if(type == Enums.VersionRestrictedType.RigidbodyInterpolation2D) {
                    return typeof(RigidbodyInterpolation2D);
                } else if(type == Enums.VersionRestrictedType.RigidbodySleepMode2D) {
                    return typeof(RigidbodySleepMode2D);
                } else if(type == Enums.VersionRestrictedType.CollisionDetectionMode2D) {
                    return typeof(CollisionDetectionMode2D);
                } else if(type == Enums.VersionRestrictedType.PhysicsMaterial2D) {
                    return typeof(PhysicsMaterial2D);
                } else if(type == Enums.VersionRestrictedType.Collider2D) {
                    return typeof(Collider2D);
                }
                return null;
            }

            public static void FailIfNo2DSupport() {
                if(_unityVersion >= UnityVersion.UNITY_4_3) return;
                throw new System.Exception("2D colliders are not supported in this version of Unity. You must use Unity 4.3+.");
            }

            public static void SetActiveRecursively(GameObject gameObject, bool state, bool forceInU4Plus = false) {
                // Replaces GameObject.SetActiveRecursively.
                // Optionally do a recursive state change in Unity 4+, but by default just set active on top object
                if(gameObject == null) return;

                if(_isSupportedVersion3) { // unity 3.5 to 3.5.7
                    SetActiveRecursively_Unity3(gameObject, state);
                } else if(_isSupportedVersion4) { // Unity 4.0 or greater
                    SetActiveRecursively_Unity4(gameObject, state, forceInU4Plus);
                }
            }

            // These Unity 3/4 functions are split out because it will cause an error if a non-existant function call is even just inside a function.
            // This affects Unity 3 because it doesn't have access to some Unity 4 functions and it will error if they're not split out like this.

            private static void SetActiveRecursively_Unity3(GameObject gameObject, bool state) {
                // Set active state on object and its children
                Transform[] transforms = gameObject.GetComponentsInChildren<Transform>(true);
                if(transforms == null || transforms.Length == 0) return; // no children

                for(int i = 0; i < transforms.Length; i++) {
                    Transform t = transforms[i];
                    GameObject go = t.gameObject;
                    if(go.active != state) go.active = state; // set active state
                }
            }

            private static void SetActiveRecursively_Unity4(GameObject gameObject, bool state, bool force) {
                if(force) { // do the recursive state change even in Unity 4+
                    Transform[] transforms = gameObject.GetComponentsInChildren<Transform>(true);
                    if(transforms == null || transforms.Length == 0) return; // no children

                    for(int i = 0; i < transforms.Length; i++) {
                        Transform t = transforms[i];
                        GameObject go = t.gameObject;
                        if(go.activeSelf != state) go.SetActive(state); // set active state
                    }
                } else {
                    SetActive_Unity4(gameObject, state); // just set the active state on the parent
                }
            }

            public static void SetActive(GameObject gameObject, bool state) {
                if(_isSupportedVersion3) { // unity 3.5 to 3.5.7
                    SetActive_Unity3(gameObject, state);
                } else if(_isSupportedVersion4) { // Unity 4.0 or greater
                    SetActive_Unity4(gameObject, state);
                }
            }

            private static void SetActive_Unity3(GameObject gameObject, bool state) {
                gameObject.active = state;
            }

            private static void SetActive_Unity4(GameObject gameObject, bool state) {
                gameObject.SetActive(state);
            }

            public static bool IsActiveInHierarchy(GameObject gameObject) {
                if(_isSupportedVersion3) { // unity 3.5 to 3.5.7
                    return IsActiveInHierarchy_Unity3(gameObject);
                } else if(_isSupportedVersion4) { // Unity 4.0 or greater
                    return IsActiveInHierarchy_Unity4(gameObject);
                } else { // unsupported unity version
                    return false;
                }
            }

            private static bool IsActiveInHierarchy_Unity3(GameObject gameObject) {
                return gameObject.active;
            }

            private static bool IsActiveInHierarchy_Unity4(GameObject gameObject) {
                return gameObject.activeInHierarchy;
            }

            public static bool IsActiveSelf(GameObject gameObject) {
                if(_isSupportedVersion3) { // unity 3.5 to 3.5.7
                    return IsActiveSelf_Unity3(gameObject);
                } else if(_isSupportedVersion4) { // Unity 4.0 or greater
                    return IsActiveSelf_Unity4(gameObject);
                } else { // unsupported unity version
                    return false;
                }
            }

            private static bool IsActiveSelf_Unity3(GameObject gameObject) {
                return gameObject.active;
            }

            private static bool IsActiveSelf_Unity4(GameObject gameObject) {
                return gameObject.activeSelf;
            }

            public static bool IsColliderOrCollider2D(System.Type type) {
                if(IsCollider3D(type) || IsCollider2D(type)) return true;
                return false;
            }

            public static bool IsColliderOrCollider2D(System.Type type, bool is2D) {
                if(is2D) return IsCollider2D(type);
                //if(type == typeof(Collider) || type.IsSubclassOf(typeof(Collider))) return true; // IsSubclassOf NOT AVAILABLE IN WINDOWS 8 STORE!
                return IsCollider3D(type);
            }

            public static bool IsCollider2D(System.Type type) {
                if(!supports2DColliders) return false;
                return IsCollider2D_Restricted(type);
            }

            private static bool IsCollider2D_Restricted(System.Type type) {
                
                // IsSubclassOf NOT AVAILABLE IN WINDOWS 8 STORE! No way to work around this!
                //if(type == typeof(Collider2D) || type.IsSubclassOf(typeof(Collider2D))) return true;

                if(type == typeof(Collider2D) ||
                    type == typeof(BoxCollider2D) ||
                    type == typeof(CircleCollider2D) ||
                    type == typeof(PolygonCollider2D)) {
                        return true;
                }

                return false;
            }

            public static bool IsCollider3D(System.Type type) {
                // IsSubclassOf NOT AVAILABLE IN WINDOWS 8 STORE! No way to work around this!
                //if(type == typeof(Collider) || type.IsSubclassOf(typeof(Collider))) return true;

                if(type == typeof(Collider) ||
                    type == typeof(BoxCollider) ||
                    type == typeof(SphereCollider) ||
                    type == typeof(CapsuleCollider) ||
                    type == typeof(MeshCollider)) {
                        return true;
                }

                return false;
            }

            public static bool IsRigidbodyOrRigidbody2D(System.Type type, bool is2D) {
                if(is2D) return IsRigidbody2D(type);
                return type == typeof(Rigidbody);
            }

            public static bool IsRigidbody2D(System.Type type) {
                if(!supports2DColliders) return false;
                return IsRigidbody2D_Restricted(type);
            }

            public static bool IsRigidbody2D_Restricted(System.Type type) {
                return type == typeof(Rigidbody2D);
            }

            public static void IgnoreCollision<TCollider>(TCollider colliderA, TCollider colliderB) where TCollider : Component {
                // Determine collider type
                bool is2D;
                if(IsCollider2D(typeof(TCollider))) is2D = true;
                else if(IsCollider3D(typeof(TCollider))) is2D = false;
                else throw new System.ArgumentException("TCollider must be equal to or derrived from Collider or Collider2D!");
                
                // Ignore collision based on type
                if(is2D) {
                    IgnoreCollision2D(colliderA, colliderB);
                } else {
                    IgnoreCollision3D(colliderA, colliderB);
                }
            }

            public static void IgnoreCollision<TCollider>(TCollider colliderA, TCollider colliderB, bool is2D) where TCollider : Component {
                if(is2D) {
                    if(!IsCollider2D(typeof(TCollider))) throw new System.ArgumentException("TCollider must be equal to or derrived from Collider or Collider2D!");
                    IgnoreCollision2D(colliderA, colliderB);
                } else {
                    if(!IsCollider3D(typeof(TCollider))) throw new System.ArgumentException("TCollider must be equal to or derrived from Collider or Collider2D!");
                    IgnoreCollision3D(colliderA, colliderB);
                }
            }

            private static void IgnoreCollision3D<T>(T colliderA, T colliderB) where T : Component {
                Physics.IgnoreCollision(colliderA as Collider, colliderB as Collider);
            }

            private static void IgnoreCollision2D<T>(T colliderA, T colliderB) where T : Component {
                Physics2D.IgnoreCollision(colliderA as Collider2D, colliderB as Collider2D);
            }

            public static int GetSortingLayerID(Renderer renderer) {
                if(!supportsSortingLayers) return 0; // not allowed in this version
                return GetSortingLayerID_Now(renderer);
            }
            public static string GetSortingLayerName(Renderer renderer) {
                if(!supportsSortingLayers) return string.Empty; // not allowed in this version
                return GetSortingLayerName_Now(renderer);
            }
            public static int GetSortingLayerOrder(Renderer renderer) {
                if(!supportsSortingLayers) return 0; // not allowed in this version
                return GetSortingLayerOrder_Now(renderer);
            }
            public static void SetSortingLayerID(Renderer renderer, int value) {
                if(!supportsSortingLayers) return; // not allowed in this version
                SetSortingLayerID_Now(renderer, value);
            }
            public static void SetSortingLayerName(Renderer renderer, string value) {
                if(!supportsSortingLayers) return; // not allowed in this version
                SetSortingLayerName_Now(renderer, value);
            }
            public static void SetSortingLayerOrder(Renderer renderer, int value) {
                if(!supportsSortingLayers) return; // not allowed in this version
                SetSortingLayerOrder_Now(renderer, value);
            }

            private static int GetSortingLayerID_Now(Renderer renderer) {
                return renderer.sortingLayerID;
            }
            private static string GetSortingLayerName_Now(Renderer renderer) {
                return renderer.sortingLayerName;
            }
            private static int GetSortingLayerOrder_Now(Renderer renderer) {
                return renderer.sortingOrder;
            }
            private static void SetSortingLayerID_Now(Renderer renderer, int value) {
                renderer.sortingLayerID = value;
            }
            private static void SetSortingLayerName_Now(Renderer renderer, string value) {
                renderer.sortingLayerName = value;
            }
            private static void SetSortingLayerOrder_Now(Renderer renderer, int value) {
                renderer.sortingOrder = value;
            }

            public static void MarkDynamic(Mesh mesh) {
                Debug.LogError("DO NOT USE -- BUGGED: http://forum.unity3d.com/threads/198020-What-is-Mesh-MarkDynamic?p=1515214&viewfull=1#post1515214");
                if(unityVersion < UnityVersion.UNITY_4_0) return;
                MarkDynamic_Now(mesh);
            }
            private static void MarkDynamic_Now(Mesh mesh) {
                mesh.MarkDynamic();
            }

            public static void FlipMesh(Mesh mesh, Vector3[] verts, int[] triangles, bool flipX, bool flipY) {
                if(mesh == null) return;

                int tempInt;
                int vertCount = verts.Length;

                // Flip the vertices
                if(flipX) {
                    if(flipY) { // flip x/y
                        for(int i = 0; i < vertCount; i++) {
                            verts[i].x *= -1.0f;
                            verts[i].y *= -1.0f;
                        }
                    } else { // flip x only
                        for(int i = 0; i < vertCount; i++) {
                            verts[i].x *= -1.0f;
                        }
                    }
                } else if(flipY) { // flip y only
                    for(int i = 0; i < vertCount; i++) {
                        verts[i].y *= -1.0f;
                    }
                } else { // do not flip
                    return;
                }

                // Set triangles
                if(flipX && flipY) {
                    // arrangement is the same for XY flipped as original!
                } else { // must be flipped in at least one direction
                    for(int i = 0; i < triangles.Length; i += 3) {
                        // triangles[i+0] = always stays same
                        tempInt = triangles[i + 1];
                        triangles[i + 1] = triangles[i + 2]; // transpose last 2 verts
                        triangles[i + 2] = tempInt;
                    }
                }

                //Utils.UnityTools.MarkDynamic(mesh); // optimize mesh for updating -- DO NOT USE -- BUGGED: http://forum.unity3d.com/threads/198020-What-is-Mesh-MarkDynamic?p=1515214&viewfull=1#post1515214
                mesh.vertices = verts;
                // uvs shouldn't change
                mesh.triangles = triangles;
                // normals will be the same
                mesh.RecalculateBounds(); // even though the docs say assigning triangles will do this, it does not and we must do it manually
                //mesh.RecalculateNormals();
            }

            public static void DestroyL1ChildrenWithComponent<T>(GameObject parent) where T : Component {
                if(parent == null) return;
                DestroyL1ChildrenWithComponent<T>(parent.transform);
            }
            public static void DestroyL1ChildrenWithComponent<T>(Transform parent) where T : Component {
                if(parent == null) return;

                int count = parent.childCount;
                for(int i = count - 1; i >= 0; i--) {
                    Transform t = parent.GetChild(i);
                    T comp = t.GetComponent<T>();
                    if(comp == null) continue;
                    Object.DestroyImmediate(comp.gameObject, false);
                }
            }

            internal static class Camera {
                public static bool isOrthographic(UnityEngine.Camera camera) {
                    if(camera == null) return false;
#if UNITY5
                    return camera.orthographic;
#else
                    return camera.isOrthoGraphic;
#endif
                }
            }
        }

        #endregion

        #region // GUI TOOLS

        public static class GUITools {

            public static class Solid {
                private static bool inSet = false;
                private static Texture2D texture;
                private static Color oldGUIColor;

                public static Color color {
                    get {
                        return GUI.color;
                    }
                    set {
                        GUI.color = value;
                    }
                }
                public static float colorR {
                    get {
                        return GUI.color.r;
                    }
                    set {
                        Color newColor = GUI.color;
                        newColor.r = value;
                        color = newColor;
                    }
                }
                public static float colorG {
                    get {
                        return GUI.color.g;
                    }
                    set {
                        Color newColor = GUI.color;
                        newColor.g = value;
                        color = newColor;
                    }
                }
                public static float colorB {
                    get {
                        return GUI.color.b;
                    }
                    set {
                        Color newColor = GUI.color;
                        newColor.b = value;
                        color = newColor;
                    }
                }
                public static float colorA {
                    get {
                        return GUI.color.a;
                    }
                    set {
                        Color newColor = GUI.color;
                        newColor.a = value;
                        color = newColor;
                    }
                }

                public static void Draw(Rect rect) {
                    // Create the texture
                    if(texture == null) { // create the pixel
                        //texture = EditorGUIUtility.whiteTexture; // only works in editor
                        texture = new Texture2D(1, 1);
                        texture.SetPixel(0, 0, Color.white); // pixel defaults to semi-transparent, so we have to set to opaque white
                        texture.Apply(); // store the change
                        texture.hideFlags = HideFlags.DontSave; // prevent unity from trying to save this asset and causing texture leaks
                    }

                    // Draw the rectangle
                    GUI.DrawTexture(rect, texture, ScaleMode.StretchToFill); // draw the line
                }

                public static void Draw(Rect rect, Color color) {
                    if(inSet) { // we are in a draw set
                        Solid.color = color; // set the color
                        Draw(rect); // draw
                    } else { // outside a draw set, save GUI, draw with incoming color, restore GUI
                        BeginDrawSet();
                        Solid.color = color;
                        Draw(rect);
                        EndDrawSet();
                    }
                }

                public static void DrawRotated(Rect rect, float rotation) {
                    // Rotate the rectangle if necessary
                    bool rotate = rotation != 0.0f ? true : false;
                    Matrix4x4 guiMatrix = GUI.matrix; // store matrix before rotation
                    if(rotate) GUIUtility.RotateAroundPivot(360.0f - rotation, rect.center); // reverse direction so GUI rotation matches scene counterclockwise = +

                    Draw(rect);

                    // Restore original GUI state if rotated
                    if(rotate) GUI.matrix = guiMatrix; // restore matrix
                }

                public static void DrawRotated(Rect rect, Color color, float rotation) {
                    // Rotate the rectangle if necessary
                    bool rotate = rotation != 0.0f ? true : false;
                    Matrix4x4 guiMatrix = GUI.matrix; // store matrix before rotation
                    if(rotate) GUIUtility.RotateAroundPivot(360.0f - rotation, rect.center); // reverse direction so GUI rotation matches scene counterclockwise = +

                    Draw(rect, color);

                    // Restore original GUI state if rotated
                    if(rotate) GUI.matrix = guiMatrix; // restore matrix
                }

                public static Texture2D DrawToTexture(Rect rect) {
                    // Create the texture
                    Texture2D texture = new Texture2D(1, 1);
                    texture.SetPixel(0, 0, Color.white);
                    texture.Resize((int)rect.width, (int)rect.height);
                    texture.Apply(); // store the change
                    texture.hideFlags = HideFlags.DontSave; // prevent unity from trying to save this asset and causing texture leaks
                    return texture;
                }

                public static void BeginDrawSet() {
                    inSet = true;
                    oldGUIColor = GUI.color;
                }

                public static void EndDrawSet() {
                    inSet = false;
                    GUI.color = oldGUIColor;
                }

                // Shapes

                public static void DrawBox(Rect rect, Color color, float lineWidth = 1.0f) {
                    if(inSet) { // we are in a draw set
                        Solid.color = color; // set the color
                        DrawBox(rect, lineWidth); // draw
                    } else { // outside a draw set, save GUI, draw with incoming color, restore GUI
                        BeginDrawSet();
                        Solid.color = color;
                        DrawBox(rect, lineWidth);
                        EndDrawSet();
                    }
                }

                public static void DrawBox(Rect rect, float lineWidth = 1.0f) {
                    Draw(new Rect(rect.x, rect.y, rect.width, lineWidth)); // top line
                    Draw(new Rect(rect.x, rect.y + rect.height - lineWidth, rect.width, lineWidth)); // bottom line
                    Draw(new Rect(rect.x, rect.y + lineWidth, lineWidth, rect.height - lineWidth * 2.0f)); // left line
                    Draw(new Rect(rect.x + rect.width - lineWidth, rect.y + lineWidth, lineWidth, rect.height - lineWidth * 2.0f)); // right line
                }

                public static void DrawBoxRotated(Rect rect, float rotation, float lineWidth = 1.0f) {
                    // Rotate the rectangle if necessary
                    bool rotate = rotation != 0.0f ? true : false;
                    Matrix4x4 guiMatrix = GUI.matrix; // store matrix before rotation
                    if(rotate) GUIUtility.RotateAroundPivot(360.0f - rotation, rect.center); // reverse direction so GUI rotation matches scene counterclockwise = +

                    Draw(new Rect(rect.x, rect.y, rect.width, lineWidth)); // top line
                    Draw(new Rect(rect.x, rect.y + rect.height - lineWidth, rect.width, lineWidth)); // bottom line
                    Draw(new Rect(rect.x, rect.y + lineWidth, lineWidth, rect.height - lineWidth * 2.0f)); // left line
                    Draw(new Rect(rect.x + rect.width - lineWidth, rect.y + lineWidth, lineWidth, rect.height - lineWidth * 2.0f)); // right line

                    // Restore original GUI state if rotated
                    if(rotate) GUI.matrix = guiMatrix; // restore matrix
                }
            }

            [System.Serializable]
            public class RotatableGUIFillBox {
                private RotatableTexture rotatableTexture;
                private Rect lastRect;
                private float lastAngle;

                public RotatableGUIFillBox() {
                    rotatableTexture = new RotatableTexture();
                }

                public void Draw(Rect rect, float angle) {

                    // Draw to texture and rotate
                    if(rect != lastRect || lastAngle != angle) { // only remake texture if necessary
                        float aspectRatio = rect.width / rect.height;
                        const float minRes = 100;
                        Texture2D box = SpriteFactory.Utils.GUITools.Solid.DrawToTexture(new Rect(0, 0, aspectRatio * minRes, minRes));
                        SetTexture(box); // assign new texture
                        SetAngle(angle); // rotate the image
                    }

                    // Determine final rect
                    Rect finalRect;
                    if(angle == 0.0f) finalRect = rect; // just use the rect as is
                    else { // enlarge rect to fit rotated texture
                        //Rect rotatedRect = rotatableTexture.rect; // get the rect from the texture
                        //rotatedRect.center = rect.center; // align to original rect's center
                        //finalRect = rotatedRect;

                        // Scale the Rect
                        Rect rotatedRect = FindRotatedPixelRect(rect, angle);
                        rotatedRect.center = rect.center; // align to original rect's center
                        finalRect = rotatedRect;
                    }

                    // Draw to GUI
                    GUI.DrawTexture(finalRect, rotatableTexture.texture, ScaleMode.StretchToFill);

                    //Utils.GUITools.Solid.DrawBox(finalRect, Color.red);

                    // Store data for next cycle
                    lastRect = rect;
                    lastAngle = angle;
                }

                private void SetTexture(Texture2D texture) {
                    rotatableTexture.Destroy(true); // destroy both textures
                    rotatableTexture.Reset(texture);
                }

                private void SetAngle(float angle) {
                    rotatableTexture.SetAngle(angle);
                }

                private Rect FindRotatedPixelRect(Rect rect, float angle) {
                    float radians = Mathf.Deg2Rad * angle; // convert angle to radians
                    int sourceHeight = (int)rect.height;
                    int sourceWidth = (int)rect.width;

                    // Compute the cosine and sine only once
                    float cosine = (float)Mathf.Cos(radians);
                    float sine = (float)Mathf.Sin(radians);

                    // Compute dimensions of the resulting bitmap
                    // First get the coordinates of the 3 corners other than origin
                    int x1 = (int)(-sourceHeight * sine);
                    int y1 = (int)(sourceHeight * cosine);
                    int x2 = (int)(sourceWidth * cosine - sourceHeight * sine);
                    int y2 = (int)(sourceHeight * cosine + sourceWidth * sine);
                    int x3 = (int)(sourceWidth * cosine);
                    int y3 = (int)(sourceWidth * sine);

                    int minX = Mathf.Min(0, Mathf.Min(x1, Mathf.Min(x2, x3)));
                    int minY = Mathf.Min(0, Mathf.Min(y1, Mathf.Min(y2, y3)));
                    int maxX = Mathf.Max(0, Mathf.Max(x1, Mathf.Max(x2, x3)));
                    int maxY = Mathf.Max(0, Mathf.Max(y1, Mathf.Max(y2, y3)));

                    int newWidth = maxX - minX + 1;
                    int newHeight = maxY - minY + 1;

                    return new Rect(0, 0, newWidth, newHeight);
                }

                public void Destroy() {
                    if(rotatableTexture != null) rotatableTexture.Destroy(true);
                }
            }

            public class RotatableTexture {
                private Texture2D sourceTexture;
                private Texture2D rotatedTexture;
                private bool rotated;
                private float angle;

                public Texture2D texture {
                    get {
                        if(rotated) return rotatedTexture;
                        return sourceTexture;
                    }
                }
                public Rect rect {
                    get {
                        if(rotated) {
                            if(rotatedTexture != null) {
                                return new Rect(0.0f, 0.0f, rotatedTexture.width, rotatedTexture.height);
                            }
                        } else {
                            if(sourceTexture != null) return new Rect(0.0f, 0.0f, sourceTexture.width, sourceTexture.height);
                        }
                        return new Rect();
                    }
                }

                public RotatableTexture() { }

                public RotatableTexture(Texture2D texture) {
                    Reset(texture);
                }

                public void Reset(Texture2D texture) {
                    Destroy(); // destroy the rotated texture to prevent memory leaks
                    this.sourceTexture = texture;
                    CheckSourceTexture();
                    rotated = false;
                    angle = 0.0f;
                }

                private void CheckSourceTexture() {
                    if(sourceTexture == null) throw new System.Exception("Texture cannot be null!");
                }

                public void SetAngle(float angle) {
                    this.angle = angle;

                    CheckSourceTexture();
                    if(angle == 0.0f) { // not rotated
                        rotated = false;
                        return;
                    }
                    rotated = true;

                    // create a new texture which is a rotated version of the original
                    Destroy(false); // destroy rotated texture to prevent memory leaks
                    rotatedTexture = GUITools.GetRotatedTexture(sourceTexture, angle, Color.clear);
                }

                public void Destroy(bool destroySource = false) {
                    // destroy textures to prevent memory leaks
                    if(rotatedTexture != null) Object.DestroyImmediate(rotatedTexture);
                    if(destroySource && sourceTexture != null) Object.DestroyImmediate(sourceTexture);
                }
            }

            // GetRotatedTexture - Create a new rotated Texture2D from a source Texture2D
            // Returns           - Returns new Texture2D
            // Texture2D         - Texture to rotate
            // Angle             - Angle of rotation in degrees
            // backgroundColor   - Color of pixels in the resulting bitmap that do not get covered by source pixels
            public static Texture2D GetRotatedTexture(Texture2D texture, float angle, Color backgroundColor) {
                float radians = Mathf.Deg2Rad * angle; // convert angle to radians
                int sourceHeight = texture.height;
                int sourceWidth = texture.width;

                // Compute the cosine and sine only once
                float cosine = (float)Mathf.Cos(radians);
                float sine = (float)Mathf.Sin(radians);

                // Compute dimensions of the resulting bitmap
                // First get the coordinates of the 3 corners other than origin
                int x1 = (int)(-sourceHeight * sine);
                int y1 = (int)(sourceHeight * cosine);
                int x2 = (int)(sourceWidth * cosine - sourceHeight * sine);
                int y2 = (int)(sourceHeight * cosine + sourceWidth * sine);
                int x3 = (int)(sourceWidth * cosine);
                int y3 = (int)(sourceWidth * sine);

                int minX = Mathf.Min(0, Mathf.Min(x1, Mathf.Min(x2, x3)));
                int minY = Mathf.Min(0, Mathf.Min(y1, Mathf.Min(y2, y3)));
                int maxX = Mathf.Max(0, Mathf.Max(x1, Mathf.Max(x2, x3)));
                int maxY = Mathf.Max(0, Mathf.Max(y1, Mathf.Max(y2, y3)));

                int newWidth = maxX - minX + 1;
                int newHeight = maxY - minY + 1;

                // Create the new pixels for working
                Color[] newTexturePixels = new Color[newWidth * newHeight];
                Color[] origTexturePixels = texture.GetPixels();

                // Now do the actual rotating - a pixel at a time
                // Computing the destination point for each source point
                // will leave a few pixels that do not get covered
                // So we use a reverse transform - e.i. compute the source point
                // for each destination point
                for(int y = 0; y < newHeight; y++) {

                    for(int x = 0; x < newWidth; x++) {

                        int newIndex = y * newWidth + x; // get the current index of the pixel in the new texture
                        int sourceX = (int)((x + minX) * cosine + (y + minY) * sine);
                        int sourceY = (int)((y + minY) * cosine - (x + minX) * sine);
                        int sourceIndex = sourceY * sourceWidth + sourceX; // get the index of the original pixel in the old texture

                        if(sourceX >= 0 && sourceX < sourceWidth && sourceY >= 0
                            && sourceY < sourceHeight) {

                            // Set the destination pixel
                            newTexturePixels[newIndex] = origTexturePixels[sourceIndex];

                        } else {
                            // Draw the background color.
                            newTexturePixels[newIndex] = backgroundColor;
                        }
                    }
                }

                // Assign the new pixels to a Texture2D
                Texture2D newTexture = new Texture2D(newWidth, newHeight);
                newTexture.SetPixels(newTexturePixels);
                newTexture.Apply(); // store the change
                newTexture.hideFlags = HideFlags.DontSave; // prevent unity from trying to save this asset and causing texture leaks

                return newTexture;
            }
        }

        #endregion

        #region // MISC TOOLS

        public static class MiscTools {

            public static void SnapToPixel(ref float offsetX, ref float offsetY, float compareX, float compareY) {
                if(!SpriteFactory.Utils.MathTools.IsNearOrWholeNumber(compareX)) offsetX -= 0.5f;
                if(!SpriteFactory.Utils.MathTools.IsNearOrWholeNumber(compareY)) offsetY += 0.5f;
            }

            public static void SnapToPixel(ref float offsetX, ref float offsetY) {
                SnapToPixel(ref offsetX, ref offsetY, offsetX, offsetY);
            }

            public static float ResolutionTargetScale(Enums.ResolutionTarget resolutionTarget) {
                if(resolutionTarget == Enums.ResolutionTarget.One) return 1.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.ThreeQuarters) return 0.75f;
                else if(resolutionTarget == Enums.ResolutionTarget.TwoThirds) return 2.0f / 3.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Half) return 0.5f;
                else if(resolutionTarget == Enums.ResolutionTarget.Third) return 1.0f / 3.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Quarter) return 0.25f;
                else if(resolutionTarget == Enums.ResolutionTarget.Fifth) return 0.2f;
                else if(resolutionTarget == Enums.ResolutionTarget.Sixth) return 1.0f / 6.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Seventh) return 1.0f / 7.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Eighth) return 0.125f;
                else if(resolutionTarget == Enums.ResolutionTarget.Ninth) return 1.0f / 9.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Tenth) return 0.1f;
                return 1.0f;
            }

            public static float ResolutionTargetInverseScale(Enums.ResolutionTarget resolutionTarget) {
                if(resolutionTarget == Enums.ResolutionTarget.One) return 1.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.ThreeQuarters) return 1.0f / 0.75f; // 1.333...
                else if(resolutionTarget == Enums.ResolutionTarget.TwoThirds) return 1.5f;
                else if(resolutionTarget == Enums.ResolutionTarget.Half) return 2.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Third) return 3.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Quarter) return 4.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Fifth) return 5.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Sixth) return 6.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Seventh) return 7.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Eighth) return 8.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Ninth) return 9.0f;
                else if(resolutionTarget == Enums.ResolutionTarget.Tenth) return 10.0f;
                return 1.0f;
            }

        }

        #endregion

        #region // UTILITY CLASSES

        public static class SmoothTime {

            public static float smoothDeltaTime { get { return _smoothDeltaTime; } }
            public static int framesToSmooth {
                get {
                    return _framesToSmooth;
                }
                set {
                    if(value <= 0) value = 1;
                    if(value == _framesToSmooth) return; // same
                    _framesToSmooth = value;
                    Reset();
                    // could add some code to smooth the new array based on the old one so we don't lose our last x frames of data
                }
            }

            private static int _framesToSmooth;
            private static int currentIndex;
            private static float[] deltaTimes;
            private static int filledCount;
            private static float _smoothDeltaTime;
            private static int lastFrameUpdate;

            static SmoothTime() {
                _framesToSmooth = 30; // default frame smoothing
                Reset();
            }

            public static void Update() {
                int thisFrame = Time.frameCount; // get the number of frames that have been drawn since startup
                if(lastFrameUpdate >= thisFrame) return; // update was already called this frame, don't update

                deltaTimes[currentIndex] = Time.deltaTime;
                if(filledCount < _framesToSmooth) // haven't passed enough frames for complete smooth
                    filledCount++;

                // Average the last X frames to get the smooth delta time
                float framesSum = 0.0f;
                for(int i = 0; i < filledCount; i++) { // if we haven't filled the array yet, just average over what we've filled
                    framesSum += deltaTimes[i];
                }
                _smoothDeltaTime = framesSum / filledCount;

                // Increment index
                currentIndex++;
                if(currentIndex >= _framesToSmooth) currentIndex = 0; // reset

                // Store the current number of frames that have passed since startup to filter out multiple calls to Update in the same frame
                lastFrameUpdate = thisFrame;
            }

            public static void Reset() {
                if(deltaTimes == null || deltaTimes.Length != _framesToSmooth) // remake array only if necessary
                    deltaTimes = new float[_framesToSmooth];
                filledCount = 0;
                currentIndex = 0;
                lastFrameUpdate = 0; // ensure update can run immediately
            }
        }

        [System.Serializable]
        public class TimerAbs {
            public bool running;
            [SerializeField]
            private float endTime;
            public float length;

            public TimerAbs() { }

            public TimerAbs(float inLength) {
                length = inLength;
            }

            public void Start() {
                running = true;
                endTime = length + Time.time;
            }

            public void Start(float inLength) {
                running = true;
                length = inLength;
                endTime = length + Time.time;
            }

            public bool Update() {
                if(!running) return false;
                if(Time.time >= endTime) { // timer has finished
                    running = false;
                    return true;
                }
                return false;
            }

            public void Clear() {
                running = false;
                endTime = 0.0f;
            }

            public void SetLength(float inLength) {
                length = inLength;
            }

            public TimerAbs Clone() {
                return (TimerAbs)this.MemberwiseClone();
            }
        }

        [System.Serializable]
        public class Timer {
            public bool running;
            [SerializeField]
            private float timer;
            public float length;

            public Timer() { }

            public Timer(float inLength) {
                length = inLength;
            }

            public void Start() {
                running = true;
                timer = length;
            }

            public void Start(float inLength) {
                running = true;
                length = inLength;
                timer = length;
            }

            public void Restart() {
                Clear();
                Start();
            }

            public bool Update(float deltaTime) {
                if(!running) return false;
                timer -= deltaTime; // decrement the timer
                if(timer <= 0.0f) { // timer has finished
                    running = false;
                    return true;
                }
                return false;
            }

            public void Clear() {
                running = false;
                timer = 0.0f;
            }

            public void SetLength(float inLength) {
                length = inLength;
            }

            public Timer Clone() {
                return (Timer)this.MemberwiseClone();
            }
        }

        [System.Serializable]
        public class FrameTimer {
            public bool running;
            [SerializeField]
            private float timeRemaining;
            public float length;
            public float overrunBuffer;

            public FrameTimer() {
            }

            public FrameTimer(float inLength) {
                length = inLength;
            }

            public void Start() {
                running = true;
                timeRemaining = length;
            }

            public void Start(float inLength) {
                running = true;
                length = inLength;
                timeRemaining = length;
            }

            public bool Update(float deltaTime, float speed) {
                if(!running) return false;

                float actualTimeRemaining = speed > 0.0f ? timeRemaining / speed : timeRemaining;

                // Decrement the timer
                actualTimeRemaining -= deltaTime; // decrement the timer

                // Subtract any leftover overrun
                if(overrunBuffer > 0.0f) actualTimeRemaining -= overrunBuffer;

                // Check if timer has finished
                if(actualTimeRemaining <= 0.0f) { // timer has finished
                    running = false;

                    // Record amount timer overran the frame to account for frame time innacurracy
                    if(actualTimeRemaining < 0.0f) overrunBuffer = actualTimeRemaining * -1.0f;
                    else overrunBuffer = 0.0f;

                    return true;

                } else { // timer is not finished yet

                    timeRemaining = actualTimeRemaining * speed; // store time remaining back in non-speed-modified format
                    //timeRemaining -= deltaTime * speed + overrunBuffer * speed; // store time remaining back in non-speed-modified format
                    overrunBuffer = 0.0f; // clear the buffer now that we used it up
                    return false;
                }
            }

            public void Clear() {
                running = false;
                timeRemaining = 0.0f;
                overrunBuffer = 0.0f;
            }

            public void SetLength(float inLength) {
                length = inLength;
            }

            public FrameTimer Clone() {
                return (FrameTimer)this.MemberwiseClone();
            }
        }

        #endregion


    }
}