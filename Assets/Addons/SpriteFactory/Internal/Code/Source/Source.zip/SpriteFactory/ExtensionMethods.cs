﻿using UnityEngine;

namespace SpriteFactory {
    
    internal static class ExtensionMethods {

        public static Vector3 GetCenter(this BoxCollider2D collider) {
#if UNITY5
            return collider.offset;
#else
            return collider.center;
#endif
        }

        public static void SetCenter(this BoxCollider2D collider, Vector3 center) {
#if UNITY5
            collider.offset = center;
#else
            collider.center = center;
#endif
        }

    }
}
