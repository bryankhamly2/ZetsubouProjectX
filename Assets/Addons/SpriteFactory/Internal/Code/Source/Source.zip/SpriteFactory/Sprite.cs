using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace SpriteFactory {

    [AddComponentMenu("")]
    [RequireComponent(typeof(MeshFilter))]
    [RequireComponent(typeof(MeshRenderer))]
    public partial class Sprite : MonoBehaviour {

        #region // Variables

        // Data objects
        [HideInInspector, SerializeField]
        private Data data; // the main sprite data object

        // Inspector vars
        public bool selfUpdate = true;
        public SpriteUpdater spriteUpdater;
        public bool playAnimationOnStart = true;
        public bool playDefaultAnimWhenIdle = true;
        public float playbackSpeed = 1.0f;
        public bool animateOffCamera = true;
        public int defaultAnimationOverride = -1;
        public int currentMaterialSetIndex = 0;
        public Material materialOverride;
        public bool isBillboard;
        public BillboardUpAxis billboardUpAxis = BillboardUpAxis.WorldY;
        public bool useBatchScaling;
        public bool scaleToActualPixelSize;
        public bool activateLocatorsRecursively;
        
        // Prev state vars for watching for changes of public inspector vars
        [System.NonSerialized]
        private SpriteUpdater spriteUpdater_prev;
        [System.NonSerialized]
        private bool renderActualPixelSize_prev;
        [System.NonSerialized]
        private int defaultAnimationOverride_prev;
        [System.NonSerialized]
        private int currentMaterialSetIndex_prev;
        [System.NonSerialized]
        private Material materialOverride_prev;
        [System.NonSerialized]
        private BillboardUpAxis billboardUpAxis_prev;
        [System.NonSerialized]
        private bool useBatchScale_prev;
        
#if UNITY5
        [HideInInspector, SerializeField]
        private UnityEngine.Rendering.ShadowCastingMode mrShadowCastingMode_prev;
#else
        [HideInInspector, SerializeField]
        private bool mrCastShadows_prev;
#endif
        [HideInInspector, SerializeField]
        private bool mrReceiveShadows_prev;

        // In-Game Variables
        // Working
        [System.NonSerialized]
        private bool _initialized; // initialization only happens in game mode
        [HideInInspector, SerializeField]
        private bool initialSetupFinished;
        //[HideInInspector, SerializeField]
        //private bool deferredOnEnable;
        [System.NonSerialized]
        private SpriteDisplay display;
        [HideInInspector, SerializeField]
        private int _currentAnimationIndex = -1;
        [HideInInspector, SerializeField]
        private bool _isPaused;
        [HideInInspector, SerializeField]
        private SpriteFactory.Utils.Timer pauseTimer;
        [HideInInspector, SerializeField]
        private bool _isActive;
        [HideInInspector, SerializeField]
        private SpriteCollider[] spriteColliders;
        [HideInInspector, SerializeField]
        private bool[] isColliderAnimated;
        [HideInInspector, SerializeField]
        private bool wakeUpParentRigidbody;
        [HideInInspector, SerializeField]
        private Locator[] locators;
        [HideInInspector, SerializeField]
        private Vector3 _billboardUpAxisVector;
        [HideInInspector, SerializeField]
        private bool _billboardUsingCameraAxis;
        [HideInInspector]
        [SerializeField]
        private bool _xAxisFlipped;
        [HideInInspector]
        [SerializeField]
        private bool _yAxisFlipped;
        [HideInInspector]
        [SerializeField]
        private bool _isFlipped;
        [HideInInspector, SerializeField]
        private Vector3 _batchScale = new Vector3(1.0f, 1.0f, 1.0f);
        [System.NonSerialized]
        private SpriteMaterial _spriteMaterial;

        // static sprite vars
        [System.NonSerialized]
        private bool static_isVisible;
        [System.NonSerialized]
        private Mesh static_mesh;
        [System.NonSerialized]
        private Frame static_frame;
        [System.NonSerialized]
        private bool static_dataSet;
        [HideInInspector, SerializeField]
        private bool static_materialOverridden;
        [System.NonSerialized]
        private Material static_overrideMaterial;
        [System.NonSerialized]
        private Vector3[] static_verts;
        [System.NonSerialized]
        private Vector2[] static_uvs;
        [System.NonSerialized]
        private int[] static_triangles;
        [System.NonSerialized]
        private int static_vertexCount;

        // Caches
        [HideInInspector, SerializeField]
        private Transform thisTransform;
        [HideInInspector, SerializeField]
        private GameObject thisGameObject;
        [HideInInspector, SerializeField]
        private SpriteHelperU3 unity3SpriteHelper;
        [System.NonSerialized]
        private bool _isStaticSprite;
        [System.NonSerialized]
        private int _animationCount;
        [System.NonSerialized]
        private int _materialSetCount;
        [System.NonSerialized]
        private int _colliderCount;
        [System.NonSerialized]
        private int _locatorCount;
        [HideInInspector, SerializeField]
        private Camera mainCamera;
        [HideInInspector, SerializeField]
        private Transform mainCameraTransform;
        [HideInInspector, SerializeField]
        private LocatorSet[] locatorSets;
        [HideInInspector, SerializeField]
        private MeshRenderer meshRenderer;
        [System.NonSerialized]
        private Sprite.MeshFrame[] meshFrames;
        [HideInInspector, SerializeField]
        private int meshFrameCount;

        // Identity
        [SerializeField]
        private SpriteFactory.GameMasterSprite gameMasterSprite; // link to the master game sprite on disk

        // Utility
        [System.NonSerialized]
        private bool isDuplicate;
        [HideInInspector, SerializeField]
        private bool wasEverInitialized;

        #endregion

        #region // Properties

        // *** Make sure all public controls and properties prevent running in editor if it sets anything or accesses Data ***

        // Properties (Read-Only)
        public GameMasterSprite masterSprite {
            get {
                return gameMasterSprite;
            }
        }
        public bool isStaticSprite {
            get {
                if(!_initialized) { // called from editor mode
                    if(gameMasterSprite == null) return false;
                    return gameMasterSprite.data.isStaticSprite;
                }
                return _isStaticSprite;
            }
        }
        public bool isActive {
            get {
                if(!_initialized) { // called in editor
                    if(SpriteFactory.Utils.UnityTools.IsActiveInHierarchy(gameObject) && this.enabled) return true;
                    return false;
                }
                if(SpriteFactory.Utils.UnityTools.IsActiveInHierarchy(thisGameObject) && this.enabled) return true;
                return false;
            }
        }
        public bool isPlaying {
            get {
                if(!_initialized) return false; // prevent calling from editor mode
                if(_animationCount <= 0 || _currentAnimationIndex < 0) return false;
                return data.animations[_currentAnimationIndex].isPlaying;
            }
        }
        public bool isPaused {
            get {
                return _isPaused;
            }
        }
        public bool isVisible {
            get {
                if(!_initialized) return false; // editor mode
                if(_isStaticSprite) return static_isVisible;
                return display.visible;
            }
        }
        public bool isFlipped {
            get {
                return _isFlipped;
            }
        }
        public bool isFlippedX {
            get {
                return _xAxisFlipped;
            }
            set {
                SetFlippedState(value, _yAxisFlipped);
            }
        }
        public bool isFlippedY {
            get {
                return _yAxisFlipped;
            }
            set {
                SetFlippedState(_xAxisFlipped, value);
            }
        }
        public int animationCount {
            get {
                if(!_initialized) { // called from editor mode
                    if(gameMasterSprite == null) return 0;
                    return gameMasterSprite.data.animationCount;
                }
                return _animationCount;
            }
        }
        public int materialSetCount {
            get {
                if(!_initialized) { // called from editor mode
                    if(gameMasterSprite == null) return 0;
                    return gameMasterSprite.data.materialSetCount;
                }
                return _materialSetCount;
            }
        }
        public int colliderCount {
            get {
                if(!_initialized) { // called from editor mode
                    if(gameMasterSprite == null) return 0;
                    return gameMasterSprite.data.colliderCount;
                }
                return _colliderCount;
            }
        }
        public int locatorCount {
            get {
                if(!_initialized) { // called from editor mode
                    if(gameMasterSprite == null) return 0;
                    return gameMasterSprite.data.locatorCount;
                }
                return _locatorCount;
            }
        }
        public Bounds meshBounds {
            get {
                if(!_initialized) return GetComponent<MeshFilter>().sharedMesh.bounds; // return the bounds of the main mesh if in editor mode
                if(_isStaticSprite) {
                    if(static_mesh == null) static_mesh = ((MeshFilter)GetComponent(typeof(MeshFilter))).mesh; // get the mesh only if needed to save time in Awake
                    return static_mesh.bounds;
                }
                return display.bounds;
            }
        }
        public string currentAnimation {
            get {
                if(!_initialized) return null;
                if(_animationCount <= 0) return null;
                if(_currentAnimationIndex < 0) return null;
                return data.animations[_currentAnimationIndex].name;
            }
        }
        public int currentAnimationIndex {
            get {
                if(!_initialized) return -1;
                if(_animationCount <= 0) return -1;
                return _currentAnimationIndex;
            }
        }
        public int currentFrameIndex {
            get {
                if(!_initialized) return -1;
                if(_animationCount <= 0 || _currentAnimationIndex < 0) return -1;
                return data.animations[_currentAnimationIndex].currentFrame;
            }
        }
        public SpriteMaterial spriteMaterial {
            get {
                return _spriteMaterial;
            }
        }

        // Properties (Read/Write)
        public string defaultAnimation {
            get {
                if(!_initialized) { // called from editor mode
                    if(gameMasterSprite == null) return null;
                    if(gameMasterSprite.data.animationCount <= 0) return null;
                    return gameMasterSprite.data.animations[defaultAnimationIndex].name;
                }
                if(_animationCount <= 0) return null;
                return data.animations[data.defaultAnimationIndex].name;
            }

            set {
                if(!_initialized) { // prevent calling from editor mode
                    Debug.LogError("defaultAnimation cannot be set now!");
                    return;
                }
                string animationName = value;
                int index = FindAnimationIndex(animationName);
                if(index == -1) {
                    Debug.LogError("Animation \"" + animationName + "\" not found in sprite!");
                    return;
                }
                defaultAnimationIndex = index;
            }
        }
        public int defaultAnimationIndex {
            get {
                if(!_initialized) { // called from editor mode
                    if(gameMasterSprite == null) return -1;
                    if(gameMasterSprite.data.animationCount <= 0) return -1;
                    return gameMasterSprite.data.defaultAnimationIndex;
                }
                if(_animationCount <= 0) return -1;
                return data.defaultAnimationIndex;
            }
            set {
                if(!_initialized) { // prevent calling from editor mode
                    Debug.LogError("defaultAnimationIndex cannot be set now!");
                    return;
                }
                int animationIndex = value;
                if(animationIndex < 0 || animationIndex >= _animationCount) throw new System.Exception("Invalid animation index!");
                if(data.animations[animationIndex] == null) throw new System.Exception("No animation at index " + animationIndex + "!");
                data.defaultAnimationIndex = animationIndex; // set the new default animation
            }
        }
        public float currentAnimationSpeed {
            get {
                if(!_initialized) return -1.0f;
                if(_animationCount <= 0) return -1.0f;
                if(_currentAnimationIndex < 0) return -1.0f;
                return data.animations[_currentAnimationIndex].speed;
            }
            set {
                if(!_initialized) { // prevent calling from editor mode
                    Debug.LogError("currentAnimationSpeed cannot be set now!");
                    return;
                }
                float speed = value;
                if(_animationCount <= 0) return;
                if(_currentAnimationIndex < 0) return;

                if(speed < 0.0f) speed = 0.0f;
                data.animations[_currentAnimationIndex].speed = speed;
            }
        }
        public Vector3 batchScale {
            get {
                return _batchScale;
            }
            set {
                if(!_initialized) return; // editor mode
                _batchScale = value;
                if(useBatchScaling) UpdateBatchScale();
            }
        }
        public int sortingLayerID {
            get {
                if(!_initialized) { // called in the editor
                    return Utils.UnityTools.GetSortingLayerID(GetComponent<MeshRenderer>());
                }
                // in play mode
                return Utils.UnityTools.GetSortingLayerID(meshRenderer);
            }
            set {
                if(!_initialized) { // called in the editor
                    Utils.UnityTools.SetSortingLayerID(GetComponent<MeshRenderer>(), value);
                    return;
                }
                // in play mode
                if(_isStaticSprite) {
                    Utils.UnityTools.SetSortingLayerID(meshRenderer, value);
                } else {
                    display.SetSortingLayerId(value);
                }
            }
        }
        public string sortingLayerName {
            get {
                if(!_initialized) { // called in the editor
                    return Utils.UnityTools.GetSortingLayerName(GetComponent<MeshRenderer>());
                }
                // in play mode
                return Utils.UnityTools.GetSortingLayerName(meshRenderer);
            }
            set {
                if(!_initialized) { // called in the editor
                    Utils.UnityTools.SetSortingLayerName(GetComponent<MeshRenderer>(), value);
                    return;
                }
                // in play mode
                if(_isStaticSprite) {
                    Utils.UnityTools.SetSortingLayerName(meshRenderer, value);
                } else {
                    display.SetSortingLayerName(value);
                }
            }
        }
        public int sortingOrder {
            get {
                if(!_initialized) { // called in the editor
                    return Utils.UnityTools.GetSortingLayerOrder(GetComponent<MeshRenderer>());
                }
                // in play mode
                return Utils.UnityTools.GetSortingLayerOrder(meshRenderer);
            }
            set {
                if(!_initialized) { // called in the editor
                    Utils.UnityTools.SetSortingLayerOrder(GetComponent<MeshRenderer>(), value);
                    return;
                }
                // in play mode
                if(_isStaticSprite) {
                    Utils.UnityTools.SetSortingLayerOrder(meshRenderer, value);
                } else {
                    display.SetSortingLayerOrder(value);
                }
            }
        }
#if UNITY5
        [System.Obsolete("castShadows is obsolete. Use shadowCastingMode instead.")]
#endif
        public bool castShadows {
            get {
                if(!_initialized) return GetComponent<MeshRenderer>().castShadows;
                return meshRenderer.castShadows;
            }
            set {
                if(!_initialized) {
                    GetComponent<MeshRenderer>().castShadows = value;
                    return;
                }

                if(_isStaticSprite) {
                    meshRenderer.castShadows = value;
                } else {
                    display.SetCastShadows(value);
                }
            }
        }
        public bool receiveShadows {
            get {
                if(!_initialized) return GetComponent<MeshRenderer>().receiveShadows;
                return meshRenderer.receiveShadows;
            }
            set {
                if(!_initialized) {
                    GetComponent<MeshRenderer>().receiveShadows = value;
                    return;
                }

                if(_isStaticSprite) {
                    meshRenderer.receiveShadows = value;
                } else {
                    display.SetReceiveShadows(value);
                }
            }
        }
#if UNITY5
        public UnityEngine.Rendering.ShadowCastingMode shadowCastingMode {
            get {
                if(!_initialized) return GetComponent<MeshRenderer>().shadowCastingMode;
                return meshRenderer.shadowCastingMode;
            }
            set {
                if(!_initialized) {
                    GetComponent<MeshRenderer>().shadowCastingMode = value;
                    return;
                }

                if(_isStaticSprite) {
                    meshRenderer.shadowCastingMode = value;
                } else {
                    display.SetShadowCastingMode(value);
                }
            }
        }
#endif

        #endregion

        #region // Initialization
        
        private void Awake() {
            if(wasEverInitialized) {
                isDuplicate = true;

                // Clean up and destroy child objects
                
                // Sprite Planes
                // Must destroy these or duplicates will share planes
                DestroySpritePlanes();

                // Colliders
                // Cannot let child colliders be initialized normally because there is a bug that causes
                // Physics.IgnoreCollisions to fail on the first frame an object is duplicated
                DestroyColliders();

                // Locators
                // Clearing these these would screw up any hierarchies already established
                // Don't clear them
            }

            // link up cache vars
            thisTransform = transform;
            thisGameObject = gameObject;

            // set prev var initial states
            spriteUpdater_prev = spriteUpdater;
            renderActualPixelSize_prev = scaleToActualPixelSize;
            defaultAnimationOverride_prev = defaultAnimationOverride;
            currentMaterialSetIndex_prev = currentMaterialSetIndex;
            materialOverride_prev = materialOverride;
            billboardUpAxis_prev = billboardUpAxis;
            useBatchScale_prev = useBatchScaling;

            // load data from master sprite
            if(gameMasterSprite == null) {
                Debug.LogWarning(gameObject.name + " has no MasterSprite! Sprite has been disabled.");
                // Actually disable the object in Start() to avoid problems if OnGUI() exists
                return;
            }
            if(!isDuplicate) data = gameMasterSprite.data.DeepCopy(); // copy the entire data structure into this sprite
            data.sharedData = gameMasterSprite.sharedData; // link up shared data

            _initialized = true;
            wasEverInitialized = true;

            // object caches
            locatorSets = data.locatorSets;

            // Set some local value caches
            _animationCount = data.animationCount;
            _materialSetCount = data.materialSetCount;
            _colliderCount = data.colliderCount;
            _locatorCount = data.locatorCount;
            meshFrames = gameMasterSprite.sharedData.meshFrames; // mesh frames are shared among all instances to save memory

            // Set some vars
            _isStaticSprite = data.isStaticSprite;
            if(!isDuplicate) _currentAnimationIndex = defaultAnimationIndex; // always start current animation index at the default because editor preview is the default

            // Set up mesh frames
            if(data.useCustomMesh && meshFrames != null) {
                meshFrameCount = meshFrames.Length;
            }

            // Batch scaling
            if(useBatchScaling) {
                // Copy whatever starting transform scale we have into the batchScale and reset the transform scale
                _batchScale = thisTransform.localScale;
                thisTransform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
            }

            // check material index setting and make sure its valid
            if(currentMaterialSetIndex < 0 || currentMaterialSetIndex >= _materialSetCount) { // invalid
                currentMaterialSetIndex = data.defaultMaterialSetIndex; // use default
            }

            // Set up locators - do not set up again if a duplicate
            if(!isDuplicate &&_locatorCount > 0) CreateLocators();

            // Handle static and animated sprites
            if(_isStaticSprite) { // this is a static sprite

                _spriteMaterial = new SpriteMaterial(this, 1); // create the sprite material
                if(isDuplicate) { // reset the mesh to the default editor preview mesh if a duplicate so we don't keep instancing instances as it gets runtime duplicated
                    MeshFilter meshFilter = (MeshFilter)GetComponent(typeof(MeshFilter));
                    meshFilter.sharedMesh = GetEditorPreviewMesh();
                }
                if(materialOverride != null) SetMaterialOverride(materialOverride); // display material override on start
                ChangeMaterialSet(currentMaterialSetIndex); // change to starting material set always so we use the sprite/group material and not the editor material
                
            } else { // animated sprite

                // Initialize objects
                if(!isDuplicate) pauseTimer = new SpriteFactory.Utils.Timer();

                // Set some variables
                if(defaultAnimationOverride >= 0 && defaultAnimationOverride < _animationCount) { // default animation override
                    data.defaultAnimationIndex = defaultAnimationOverride;
                }

                // Do setup of display, geometry, materials, objects, etc
                InitializeDisplay(); 

                // Initialize animations
                if(!isDuplicate) {
                    for(int i = 0; i < _animationCount; i++) {
                        data.animations[i].Initialize(this, i);
                    }
                }
            }

            // Doing initial setup in Awake where we create colliders by using AddComponent enables a bug to happen which can crash the editor:
            // CRASH IN UNITY 3 AND 4
            // ONLY HAPPENS USING THE CHECKBOX IN THE INSPECTOR ON THE SPRITE
            // Start the player with sprite w/ parent collider disabled, enable during gameplay with the inspector, quit the player, crash
            // This is a known bug, but I feel its obscure enough to outweigh the benefits of running this in Awake -- namely, colliders and rigidbodies
            // will be ready to interact with immediately after spawning a Sprite
            // To avoid the editor crash bug, comment this and uncomment the EDITOR CRASH FIX areas in Start (2x), and OnEnable. May need to uncomment a variable too.
            DoInitialSetup();
        }

        private void Start() {
            if(!_initialized) {
                SpriteFactory.Utils.UnityTools.SetActive(thisGameObject, false); // disable the game object if we could not initialize
                return;
            }

            // EDITOR CRASH FIX Part 1
            //if(!initialSetupFinished) DoInitialSetup();

            // Add sprite to SpriteUpdater
            if(!selfUpdate && spriteUpdater != null) spriteUpdater.AddSprite(this);

            // Get camera cache
            if(isBillboard || scaleToActualPixelSize) { // this is a billboard polygon or we need to scale to actual pixel size
                mainCamera = Camera.main; // get camera if we need it for anything
                if(isBillboard) {
                    mainCameraTransform = mainCamera.transform;
                    CalculateBillboardAxis();
                }
            }

            // Scale sprite to screen
            if(scaleToActualPixelSize) {
                ScaleToActualPixelSize(mainCamera);
            }

            if(_isStaticSprite) return; // static sprites don't do anything beyond this point

            // Play animations on start
            if(!isDuplicate) {
                if(_animationCount > 0 && playAnimationOnStart) {
                    Play(data.defaultAnimationIndex); // play on start
                }
            }

            // EDITOR CRASH FIX Part 3
            // Do the delayed OnEnable so it happens the first time only after children have been created
            //if(deferredOnEnable) {
            //    deferredOnEnable = false;
            //    DoOnEnable();
            //}
        }

        private void DoInitialSetup() {
            initialSetupFinished = true;

            // All collider dependent code moved to Start() because of a Unity BUG:
            // Editor crash when AddComponent called in Awake() or OnEnable() when object first enabled in Play mode by clicking Activate checkbox in inspector.
            if(_colliderCount > 0) CreateColliders(); // set up colliders

            // Set up initial state on static and static animated sprites
            if(_isStaticSprite) { // static sprite
                
                // Batch scale static sprites
                if(useBatchScaling && (_batchScale.x != 1.0f || _batchScale.y != 1.0f || _batchScale.z != 1.0f))
                    UpdateBatchScale(); // scale the sprite mesh to the new scale immediately
            
            } else { // animated sprite
                
                // Special case for starting sprite with no animation playing (essentially static animated sprite)
                if(!playAnimationOnStart && !playDefaultAnimWhenIdle && _animationCount > 0) {
                    Animation[] anims = data.animations;
                    Animation anim = anims[defaultAnimationIndex];
                    Frame[] frames = anim.frames;
                    if(frames != null && frames.Length > 0) {
                        display.SetDefaultCurrentFrame(frames[0]); // assign first frame of default animation
                        if(useBatchScaling) display.Render(); // render the first frame so scale is correct

                        // Render the colliders and locators in the first frame
                        UpdateAnimatedColliders(frames[0]);
                        UpdateLocators(frames[0]);
                    }
                }
            }
        }

        private void InitializeDisplay() {
            // Create meshes for atlases
            Sprite.Atlas[] atlases = data.atlases;
            int atlasCount = atlases.Length;
            _spriteMaterial = new SpriteMaterial(this, atlasCount); // create the sprite material
            if(atlasCount == 0) {
                display = new SpriteDisplay();
                return;
            }
            
            display = new SpriteDisplay(data, _spriteMaterial, atlasCount, data.twoSidedMesh, data.useCustomMesh, _isFlipped, _xAxisFlipped, _yAxisFlipped); // create display object
            if(data.useCustomMesh) display.SetMeshFrameData(meshFrames, meshFrameCount); // fill mesh frame vars
            if(useBatchScaling) display.SetBatchScale(_batchScale, false); // set scale if we are using batch scaling

            meshRenderer = (MeshRenderer)this.GetComponent(typeof(MeshRenderer));
            MeshFilter meshFilter = (MeshFilter)this.GetComponent(typeof(MeshFilter));

            // Make sure we always start with the normal mesh, not a flipped mesh set in the editor
            if(isFlippedX || isFlippedY) {
                meshFilter.mesh = data.editorPreviewMeshes[0]; // assign the unflipped mesh so we're not working with a flipped mesh to begin with
            }

            // instantiate the sprite mesh objects
            // Always start with 1 mesh for previewing in editor. Use this mesh only if we have 1 atlas. This will be on the sprite game object.
            Atlas atlas = atlases[0];
            Material material = null;

            // Material Override
            bool overrideMaterial = false;
            if(materialOverride != null) {
                if(CheckMaterial(materialOverride)) { // make sure material is compatible
                    material = materialOverride; // override the main material
                    overrideMaterial = true;
                    display.materialOverridden = true;
                }
            }
            if(!overrideMaterial)
                material = atlas.materials[currentMaterialSetIndex]; // use the material saved in the atlas

            // Create primary sprite mesh
            display.AddPrimaryMesh(
                0,
                data.animations[data.defaultAnimationIndex].frames[0],
                atlas,
                meshFilter,
                meshRenderer,
                material,
                overrideMaterial
            );

            // Get sorting layer information from main mesh renderer
            int sortingLayerId = this.sortingLayerID;
            int sortingOrder = this.sortingOrder;

            // Create child meshes if needed
            if(atlasCount > 1) { // we have more than 1 atlas, create meshes and materials for each plane
                int parentLayer = thisGameObject.layer; // get the layer of the parent sprite
                
                // Get the default sprite plane mesh
                GameObject spritePlanePrefab;
                if(!data.twoSidedMesh) spritePlanePrefab = data.gameSettings.defaultObjects.spritePlane;
                else spritePlanePrefab = data.gameSettings.defaultObjects.spritePlaneTwoSided;

                for(int i = 1; i < atlasCount; i++) {
                    // instantiate plane
                    GameObject plane = (GameObject)Instantiate(spritePlanePrefab);
                    SpriteRenderMesh renderMesh = (SpriteRenderMesh)plane.GetComponent(typeof(SpriteRenderMesh));
                    Transform xform = renderMesh.transform;
                    xform.parent = thisTransform; // parent to this object
                    xform.localPosition = new Vector3(0.0f, 0.0f, 0.0f); // zero position
                    xform.localRotation = Quaternion.identity; // zero rotation so parent sprite rotation rules
                    xform.localScale = Vector3.one;
                    if(parentLayer != 0) plane.layer = parentLayer; // set the layer of the child object to the same layer as parent
#if UNITY5
                    renderMesh.meshRenderer.shadowCastingMode = meshRenderer.shadowCastingMode; // match the parent's shadow settings
#else
                    renderMesh.meshRenderer.castShadows = meshRenderer.castShadows; // match the parent's shadow settings
#endif
                    renderMesh.meshRenderer.receiveShadows = meshRenderer.receiveShadows;
                    renderMesh.Initialize(this); // initialize the child mesh and disable it

                    if(overrideMaterial)  // material was overridden
                        material = materialOverride; // use override material
                    else material = atlases[i].materials[currentMaterialSetIndex]; // get material from atlas

                    // create a new object
                    display.AddChildMesh(
                        i,
                        atlases[i],
                        renderMesh.meshFilter,
                        renderMesh.meshRenderer,
                        material,
                        overrideMaterial,
                        renderMesh,
                        sortingLayerId,
                        sortingOrder
                    );
                }
            }
            display.FinishSetup();
        }

        #endregion

        #region // Events
        
        private void Update() {
            if(selfUpdate) UpdateSprite();
        }

        private void OnEnable() {
            if(!_initialized) return; // prevent calling from editor mode
            // EDITOR CRASH FIX Part 2
            // This was used to avoid an editor crash bug explained in Awake. We are going to go ahead and let the bug exist because we want colliders set up in Awake.
            //if(!initialSetupFinished) { // this is the first run either on Play or when first activated, we must let initial setup finish in Start first
            //    deferredOnEnable = true; // defer the OnEnable processing until the end of Start
            //    return;
            //}
            DoOnEnable();
        }

        private void DoOnEnable() {
            if(_animationCount == 0) return;
            ActivateChildren();
        }
        
        private void OnDisable() {
            if(!_initialized) return; // prevent calling from editor mode
            if(_animationCount == 0) return;
            DeactivateChildren();
        }

        private void OnBecameVisible() {
            if(!_initialized) return; // prevent calling from editor mode
            if(_isStaticSprite) {
                static_isVisible = true;
                return;
            }
            display.primaryMeshVisible = true;

            // Possible reasons this was called:
            // Activated by animation system
            // Camera enter
            // Activation
            // MeshRenderer enabled
            // Scene load/play (if on camera)

            if(display.currentActive == 0) { // we know this is the active sprite mesh because we are set to show
                Render(); // re-render the mesh/uvs
            }
        }

        private void OnBecameInvisible() {
            if(!_initialized) return; // prevent calling from editor mode
            if(_isStaticSprite) {
                static_isVisible = false;
                return;
            }
            display.primaryMeshVisible = false;

            // Possible reasons this was called:
            // Deactivated by animation system
            // Camera exit
            // Deactivation
            // Destruction
            // MeshRenderer disabled
        }

        private void OnDestroy() {
            if(!_initialized) return;
            CleanUpTempMaterials();
        }
        
        #endregion

        #region // Main Updates

        public void UpdateSprite() { // update driven by SpriteManager
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(_animationCount <= 0) return; // no animations to play

            // Run updates only for animated sprites
            if(!_isStaticSprite) { // animated sprite
                if(!display.visible && !animateOffCamera) return; // don't animate when off camera

                DetectChangesToPublicVariables(); // react to changes to variables directly
                UpdateTimers();

                // Play the animation
                if(isPlaying) { // an animation is playing
                    if(!_isPaused) {
                        data.animations[_currentAnimationIndex].Animate(Time.deltaTime, playbackSpeed); // update animation
                    }
                } else { // no animation is playing
                    if(playDefaultAnimWhenIdle) {
                        Play(data.defaultAnimationIndex); // play the default animation if not playing anything else
                    }
                }

            } else { // static sprite
                DetectChangesToPublicVariables(); // react to changes to variables directly
            }

            // Billboard polygon look at camera
            if(isBillboard && isVisible) UpdateBillboardLookAt();

            // Wake rigidbody for special cases
            if(wakeUpParentRigidbody) spriteColliders[data.parentColliderIndex].rigidbodyInfo.WakeUp();
        }

        private void UpdateTimers() {
            if(_isPaused) {
                if(pauseTimer.Update(Time.deltaTime)) { // finished
                    Unpause();
                }
            }
        }

        private void DetectChangesToPublicVariables() {
            // Changes won't take place right away... Only after the cycle updates do they take effect

            if(spriteUpdater != spriteUpdater_prev) {
                SetSpriteUpdater(spriteUpdater); // update the sprite updater assignment and add/remove in SpriteUpdaters
            }

            if(useBatchScaling != useBatchScale_prev) {
                // Update original scale for locator children
                if(useBatchScaling && _locatorCount > 0) { // we have locators and useBatchScaling was just turned on
                    UpdateLocatorChildrenScale(); // get the current scale for each child and store it
                }
                UpdateBatchScale(); // update the scale on all objects
                useBatchScale_prev = useBatchScaling;
            }

            if(scaleToActualPixelSize != renderActualPixelSize_prev) {
                if(scaleToActualPixelSize) { // just enabled
                    if(mainCamera != Camera.main) mainCamera = Camera.main; // update main camera if it was null or changed
                    ScaleToActualPixelSize(mainCamera); // scale sprite
                }
                renderActualPixelSize_prev = scaleToActualPixelSize;
            }
            if(defaultAnimationOverride != defaultAnimationOverride_prev) {
                if(defaultAnimationOverride >= 0 && defaultAnimationOverride < _animationCount) {
                    data.defaultAnimationIndex = defaultAnimationOverride; // change the default animation in data
                } else {
                    defaultAnimationOverride = -1; // set to no override
                }
                defaultAnimationOverride_prev = defaultAnimationOverride;
            }
            if(currentMaterialSetIndex != currentMaterialSetIndex_prev) {
                currentMaterialSetIndex_prev = currentMaterialSetIndex;
                ChangeMaterialSet(currentMaterialSetIndex); // change the material set
            }
            if(materialOverride != materialOverride_prev) {
                materialOverride_prev = materialOverride;
                if(materialOverride != null) // adding a material
                    SetMaterialOverride(materialOverride); // override the material
                else // set to null, remove the material override
                    DisableMaterialOverride();
            }
            // billboardUpAxis handled in UpdateBillboardLookAt()

#if UNITY5
            // MeshRenderer.shadowCastingMode
            UnityEngine.Rendering.ShadowCastingMode shadowCastingMode = this.shadowCastingMode;
            if(shadowCastingMode != mrShadowCastingMode_prev) {
                mrShadowCastingMode_prev = shadowCastingMode;
                this.shadowCastingMode = shadowCastingMode; // change the setting in all meshes to match
            }
#else
            // MeshRenderer.castShadows - watch the mesh renderer for changes
            bool castShadows = this.castShadows;
            if(castShadows != mrCastShadows_prev) {
                mrCastShadows_prev = castShadows;
                this.castShadows = castShadows; // change the setting in all meshes to match
            }
#endif

            // MeshRenderer.receiveShadows - watch the mesh renderer for changes
            bool receiveShadows = this.receiveShadows;
            if(receiveShadows != mrReceiveShadows_prev) {
                mrReceiveShadows_prev = receiveShadows;
                this.receiveShadows = receiveShadows; // change the setting in all meshes to match
            }

        }

        #endregion

        #region // Public Animation Controls

        // *** Make sure all public controls and properties prevent running in editor if it sets anything that might be serialized ***

        // ANIMATION ////

        public void Play() {
            Play(false, false);
        }
        public void Play(bool replayFromStart) {
            Play(replayFromStart, false);
        }
        public void Play(bool replayFromStart, bool playBackwards) {
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(_animationCount <= 0) return;
            if(_isStaticSprite) return;

            // play the current animation again, or default if one was not playing
            if(isPlaying) { // already playing an animation
                Play(_currentAnimationIndex, replayFromStart, playBackwards); // just replay the current animation
            } else { // not playing anything
                if(_currentAnimationIndex < 0) { // no animation is currently set
                    PlayDefaultAnimation(replayFromStart, playBackwards); // just play the default
                } else { // play the last animation again
                    Play(_currentAnimationIndex, replayFromStart, playBackwards);
                }
            }
        }
        
        public void Play(string animationName) {
            Play(animationName, false, false);
        }
        public void Play(string animationName, bool replayFromStart) {
            Play(animationName, replayFromStart, false);
        }
        public void Play(string animationName, bool replayFromStart, bool playBackwards) {
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(_animationCount <= 0) return;
            if(_isStaticSprite) return;

            int index = FindAnimationIndex(animationName);
            if(index == -1) {
                Debug.LogError("Animation \"" + animationName + "\" not found in sprite!");
                return;
            }
            Play(index, replayFromStart, playBackwards);
        }

        public void Play(int animationIndex) {
            Play(animationIndex, false, false);
        }
        public void Play(int animationIndex, bool replayFromStart) {
            Play(animationIndex, replayFromStart, false);
        }
        public void Play(int animationIndex, bool replayFromStart, bool playBackwards) {
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(_animationCount <= 0) return;
            if(_isStaticSprite) return;

            if(animationIndex < 0 || animationIndex >= _animationCount) throw new System.Exception("Invalid animation index!");
            Sprite.Animation anim = data.animations[animationIndex];
            if(anim == null) throw new System.Exception("No animation at index " + animationIndex + "!");
            if(_isPaused) Unpause(); // unpause if paused
            if(!replayFromStart && anim.isPlaying) {
                if(anim.playBackwards == playBackwards) return; // don't replay the animation if already playing and direction matches
                else { // same animation is playing, but play mode is reversed
                    Reverse();
                    return;
                }
            }
            if(animationIndex != _currentAnimationIndex || replayFromStart) {
                data.animations[_currentAnimationIndex].Finished(true); // finish the previous animation first, or finish self if replaying from start
                _currentAnimationIndex = animationIndex; // save the index of the playing animation
            }
            anim.Play(playBackwards); // play the new animation
        }

        public void PlayAtFrame(string animationName, int frameIndex) {
            PlayAtFrame(animationName, frameIndex, false);
        }
        public void PlayAtFrame(string animationName, int frameIndex, bool playBackwards) {
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(_animationCount <= 0) return;
            if(_isStaticSprite) return;

            int index = FindAnimationIndex(animationName);
            if(index == -1) {
                Debug.LogError("Animation \"" + animationName + "\" not found in sprite!");
                return;
            }
            PlayAtFrame(index, frameIndex, playBackwards);
        }

        public void PlayAtFrame(int animationIndex, int frameIndex) {
            PlayAtFrame(animationIndex, frameIndex, false);
        }
        public void PlayAtFrame(int animationIndex, int frameIndex, bool playBackwards) {
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(_animationCount <= 0) return;
            if(_isStaticSprite) return;

            if(animationIndex < 0 || animationIndex >= _animationCount) throw new System.Exception("Invalid animation index!");
            Sprite.Animation anim = data.animations[animationIndex];
            if(anim == null) throw new System.Exception("No animation at index " + animationIndex + "!");
            data.animations[_currentAnimationIndex].Finished(true); // always end the previous animation first, even if self
            if(_currentAnimationIndex != animationIndex) _currentAnimationIndex = animationIndex; // save the index of the playing animation
            anim.Play(frameIndex, playBackwards); // play the new animation
            if(_isPaused) Unpause(); // unpause if paused
        }

        public void PlayDefaultAnimation() {
            PlayDefaultAnimation(false, false);
        }
        public void PlayDefaultAnimation(bool replayFromStart) {
            PlayDefaultAnimation(replayFromStart, false);
        }
        public void PlayDefaultAnimation(bool replayFromStart, bool playBackwards) {
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(_animationCount <= 0) return;
            if(_isStaticSprite) return;

            int defaultAnimationIndex = data.defaultAnimationIndex;
            if(defaultAnimationIndex < 0 || defaultAnimationIndex >= _animationCount) {
                Debug.LogWarning("No default animation found!");
                return;
            }
            Play(defaultAnimationIndex, replayFromStart, playBackwards);
        }

        public void Stop() {
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(!isPlaying) return;
            if(_isStaticSprite) return;

            if(playDefaultAnimWhenIdle) {
                PlayDefaultAnimation(false, false); // revert to playing the default animation
            } else { // do not play the default, just stop at current frame
                data.animations[_currentAnimationIndex].isPlaying = false;
            }
        }

        public void Pause() {
            Pause(0.0f);
        }
        public void Pause(float time) {
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(_animationCount <= 0) return;
            if(_isStaticSprite) return;

            if(time > 0.0f) { // timed pause
                pauseTimer.Start(time);
            }
            _isPaused = true;
        }

        public void Unpause() {
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(!_isPaused) return;
            if(_isStaticSprite) return;

            _isPaused = false;
            if(pauseTimer.running) pauseTimer.Clear(); // clear the timer
        }

        public void Rewind() {
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(_animationCount <= 0) return;
            if(_isStaticSprite) return;

            // Rewind the current animation to frame 0, do not start playing it again, but if its already playing, do not stop it
            data.animations[_currentAnimationIndex].Rewind();
        }

        public void Reverse() {
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(_animationCount <= 0) return;
            if(_isStaticSprite) return;
            if(_currentAnimationIndex < 0 || _currentAnimationIndex >= _animationCount) return;
            Sprite.Animation anim = data.animations[_currentAnimationIndex];
            if(anim == null || !anim.isPlaying) return;
            anim.Reverse();
        }

        public bool IsAnimationPlaying(string animationName) {
            if(!_initialized) return false; // prevent calling from editor mode
            if(_animationCount <= 0) return false;

            int index = FindAnimationIndex(animationName);
            if(index == -1) {
                Debug.LogError("Animation \"" + animationName + "\" not found in sprite!");
                return false;
            }
            return IsAnimationPlaying(index);
        }

        public bool IsAnimationPlaying(int animationIndex) {
            if(!_initialized) return false; // prevent calling from editor mode

            if(isPlaying && _currentAnimationIndex == animationIndex) return true;
            return false;
        }

        public float GetAnimationSpeed(string animationName) {
            if(!_initialized) return -1.0f; // editor mode
            if(_animationCount <= 0) return -1.0f;
            int index = FindAnimationIndex(animationName);
            if(index == -1) {
                Debug.LogError("Animation \"" + animationName + "\" not found in sprite!");
                return -1.0f;
            }
            return GetAnimationSpeed(index);
        }

        public float GetAnimationSpeed(int animationIndex) {
            if(!_initialized) return -1.0f; // editor mode
            if(_animationCount <= 0) return -1.0f;
            if(animationIndex < 0 || animationIndex >= _animationCount) throw new System.Exception("Invalid animation index!");
            Sprite.Animation anim = data.animations[animationIndex];
            if(anim == null) throw new System.Exception("No animation at index " + animationIndex + "!");
            return anim.speed;
        }

        public void SetAnimationSpeed(string animationName, float speed) {
            if(!_initialized) { // prevent calling from editor mode
                Debug.LogError("Animation speed cannot be set before Awake runs in Sprite! Consider moving the call to Start.");
                return;
            }
            if(_animationCount <= 0) return;
            int index = FindAnimationIndex(animationName);
            if(index == -1) {
                Debug.LogError("Animation \"" + animationName + "\" not found in sprite!");
                return;
            }
            SetAnimationSpeed(index, speed);
        }

        public void SetAnimationSpeed(int animationIndex, float speed) {
            if(!_initialized) { // prevent calling from editor mode
                Debug.LogError("Animation speed cannot be set before Awake runs in Sprite! Consider moving the call to Start.");
                return;
            }
            if(_animationCount <= 0) return;
            if(animationIndex < 0 || animationIndex >= _animationCount) throw new System.Exception("Invalid animation index!");
            Sprite.Animation anim = data.animations[animationIndex];
            if(anim == null) throw new System.Exception("No animation at index " + animationIndex + "!");
            anim.speed = speed;
        }

        public void SetAnimationStartedCallback(string animationName, System.Action callback) {
            if(!_initialized) { // prevent calling from editor mode
                Debug.LogError("Animation callback cannot be set before Awake runs in Sprite! Consider moving the call to Start.");
                return;
            }
            if(_animationCount <= 0) return;
            int index = FindAnimationIndex(animationName);
            if(index == -1) {
                Debug.LogError("Animation \"" + animationName + "\" not found in sprite!");
                return;
            }
            SetAnimationStartedCallback(index, callback);
        }

        public void SetAnimationStartedCallback(int animationIndex, System.Action callback) {
            if(!_initialized) { // prevent calling from editor mode
                Debug.LogError("Animation callback cannot be set before Awake runs in Sprite! Consider moving the call to Start.");
                return;
            }
            if(_animationCount <= 0) return;
            if(animationIndex < 0 || animationIndex >= _animationCount) throw new System.Exception("Invalid animation index!");
            Sprite.Animation anim = data.animations[animationIndex];
            if(anim == null) throw new System.Exception("No animation at index " + animationIndex + "!");
            anim.SetStartedCallback(callback);
        }

        public void SetAnimationFinishedCallback(string animationName, System.Action callback) {
            if(!_initialized) { // prevent calling from editor mode
                Debug.LogError("Animation callback cannot be set before Awake runs in Sprite! Consider moving the call to Start.");
                return;
            }
            if(_animationCount <= 0) return;
            int index = FindAnimationIndex(animationName);
            if(index == -1) {
                Debug.LogError("Animation \"" + animationName + "\" not found in sprite!");
                return;
            }
            SetAnimationFinishedCallback(index, callback);
        }

        public void SetAnimationFinishedCallback(int animationIndex, System.Action callback) {
            if(!_initialized) { // prevent calling from editor mode
                Debug.LogError("Animation callback cannot be set before Awake runs in Sprite! Consider moving the call to Start.");
                return;
            }
            if(_animationCount <= 0) return;
            if(animationIndex < 0 || animationIndex >= _animationCount) throw new System.Exception("Invalid animation index!");
            Sprite.Animation anim = data.animations[animationIndex];
            if(anim == null) throw new System.Exception("No animation at index " + animationIndex + "!");
            anim.SetFinishedCallback(callback);
        }

        public void SetAnimationEndedCallback(string animationName, System.Action callback) {
            if(!_initialized) { // prevent calling from editor mode
                Debug.LogError("Animation callback cannot be set before Awake runs in Sprite! Consider moving the call to Start.");
                return;
            }
            if(_animationCount <= 0) return;
            int index = FindAnimationIndex(animationName);
            if(index == -1) {
                Debug.LogError("Animation \"" + animationName + "\" not found in sprite!");
                return;
            }
            SetAnimationEndedCallback(index, callback);
        }

        public void SetAnimationEndedCallback(int animationIndex, System.Action callback) {
            if(!_initialized) { // prevent calling from editor mode
                Debug.LogError("Animation callback cannot be set before Awake runs in Sprite! Consider moving the call to Start.");
                return;
            }
            if(_animationCount <= 0) return;
            if(animationIndex < 0 || animationIndex >= _animationCount) throw new System.Exception("Invalid animation index!");
            Sprite.Animation anim = data.animations[animationIndex];
            if(anim == null) throw new System.Exception("No animation at index " + animationIndex + "!");
            anim.SetEndedCallback(callback);
        }

        public WrapMode GetAnimationWrapMode() {
            return GetAnimationWrapMode(_currentAnimationIndex);
        }

        public WrapMode GetAnimationWrapMode(string animationName) {
            return GetAnimationWrapMode(FindAnimationIndex(animationName));
        }

        public WrapMode GetAnimationWrapMode(int animationIndex) {
            if(!_initialized) return WrapMode.Once; // prevent calling from editor mode
            if(_animationCount <= 0) return WrapMode.Once;
            if(_isStaticSprite) return WrapMode.Clamp;
            if(animationIndex < 0 || animationIndex >= data.animationCount) return WrapMode.Once;
            return data.animations[animationIndex].wrapMode;
        }

        #endregion

        #region // Public User Functions

        #region // MATERIALS

        public void SetMaterialOverride(Material material) {
            if(_animationCount <= 0) return;
            if(!CheckMaterial(material)) return; // make sure material is compatible
            if(!_initialized) { // editor mode
                materialOverride = material; // set the material override the actual incoming material
                return;
            }
            if(material == null) {
                if(IsMaterialOverridden()) DisableMaterialOverride();
                materialOverride = null;
                materialOverride_prev = null; // set now so it won't process twice
                return;
            }

            // game mode
            // Update display
            if(_isStaticSprite) {
                Sprite.Atlas[] atlases = data.atlases;
                if(atlases == null || atlases.Length == 0) return;
                AssignMaterialOnStaticSprite(material, atlases[0].textureMap, true); // apply material to sprite
            } else {
                display.SetMaterialOverride(material); // set the material to a copy of the incoming material
            }
            materialOverride = material;
            materialOverride_prev = material; // set now so it won't process twice
        }

        public void EnableMaterialOverride() { // enable last set material override
            if(_animationCount <= 0) return;
            if(!_initialized) return; // editor mode
            if(materialOverride == null) {
                Debug.LogWarning("No material override has been set yet! Assign a material override in the inspector or call SetMaterialOverride(material).");
                return;
            }
            SetMaterialOverride(materialOverride);
        }

        public void DisableMaterialOverride() {
            if(_animationCount <= 0) return;
            if(!_initialized) { // editor mode
                materialOverride = null; // set the material override to none
                return;
            }

            // game mode
            // Update display
            if(_isStaticSprite) {
                // replace material with one from last selected material set
                if(!static_materialOverridden) return;
                Sprite.Atlas[] atlases = data.atlases;
                if(atlases == null || atlases.Length == 0) return;
                AssignMaterialOnStaticSprite(atlases[0].materials[currentMaterialSetIndex], null, false); // revert to last material set material
            } else {
                display.RemoveMaterialOverride(currentMaterialSetIndex);
            }
        }

        public void ChangeMaterialSet(string materialSetName) {
            if(_animationCount <= 0) return;
            if(!_initialized) { // editor mode
                // Find the material set in the source sprite
                Sprite.MaterialSet[] materialSets = gameMasterSprite.data.materialSets;
                if(materialSets != null) {
                    for(int i = 0; i < materialSets.Length; i++) {
                        if(materialSets[i].name == materialSetName) {
                            currentMaterialSetIndex = i;
                            return;
                        }
                    }
                }
                Debug.LogError("Material Set \"" + materialSetName + "\" not found in sprite!");
                return;

            }

            // game mode
            int index = FindMaterialSetIndex(materialSetName);
            if(index == -1) {
                Debug.LogError("Material Set \"" + materialSetName + "\" not found in sprite!");
                return;
            }
            ChangeMaterialSet(index); // call int function
        }

        public void ChangeMaterialSet(int materialSetIndex) {
            if(_animationCount <= 0) return;
            if(!_initialized) { // editor mode
                // Find the material set in the source sprite
                Sprite.MaterialSet[] materialSets = gameMasterSprite.data.materialSets;
                if(materialSetIndex < 0 || materialSetIndex >= materialSets.Length) {
                    Debug.LogError("Material Set \"" + materialSetIndex + "\" not found in sprite!");
                    return;
                }
                currentMaterialSetIndex = materialSetIndex;
                return;
            }

            // game mode
            if(_materialSetCount <= 0 || materialSetIndex >= _materialSetCount) {
                Debug.LogError("Material Set \"" + materialSetIndex + "\" not found in sprite!");
                return;
            }
            currentMaterialSetIndex = materialSetIndex;

            // Update display
            if(_isStaticSprite) {
                if(static_materialOverridden) return; // don't update the display because material override is still in effect
                // replace material with one from selected material set
                Sprite.Atlas[] atlases = data.atlases;
                if(atlases == null || atlases.Length == 0) return;
                AssignMaterialOnStaticSprite(atlases[0].materials[currentMaterialSetIndex], null, false); // apply material to sprite

            } else {
                display.ChangeMaterialSet(currentMaterialSetIndex); // change the material on the sprite meshes
            }
        }

        #endregion

        #region // COLLIDER SETS

        public ColliderInfo[] GetColliders() {
            if(!_initialized) return null; // called in editor
            if(_colliderCount == 0) return null; // no colliders
            ColliderInfo[] colliders = new ColliderInfo[_colliderCount];
            for(int i = 0; i < _colliderCount; i++) {
                ColliderInfo colliderInfo = spriteColliders[i].colliderInfo;
                if(colliderInfo == null) continue; // collider info is null, don't add
                colliders[i] = new ColliderInfo(colliderInfo); // clone it
            }
            return colliders;
        }

        public ColliderInfo GetCollider(int colliderId) {
            if(!_initialized) return null; // called in editor
            if(_colliderCount == 0) return null; // no colliders
            if(colliderId < 0 || colliderId >= _colliderCount) return null;
            ColliderInfo colliderInfo = spriteColliders[colliderId].colliderInfo;
            if(colliderInfo == null) return null;
            return new ColliderInfo(spriteColliders[colliderId].colliderInfo); // clone it
        }

        public ColliderInfo GetCollider(string colliderName) {
            if(!_initialized) return null; // called in editor
            if(_colliderCount == 0) return null; // no colliders
            if(colliderName == null || colliderName == "" || colliderName == string.Empty) return null;

            ColliderSet[] colliderSets = data.colliderSets;
            for(int i = 0; i < _colliderCount; i++) {
                if(colliderSets[i].name == colliderName) {
                    ColliderInfo colliderInfo = spriteColliders[i].colliderInfo;
                    if(colliderInfo == null) return null; // collider info is null
                    return new ColliderInfo(colliderInfo); // clone
                }
            }
            Debug.LogWarning("Collider \"" + colliderName + "\" not found in Sprite!");
            return null;
        }

        public RigidbodyInfo GetRigidbody(int colliderId) {
            if(!_initialized) return null; // called in editor
            if(_colliderCount == 0) return null; // no colliders
            if(colliderId < 0 || colliderId >= _colliderCount) return null;
            RigidbodyInfo rbInfo = spriteColliders[colliderId].rigidbodyInfo;
            if(rbInfo == null) return null; // no rigidbody
            return new RigidbodyInfo(rbInfo); // clone it
        }

        public RigidbodyInfo GetRigidbody(string colliderName) {
            if(!_initialized) return null; // called in editor
            if(_colliderCount == 0) return null; // no colliders
            if(colliderName == null || colliderName == "" || colliderName == string.Empty) return null;

            ColliderSet[] colliderSets = data.colliderSets;
            for(int i = 0; i < _colliderCount; i++) {
                if(colliderSets[i].name == colliderName) {
                    RigidbodyInfo rbInfo = spriteColliders[i].rigidbodyInfo;
                    if(rbInfo == null) return null; // no rigidbody
                    return new RigidbodyInfo(rbInfo); // clone it
                }
            }
            Debug.LogWarning("Collider \"" + colliderName + "\" not found in Sprite!");
            return null;
        }

        #endregion

        #region // LOCATORS

        public Locator GetLocator(int locatorId) {
            if(!_initialized) return null; // called in editor
            if(_locatorCount == 0) return null; // no locators
            if(locatorId < 0 || locatorId >= _colliderCount) return null;
            return locators[locatorId];
        }

        public Locator GetLocator(string locatorName) {
            if(!_initialized) return null; // called in editor
            if(_locatorCount == 0) return null; // no locators
            if(locatorName == null || locatorName == "" || locatorName == string.Empty) return null;

            for(int i = 0; i < _locatorCount; i++) {
                if(locators[i].name == locatorName) return locators[i];
            }
            Debug.LogWarning("Locator \"" + locatorName + "\" not found in Sprite!");
            return null;
        }

        #endregion

        #region // FLIP

        public void FlipX() {
            _xAxisFlipped = !_xAxisFlipped;
            if(_xAxisFlipped || _yAxisFlipped) _isFlipped = true;
            else _isFlipped = false;

            if(!_initialized) { // called in editor
                // Swap editor meshes in mesh filter
                MeshFilter mf = (MeshFilter)GetComponent(typeof(MeshFilter));
                if(mf == null) {
                    Debug.LogWarning("No MeshFilter found!");
                    return;
                }
                if(gameMasterSprite == null) return;
                Mesh editorPreviewMesh = GetEditorPreviewMesh(); // get the proper mesh based on current flip states
                if(editorPreviewMesh == null) return;
                mf.sharedMesh = editorPreviewMesh; // set mesh in mesh filter
                return;
            }

            // Called in game
            if(_isStaticSprite) Static_FlipMesh(true, false); // flip static sprite
            else display.SetFlippedState(_xAxisFlipped, _yAxisFlipped); // update sprite display
            RenderCollidersAndLocators(); // update the sprite now
        }

        public void FlipY() {
            _yAxisFlipped = !_yAxisFlipped;
            if(_xAxisFlipped || _yAxisFlipped) _isFlipped = true;
            else _isFlipped = false;

            if(!_initialized) { // called in editor
                // Swap editor meshes in mesh filter
                MeshFilter mf = (MeshFilter)GetComponent(typeof(MeshFilter));
                if(mf == null) {
                    Debug.LogWarning("No MeshFilter found!");
                    return;
                }
                if(gameMasterSprite == null) return;
                Mesh editorPreviewMesh = GetEditorPreviewMesh(); // get the proper mesh based on current flip states
                if(editorPreviewMesh == null) return;
                mf.sharedMesh = editorPreviewMesh; // set mesh in mesh filter
                return;
            }

            // Called in game
            if(_isStaticSprite) Static_FlipMesh(false, true); // flip static sprite
            else display.SetFlippedState(_xAxisFlipped, _yAxisFlipped); // update sprite display
            RenderCollidersAndLocators(); // update the sprite now
        }

        public void Flip(bool flipX, bool flipY) {
            if(!_initialized) { // called in editor
                if(flipX) FlipX();
                if(flipY) FlipY();
                return;
            }

            // Called in game
            if(flipX) _xAxisFlipped = !_xAxisFlipped;
            if(flipY) _yAxisFlipped = !_yAxisFlipped;
            if(_xAxisFlipped || _yAxisFlipped) _isFlipped = true;
            else _isFlipped = false;
            if(_isStaticSprite) Static_FlipMesh(flipX, flipY); // flip static sprite
            else display.SetFlippedState(_xAxisFlipped, _yAxisFlipped); // update sprite display
            RenderCollidersAndLocators(); // update the sprite now
        }

        public void SetFlippedState(bool xFlippedState, bool yFlippedState) {
            if(!_initialized) { // called in editor
                if(xFlippedState != _xAxisFlipped) FlipX();
                if(yFlippedState != _yAxisFlipped) FlipY();
                return;
            }

            // Called in game
            bool changeX;
            bool changeY;
            if(_xAxisFlipped != xFlippedState) changeX = true;
            else changeX = false;
            if(_yAxisFlipped != yFlippedState) changeY = true;
            else changeY = false;
            _xAxisFlipped = xFlippedState;
            _yAxisFlipped = yFlippedState;
            if(_xAxisFlipped || _yAxisFlipped) _isFlipped = true;
            else _isFlipped = false;
            if(_isStaticSprite) Static_FlipMesh(changeX, changeY); // flip static sprite
            else display.SetFlippedState(_xAxisFlipped, _yAxisFlipped); // update sprite display
            RenderCollidersAndLocators(); // update the sprite now
        }

        #endregion

        #region // OTHER

        public void ScaleToActualPixelSize(Camera camera) {
            if(camera == null) return;
            if(!Utils.UnityTools.Camera.isOrthographic(camera)) {
                Debug.LogWarning("Sprite can only be displayed at actual pixel size if the camera projection is set to orthographic.");
                return;
            }

            // Make sure SpriteCamera isn't already scaling to actual pixel size
            SpriteCamera spriteCamera = (SpriteCamera)camera.GetComponent(typeof(SpriteCamera));
            if(spriteCamera != null) {
                if(spriteCamera.renderAtActualPixelSize) // sprite camera is already going to render at actual pixel size, don't scale
                    return;
            }

            // Get information on the screen from the camera
            float screenHeight = camera.pixelHeight;
            float screenUnitsY = camera.orthographicSize * 2.0f; // how many units fit on the screen

            // Get dimensions of sprite
            Sprite.Animation[] animations = data.animations;
            if(animations == null || animations.Length == 0) return; // no animations
            if(animations[0].frames == null || animations[0].frames.Length == 0) return; // no frames
            Frame frame = data.animations[0].frames[0];
            int spriteHeight = frame.pixelHeight;
            float spriteUnitHeight = frame.meshExtents.y * 2.0f;

            // Find out how big this sprite should be compared to the screen
            float pixelHeightRatio = spriteHeight / screenHeight; // how big is this sprite compared to the pixel screen height?
            float unitHeightRatio = spriteUnitHeight / screenUnitsY; // how big os this sprite compared to the unit screen height?

            float size = pixelHeightRatio / unitHeightRatio; // scale unit height to be 1:1 on screen

            // Scale the sprite
            if(useBatchScaling) {
                //thisTransform.localScale = new Vector3(1.0f, 1.0f, 1.0f); // make sure the transform isn't scaled
                batchScale = new Vector3(size, size, 1.0f); // scale and update using batch scale
            } else {
                thisTransform.localScale = new Vector3(size, size, 1.0f); // scale using transform
            }
        }

        public void IgnoreCollisions(Collider collider) {
            if(!_initialized) return;
            if(_colliderCount == 0) return;
            if(collider == null) return;
            IgnoreCollisionsWithInternalColliders<Collider>(collider); // ignore collisions between incoming collider and all colliders in the sprite
        }

        public void IgnoreCollisions<TCollider>(TCollider collider) where TCollider : Component {
            if(!_initialized) return;
            if(_colliderCount == 0) return;
            if(collider == null) return;

            // make sure component is a proper type
            if(!Utils.UnityTools.IsColliderOrCollider2D(typeof(TCollider))) throw new System.ArgumentException("TCollider must be equal to or derrived from Collider or Collider2D!");
            
            IgnoreCollisionsWithInternalColliders<TCollider>(collider); // ignore collisions between incoming collider and all colliders in the sprite
        }

        public void SetActiveRecursively(bool state) {
            SpriteFactory.Utils.UnityTools.SetActiveRecursively(thisGameObject, state, false);
        }

        public void SetSpriteUpdater(SpriteUpdater newSpriteUpdater) {
            if(!_initialized) return; // called in editor

            // For when user changes SpriteUpdater directly in Sprite -- Must assign/unassign to SpriteUpdaters
            if(newSpriteUpdater == spriteUpdater_prev) return; // same updater

            // We want to change sprite updaters, Sprite is handling assignment/unassignment
            if(newSpriteUpdater != null) { // changing to a new updater

                int index = newSpriteUpdater.AddSprite(this); // add this sprite to new updater, will automatically remove it from old one
                // the sprite updater variable was already updated by AddSprite above on success
                // on fail, no assignment change was made
                if(index >= 0) { // not allowed to self update, only change if assignment was successful
                    if(selfUpdate) selfUpdate = false; // don't self update anymore so we don't update the sprite twice
                }

            } else { // assigning null

                if(spriteUpdater_prev != null) spriteUpdater_prev.RemoveSprite(this, false); // remove it from old updater first
                spriteUpdater = null; // clear updater
                spriteUpdater_prev = null; // store for prev comparison
            }
        }

        public void SetUseBatchScaling(bool state, bool convertTransformScale = true) {
            if(!_initialized) return; // called in editor
            if(state == useBatchScaling) return; // already set

            useBatchScaling = state;
            if(convertTransformScale && state) { // just turned on batch scaling, convert transform scale to batch scale
                _batchScale = thisTransform.localScale;
                thisTransform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
            }
            // Update original scale for locator children
            if(state && _locatorCount > 0) { // we have locators and useBatchScaling was just turned on
                UpdateLocatorChildrenScale(); // get the current scale for each child and store it
            }
            UpdateBatchScale(); // update scale on all parts
            useBatchScale_prev = state; // save prev state
        }

        #endregion

        #region // GET INFORMATION

        public string[] GetAnimationNames() {
            if(!_initialized) { // called in editor
                if(gameMasterSprite == null) return null;
                return gameMasterSprite.data.GetAnimationNames();
            }

            // called in-game
            return data.GetAnimationNames();
        }

        public string[] GetMaterialSetNames() {
            if(!_initialized) { // called in editor
                if(gameMasterSprite == null) return null;
                return gameMasterSprite.data.GetMaterialSetNames();
            }

            // called in-game
            return data.GetMaterialSetNames();
        }

        public int[] GetAnimationFrameCounts() {
            if(!_initialized) { // called in editor
                if(gameMasterSprite == null) return null;
                return gameMasterSprite.data.GetAnimationFrameCounts();
            }

            // called in-game
            return data.GetAnimationFrameCounts();
        }

        public string[] GetColliderNames() {
            if(!_initialized) { // called in editor
                if(gameMasterSprite == null) return null;
                return gameMasterSprite.data.GetColliderSetNames();
            }
            if(_colliderCount == 0) return null; // no colliders
            string[] names = new string[_colliderCount];
            for(int i = 0; i < _colliderCount; i++)
                names[i] = spriteColliders[i].name;
            return names;
        }

        public bool GetEditorPreviewFrameData(out Texture2D texture, out Rect uvCoords) {
            texture = null;
            Frame frame;
            Sprite.Data spriteData;

            // Get data source based on whether we're in the editor or in the player
            if(!_initialized) { // called in editor
                if(gameMasterSprite == null) {
                    uvCoords = new Rect();
                    return false;
                }
                spriteData = gameMasterSprite.data;
            } else { // called in-game
                spriteData = data;
            }

            // Get data
            frame = spriteData.GetEditorPreviewFrame(); // get frame
            texture = spriteData.GetEditorPreviewAtlasTexture(); // get atlas texture
            if(frame == null || texture == null) { // no frame or texture found
                uvCoords = new Rect();
                return false;
            }
            uvCoords = frame.uvCoords;

            return true;
        }

        #endregion

        #endregion

        #region // Public Comm Functions

        // for communication between SpriteRenderMesh and Sprite

        public void Render() { // Force the current frame to render/update
            if(!_initialized) return; // prevent calling from editor mode
            if(!_isActive) return;
            if(_animationCount <= 0) return;
            if(_currentAnimationIndex < 0) return;

            display.Render(); // update the frame uv's and mesh
        }

        // for communication between SpriteCollider and Sprite

        public void ColliderEnabled(int colliderIndex) {
            if(!_initialized) return; // prevent calling from editor mode
            if(_colliderCount == 0) return;
            if(colliderIndex < 0 || colliderIndex >= _colliderCount) return;

            // Make sure collider is allowed to be enabled first, disable if not
            ColliderSet colliderSet = data.colliderSets[colliderIndex];
            if(colliderSet.isAnimated) { // animated collider
                Frame frame = GetCurrentFrame();
                if(frame == null) { // no frames, should not be active
                    SetColliderActive(spriteColliders[colliderIndex], false); // disable collider
                    //Debug.Log("Animated collider has no frames and cannot be enabled! Disable!");
                    // Collider will actually be off but unity will display it as if its on
                    return;
                }
                ColliderFrame colliderFrame = frame.colliderFrames[colliderIndex];
                if(!colliderFrame.enabled) { // frame shouldn't be enabled
                    SetColliderActive(spriteColliders[colliderIndex], false); // disable collider
                    //Debug.Log("Animated collider is not supposed to be enabled! Disable!");
                    //Collider will actually be off but unity will display it as if its on
                    return;
                }
            } else { // static collider
                ColliderFrame colliderFrame = colliderSet.staticColliderFrame;
                if(!colliderFrame.enabled) { // this collider frame is not supposed to be enabled
                    SetColliderActive(spriteColliders[colliderIndex], false); // disable collider
                    //Debug.Log("Static collider is not supposed to be enabled! Disable!");
                    //Collider will actually be off but unity will display it as if its on
                    return;
                }
            }
            
            IgnoreCollisionsWithInternalColliders(colliderIndex); // ignore colliders now
        }

        // for communication between SpriteLocator and Sprite

        public void LocatorEnabled(int locatorIndex) { // called when a locator runs OnEnable but doesn't detect that it was called by Sprite animation
            if(!_initialized) return; // prevent calling from editor mode
            if(_locatorCount == 0) return;
            if(locatorIndex < 0 || locatorIndex >= _locatorCount) return;
            Frame frame = GetCurrentFrame();
            if(frame == null) return;

            if(_isActive && frame.locatorFrames[locatorIndex].enabled) { // locator is allowed to be activated now, make sure children are activated too
                if(activateLocatorsRecursively) locators[locatorIndex].SetActiveRecursively(true); // recursively activate the locator
                else locators[locatorIndex].SetActive(true, true); // activate the locator and first level children

            } else { // locator isn't supposed to be enabled in this frame, disable it and children
                if(activateLocatorsRecursively) locators[locatorIndex].SetActiveRecursively(false); // recursively deactivate the locator
                else locators[locatorIndex].SetActive(false, true); // deactivate the locator and first level children
            }
        }

        // for communication between SpriteHelperU3 and Sprite (Unity 3.x only)

        public void DoDeferredParentColliderStateChange(bool state) {
            // This should only be called in Unity 3.x by SpriteU3Helper
            if(!_initialized) return;
            if(_colliderCount == 0) return;
            int parentColliderIndex = data.parentColliderIndex;
            if(parentColliderIndex < 0) return;

            // Toggle the state back and forth to make sure its in truly in the proper state -- this is the only way to force it to update
            SetColliderActive(spriteColliders[parentColliderIndex], !state, true, false); // force update, don't ignore physics
            SetColliderActive(spriteColliders[parentColliderIndex], state, true, true); // force update, do ignore physics
        }

        public void DoDeferredChildColliderStateChange(Utils.DataClasses.Workpool_int colliderIndices,  Utils.DataClasses.Workpool_bool states) {
            // This should only be called in Unity 3.x by SpriteU3Helper
            if(!_initialized) return;
            if(_colliderCount == 0) return;

            // Set the collider states
            for(int i = 0; i < colliderIndices.Length; i++) {
                int colliderIndex = colliderIndices[i];
                bool state = states[i];
                if(!state) { // deactivated collider
                    // Workaround for: Collider is supposed to be deactivated, but when parent game object is activated, even though collider game object is !active, it still collides. Toggle it.
                    SetColliderActive(spriteColliders[colliderIndex], true, true, false); // force enable before we disable below
                }
                SetColliderActive(spriteColliders[colliderIndex], state, true); // set the final state on the collider gameobject
            }
        }

        #endregion

        #region // Callbacks

        private void DisplayFrame(Frame frame, bool isSkipFrame) {

            // Update the sprite display if necessary
            if(!isSkipFrame) display.Update(frame);

            // Update the colliders if necessary
            if(_colliderCount > 0 && data.hasAnimatedColliders) UpdateAnimatedColliders(frame);

            // Update the locators if necessary
            if(_locatorCount > 0) UpdateLocators(frame);
        }

        private void ReportFrameStartEvent(FrameEvent frameEvent) {
            thisGameObject.SendMessage("OnSpriteFrameStart", frameEvent, SendMessageOptions.DontRequireReceiver);
        }

        private void ReportFrameEndEvent(FrameEvent frameEvent) {
            thisGameObject.SendMessage("OnSpriteFrameEnd", frameEvent, SendMessageOptions.DontRequireReceiver);
        }

        public void SpriteUpdaterCallback(SpriteUpdater newSpriteUpdater) { // callback for SpriteUpdater.AddSprite(sprite)
            if(!_initialized) return; // called in editor

            if(newSpriteUpdater != spriteUpdater_prev && spriteUpdater_prev != null) spriteUpdater_prev.RemoveSprite(this, false); // remove it from old updater first
            if(newSpriteUpdater != null && selfUpdate) selfUpdate = false; // disable self update if assigning a new SpriteUpdater
            spriteUpdater = newSpriteUpdater; // set the new updater
            spriteUpdater_prev = newSpriteUpdater; // store for prev comparison
        }

        #endregion

        #region // Colliders

        private void CreateColliders() {
            ColliderSet[] colliderSets = data.colliderSets;
            spriteColliders = new SpriteCollider[_colliderCount];
            isColliderAnimated = new bool[_colliderCount];
            int parentColliderIndex = data.parentColliderIndex;
            ColliderSet colliderSet;
            ColliderGroup colliderGroup;
            Component colliderComponent;
            bool parentHasRigidbody = false;
            bool hasAnimatedChildWithoutRigidbody = false;
            bool deferredParentColliderDisable = false;

            // Create a helper component for Unity 3 to workaround bugs with component.enable and Physics.IgnoreCollisions being run in OnEnable
            if(Utils.UnityTools.isSupportedVersion3) {
                unity3SpriteHelper = (SpriteHelperU3) thisGameObject.AddComponent(typeof(SpriteHelperU3)); // create a new component to handle issues for Unity3
                unity3SpriteHelper.Initialize(this, _colliderCount); // initialize the sprite helper
            }

            // Create parent collider
            if(parentColliderIndex >= 0) { // we have a parent collider
                colliderSet = colliderSets[parentColliderIndex];
                if(colliderSet.groupId >= 0) colliderGroup = data.GetColliderGroup(colliderSet.groupId);
                else colliderGroup = null;
                
                // Check and add or remove collider
                CheckAndRemoveExistingColliders(thisGameObject); // remove existing collider or collider2D on the main game object if any

                // Create parent collider
                colliderComponent = CreateColliderComponent(colliderSet, thisGameObject); // create the collider component

                // Remove any existing rigidbodies first
                CheckAndRemoveExistingRigidbodies(thisGameObject);

                // Add rigidbody if necessary
                Component rigidbodyComponent = null;
                if(colliderSet.hasRigidbody) {
                    parentHasRigidbody = true;
                    rigidbodyComponent = CreateRigidbodyComponent(colliderSet, thisGameObject); // add the rigidbody
                    colliderSet.ExportToRigidbody(rigidbodyComponent); // copy data to the rigidbody
                }

                // Add SpriteCollider
                SpriteCollider spriteCollider = (SpriteCollider)thisGameObject.AddComponent(typeof(SpriteCollider)); // create the sprite collider
                spriteCollider.transform = thisTransform; // copy transform link to SpriteCollider -- parent's transform is always sprite's transform
                spriteCollider.gameObject = thisGameObject; // copy gameobject link
                spriteCollider.Initialize(this, thisGameObject, colliderComponent, rigidbodyComponent, colliderSet, colliderGroup, parentColliderIndex, true); // fill links in sprite collider
                spriteColliders[parentColliderIndex] = spriteCollider; // store the collider
                if(colliderSet.tag != "") { // set tag on game object
                    if(thisGameObject.tag != "Untagged") { // warn if parent game object already has a tag
                        Debug.LogWarning("You have assigned the tag \"" + colliderSet.tag + "\" to a collider which is set to Parent, but the Sprite GameObject already has the tag \"" + thisGameObject.tag + "\" assigned. The GameObject's tag has been changed to \"" + colliderSet.tag + ".");
                    }
                    thisGameObject.tag = colliderSet.tag;
                }

                // ISSUE: The new box collider created by AddComponent CANNOT be disabled in the 1st frame. Unity doesn't register it immediately.
                // BIG PROBLEM -- If parent collider is supposed to be off in the first frame, it cannot be and by forcing it to try to go off it will not disable internal collisions and unit will hit himself.
                // Leave it ENABLED so at least ignore collisions will work
                // We can prevent it from hitting other stuff in THIS sprite, but not in others -- Strangely, it does seem to prevent it from hitting other stuff... awesome!

                colliderSet.ExportToCollider(colliderComponent); // copy data to collider
                isColliderAnimated[parentColliderIndex] = colliderSet.isAnimated;

                // Initialize static colliders now
                if(!colliderSet.isAnimated) { // static
                    ColliderFrame staticColliderFrame = colliderSet.staticColliderFrame;
                    if(!staticColliderFrame.enabled) { // this collider must be disabled but we can't do it now (see issue above)
                        RenderCollider(spriteCollider.colliderInfo, staticColliderFrame, spriteCollider, false); // set the collider shape and size but do not change enable state
                        deferredParentColliderDisable = true;
                    } else // collider is supposed to be enabled, so we can go ahead and do that now
                        RenderCollider(spriteCollider.colliderInfo, staticColliderFrame, spriteCollider, true); // set the collider shape and size and enable state
                } else { // animated collider
                    // We want this disabled, but we can't do it yet (see issue above)
                    deferredParentColliderDisable = true;
                }
            }

            // Add each child collider below this game object
            for(int i = 0; i < _colliderCount; i++) {
                if(i == parentColliderIndex) continue; // skip the parent
                colliderSet = colliderSets[i];
                if(colliderSet.groupId >= 0) colliderGroup = data.GetColliderGroup(colliderSet.groupId);
                else colliderGroup = null;
                CreateChildCollider(colliderSet, i, colliderGroup, ref hasAnimatedChildWithoutRigidbody);
            }

            // Determine if we need to wake up the parent rigidbody every frame based on structure
            if(parentHasRigidbody && hasAnimatedChildWithoutRigidbody) { // we have a parent and a child that wants to use the parent's rigidbody
                wakeUpParentRigidbody = true; // wake the rigidbody every frame
            }

            // Make all internal colliders ignore each other
            IgnoreAllCollisionsBetweenInternalColliders();

            // Disable any parent colliders now after physics ignore has taken place
            if(deferredParentColliderDisable) {
                SetColliderActive(spriteColliders[parentColliderIndex], false); // disable the collider
            }
        }

        private void CheckAndRemoveExistingColliders(GameObject gameObject) {
            // Remove existing Collider
            Collider existingCollider = (Collider)gameObject.GetComponent(typeof(Collider)); // make sure this game object doesn't already have a collider added by user
            if(existingCollider != null) {
                Debug.LogWarning("Sprite \"" + thisGameObject.name + "\" has a user-defined Collider component and also has a Sprite Collider defined as Parent. You cannot have both. The user-defined Collider has been removed! Either remove the Parent status on the Sprite Collider or delete the user-defined Collider component in the sprite.");
                Destroy(existingCollider); // remove the collider component
                return;  // removed collider, cannot have a collider2D also so done
            }

            // Remove existing Collider2D
            if(Utils.UnityTools.supports2DColliders) {
                CheckAndRemoveCollider2D(gameObject);
            }
        }

        private void CheckAndRemoveCollider2D(GameObject gameObject) {
            Collider2D existingCollider = (Collider2D)gameObject.GetComponent(typeof(Collider2D)); // make sure this game object doesn't already have a 2d collider added by user
            if(existingCollider != null) {
                Debug.LogWarning("Sprite \"" + thisGameObject.name + "\" has a user-defined Collider2D component and also has a Sprite Collider defined as Parent. You cannot have both. The user-defined Collider has been removed! Either remove the Parent status on the Sprite Collider or delete the user-defined Collider2D component in the sprite.");
                Destroy(existingCollider); // remove the Collider2D component
            }
        }

        private void CheckAndRemoveExistingRigidbodies(GameObject gameObject) {
            // Check and add or remove existing Rigidbody
            Rigidbody existingRigidbody = (Rigidbody)thisGameObject.GetComponent(typeof(Rigidbody));
            if(existingRigidbody != null) {
                Debug.LogWarning("Sprite \"" + thisGameObject.name + "\" has a user-defined Rigidbody component and also has a Sprite Collider defined as Parent. You cannot have both. The user-defined Rigidbody has been removed! Either remove the Parent status on the Sprite Collider or delete the user-defined Rigidbody component in the sprite.");
                Destroy(existingRigidbody); // remove the rigidbody component
                return; // cannot have both 3D and 2D, so done
            }

            // Check and remove existing Rigidbody2D
            if(Utils.UnityTools.supports2DColliders) {
                CheckAndRemoveRigidbody2D(gameObject);
            }
        }

        private void CheckAndRemoveRigidbody2D(GameObject gameObject) {
            Rigidbody2D existingRb = (Rigidbody2D)gameObject.GetComponent(typeof(Rigidbody2D)); // make sure this game object doesn't already have a 2d rb added by user
            if(existingRb != null) {
                Debug.LogWarning("Sprite \"" + thisGameObject.name + "\" has a user-defined Rigidbody2D component and also has a Sprite Collider defined as Parent. You cannot have both. The user-defined Rigidbody2D has been removed! Either remove the Parent status on the Sprite Collider or delete the user-defined Rigidbody2D component in the sprite.");
                Destroy(existingRb); // remove the Collider2D component
            }
        }

        private Component CreateColliderComponent(ColliderSet colliderSet, GameObject gameObject) {
            ColliderType type = colliderSet.colliderType;

            // Create 2D collider - Unity 4.3+ only
            if(colliderSet.is2D) {
                Utils.UnityTools.FailIfNo2DSupport();
                return CreateCollider2DComponent(gameObject, type);
            }

            // Create 3D collider
            if(type == ColliderType.Box) {
                return gameObject.AddComponent(typeof(BoxCollider)); // create the collider
            }
            throw new System.Exception("Unknown or unsupported Collider2D type: " + type.ToString());
        }

        private Component CreateCollider2DComponent(GameObject gameObject, ColliderType type) {
            if(type == ColliderType.Box2D) {
                return gameObject.AddComponent(typeof(BoxCollider2D)); // create the collider
            }
            throw new System.Exception("Unknown or unsupported Collider2D type: " + type.ToString());
        }

        private Component CreateRigidbodyComponent(ColliderSet colliderSet, GameObject gameObject) {
            // Create 2D rigidbody - Unity 4.3+ only
            if(colliderSet.is2D) {
                Utils.UnityTools.FailIfNo2DSupport();
                return CreateRigidbody2DComponent(gameObject);
            }

            // Create 3D rigidbody
            return gameObject.AddComponent(typeof(Rigidbody)); // create the rigidbody
        }

        private Component CreateRigidbody2DComponent(GameObject gameObject) {
            return gameObject.AddComponent(typeof(Rigidbody2D)); // create the rb2d
        }

        private void CreateChildCollider(ColliderSet colliderSet, int colliderSetIndex, ColliderGroup colliderGroup, ref bool hasAnimatedChildWithoutRigidbody) {
            // Create 2D child colliders - Unity 4.3+ only
            if(colliderSet.is2D) {
                Utils.UnityTools.FailIfNo2DSupport();
                CreateChildCollider2D(colliderSet, colliderSetIndex, colliderGroup, ref hasAnimatedChildWithoutRigidbody);
                return;
            }
            
            // Create 3D child colliders
            CreateChildCollider3D(colliderSet, colliderSetIndex, colliderGroup, ref hasAnimatedChildWithoutRigidbody);
        }

        private void CreateChildCollider3D(ColliderSet colliderSet, int colliderSetIndex, ColliderGroup colliderGroup, ref bool hasAnimatedChildWithoutRigidbody) {
            ColliderType colliderType = colliderSet.colliderType;
            
            if(colliderType == ColliderType.Box) {
                Component colliderComponent;

                // Instantiate the prefab
                GameObject childGO;

                // Rigidbody
                Rigidbody rb = null;
                if(colliderSet.hasRigidbody) {
                    childGO = (GameObject)Instantiate(data.gameSettings.defaultObjects.boxColliderRB);
                    rb = (Rigidbody)childGO.GetComponent(typeof(Rigidbody));
                    colliderSet.ExportToRigidbody3D(rb);
                } else {
                    if(colliderSet.isAnimated) hasAnimatedChildWithoutRigidbody = true;
                    childGO = (GameObject)Instantiate(data.gameSettings.defaultObjects.boxCollider);
                }

                 colliderComponent = childGO.GetComponent(typeof(Collider)); // get collider component from prefab

                // Get SpriteCollider
                SpriteCollider spriteCollider = (SpriteCollider)childGO.GetComponent(typeof(SpriteCollider)); // get the sprite collider
                if(spriteCollider == null) {
                    Debug.LogError("SpriteCollider is missing on sprite collider prefab object! Critical files have been changed! You should reinstall Sprite Factory!");
                }
                spriteColliders[colliderSetIndex] = spriteCollider; // store the collider
                spriteCollider.Initialize(this, thisGameObject, colliderComponent, rb, colliderSet, colliderGroup, colliderSetIndex, false); // fill links in sprite collider

                childGO.name = colliderSet.name; // set name of object
                if(!string.IsNullOrEmpty(colliderSet.tag)) childGO.tag = colliderSet.tag; // set tag of object

                // set layer on game object
                if(colliderSet.inheritLayer) childGO.layer = thisGameObject.layer; // use layer from parent sprite
                else childGO.layer = colliderSet.layer; // use layer set in collider set

                Transform childXform = spriteCollider.transform; // get prefab transform
                colliderSet.ExportToCollider(colliderComponent); // copy settings to collider
                childXform.parent = thisTransform; // parent the child to the sprite
                childXform.localPosition = new Vector3(0.0f, 0.0f, 0.0f); // make sure centered locally after parenting
                childXform.localRotation = Quaternion.identity; // make sure no rotation after parenting
                childXform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
                isColliderAnimated[colliderSetIndex] = colliderSet.isAnimated;

                BoxCollider boxCollider = (BoxCollider)colliderComponent;
                boxCollider.enabled = true; // make sure the box collider component starts enabled because the prefabs have it disabled
                if(!colliderSet.isAnimated) { // initialize static colliders now
                    ColliderFrame staticColliderFrame = colliderSet.staticColliderFrame;
                    RenderCollider(spriteCollider.colliderInfo, staticColliderFrame, spriteCollider, true); // set the collider shape and size and enable state

                } else { // animated collider
                    SetColliderActive(spriteCollider, false); // disable the collider
                    // set the size to something small because it could be sitting around disabled for a while and we don't want it to be too obtrusive
                    Vector3 zero = new Vector3(0.0f, 0.0f, 0.0f);
                    boxCollider.center = zero;
                    boxCollider.size = zero;
                }
                return;
            }
            throw new System.Exception("Unknown or unsupported Collider2D type: " + colliderType.ToString());
        }

        private void CreateChildCollider2D(ColliderSet colliderSet, int colliderSetIndex, ColliderGroup colliderGroup, ref bool hasAnimatedChildWithoutRigidbody) {
            ColliderType colliderType = colliderSet.colliderType;
            
            if(colliderType == ColliderType.Box2D) {
                Component colliderComponent;

                // We have to add the Collider2D to the prefab because we can't have an object that requires Collider2D for < Unity 4.3 support
                GameObject childGO = (GameObject)Instantiate(data.gameSettings.defaultObjects.boxCollider2D); // instantiate the prefab
                colliderComponent = childGO.AddComponent(typeof(BoxCollider2D)); // add box collider to game object
                
                // Add rigidbody if necessary
                Component rigidbodyComponent = null;
                if(colliderSet.hasRigidbody) {
                    rigidbodyComponent = childGO.AddComponent(typeof(Rigidbody2D)); // create the rigidbody component
                    colliderSet.ExportToRigidbody2D(rigidbodyComponent);
                } else {
                    if(colliderSet.isAnimated) hasAnimatedChildWithoutRigidbody = true;
                }
                
                // Get SpriteCollider
                SpriteCollider spriteCollider = (SpriteCollider)childGO.GetComponent(typeof(SpriteCollider)); // get the sprite collider
                if(spriteCollider == null) {
                    Debug.LogError("SpriteCollider is missing on sprite collider prefab object! Critical files have been changed! You should reinstall Sprite Factory!");
                }
                spriteColliders[colliderSetIndex] = spriteCollider; // store the collider
                spriteCollider.Initialize(this, thisGameObject, colliderComponent, rigidbodyComponent, colliderSet, colliderGroup, colliderSetIndex, false); // fill links in sprite collider

                childGO.name = colliderSet.name; // set name of object
                if(!string.IsNullOrEmpty(colliderSet.tag)) childGO.tag = colliderSet.tag; // set tag of object

                // set layer on game object
                if(colliderSet.inheritLayer) childGO.layer = thisGameObject.layer; // use layer from parent sprite
                else childGO.layer = colliderSet.layer; // use layer set in collider set

                Transform childXform = spriteCollider.transform; // get prefab transform
                colliderSet.ExportToCollider(colliderComponent); // copy settings to collider
                childXform.parent = thisTransform; // parent the child to the sprite
                childXform.localPosition = new Vector3(0.0f, 0.0f, 0.0f); // make sure centered locally after parenting
                childXform.localRotation = Quaternion.identity; // make sure no rotation after parenting
                childXform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
                isColliderAnimated[colliderSetIndex] = colliderSet.isAnimated;

                BoxCollider2D boxCollider2D = (BoxCollider2D)colliderComponent;
                boxCollider2D.enabled = true; // make sure the box collider component starts enabled because the prefabs have it disabled
                if(!colliderSet.isAnimated) { // initialize static colliders now
                    ColliderFrame staticColliderFrame = colliderSet.staticColliderFrame;
                    RenderCollider(spriteCollider.colliderInfo, staticColliderFrame, spriteCollider, true); // set the collider shape and size and enable state

                } else { // animated collider
                    SetColliderActive(spriteCollider, false); // disable the collider
                    // set the size to something small because it could be sitting around disabled for a while and we don't want it to be too obtrusive
                    Vector2 zero = new Vector2(0.0f, 0.0f);
                    boxCollider2D.SetCenter(zero);
                    boxCollider2D.size = zero;
                }
                return;
            }
            throw new System.Exception("Unknown or unsupported Collider2D type: " + colliderType.ToString());
        }

        private void UpdateColliders() {
            if(_colliderCount == 0) return;

            // update static and animated colliders
            for(int i = 0; i < _colliderCount; i++) {
                if(isColliderAnimated[i]) { // animated collider

                    // get current animation frame
                    Frame frame = GetCurrentFrame();
                    if(frame == null) continue;

                    SpriteCollider spriteCollider = spriteColliders[i];
                    RenderCollider(spriteCollider.colliderInfo, frame.colliderFrames[i], spriteCollider, false); // set the collider shape and size, do not set enable state

                } else { // static collider
                    ColliderFrame colliderFrame = data.colliderSets[i].staticColliderFrame;
                    SpriteCollider spriteCollider = spriteColliders[i];
                    RenderCollider(spriteCollider.colliderInfo, colliderFrame, spriteCollider, false); // set the collider shape and size, do not set enable state
                }
            }
        }

        private void UpdateAnimatedColliders(Frame frame) {
            if(frame == null) return;
            ColliderFrame[] colliderFrames = frame.colliderFrames;

            // Animate the colliders
            for(int i = 0; i < _colliderCount; i++) {
                if(!isColliderAnimated[i]) continue; // skip static colliders

                ColliderFrame colliderFrame = colliderFrames[i];
                SpriteCollider spriteCollider = spriteColliders[i];

                // Animate the collider
                bool isEnabled = colliderFrame.enabled;
                SetColliderActive(spriteCollider, isEnabled); // animate enabled state
                
                if(isEnabled) {
                    // ignore collisions call is being handled by SpriteCollider when it calls OnEnable
                    RenderCollider(spriteCollider.colliderInfo, colliderFrame, spriteCollider, false); // set the collider shape and size, do not set enable state again
                }
            }
        }

        private void UpdateStaticColliders() {
            for(int i = 0; i < _colliderCount; i++) {
                if(isColliderAnimated[i]) continue; // skip animated colliders

                ColliderFrame colliderFrame = data.colliderSets[i].staticColliderFrame;
                SpriteCollider spriteCollider = spriteColliders[i];
                RenderCollider(spriteCollider.colliderInfo, colliderFrame, spriteCollider, false); // set the collider shape and size, do not set enable state
            }
        }

        private void RenderCollider(ColliderInfo colliderInfo, ColliderFrame colliderFrame, SpriteCollider spriteCollider, bool setEnabledState) {
            // Render 2D collider - Unity 4.3+ only
            if(colliderInfo.is2D) {
                Utils.UnityTools.FailIfNo2DSupport();
                RenderCollider2D(colliderInfo, colliderFrame, spriteCollider, setEnabledState);
                return;
            }

            // Render 3D collider
            RenderCollider3D(colliderInfo, colliderFrame, spriteCollider, setEnabledState);
        }

        private void RenderCollider3D(ColliderInfo colliderInfo, ColliderFrame colliderFrame, SpriteCollider spriteCollider, bool setEnabledState) {
            if(colliderInfo.type == ColliderType.Box) {
                BoxCollider boxCollider = (BoxCollider)colliderInfo.collider3D;
                Transform xform = spriteCollider.transform;

                // Set enabled state in collider if allowed
                if(setEnabledState) SetColliderActive(spriteCollider, colliderFrame.enabled);

                // Set collider position and size
                // flip collider if necessary
                // center z will change!
                if(_isFlipped) { // sprite is flipped
                    
                    Vector3 center = colliderFrame.center;
                    Vector3 size = colliderFrame.size;

                    // Scale colliders when using batch scaling
                    if(useBatchScaling) { // sprite is scaled via batch scaling, scale colliders too
                        center.x *= batchScale.x;
                        center.y *= batchScale.y;
                        center.z *= batchScale.z;
                        size.x *= batchScale.x;
                        size.y *= batchScale.y;
                        size.z *= batchScale.z;
                    }

                    if(_xAxisFlipped) {
                        //center.x *= -1.0f; // flip x position of collider
                        center.x *= -1.0f; // flip x position of collider
                    }
                    if(_yAxisFlipped) {
                        //center.y *= -1.0f;
                        center.y *= -1.0f;
                    }

                    // Rotate
                    float rotation = _xAxisFlipped ? colliderFrame.rotation * -1.0f : colliderFrame.rotation;
                    if(_yAxisFlipped) rotation *= -1.0f;
                    Quaternion rot = Quaternion.Euler(0.0f, 0.0f, rotation);
                    if(xform.localRotation != rot) xform.localRotation = rot;
                    
                    // Apply size and position
                    boxCollider.size = size;

                    if(spriteCollider._isParent) { // parent sprites use collider.center instead of transform.position
                        boxCollider.center = center;
                    } else {
                        xform.localPosition = center; // do xform last so it takes care of hack issue
                    }

                } else { // not flipped, use precalculated values

                    // Scale colliders when using batch scaling
                    if(useBatchScaling) { // sprite is scaled via batch scaling, scale colliders too
                        Vector3 center = colliderFrame.center;
                        Vector3 size = colliderFrame.size;
                        center.x *= batchScale.x;
                        center.y *= batchScale.y;
                        center.z *= batchScale.z;
                        size.x *= batchScale.x;
                        size.y *= batchScale.y;
                        size.z *= batchScale.z;
                        
                        // Rotate
                        Quaternion rot = Quaternion.Euler(0.0f, 0.0f, colliderFrame.rotation);
                        if(xform.localRotation != rot) xform.localRotation = rot;
                        
                        // Apply size and position
                        boxCollider.size = size;
                        
                        if(spriteCollider._isParent) { // parent sprites use collider.center instead of transform.position
                            boxCollider.center = center;
                        } else {
                            xform.localPosition = center; // do xform last so it takes care of hack issue
                        }

                    } else { // not batch scaled

                        if(spriteCollider._isParent) { // parent sprites use collider.center instead of transform.position
                            // Apply size and position, no rotation on parents
                            boxCollider.size = colliderFrame.size;
                            boxCollider.center = colliderFrame.center;
                        } else {
                            // Rotate
                            Quaternion rot = Quaternion.Euler(0.0f, 0.0f, colliderFrame.rotation);
                            if(xform.localRotation != rot) xform.localRotation = rot;

                            // Apply size and position
                            boxCollider.size = colliderFrame.size;
                            xform.localPosition = colliderFrame.center; // do xform last so it takes care of hack issue
                        }
                    }
                }

                // hack - update the position of the transform to make physics re-evaluate the center/size change on the collider
                if(colliderFrame.enabled && spriteCollider._isParent) { // only hack if parent because xform position will have been set above on non-parented colliders
                    xform.localPosition = xform.localPosition;
                }

                return;
            }
            throw new System.Exception("Unknown or unsupported Collider type: " + colliderInfo.type.ToString());
        }

        private void RenderCollider2D(ColliderInfo colliderInfo, ColliderFrame colliderFrame, SpriteCollider spriteCollider, bool setEnabledState) {
            if(colliderInfo.type == ColliderType.Box2D) {
                BoxCollider2D boxCollider2D = (BoxCollider2D)colliderInfo.colliderComponent;
                Transform xform = spriteCollider.transform;

                // Set enabled state in collider if allowed
                if(setEnabledState) SetColliderActive(spriteCollider, colliderFrame.enabled);

                // Set collider position and size
                // flip collider if necessary
                // center z will change!
                if(_isFlipped) { // sprite is flipped

                    Vector2 center = colliderFrame.center;
                    Vector2 size = colliderFrame.size;

                    // Scale colliders when using batch scaling
                    if(useBatchScaling) { // sprite is scaled via batch scaling, scale colliders too
                        center.x *= batchScale.x;
                        center.y *= batchScale.y;
                        size.x *= batchScale.x;
                        size.y *= batchScale.y;
                    }

                    if(_xAxisFlipped) {
                        center.x *= -1.0f; // flip x position of collider
                    }
                    if(_yAxisFlipped) {
                        center.y *= -1.0f;
                    }

                    // Rotate
                    float rotation = _xAxisFlipped ? colliderFrame.rotation * -1.0f : colliderFrame.rotation;
                    if(_yAxisFlipped) rotation *= -1.0f;
                    Quaternion rot = Quaternion.Euler(0.0f, 0.0f, rotation);
                    if(xform.localRotation != rot) xform.localRotation = rot;
                    
                    // Apply size and position
                    boxCollider2D.size = size;

                    if(spriteCollider._isParent) { // parent sprites use collider.center instead of transform.position
                        boxCollider2D.SetCenter(center);
                    } else {
                        xform.localPosition = center;
                    }

                } else { // not flipped, use precalculated values
                    // Scale colliders when using batch scaling
                    if(useBatchScaling) { // sprite is scaled via batch scaling, scale colliders too
                        Vector2 center = colliderFrame.center;
                        Vector2 size = colliderFrame.size;
                        center.x *= batchScale.x;
                        center.y *= batchScale.y;
                        size.x *= batchScale.x;
                        size.y *= batchScale.y;
                        
                        // Rotate
                        Quaternion rot = Quaternion.Euler(0.0f, 0.0f, colliderFrame.rotation);
                        if(xform.localRotation != rot) xform.localRotation = rot;

                        // Apply size and position
                        boxCollider2D.size = size;

                        if(spriteCollider._isParent) { // parent sprites use collider.center instead of transform.position
                            boxCollider2D.SetCenter(center);
                        } else {
                            xform.localPosition = center;
                        }
                    } else { // not batch scaled
                        
                        if(spriteCollider._isParent) { // parent sprites use collider.center instead of transform.position
                            // Apply size and position, no rotation on parents
                            boxCollider2D.size = colliderFrame.size;
                            boxCollider2D.SetCenter(colliderFrame.center);
                        } else {
                            // Rotate
                            Quaternion rot = Quaternion.Euler(0.0f, 0.0f, colliderFrame.rotation);
                            if(xform.localRotation != rot) xform.localRotation = rot;

                            // Apply size and position
                            boxCollider2D.size = colliderFrame.size;
                            xform.localPosition = colliderFrame.center;
                        }
                    }
                }

                // hack - update the position of the transform to make physics re-evaluate the center/size change on the collider
                // 2D colliders don't seem to need this hack
                //if(colliderFrame.enabled) {
                    //Transform xform = xform;
                    //xform.localPosition = xform.localPosition;
                //}
                return;
            }
            throw new System.Exception("Unknown or unsupported Collider2D type: " + colliderInfo.type.ToString());
        }

        // Ignore collisions from a single collider

        private void IgnoreCollisionsWithInternalColliders(int colliderIndex) {
            if(colliderIndex < 0 || colliderIndex >= _colliderCount) throw new System.ArgumentOutOfRangeException("colliderIndex");

            // Ignore collisions to all other colliders
            SpriteCollider spriteColliderA = spriteColliders[colliderIndex];
            if(spriteColliderA == null) return;
            IgnoreCollisionsWithInternalColliders(spriteColliderA, colliderIndex, 0);
        }

        private void IgnoreCollisionsWithInternalColliders(SpriteCollider spriteCollider, int sourceColliderIndex, int startIndex) {
            if(spriteCollider == null) return;
            if(!Utils.UnityTools.IsActiveInHierarchy(spriteCollider.gameObject)) return;
            IgnoreCollisionsWithInternalColliders(spriteCollider.colliderInfo, sourceColliderIndex, startIndex);
        }

        private void IgnoreCollisionsWithInternalColliders<TCollider>(TCollider collider, int sourceColliderIndex = -1, int startIndex = 0) where TCollider : Component {
            if(collider == null) return;

            if(Utils.UnityTools.IsCollider2D(typeof(TCollider))) {
                IgnoreCollisionsWithInternalColliders2D(collider, sourceColliderIndex, startIndex);
            } else if(Utils.UnityTools.IsCollider3D(typeof(TCollider))) {
                IgnoreCollisionsWithInternalColliders3D(collider, sourceColliderIndex, startIndex);
            }
            else throw new System.NotImplementedException("Unknown collider type!");
        }

        private void IgnoreCollisionsWithInternalColliders(ColliderInfo colliderInfo, int sourceColliderIndex = -1, int startIndex = 0) {
            if(colliderInfo == null) return;

            if(colliderInfo.is2D) {
                IgnoreCollisionsWithInternalColliders2D(colliderInfo, sourceColliderIndex, startIndex);
            } else {
                IgnoreCollisionsWithInternalColliders3D(colliderInfo, sourceColliderIndex, startIndex);
            }
        }

        private void IgnoreCollisionsWithInternalColliders3D(ColliderInfo colliderInfo, int sourceColliderIndex, int startIndex) {
            IgnoreCollisionsWithInternalColliders_Now(colliderInfo.GetCollider<Collider>(), sourceColliderIndex, startIndex);
        }

        private void IgnoreCollisionsWithInternalColliders2D(ColliderInfo colliderInfo, int sourceColliderIndex, int startIndex) {
            IgnoreCollisionsWithInternalColliders_Now(colliderInfo.GetCollider<Collider2D>(), sourceColliderIndex, startIndex);
        }

        private void IgnoreCollisionsWithInternalColliders3D<TCollider>(TCollider collider, int sourceColliderIndex, int startIndex) where TCollider : Component {
            IgnoreCollisionsWithInternalColliders_Now(collider as Collider, sourceColliderIndex, startIndex);
        }

        private void IgnoreCollisionsWithInternalColliders2D<TCollider>(TCollider collider, int sourceColliderIndex, int startIndex) where TCollider : Component {
            IgnoreCollisionsWithInternalColliders_Now(collider as Collider2D, sourceColliderIndex, startIndex);
        }

        private void IgnoreCollisionsWithInternalColliders_Now<TCollider>(TCollider collider, int sourceColliderIndex, int startIndex) where TCollider : Component {
            if(startIndex < 0 || startIndex >= _colliderCount) return;

            // ensure component type is already verified before calling this method!

            // determine 2d/3d collider type
            bool a_is2D = Utils.UnityTools.IsCollider2D(typeof(TCollider));
            if(a_is2D && !Utils.UnityTools.supports2DIgnoreCollisions) return; // skip checking 2D colliders if < Unity 4.5 because it does not have Physics2D.IgnoreCollisions

            // Ignore collisions to all other colliders
            for(int i = startIndex; i < _colliderCount; i++) {
                if(sourceColliderIndex >= 0 && i == sourceColliderIndex) continue; // skip self by index check
                SpriteCollider spriteColliderB = spriteColliders[i];
                if(spriteColliderB == null) continue;
                ColliderInfo colliderInfoB = spriteColliderB.colliderInfo;
                if(a_is2D != colliderInfoB.is2D) continue; // collider types don't match
                TCollider colliderB = spriteColliderB.colliderInfo.GetCollider<TCollider>();
                if(colliderB == collider) continue; // skip self
                if(!SpriteFactory.Utils.UnityTools.IsActiveInHierarchy(spriteColliderB.gameObject) || !colliderInfoB.enabled) continue; // skip disabled colliders
                //Debug.Log("Ignore collision: " + collider.transform.root.name + "/" + collider.gameObject.name + " <-> " + spriteColliderB.transform.root.name + "/" + spriteColliderB.gameObject.name + " at " + Time.time);
                Utils.UnityTools.IgnoreCollision<TCollider>(collider, colliderB, a_is2D); // ignore collisions
            }
        }

        // Ignore ALL internal collisions

        private void IgnoreAllCollisionsBetweenInternalColliders() {
            // Ignore collisions from all to all internal colliders
            for(int i = 0; i < _colliderCount; i++) {
                SpriteCollider spriteColliderA = spriteColliders[i];
                if(spriteColliderA == null) continue;
                IgnoreCollisionsWithInternalColliders(spriteColliderA, i, i + 1); // ignore the internal colliders
            }
        }

        // Change collider active state

        private void SetColliderActive(SpriteCollider spriteCollider, bool state, bool forceUpdate = false, bool ignoreCollidersIfParent = true) {
            if(spriteCollider._isParent) { // parent sprites must have their collider component enabled/disabled
                ColliderInfo colliderInfo = spriteCollider.colliderInfo;
                if(forceUpdate || colliderInfo.enabled != state) {
                    colliderInfo.enabled = state; // animate by enabling/disabling component
                    
                    // Parent collider does not call OnEnable unless the whole sprite has been enabled, so we must ignore collisions here instead
                    if(ignoreCollidersIfParent && state) IgnoreCollisionsWithInternalColliders(colliderInfo); // just activated, ignore internal colliders here
                }
            } else { // child sprites must have the game object enabled/disabled
                GameObject go = spriteCollider.gameObject;
                if(go == null) return;
                if(forceUpdate || Utils.UnityTools.IsActiveInHierarchy(spriteCollider.gameObject) != state) {
                    Utils.UnityTools.SetActive(spriteCollider.gameObject, state); // animate by activating/deactivating game object, not component
                }
            }
        }

        // Clear

        private void DestroyColliders() {
            int parentColliderIndex = data.parentColliderIndex;
            
            // Destroy Unity3SpriteHelper component
            if(Utils.UnityTools.isSupportedVersion3) {
                Object.DestroyImmediate(unity3SpriteHelper, false);
                unity3SpriteHelper = null;
            }

            // Create parent collider
            if(parentColliderIndex >= 0) { // we have a parent collider

                // Check and add or remove collider
                CheckAndRemoveExistingColliders(thisGameObject); // remove existing collider or collider2D on the main game object if any

                // Remove any existing rigidbodies
                CheckAndRemoveExistingRigidbodies(thisGameObject);

                // Remove SpriteCollider
                SpriteCollider spriteCollider = (SpriteCollider)thisGameObject.GetComponent(typeof(SpriteCollider));
                if(spriteCollider != null) Object.DestroyImmediate(spriteCollider, false);
            }

            // Remove each child collider below this game object
            Utils.UnityTools.DestroyL1ChildrenWithComponent<SpriteCollider>(thisTransform);
        }

        #endregion

        #region // Locators

        private void CreateLocators() {
            locators = new Locator[_locatorCount];
            LocatorSet locatorSet;
            GameObject locatorPrefab = data.gameSettings.defaultObjects.spriteLocator;

            // Add each child locator below this game object
            for(int i = 0; i < _locatorCount; i++) {
                locatorSet = locatorSets[i];

                // Create the locator script prefab
                GameObject locatorGameObject = (GameObject)Instantiate(locatorPrefab);
                locatorGameObject.name = locatorSet.name; // set name of game object
                Transform locatorTransform = locatorGameObject.transform;
                SpriteLocator locatorScript = (SpriteLocator)locatorGameObject.GetComponent(typeof(SpriteLocator));
                locatorScript.Initialize(this, locatorGameObject, i); // initialize the locator script

                // Create the locator internal object
                Locator locator = new Locator(this, locatorSet.name, locatorGameObject, locatorTransform, locatorScript);
                locators[i] = locator; // store the locator

                locatorTransform.parent = thisTransform; // parent the child to the sprite
                locatorTransform.localPosition = new Vector3(0.0f, 0.0f, 0.0f); // make sure centered locally after parenting
                locatorTransform.localRotation = Quaternion.identity; // make sure no rotation after parenting
                locatorTransform.localScale = new Vector3(1.0f, 1.0f, 1.0f);
                SpriteFactory.Utils.UnityTools.SetActive(locatorGameObject, false); // deactivate the locator object until the frame activates it
            }

            // Animate the first frame because sprite might be static or not playing animation
            if(_animationCount == 0) return;
            Animation[] anims = data.animations;
            int defaultAnimIndex = data.defaultAnimationIndex;
            if(anims[defaultAnimIndex].frameCount == 0) return; // no frames
            LocatorFrame[] locatorFrames = anims[defaultAnimIndex].frames[0].locatorFrames;
            if(locatorFrames == null || locatorFrames.Length == 0) return;
            for(int i = 0; i < locatorFrames.Length; i++) {
                if(!locatorFrames[i].enabled) continue;
                Locator locator = locators[i];
                locator.SetActive(true, false); // enable the locator
                if(useBatchScaling) { // adjust position for batch scaling
                    locator.localPosition = Vector3.Scale(locatorFrames[i].unitPosition, _batchScale);
                } else { // not batch scaled, just use precomputed position
                    locator.localPosition = locatorFrames[i].unitPosition;
                }
            }
        }

        private void UpdateLocators(Frame frame) {
            if(frame == null) return;

            LocatorFrame[] locatorFrames = frame.locatorFrames;

            // Animate the locators
            for(int i = 0; i < _locatorCount; i++) {
                LocatorFrame locatorFrame = locatorFrames[i];
                Locator locator = locators[i];

                // Animate the locator
                bool isEnabled = locatorFrame.enabled;
                if(activateLocatorsRecursively) locator.SetActiveRecursively(isEnabled); // animate enabled state recursively on all children
                else locator.SetActive(isEnabled); // animate enabled state only on 1st tier children

                if(isEnabled) {

                    Vector3 pos;
                    Quaternion rot;
                    Vector3 scale;

                    if(_isFlipped) {
                        // Position
                        pos = locatorFrame.unitPosition;
                        if(_xAxisFlipped) pos.x *= -1.0f; // flip position on X if flipped
                        if(_yAxisFlipped) pos.y *= -1.0f; // flip position on Y if flipped

                        if(locatorFrame.flipForwardVector) { // locator flipped in sprite editor
                            float scaleY = 1.0f;
                            float scaleZ = 1.0f;

                            if(_xAxisFlipped) {
                                if(_yAxisFlipped) { // xy flipped
                                    rot = Quaternion.Euler(new Vector3(180.0f, 0.0f, locatorFrame.facing));
                                    scaleY = -1.0f; // mirror y
                                    scaleZ = -1.0f; // mirror z
                                } else { // x flipped
                                    rot = Quaternion.Euler(new Vector3(0.0f, 0.0f, locatorFrame.facing));
                                    scaleY = -1.0f; // mirror y
                                }
                            } else if(_yAxisFlipped) { // y flipped
                                rot = Quaternion.Euler(new Vector3(0.0f, 180.0f, SpriteFactory.Utils.MathTools.ClampAngle360(360.0f - locatorFrame.facing)));
                                scaleZ = -1.0f; // mirror Z
                            } else { // no flip
                                rot = locatorFrame.unitRotation;
                            }

                            // Apply scale
                            scale = new Vector3(1.0f, scaleY, scaleZ);

                        } else { // not flipped in sprite editor

                            float scaleY = 1.0f;
                            float scaleZ = 1.0f;

                            if(_xAxisFlipped) {
                                if(_yAxisFlipped) { // xy flipped
                                    rot = Quaternion.Euler(new Vector3(180.0f, 180.0f, locatorFrame.facing));
                                } else { // x flipped
                                    rot = Quaternion.Euler(new Vector3(0.0f, 180.0f, locatorFrame.facing));
                                    scaleZ = -1.0f; // mirror z
                                }
                            } else if(_yAxisFlipped) { // y flipped
                                rot = Quaternion.Euler(new Vector3(0.0f, 0.0f, SpriteFactory.Utils.MathTools.ClampAngle360(360.0f - locatorFrame.facing)));
                                scaleY = -1.0f;
                            } else { // no flip
                                rot = locatorFrame.unitRotation;
                            }

                            // Apply scale
                            scale = new Vector3(1.0f, scaleY, scaleZ);
                        }

                    } else { // not flipped
                        pos = locatorFrame.unitPosition;
                        rot = locatorFrame.unitRotation; // use precacluated rotation

                        // mirror for flip forward vector
                        if(locatorFrame.flipForwardVector) scale = new Vector3(1.0f, -1.0f, -1.0f);
                        else scale = new Vector3(1.0f, 1.0f, 1.0f);
                    }

                    // adjust position for batch scaling
                    if(useBatchScaling) {
                        pos.x *= _batchScale.x;
                        pos.y *= _batchScale.y;
                        pos.z *= _batchScale.z;
                    }

                    // Apply changes to locator
                    locator.localPosition = pos;
                    locator.localRotation = rot;
                    locator.localScale = scale;
                }
            }
        }

        private void UpdateLocatorChildrenScale() {
            for(int i = 0; i < _locatorCount; i++) {
                locators[i].Refresh(); // store locator children original scale/position
            }
        }

        #endregion

        #region // Get / Find

        private int FindAnimationIndex(string animationName) {
            if(_animationCount <= 0) return -1;

            for(int i = 0; i < _animationCount; i++) {
                if(data.animations[i].name == animationName) {
                    return i;
                }
            }
            return -1;
        }

        private int FindMaterialSetIndex(string materialSetName) {
            if(_materialSetCount <= 0) return -1;
            for(int i = 0; i < _materialSetCount; i++) {
                if(data.materialSets[i].name == materialSetName) {
                    return i;
                }
            }
            return -1;
        }

        private Frame GetCurrentFrame() {
            if(_animationCount == 0) return null;

            Animation anim;
            Frame frame;

            if(_currentAnimationIndex >= 0) {
                anim = data.animations[_currentAnimationIndex];
                frame = anim.currentFrameObject;
            } else { // animation has not started yet
                anim = data.animations[data.defaultAnimationIndex];
                Frame[] frames = anim.frames;
                if(frames != null && frames.Length > 0)
                    frame = anim.frames[0];
                else frame = null;
            }

            return frame;
        }

        private Sprite.ColliderFrame GetColliderFrame(int animIndex, int frameIndex, int colliderSetIndex) {
            if(_colliderCount == 0) return null; // no collider sets
            if(colliderSetIndex < 0 || colliderSetIndex >= data.colliderSets.Length) return null; // invalide collider set index
            ColliderSet colliderSet = data.colliderSets[colliderSetIndex];
            if(colliderSet == null) return null; // collider set is missing!

            if(!colliderSet.isAnimated) { // static collider
                return colliderSet.staticColliderFrame; // get static collider frame from collider set

            } else { // animated collider
                if(_animationCount == 0) return null;
                Animation[] animations = data.animations;
                if(animIndex < 0 || animIndex >= _animationCount) return null; // invalid anim index

                Frame[] frames = animations[animIndex].frames;
                if(frames == null || frames.Length == 0) return null; // no frames
                if(frameIndex < 0 || frameIndex >= frames.Length) return null; // invalid frame index

                Frame frame = frames[frameIndex];
                if(frame.colliderFrames == null || colliderSetIndex >= frame.colliderFrames.Length) return null; // no collider frames

                return frame.colliderFrames[colliderSetIndex]; // get the current collider frame from the sprite frame
            }
        }

        private Mesh GetEditorPreviewMesh() {
            //if(_initialized) return null; // this function is only for editor mode -- Must allow to run in game mode for duplication fix
            if(gameMasterSprite == null) return null;
            Sprite.Data spriteData = gameMasterSprite.data;

            if(_xAxisFlipped) { // X is flipped
                if(_yAxisFlipped) return spriteData.editorPreviewMeshes[3]; // use xy-flipped
                else return spriteData.editorPreviewMeshes[1]; // use x-flipped
            } else { // x is not flipped
                if(_yAxisFlipped) return spriteData.editorPreviewMeshes[2]; // use y-flipped
                else return spriteData.editorPreviewMeshes[0]; // use normal
            }
        }

        #endregion

        #region // Activate / Deactivate

        private void ActivateChildren() {
            // disable sprite meshes in display that shouldn't be shown and may have been enabled by SetActiveRecursively
            if(!_isStaticSprite) display.Activate();

            // make sure collider and locator children are activated

            // Colliders
            if(_colliderCount > 0) {
                ColliderSet[] colliderSets = data.colliderSets;
                Frame frame = GetCurrentFrame(); // get current frame so we can know if collider is enabled or not
                bool isUnity3 = Utils.UnityTools.isSupportedVersion3;
                for(int i = 0; i < _colliderCount; i++) {
                    bool isAnimated = colliderSets[i].isAnimated;
                    if(isAnimated && frame == null) continue; // no frame
                    // If static and frame is null but we still may need to enable the collider
                        
                    ColliderFrame colliderFrame;
                    if(!isAnimated) colliderFrame = colliderSets[i].staticColliderFrame;
                    else colliderFrame = frame.colliderFrames[i];

                    if(isUnity3) { // Unity 3.5.0 - 3.5.7

                        // Special case for Unity 3.x -- We cannot set collider enabled state in OnEnable. This is deferred until the next fixed update.
                        if(colliderSets[i].isParent) {
                            unity3SpriteHelper.DeferParentColliderStateChange(colliderFrame.enabled);
                            continue;
                        }

                        // Special case for Unity 3.x -- Bug where the collider may collide anyway even though its !active.
                        //if(!colliderFrame.enabled) { // collider should not be activated because its disabled in this frame
                        // Defer all collider state changes in Unity3.x
                            unity3SpriteHelper.DeferChildColliderStateChange(colliderFrame.enabled, i); // defer the activation until FixedUpdate
                            continue; 
                        //}

                    } else { // Unity 4+
                        if(!colliderFrame.enabled) continue; // collider should not be activated because its disabled in this frame
                        SetColliderActive(spriteColliders[i], true); // activate now
                    }
                }
            }

            // Locators
            if(_locatorCount > 0) {
                Frame frame = GetCurrentFrame(); // get current frame so we can know if locator is enabled or not
                if(frame != null) {
                    for(int i = 0; i < _locatorCount; i++) {
                        if(!frame.locatorFrames[i].enabled) continue; // locator should not be activated because its disabled in this frame
                        if(locators[i].active) continue; // locator is already activated, don't bother reactivating it
                        if(activateLocatorsRecursively) locators[i].SetActiveRecursively(true);
                        else locators[i].SetActive(true);
                    }
                }
            }

            _isActive = true;
        }

        private void DeactivateChildren() {
            if(_animationCount == 0) return;

            // disable sprite meshes even if !recursive
            if(!_isStaticSprite) display.Deactivate();

            // make sure collider and locator children are deactivated
            // Colliders
            if(_colliderCount > 0) {
                ColliderSet[] colliderSets = data.colliderSets;
                for(int i = 0; i < _colliderCount; i++) {
                    SpriteCollider spriteCollider = spriteColliders[i];
                    SetColliderActive(spriteCollider, false); // deactivate
                }
            }

            // Locators
            if(_locatorCount > 0) {
                for(int i = 0; i < _locatorCount; i++) {
                    if(!locators[i].active) continue; // locator is already deactivated
                    if(activateLocatorsRecursively) locators[i].SetActiveRecursively(false);
                    else locators[i].SetActive(false);
                }
            }

            _isActive = false;
        }

        #endregion

        #region // Flip

        private void RenderCollidersAndLocators() {
            if(_animationCount <= 0) return;
            if(_currentAnimationIndex < 0) return;

            // render sprite display, colliders, and locators

            if(_isStaticSprite) { // Static Sprite
                // Sprite display
                // static sprites do not use display

                // Colliders
                if(_colliderCount > 0) {
                    UpdateStaticColliders(); // just update the static colliders
                }

                // Locators
                if(_locatorCount > 0) {
                    Frame[] frames = data.animations[0].frames;
                    if(frames != null && frames.Length > 0) UpdateLocators(frames[0]);
                }

            } else { // Animated Sprite

                // Sprite display
                // Do not need to re-render sprite display anymore because flip automatically includes offset

                // Colliders
                if(_colliderCount > 0) {
                    UpdateStaticColliders(); // uodate the static colliders
                    if(_currentAnimationIndex >= 0) { // we have animations, we may have animated colliders
                        UpdateAnimatedColliders(data.animations[_currentAnimationIndex].currentFrameObject);
                    }
                }

                // Locators
                if(_locatorCount > 0) {
                    if(_currentAnimationIndex >= 0) { // we have animations
                        UpdateLocators(data.animations[_currentAnimationIndex].currentFrameObject); // use current animation to determine locator positions
                    } else {
                        // No animation or none played yet!
                        // could be an animated sprite, but no animation played at start
                        // if this is the first frame since starting play,
                        // just take it from defaultAnimationIndex frame 0
                        Animation[] anims = data.animations;
                        int defaultAnimIndex = data.defaultAnimationIndex;
                        Animation anim = anims[defaultAnimIndex];
                        if(anim.frameCount > 0) {
                            UpdateLocators(anim.frames[0]); // use locator position from default animation frame 0
                        }
                    }
                }
            }
        }

        #endregion

        #region // Batch Scaling

        private void UpdateBatchScale() { // called when scale changes or when useBatchScale is turned on/off

            if(_isStaticSprite) { // static -- no display, scale the mesh manually

                // redraw the mesh
                Static_UpdateMesh();

            } else { // animated sprite

                if(useBatchScaling) {

                    // update display meshes
                    display.SetBatchScale(_batchScale); // set scale in the display controller, enable scaling, and render

                } else { // not scaling
                    display.useBatchScaling = false; // disable batch scaling and re-render
                }

            }

            // Uspdate the colliders if necessary
            if(_colliderCount > 0) UpdateColliders();

            // Update the locators and locator children if necessary
            if(_locatorCount > 0) {

                // update locators
                Frame frame = GetCurrentFrame();
                if(frame != null) UpdateLocators(frame);

                // scale children of locators
                if(useBatchScaling) {

                    for(int i = 0; i < _locatorCount; i++) {
                        Locator locator = locators[i];
                        locator.BatchScaleChildren(_batchScale);
                    }
                }
            }
        }

        #endregion

        #region // Materials

        private bool CheckMaterial(Material material) {
            if(material == null) return false;
            if(!material.HasProperty("_MainTex")) {
                Debug.LogWarning("Material does not have a \"_MainTex\" property and is incompatible!");
                return false;
            }
            return true;
        }

        private void AssignMaterialOnStaticSprite(Material material, Texture2D texture, bool isOverride) {
            if(meshRenderer == null) meshRenderer = (MeshRenderer)GetComponent(typeof(MeshRenderer));

            if(static_overrideMaterial != null) CleanUpTempMaterials(); // material was already overridden, destroy temp materials first before we assign new ones

            if(isOverride) { // copy the material before assigning -- used for overrides
                Material instance = new Material(material);
                instance.name += " (instance)";
                instance.hideFlags = HideFlags.HideAndDontSave;
                if(texture != null) instance.mainTexture = texture;
                meshRenderer.material = instance; // assign instanced material to mesh renderer
                static_materialOverridden = true;
                static_overrideMaterial = instance;
                spriteMaterial.materials[0] = instance; // refresh the materials in sprite material
            } else { // assign the incoming material -- used for material sets
                meshRenderer.material = material; // assign instanced material to mesh renderer
                spriteMaterial.materials[0] = material; // refresh the materials in sprite material
                static_materialOverridden = false;
            }
        }

        internal void PrepareForSpriteMaterialChange() {
            if(IsMaterialOverridden()) return; // nothing to do, just use the overridden materials
            CreateMaterialOverrideFromCurrentMaterial();
        }

        internal bool IsMaterialOverridden() {
            if(_isStaticSprite) {
                return static_materialOverridden;
            } else {
                return display.materialOverridden;
            }
        }

        internal void CreateMaterialOverrideFromCurrentMaterial() {
            Sprite.Atlas[] atlases = data.atlases;
            if(atlases == null || atlases.Length == 0) return;
            SetMaterialOverride(atlases[0].materials[currentMaterialSetIndex]);
        }

        internal void SpriteMaterial_Revert() {
            if(!IsMaterialOverridden()) return;

            // Determine if we should revert to the override material or the material set material
            Sprite.Atlas[] atlases = data.atlases;
            if(atlases != null && atlases.Length > 0) {
                if(materialOverride == atlases[0].materials[currentMaterialSetIndex]) {
                    DisableMaterialOverride();
                    materialOverride = null; // clear the material override
                    materialOverride_prev = null; // clear the prev check so it doesn't process again
                    return;
                }
            }

            // Just restore the override material
            if(materialOverride != null) EnableMaterialOverride();
        }

        #endregion

        #region // Billboard

        private void UpdateBillboardLookAt() {
            // Check for changes in main camera
            if(mainCamera != Camera.main || mainCameraTransform == null) { // update main camera if it changed
                mainCamera = Camera.main;
                mainCameraTransform = mainCamera.transform;
            }

            // Check for changes in billboard up axis
            if(billboardUpAxis_prev != billboardUpAxis) {
                billboardUpAxis_prev = billboardUpAxis; // store current as previous
                CalculateBillboardAxis();
            } else if(_billboardUsingCameraAxis) // no change, but using a camera axis so we must update every frame
                CalculateBillboardAxisFromCamera();
            Quaternion lookRotation = Quaternion.LookRotation((mainCameraTransform.position - thisTransform.position) * -1.0f, _billboardUpAxisVector); // look away from camera because we use -Z as the forward of sprites
            thisTransform.rotation = lookRotation;
        }

        private void CalculateBillboardAxis() {
            if(billboardUpAxis == BillboardUpAxis.WorldX) {
                _billboardUpAxisVector = new Vector3(1.0f, 0.0f, 0.0f);
                _billboardUsingCameraAxis = false;
            } else if(billboardUpAxis == BillboardUpAxis.WorldY) {
                _billboardUpAxisVector = new Vector3(0.0f, 1.0f, 0.0f);
                _billboardUsingCameraAxis = false;
            } else if(billboardUpAxis == BillboardUpAxis.WorldZ) {
                _billboardUpAxisVector = new Vector3(0.0f, 0.0f, 1.0f);
                _billboardUsingCameraAxis = false;
            } else if(billboardUpAxis == BillboardUpAxis.WorldNegX) {
                _billboardUpAxisVector = new Vector3(-1.0f, 0.0f, 0.0f);
                _billboardUsingCameraAxis = false;
            } else if(billboardUpAxis == BillboardUpAxis.WorldNegY) {
                _billboardUpAxisVector = new Vector3(0.0f, -1.0f, 0.0f);
                _billboardUsingCameraAxis = false;
            } else if(billboardUpAxis == BillboardUpAxis.WorldNegZ) {
                _billboardUpAxisVector = new Vector3(0.0f, 0.0f, -1.0f);
                _billboardUsingCameraAxis = false;
            } else if(mainCameraTransform != null) {
                CalculateBillboardAxisFromCamera();
            } else {
                _billboardUpAxisVector = new Vector3(0.0f, 1.0f, 0.0f);
                _billboardUsingCameraAxis = false;
            }
        }

        private void CalculateBillboardAxisFromCamera() {
            if(billboardUpAxis == BillboardUpAxis.CameraX) {
                _billboardUpAxisVector = mainCameraTransform.right;
                _billboardUsingCameraAxis = true;
            } else if(billboardUpAxis == BillboardUpAxis.CameraY) {
                _billboardUpAxisVector = mainCameraTransform.up;
                _billboardUsingCameraAxis = true;
            } else if(billboardUpAxis == BillboardUpAxis.CameraZ) {
                _billboardUpAxisVector = mainCameraTransform.forward;
                _billboardUsingCameraAxis = true;
            } else if(billboardUpAxis == BillboardUpAxis.CameraNegX) {
                _billboardUpAxisVector = -mainCameraTransform.right;
                _billboardUsingCameraAxis = true;
            } else if(billboardUpAxis == BillboardUpAxis.CameraNegY) {
                _billboardUpAxisVector = -mainCameraTransform.up;
                _billboardUsingCameraAxis = true;
            } else if(billboardUpAxis == BillboardUpAxis.CameraNegZ) {
                _billboardUpAxisVector = -mainCameraTransform.forward;
                _billboardUsingCameraAxis = true;
            } else {
                _billboardUpAxisVector = new Vector3(0.0f, 1.0f, 0.0f);
                _billboardUsingCameraAxis = false;
            }
        }

        #endregion

        #region // Static Sprite

        private void Static_UpdateMesh() {
            if(!static_dataSet) { // get the static data only if needed to save time in Awake
                if(!GetStaticData()) return; // some element was missing in the data, we cannot continue
            }
            SpriteMesh.UpdateMesh_Plane(static_mesh, static_frame, static_verts, static_uvs, data.twoSidedMesh, data.useCustomMesh, _isFlipped, _xAxisFlipped, _yAxisFlipped, useBatchScaling, _batchScale);
        }

        private void Static_FlipMesh(bool flipX, bool flipY) {
            if(!flipX && !flipY) return;

            if(!static_dataSet) { // get the static data only if needed to save time in Awake
                if(!GetStaticData()) return; // some element was missing in the data, we cannot continue
            }

            if(!data.useCustomMesh) { // default plane mesh
                Utils.UnityTools.FlipMesh(static_mesh, static_verts, static_triangles, flipX, flipY); // we just flip the stored mesh (relative flip)
            } else { // custom mesh
                Utils.UnityTools.FlipMesh(static_mesh, static_verts, static_triangles, flipX, flipY);  // we just flip the stored mesh (relative flip) because static mesh doesn't ever change
            }
        }

        private bool GetStaticData() {
            static_mesh = ((MeshFilter)GetComponent(typeof(MeshFilter))).mesh; // get the mesh
            static_frame = GetStaticFrame(); // get the static animation frame
            if(static_mesh == null || static_frame == null) return false; // failed to get valid data

            static_verts = static_mesh.vertices;
            static_vertexCount = static_mesh.vertexCount;
            static_uvs = static_mesh.uv;
            static_triangles = static_mesh.triangles;

            static_dataSet = true;
            return true;
        }

        private Frame GetStaticFrame() {
            if(_animationCount == 0) return null;

            Animation[] anims = data.animations;
            Animation anim = anims[defaultAnimationIndex];
            if(anim == null) return null;

            Frame[] frames = anim.frames;
            if(frames == null || frames.Length == 0) return null;

            return frames[0];
        }

        #endregion

        #region // Clean up

        private void CleanUpTempMaterials() {
            if(_animationCount <= 0) return;
            if(!_initialized) return;

            if(_isStaticSprite) {
                if(static_overrideMaterial != null) DestroyImmediate(static_overrideMaterial);
            } else {
                display.CleanUpTempMaterials();
            }
        }

        private void DestroySpritePlanes() {
            Utils.UnityTools.DestroyL1ChildrenWithComponent<SpriteRenderMesh>(thisTransform);
        }

        #endregion

        #region // Trial Version Watermark

#if TRIALVERSION

        [HideInInspector, SerializeField]
        private static float trialLabel_lastTimeDrawn = 0.0f;
        
        private void OnGUI() {
            // Draw a label on the screen in trial version
            if(Event.current.type == EventType.repaint) {
                if(Time.time > trialLabel_lastTimeDrawn) {
                    trialLabel_lastTimeDrawn = Time.time;
                    float width = 300.0f;
                    float height = 30.0f;
                    float hPadding = 30.0f;
                    float vPadding = 60.0f;
                    float rightHPos = Screen.width - hPadding - width;
                    float botVPos = Screen.height - (height * 0.5f) - vPadding;
                    float topVPos = vPadding - (height * 0.5f);
                    
                    // Draw labels on the screen
                    GUI.Label(new Rect(hPadding, topVPos, width, height), "Sprite Factory Trial - For Evaluation Purposes Only"); // top left
                    //GUI.Label(new Rect(rightHPos, topVPos, width, height), "Sprite Factory Trial - Not Licensed for Distribution"); // top right
                    //GUI.Label(new Rect(hPadding, botVPos, width, height), "Sprite Factory Trial - For Evaluation Purposes Only"); // bottom left
                    GUI.Label(new Rect(rightHPos, botVPos, width, height), "Sprite Factory Trial - Not Licensed for Distribution"); // bottom right
                }
            }
        }

#endif

        #endregion

        //////////////////////////////////////////////////////

        #region // PRIVATE CLASSES //////////////////////

        [System.Serializable]
        private class SpriteDisplay {
            [SerializeField]
            private bool initialized;
            [SerializeField]
            private int meshCount = 0;
            [SerializeField]
            private SpriteMesh[] spriteMeshes;
            [SerializeField]
            public bool materialOverridden;
            [SerializeField]
            private bool _useBatchScaling;
            [SerializeField]
            private Vector3 batchScale;
            [SerializeField]
            private SpriteMaterial spriteMaterial;

            [SerializeField]
            private bool twoSidedMesh;
            [SerializeField]
            private bool useCustomMesh;

            [SerializeField]
            private int maxVertCount = 0;
            [SerializeField]
            private int maxUVCount = 0;
            [SerializeField]
            private int maxTriangleCount = 0;

            // Working
            public int currentActive = 0;
            [SerializeField]
            private Frame currentFrame;
            public bool flipped;
            public bool flippedX;
            public bool flippedY;
            [SerializeField]
            private Vector3[] customMeshVerts_working;
            [SerializeField]
            private Vector2[] customMeshUvs_working;
            [SerializeField]
            private int[] customMeshTriangles_working;
            [SerializeField]
            private Vector3[] customMeshNormals_working;
            [SerializeField]
            private bool finalized;

            // Mesh frame working vars
            public MeshFrame[] meshFrames;
            public int meshFrameCount;

            // Properties
            public Bounds bounds {
                get {
                    if(!initialized) return new Bounds();
                    return spriteMeshes[currentActive].bounds;
                }
            }
            public bool visible {
                get {
                    if(!initialized) return false;
                    return spriteMeshes[currentActive].visible;
                }
            }
            public bool primaryMeshVisible {
                get {
                    if(!initialized) return false;
                    return spriteMeshes[0].visible;
                }
                set {
                    if(!initialized) return;
                    spriteMeshes[0].visible = value;
                }
            }
            public bool useBatchScaling {
                get {
                    return _useBatchScaling;
                }
                set {
                    if(_useBatchScaling == value) return; // already set
                    _useBatchScaling = value;
                    Render(); // re-render the mesh when changing
                }
            }


            public SpriteDisplay() { } // constructor for empty sprite with no atlases, never initialize the display

            public SpriteDisplay(Data data, SpriteMaterial spriteMaterial, int inCount, bool twoSidedMesh, bool useCustomMesh, bool inFlipped, bool inFlippedX, bool inFlippedY) {
                this.spriteMaterial = spriteMaterial;
                meshCount = inCount;
                this.twoSidedMesh = twoSidedMesh;
                this.useCustomMesh = useCustomMesh;
                flipped = inFlipped;
                flippedX = inFlippedX;
                flippedY = inFlippedY;
                spriteMeshes = new SpriteMesh[inCount]; // initialize the array
                initialized = true;

                // Special setup for custom meshes
                if(useCustomMesh) {

                    // Get max custom mesh component counts
                    maxVertCount = data.maxVertexCount;
                    maxUVCount = data.maxUVCount;
                    maxTriangleCount = data.maxTriangleCount;
                
                    // Create custom mesh working arrays
                    customMeshVerts_working = new Vector3[maxVertCount];
                    customMeshUvs_working = new Vector2[maxUVCount];
                    customMeshTriangles_working = new int[maxTriangleCount];
                    customMeshNormals_working = new Vector3[maxVertCount]; // only need to worry about normals if using a 2-sided mesh because 1-sided never changes. Still create for all.
                }
            }

            public void AddPrimaryMesh(int index, Sprite.Frame startingFrame, Atlas inAtlas, MeshFilter inMeshFilter, MeshRenderer inMeshRenderer, Material inMaterial, bool overrideMaterial) {
                currentFrame = startingFrame; // set the current frame always to the default primary animation frame
                SpriteMesh spriteMesh = new SpriteMesh(true, startingFrame, inAtlas, inMeshFilter, inMeshRenderer, inMaterial, overrideMaterial, twoSidedMesh, useCustomMesh, null);
                spriteMeshes[index] = spriteMesh;

                AddMesh_Finish(spriteMesh);
            }

            public void AddChildMesh(int index, Atlas inAtlas, MeshFilter inMeshFilter, MeshRenderer inMeshRenderer, Material inMaterial, bool overrideMaterial, SpriteRenderMesh inSpriteRenderMesh, int sortingLayerId, int sortingOrder) {
                SpriteMesh spriteMesh = new SpriteMesh(false, null, inAtlas, inMeshFilter, inMeshRenderer, inMaterial, overrideMaterial, twoSidedMesh, useCustomMesh, inSpriteRenderMesh);
                spriteMeshes[index] = spriteMesh;

                // Set the sorting layer and order on the mesh renderer
                spriteMesh.SetSortingLayerId(sortingLayerId);
                spriteMesh.SetSortingLayerOrder(sortingOrder);

                AddMesh_Finish(spriteMesh);
            }

            private void AddMesh_Finish(SpriteMesh spriteMesh) {

                // Initialize custom meshes
                if(useCustomMesh) {
                    // Set up normals in custom mesh once because they will never change unless using two-sided mesh
                    try {
                        for(int i = 0; i < customMeshNormals_working.Length; i++) {
                            // x = 0, y = 0, z = -1.0f
                            customMeshNormals_working[i].z = -1.0f;
                        }
                    } catch(System.Exception e) {
                        UnityEngine.Debug.LogError(e);
                        throw;
                    }

                    // Initialize the mesh -- these values except normals are blank, but sprite will be rendered in FinishSetup to set the mesh/bounds
                    spriteMesh.InitializeCustomMesh(customMeshVerts_working, customMeshUvs_working, customMeshTriangles_working, customMeshNormals_working);
                }

                // Flip meshes to match initial state if necessary
                if(flipped) {
                    if(useCustomMesh) spriteMesh.FlipMesh_Custom(flippedX, flippedY, _useBatchScaling, meshFrames, meshFrameCount, false, customMeshVerts_working, customMeshUvs_working, customMeshTriangles_working, customMeshNormals_working); // flip custom mesh, but don't draw it now
                    else spriteMesh.FlipMesh_Plane(flippedX, flippedY); // flip planar mesh
                }
            }

            public void FinishSetup() {
                Activate(); // the default frame should always be active on start, others will be deactivated
                UpdateSpriteMaterial(); // make sure all materials were added to sprite material at start
                Render(); // render the sprite now so the mesh is built for the first update
                if(useCustomMesh) {
                    // We don't need to keep the custom mesh normals around if using single sided meshes
                    if(!twoSidedMesh) customMeshNormals_working = null;
                }
            }

            public void SetDefaultCurrentFrame(Frame frame) { // for animated sprites that do not start playing an animation (static animated sprites)
                if(!initialized) return;
                currentFrame = frame;
                // current frame index will stay 0;
            }

            public void Update(Frame frame) { // check if we need to change the display
                if(!initialized) return;
                currentFrame = frame; // store the frame
                int index = frame.atlasIndex;
                if(index != currentActive) UpdateActiveMesh(index); // update which sprite mesh is displayed based on current atlas index
                //if(visible) Render(); // update the mesh to update animation if visible. If invisible, we defer updating the frame until visible - no longer done
                Render(); // always update the mesh even if invisible so mesh bounds is recalculated for each animation frame so if frame changes shape off camera visibility will be detected correctly
            }

            private void UpdateActiveMesh(int index) {
                // update the display
                spriteMeshes[currentActive].Deactivate(); // disable the old mesh
                currentActive = index; // update the active mesh index
                spriteMeshes[currentActive].Activate(); // enable the new mesh
            }

            public void Render() { // re-render the frame immediately
                if(!initialized) return;
                if(currentFrame == null) return; // no frame has been loaded yet
                if(_useBatchScaling) spriteMeshes[currentActive].SetScale(batchScale); // set scale in mesh every time if using batch scaling
                if(useCustomMesh) {
                    spriteMeshes[currentActive].UpdateMesh_Custom(currentFrame, _useBatchScaling, meshFrames, meshFrameCount, customMeshVerts_working, customMeshUvs_working, customMeshTriangles_working, customMeshNormals_working); // update the uvs on the mesh to update animation if visible. If invisible, we defer updating the frame until visible
                } else
                    spriteMeshes[currentActive].UpdateMesh_Plane(currentFrame, _useBatchScaling); // update the uvs on the mesh to update animation if visible. If invisible, we defer updating the frame until visible
            }

            public void SetMaterialOverride(Material inMaterial) {
                if(!initialized) return;
                if(materialOverridden) CleanUpTempMaterials(); // material was already overridden, destroy the materials before we assign new ones

                // set material in all sprite meshes
                for(int i = 0; i < meshCount; i++) {
                    spriteMeshes[i].SetMaterialOverride(inMaterial);
                }
                materialOverridden = true;
                UpdateSpriteMaterial();
            }

            public void RemoveMaterialOverride(int currentMaterialSetIndex) {
                if(!initialized) return;
                if(!materialOverridden) return; // material is not overridden
                CleanUpTempMaterials(); // destroy the materials

                // set material in all sprite meshes
                for(int i = 0; i < meshCount; i++) {
                    spriteMeshes[i].RemoveMaterialOverride(currentMaterialSetIndex);
                }
                materialOverridden = false;
                UpdateSpriteMaterial();
            }

            public void ChangeMaterialSet(int materialSetIndex) {
                if(!initialized) return;
                if(materialOverridden) return; // don't remove the override when changing material sets
                for(int i = 0; i < meshCount; i++) {
                    spriteMeshes[i].ChangeMaterialSet(materialSetIndex);
                }
                UpdateSpriteMaterial();
            }

            public void UpdateSpriteMaterial() {
                Material[] materials = spriteMaterial.materials;
                if(meshCount != materials.Length) throw new System.Exception("Material count does not match mesh count!");
                for(int i = 0; i < meshCount; i++) {
                    materials[i] = spriteMeshes[i].material;
                }
            }

            public void CleanUpTempMaterials() {
                if(!materialOverridden) return;
                for(int i = 0; i < meshCount; i++) {
                    spriteMeshes[i].DestroyMaterial(materialOverridden);
                }
            }

            public void Deactivate() {
                if(!initialized) return;
                // disable all sprite meshes -- currentActive is left untouched, so when we re-enable, we'll use that to determine which is active
                for(int i = 0; i < meshCount; i++) {
                    spriteMeshes[i].Deactivate();
                }
            }

            public void Activate() {
                if(!initialized) return;

                spriteMeshes[currentActive].Activate(); // activate the current active just in case

                // disable all sprite meshes except the current active
                for(int i = 0; i < meshCount; i++) {
                    if(i == currentActive) continue; // don't disable current active
                    spriteMeshes[i].Deactivate();
                }
            }

            public void SetFlippedState(bool xState, bool yState) {
                // determine changes in flip states
                bool changed = false;

                if(xState != flippedX) changed = true;
                if(yState != flippedY) changed = true;

                if(!changed) return; // no change, do nothing

                // we changed flip states
                bool flipX = flippedX != xState ? true : false;
                bool flipY = flippedY != yState ? true : false;

                // set flipped vars
                flippedX = xState;
                flippedY = yState;
                if(xState || yState) flipped = true;
                else flipped = false;

                // flip meshes
                if(!useCustomMesh) { // using default plane mesh
                    for(int i = 0; i < meshCount; i++) {
                        spriteMeshes[i].FlipMesh_Plane(flipX, flipY);
                    }
                } else { // using custom meshes
                    for(int i = 0; i < meshCount; i++) {
                        if(currentActive == i) // this is the current active mesh, flip it and draw it now
                            spriteMeshes[i].FlipMesh_Custom(flipX, flipY, _useBatchScaling, meshFrames, meshFrameCount, true, customMeshVerts_working, customMeshUvs_working, customMeshTriangles_working, customMeshNormals_working);
                        else // this is an inactive mesh, just flip it without drawing
                            spriteMeshes[i].FlipMesh_Custom(flipX, flipY, _useBatchScaling, meshFrames, meshFrameCount, false, customMeshVerts_working, customMeshUvs_working, customMeshTriangles_working, customMeshNormals_working);
                    }
                }
            }

            public void SetBatchScale(Vector3 scale, bool renderNow = true) {
                // Activate use batch scaling if not already
                bool changed = false;
                if(!_useBatchScaling) {
                    _useBatchScaling = true; // just activated use batch scaling
                    changed = true;
                }

                if(changed || scale != batchScale) { // just started scaling or scale was changed
                    batchScale = scale; // update scale
                    if(renderNow) Render(); // re-render current frame at new scale
                }
            }

            public void SetMeshFrameData(Sprite.MeshFrame[] meshFrames, int meshFrameCount) {
                this.meshFrames = meshFrames;
                this.meshFrameCount = meshFrameCount;
            }

            public void SetSortingLayerId(int id) {
                for(int i = 0; i < meshCount; i++) {
                    spriteMeshes[i].SetSortingLayerId(id);
                }
            }

            public void SetSortingLayerName(string name) {
                for(int i = 0; i < meshCount; i++) {
                    spriteMeshes[i].SetSortingLayerName(name);
                }
            }

            public void SetSortingLayerOrder(int order) {
                for(int i = 0; i < meshCount; i++) {
                    spriteMeshes[i].SetSortingLayerOrder(order);
                }
            }

            public void SetCastShadows(bool value) {
                for(int i = 0; i < meshCount; i++) {
                    spriteMeshes[i].SetCastShadows(value);
                }
            }

            public void SetReceiveShadows(bool value) {
                for(int i = 0; i < meshCount; i++) {
                    spriteMeshes[i].SetReceiveShadows(value);
                }
            }

#if UNITY5
            public void SetShadowCastingMode(UnityEngine.Rendering.ShadowCastingMode mode) {
                for(int i = 0; i < meshCount; i++) {
                    spriteMeshes[i].SetShadowCastingMode(mode);
                }
            }
#endif
        }

        [System.Serializable]
        private class SpriteMesh {
            [SerializeField]
            private SpriteRenderMesh spriteRenderMesh;
            [SerializeField]
            private Atlas atlas;
            [SerializeField]
            private MeshFilter meshFilter;
            [SerializeField]
            private MeshRenderer meshRenderer;
            [SerializeField]
            private Mesh mesh;
            [SerializeField]
            private Material _material;
            [SerializeField]
            private bool isPrimary;
            [SerializeField]
            private bool twoSidedMesh;
            [SerializeField]
            private bool useCustomMesh;
            [SerializeField]
            private bool flipped;
            [SerializeField]
            private bool flippedX;
            [SerializeField]
            private bool flippedY;
            [SerializeField]
            private Vector3 batchScale;
            [SerializeField]
            private Vector3[] planeVerts;
            [SerializeField]
            private Vector2[] planeUVs;
            [SerializeField]
            private int[] triangles = null;
            [SerializeField]
            private Sprite.Frame currentFrame;

            // variables only for the primay
            [SerializeField]
            private bool _primaryVisible; // visibility of the primary sprite mesh

            // Properties
            public Bounds bounds {
                get {
                    return mesh.bounds;
                }
            }
            public bool visible {
                get {
                    if(isPrimary) {
                        return _primaryVisible;
                    } else {
                        return spriteRenderMesh.visible; // get visibility state from the child sprite mesh
                    }
                }
                set { // this will only ever be called by Sprite, the primary
                    if(isPrimary) {
                        _primaryVisible = value;
                    } else {
                        // should never happen
                    }
                }
            }
            public Material material { get { return _material; } }


            public SpriteMesh(bool inIsPrimary, Sprite.Frame startingFrame, Atlas inAtlas, MeshFilter inMeshFilter, MeshRenderer inMeshRenderer, Material inMaterial, bool overrideMaterial, bool twoSidedMesh, bool useCustomMesh, SpriteRenderMesh inSpriteRenderMesh) {
                isPrimary = inIsPrimary;
                if(isPrimary) currentFrame = startingFrame;
                atlas = inAtlas;
                meshFilter = inMeshFilter;
                meshRenderer = inMeshRenderer;
                if(meshFilter.sharedMesh != null) {
                    mesh = meshFilter.mesh; // cache the mesh
                    if(!useCustomMesh) {
                        // cache the verts and uvs for speed so we can reuse them
                        planeVerts = mesh.vertices;
                        planeUVs = mesh.uv;
                    }
                }
                
                spriteRenderMesh = inSpriteRenderMesh;

                this.twoSidedMesh = twoSidedMesh;
                this.useCustomMesh = useCustomMesh;

                if(overrideMaterial) {
                    SetMaterialOverride(inMaterial);
                } else {
                    _material = inMaterial;
                    meshRenderer.material = _material; // assign material to mesh renderer
                }
            }

            public void Activate() {
                //if(_active) return; // already active - allow it to run again even if active just in case to clean up errors caused by users enabling/disabling components manually

                if(isPrimary) {
                    if(!meshRenderer.enabled) {
                        meshRenderer.enabled = true; // enable the mesh renderer for the primary sprite mesh
                    }
                } else {
                    spriteRenderMesh.show = true; // enable the game object on child
                }
            }

            public void Deactivate() {
                //if(!_active) return; // already inactive - allow it to run again even if active just in case to clean up errors caused by users enabling/disabling components manually

                if(isPrimary) {
                    if(meshRenderer.enabled) {
                        meshRenderer.enabled = false; // disable the mesh renderer for the primary sprite mesh
                    }
                } else {
                    if(spriteRenderMesh != null) { // make sure it hasn't been destroyed because Deactivate will be called on OnDestroy
                        spriteRenderMesh.show = false; // disable the game object on child
                    }
                }
            }

            public void SetMaterialOverride(Material inMaterial) {
                // Not sure if it would be faster to clone first or just let meshRenderer clone it and then set textureMap in mr.material.mainTexture
                _material = new Material(inMaterial); // clone incoming material
                _material.name += " (instance)";
                _material.mainTexture = atlas.textureMap; // set texture in material
                meshRenderer.material = _material; // set material in the renderer
            }

            public void RemoveMaterialOverride(int currentMaterialSetIndex) {
                ChangeMaterialSet(currentMaterialSetIndex);
            }

            public void ChangeMaterialSet(int materialSetIndex) {
                _material = atlas.materials[materialSetIndex];
                if(meshRenderer.material != _material) meshRenderer.material = _material; // set material in the renderer
            }

            public void DestroyMaterial(bool isOverridden) {
                if(!isOverridden) return;
                DestroyImmediate(_material);
            }

            public void UpdateMesh_Plane(Frame frame, bool useBatchScaling) {
                currentFrame = frame; // update the current frame
                SpriteMesh.UpdateMesh_Plane(mesh, frame, planeVerts, planeUVs, twoSidedMesh, useCustomMesh, flipped, flippedX, flippedY, useBatchScaling, batchScale);
            }

            public void UpdateMesh_Custom(Frame frame, bool useBatchScaling, MeshFrame[] meshFrames, int meshFrameCount, Vector3[] workingVerts, Vector2[] workingUvs, int[] workingTriangles, Vector3[] workingNormals) {
                currentFrame = frame; // update the current frame
                if(meshFrameCount <= 0) return;
                SpriteMesh.UpdateMesh_Custom(mesh, frame, meshFrames[frame.meshFrameIndex], twoSidedMesh, flipped, flippedX, flippedY, useBatchScaling, batchScale, workingVerts, workingUvs, workingTriangles, workingNormals);
            }

            public void FlipMesh_Plane(bool flipX, bool flipY) {
                if(mesh == null) return;
                if(!flipX && !flipY) return;

                // Set flipped states
                if(flipX) flippedX = !flippedX;
                if(flipY) flippedY = !flippedY;
                if(flippedX || flippedY) flipped = true;
                else flipped = false;
                    
                // We just cache the triangles and UVs once for planar meshes because they are always the same number.
                // The contents may be modified by flipping, but we do relative flipping so its okay.
                if(triangles == null) triangles = mesh.triangles; // cache the mesh triangles only if needed to save time
                Utils.UnityTools.FlipMesh(mesh, planeVerts, triangles, flipX, flipY); // we just flip the stored mesh (relative flip)
            }

            public void FlipMesh_Custom(bool flipX, bool flipY, bool useBatchScaling, MeshFrame[] meshFrames, int meshFrameCount, bool drawNow, Vector3[] workingVerts, Vector2[] workingUvs, int[] workingTriangles, Vector3[] workingNormals) {
                if(mesh == null) return;
                if(!flipX && !flipY) return;

                // Set flipped states
                if(flipX) flippedX = !flippedX;
                if(flipY) flippedY = !flippedY;
                if(flippedX || flippedY) flipped = true;
                else flipped = false;

                if(meshFrameCount <= 0) return;

                // Our mesh data may change between frames, yet we don't want to store all the mesh data every time we update the mesh because its slow
                // Just redraw the frame completely
                if(drawNow) UpdateMesh_Custom(mesh, currentFrame, meshFrames[currentFrame.meshFrameIndex], twoSidedMesh, flipped, flippedX, flippedY, useBatchScaling, batchScale, workingVerts, workingUvs, workingTriangles, workingNormals);
            }

            public void SetScale(Vector3 inBatchScale) {
                batchScale = inBatchScale;
            }

            public void SetSortingLayerId(int id) {
                Utils.UnityTools.SetSortingLayerID(meshRenderer, id);
            }

            public void SetSortingLayerName(string name) {
                Utils.UnityTools.SetSortingLayerName(meshRenderer, name);
            }

            public void SetSortingLayerOrder(int order) {
                Utils.UnityTools.SetSortingLayerOrder(meshRenderer, order);
            }

            public void SetCastShadows(bool value) {
                meshRenderer.castShadows = value;
            }

            public void SetReceiveShadows(bool value) {
                meshRenderer.receiveShadows = value;
            }

#if UNITY5
            public void SetShadowCastingMode(UnityEngine.Rendering.ShadowCastingMode mode) {
                meshRenderer.shadowCastingMode = mode;
            }
#endif

            public void InitializeCustomMesh(Vector3[] verts, Vector2[] uvs, int[] triangles, Vector3[] normals) {
                if(mesh == null) return;
                mesh.vertices = verts;
                mesh.uv = uvs;
                mesh.triangles = triangles;
                mesh.normals = normals;
                mesh.RecalculateBounds();
            }

            // STATIC METHODS

            public static void UpdateMesh_Plane(Mesh mesh, Sprite.Frame frame, Vector3[] verts, Vector2[] uvs, bool twoSidedMesh, bool useCustomMesh, bool flipped, bool flippedX, bool flippedY, bool useBatchScaling, Vector3 batchScale) {
                if(mesh == null) return;

                // Get frame offsets
                float offsetX = frame.frameOffset.x;
                float offsetY = frame.frameOffset.y;

                // Update uv positions in mesh
                Rect uvCoords = frame.uvCoords;
                uvs[0].x = uvCoords.x; // lower left
                uvs[0].y = uvCoords.y;
                uvs[1].x = uvCoords.x + uvCoords.width; // lower right
                uvs[1].y = uvCoords.y;
                uvs[2].x = uvCoords.x; // upper left
                uvs[2].y = uvCoords.y + uvCoords.height;
                uvs[3].x = uvCoords.x + uvCoords.width; // upper right
                uvs[3].y = uvCoords.y + uvCoords.height;

                // Update mesh shape
                // vert 0 = lower left
                // vert 1 = lower right
                // vert 2 = upper left
                // vert 3 = upper right

                // Get the mesh extents
                float extentsX = frame.meshExtents.x;
                float extentsY = frame.meshExtents.y;

                // Scale the verts and offsets for batch scaling
                if(useBatchScaling) {
                    extentsX *= batchScale.x;
                    extentsY *= batchScale.y;
                    offsetX *= batchScale.x;
                    offsetY *= batchScale.y;
                }

                if(!flipped) { // normal orientation

                    // Set vert positions to match the shape of our trimmed sprite
                    verts[0].x = -extentsX;
                    verts[0].y = -extentsY;
                    verts[1].x = extentsX;
                    verts[1].y = verts[0].y;
                    verts[2].x = verts[0].x;
                    verts[2].y = extentsY;
                    verts[3].x = verts[1].x;
                    verts[3].y = extentsY;

                    // Offset all verts if we have any trim or frame offset
                    if(offsetX != 0.0f || offsetY != 0.0f) { // we have some offset
                        verts[0].x += offsetX;
                        verts[0].y += offsetY;
                        verts[1].x += offsetX;
                        verts[1].y += offsetY;
                        verts[2].x += offsetX;
                        verts[2].y += offsetY;
                        verts[3].x += offsetX;
                        verts[3].y += offsetY;
                    }

                } else { // sprite is flipped

                    if(flippedX) {
                        if(flippedY) { // xy flipped

                            // Set vert positions to match the shape of our trimmed sprite
                            verts[0].x = extentsX;  // flip
                            verts[0].y = extentsY;  // flip
                            verts[1].x = -extentsX;  // flip
                            verts[1].y = verts[0].y;
                            verts[2].x = verts[0].x;
                            verts[2].y = -extentsY;  // flip
                            verts[3].x = verts[1].x;
                            verts[3].y = verts[2].y;

                            // Offset all verts if we have any trim or frame offset
                            if(offsetX != 0.0f || offsetY != 0.0f) { // we have some offset
                                verts[0].x -= offsetX; // flip
                                verts[0].y -= offsetY; // flip
                                verts[1].x -= offsetX; // flip
                                verts[1].y -= offsetY; // flip
                                verts[2].x -= offsetX; // flip
                                verts[2].y -= offsetY; // flip
                                verts[3].x -= offsetX; // flip
                                verts[3].y -= offsetY; // flip
                            }

                        } else { // just x flipped

                            // Set vert positions to match the shape of our trimmed sprite
                            verts[0].x = extentsX; // flip
                            verts[0].y = -extentsY;
                            verts[1].x = -extentsX; // flip
                            verts[1].y = verts[0].y;
                            verts[2].x = verts[0].x;
                            verts[2].y = extentsY;
                            verts[3].x = verts[1].x;
                            verts[3].y = extentsY;

                            // Offset all verts if we have any trim or frame offset
                            if(offsetX != 0.0f || offsetY != 0.0f) { // we have some offset
                                verts[0].x -= offsetX; // flip
                                verts[0].y += offsetY;
                                verts[1].x -= offsetX; // flip
                                verts[1].y += offsetY;
                                verts[2].x -= offsetX; // flip
                                verts[2].y += offsetY;
                                verts[3].x -= offsetX; // flip
                                verts[3].y += offsetY;
                            }
                        }

                    } else if(flippedY) { // just y flipped

                        // Set vert positions to match the shape of our trimmed sprite
                        verts[0].x = -extentsX;
                        verts[0].y = extentsY; // flip
                        verts[1].x = extentsX;
                        verts[1].y = verts[0].y;
                        verts[2].x = verts[0].x;
                        verts[2].y = -extentsY; // flip
                        verts[3].x = verts[1].x;
                        verts[3].y = verts[2].y;

                        // Offset all verts if we have any trim or frame offset
                        if(offsetX != 0.0f || offsetY != 0.0f) { // we have some offset
                            verts[0].x += offsetX;
                            verts[0].y -= offsetY; // flip
                            verts[1].x += offsetX;
                            verts[1].y -= offsetY; // flip
                            verts[2].x += offsetX;
                            verts[2].y -= offsetY; // flip
                            verts[3].x += offsetX;
                            verts[3].y -= offsetY; // flip
                        }
                    }
                }

                // Handle two-sided meshes
                if(twoSidedMesh) { // two-sided mesh
                    uvs[4] = uvs[0]; // reuse uvs from front side
                    uvs[5] = uvs[1];
                    uvs[6] = uvs[2];
                    uvs[7] = uvs[3];

                    // Copy positions for backfacing verts. Always the same as front verts.
                    verts[4].x = verts[0].x;
                    verts[4].y = verts[0].y;
                    verts[5].x = verts[1].x;
                    verts[5].y = verts[1].y;
                    verts[6].x = verts[2].x;
                    verts[6].y = verts[2].y;
                    verts[7].x = verts[3].x;
                    verts[7].y = verts[3].y;
                }

                // Apply changes to the Mesh
                //Utils.UnityTools.MarkDynamic(mesh); // optimize mesh for updating -- DO NOT USE -- BUGGED: http://forum.unity3d.com/threads/198020-What-is-Mesh-MarkDynamic?p=1515214&viewfull=1#post1515214
                mesh.uv = uvs; // update uvs in mesh
                mesh.vertices = verts; // update verts in the mesh
                mesh.RecalculateBounds();
            }

            public static void UpdateMesh_Custom(Mesh mesh, Sprite.Frame frame, MeshFrame meshFrame, bool twoSidedMesh, bool flipped, bool flippedX, bool flippedY, bool useBatchScaling, Vector3 batchScale, Vector3[] workingVerts, Vector2[] workingUVs, int[] workingTriangles, Vector3[] workingNormals) {
                if(mesh == null) return;

                // Copy data from MeshFrame into working arrays
                meshFrame.CopyMeshDataToWorkingArrays(workingVerts, workingUVs, workingTriangles);

                // Get offset information
                float offsetX = frame.frameOffset.x;
                float offsetY = frame.frameOffset.y;
                bool hasFrameOffset = offsetX != 0.0f || offsetY != 0.0f;

                if(flipped || useBatchScaling || hasFrameOffset) { // mesh data must be modified before sending it to the mesh

                    // Use working arrays for mesh components

                    int trueVertCount = meshFrame.vertices.Length;
                    int trueUVCount = meshFrame.uvs.Length;

                    // Apply frame offset
                    if(hasFrameOffset) {
                        for(int i = 0; i < trueVertCount; i++) {
                            workingVerts[i].x += offsetX;
                            workingVerts[i].y += offsetY;
                        }
                    }

                    if(flipped) { // sprite is flipped

                        if(flippedX) {
                            if(flippedY) { // xy flipped

                                // Flip the verts
                                for(int i = 0; i < trueVertCount; i++) {
                                    workingVerts[i].x *= -1.0f;
                                    workingVerts[i].y *= -1.0f;
                                }

                            } else { // just x flipped

                                // Flip the verts
                                for(int i = 0; i < trueVertCount; i++) {
                                    workingVerts[i].x *= -1.0f;
                                }
                            }

                        } else if(flippedY) { // just y flipped

                            // Flip the verts
                            for(int i = 0; i < trueVertCount; i++) {
                                workingVerts[i].y *= -1.0f;
                            }
                        }

                        // Set triangles
                        if(flippedX != flippedY && !twoSidedMesh) { // only flip triangles if flipped in 1 direction only, don't flip triangles on two sided meshes ever

                            int trueTriangleCount = meshFrame.triangles.Length;

                            int tempInt;
                            for(int i = 0; i < trueTriangleCount; i += 3) {
                                // triangles[i+0] = always stays same
                                tempInt = workingTriangles[i + 1];
                                workingTriangles[i + 1] = workingTriangles[i + 2]; // transpose last 2 verts
                                workingTriangles[i + 2] = tempInt;
                            }
                        }
                    }

                    // Scale the verts and offsets for batch scaling
                    if(useBatchScaling) {
                        for(int i = 0; i < trueVertCount; i++) {
                            workingVerts[i].x *= batchScale.x;
                            workingVerts[i].y *= batchScale.y;
                        }
                    }
                }

                // Apply changes to the Mesh
                //Utils.UnityTools.MarkDynamic(mesh); // optimize mesh for updating -- DO NOT USE -- BUGGED: http://forum.unity3d.com/threads/198020-What-is-Mesh-MarkDynamic?p=1515214&viewfull=1#post1515214
                //mesh.Clear(); // clear the mesh first to avoid vert/tri vertification problems when changing the number - Not necessary anymore since custom meshes will always have the same number of verts
                //mesh.colors = null; // clear colors - BUG - unity keeps adding colors back to meshes when mesh.Clear() is called I think
                mesh.vertices = workingVerts; // update verts in the mesh
                mesh.uv = workingUVs; // update uvs in mesh
                mesh.triangles = workingTriangles; // update triangles in mesh
                //mesh.RecalculateNormals(); // Normals are now set just once when initialized

                // Set the mesh normals if using two-sided mesh - must be updated each frame because number of actual mesh verts changes from frame to frame
                if(twoSidedMesh && workingNormals != null) {
                    int doubleSidedNormalCount = meshFrame.vertices.Length;
                    int singleSideNormalCount = doubleSidedNormalCount >> 1; // divide by 2
                    for(int i = 0; i < singleSideNormalCount; i++) { // set front side normals
                        if(workingNormals[i].z != -1.0f) workingNormals[i].z = -1.0f;
                    }
                    for(int i = singleSideNormalCount; i < doubleSidedNormalCount; i++) { // set back side normals
                        if(workingNormals[i].z != 1.0f) workingNormals[i].z = 1.0f;
                    }
                    mesh.normals = workingNormals; // set normals in mesh
                }

                mesh.RecalculateBounds();
            }

        }

        #endregion

        // See SpriteClasses.cs for the rest of this partial class
    }
}