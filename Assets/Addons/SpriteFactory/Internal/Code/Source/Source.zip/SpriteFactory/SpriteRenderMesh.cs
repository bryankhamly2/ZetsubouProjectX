using UnityEngine;
using System.Collections;

namespace SpriteFactory {

    [AddComponentMenu("")]
    public class SpriteRenderMesh : MonoBehaviour {

        // Inspector vars
        new public GameObject gameObject;
        new public Transform transform;
        public MeshRenderer meshRenderer;
        public MeshFilter meshFilter;

        // Vars set by Sprite
        [HideInInspector, SerializeField]
        private Sprite parentSprite;

        // Working
        [HideInInspector, SerializeField]
        private bool initialized;
        [HideInInspector, SerializeField]
        private bool _isShowing;
        [HideInInspector, SerializeField]
        private bool _isVisible;
        [HideInInspector, SerializeField]
        private bool calledByAnimation; // momentary flag so we know whether OnEnable was called by this or something else

        // Properties
        public bool show {
            get {
                return _isShowing;
            }
            set { // Enable/Disable the game object
                _isShowing = value;
                if(_isShowing) { // show
                    _isShowing = true;
                    if(Utils.UnityTools.IsActiveInHierarchy(gameObject)) return; // already active
                    calledByAnimation = true;
                    Utils.UnityTools.SetActive(gameObject, true);
                    calledByAnimation = false;
                } else { // hide
                    _isShowing = false;
                    if(!Utils.UnityTools.IsActiveInHierarchy(gameObject)) return; // already inactive
                    calledByAnimation = true;
                    Utils.UnityTools.SetActive(gameObject, false);
                    calledByAnimation = false;
                }
            }
        }
        public bool visible {
            get {
                return _isVisible;
            }
        }

        public void Initialize(Sprite inParentSprite) {
            parentSprite = inParentSprite;
            Utils.UnityTools.SetActive(gameObject, false); // make sure child mesh starts disabled (must do this before setting intialized = true)
            initialized = true;
        }

        private void OnEnable() {
            if(!initialized) return; // prevent this from running in the editor

            if(!calledByAnimation) { // called by an external force
                // User Activation
                // Instantiation
                // Scene load/play

                // Undo if it was enabled directly by user or SetActiveRecursively
                // If SetActiveRecursively(true) is called, all child sprite meshes will be enabled, which is not correct
                // The sprite mesh must turn itself off again so SetActiveRecursively will work as intended to enable a nested sprite hierarchy.
                if(!_isShowing) { // we know this is not the active sprite mesh because we are not set to show
                    Utils.UnityTools.SetActive(gameObject, false); // deactivate it
                    // Note: The object in Hierarchy and checkbox in Inspector will not update correctly for some reason and it will show it enabled even though it is not.
                }
            }
        }

        private void OnBecameVisible() {
            if(!initialized) return; // prevent this from running in the editor

            _isVisible = true;

            // WE CANNOT RELY ON calledByAnimation TO STILL BE SET BY THE TIME IT GETS AROUND TO CALLING THIS FUNCTION

            // Possible reasons this was called:
            // Activated by animation system
            // Camera enter
            // Activation
            // MeshRenderer enabled
            // Scene load/play (if on camera)

            // We only need to report to Sprite that we became visible if this is the active sprite mesh
            // Mesh must be re-rendered on visible because we may have been animating while invisible and mesh and uvs need to be updated
            if(_isShowing) { // we know this is the active sprite mesh because we are set to show
                parentSprite.Render();
            }
        }

        private void OnBecameInvisible() {
            if(!initialized) return; // prevent this from running in the editor

            _isVisible = false;

            // Possible reasons this was called:
            // Deactivated by animation system
            // Camera exit
            // Deactivation
            // Destruction
            // MeshRenderer disabled
        }
    }
}