﻿namespace SpriteFactory {
    public enum ColliderType { Box = 0, Sphere = 1, Capsule = 2, Mesh = 3, CharacterController = 4, Circle2D = 50, Box2D = 51, Edge2D = 52, Polygon2D = 53 };
    public enum CollisionType { Collider = 0, Trigger = 1, Particle = 2, Mouse = 3 };
    public enum CollisionDetectionMode2D { Discrete = 0, Continuous = 1 }; // replacement for Unity's bugged enum, 0 = None, but it should be Discreet
    
    public enum AutomaticActionPolicy { Prompt = 0, Always = 1, Never = 2 }
    //public enum AtlasPackingMethod { Default = 0, Simple = 1 }
    public enum BoolDefaultOption { Default = 0, True = 1, False = 2 }

    namespace Enums {
        public enum SpriteMeshType { Rectangle = 0, AutoMesh = 1 }
        public enum TransparencyChannel { Alpha = 0, Red = 1, Green = 2, Blue = 3, None = -1 } // Alpha must be 0 so existing Master Sprites will be set to Alpha by default instead of Red during an upgrade
        public enum ResolutionTarget { One = 0, ThreeQuarters = 34, TwoThirds = 23, Half = 2, Third = 3, Quarter = 4, Fifth = 5, Sixth = 6, Seventh = 7, Eighth = 8, Ninth = 9, Tenth = 10 }
        public enum ImageResamplingMode {
                None = 0,    

                // ResamplingService
                Box = 1,
                Triangle = 2,
                Hermite = 3,
                Bell = 4,
                CubicBSpline = 5,
                Lanczos3 = 6,
                Mitchell = 7,
                Cosine = 8,
                CatmullRom = 9,
                Quadratic = 10,
                QuadraticBSpline = 11,
                CubicConvolution = 12,
                Lanczos8 = 13,

                // TextureScale
                Point = 20,
                Bilinear = 21,
                //Trilinear = 22, // unused
                //Bicubic = 23, // unused
        }
        public enum VersionRestrictedType {
            RigidbodyInterpolation2D,
            RigidbodySleepMode2D,
            CollisionDetectionMode2D,
            PhysicsMaterial2D,
            Collider2D
        }
    }
}
