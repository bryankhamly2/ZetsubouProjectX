using UnityEngine;
using System.Collections;

namespace SpriteFactory {

    [AddComponentMenu("")]
    [ExecuteInEditMode]
    [RequireComponent(typeof(Camera))]
    public class SpriteCamera : MonoBehaviour {

        public bool renderAtActualPixelSize;
        public bool adjustForResolutionTarget = true;

        public bool showResolutionGate; // show a box showing the target resolution through the camera. This is only rendered in the editor.
        public DisplayResolution resolutionGateSize = DisplayResolution.Custom;
        public bool rotateLayout;
        public int customGateWidth = 1024;
        public int customGateHeight = 768;
        public Color resolutionGateColor = new Color(1.0f, 1.0f, 0.0f, 0.75f);

        public GameSettings gameSettings;

        new private Camera camera;
        private bool isActualPixelSize;
        private float origOrthographicSize;

        // Previous states for watching public vars
        private bool adjustForResolutionTarget_prev;
        private bool renderAtActualPixelSize_prev;
        private float orthographicSize_prev;

        private void Awake() {
            GetCamera();
        }

        private void Start() {
            if(camera == null) return;

            // Render at actual pixel size
            if(renderAtActualPixelSize) SetCameraToActualPixelSize(); // do this in start so camera pixel size has a chance to initialize first when dropping a new camera in scene
        }

        private void OnPreCull() {
            // Update the camera size every frame in the editor mode so it updates with screen size changes and also to get around a bug that returns the wrong camera size on level/Unity load in Unity 3.x
            if(Application.isEditor && !Application.isPlaying) {
                if(renderAtActualPixelSize) SetCameraToActualPixelSize(); // update it every frame while set to render at actual pixel size
            }
        }

        private void LateUpdate() {
            if(camera == null) return;

            // Detect changes to the public variables

            // Check for changes while we are in actual pixel size mode
            if(isActualPixelSize) {
                // Check for changes to camrea mode
                if(!Utils.UnityTools.Camera.isOrthographic(camera)) { // camera has been changed to a non orthographic camera
                    Debug.LogWarning("Camera projection mode was changed! No longer rendering at actual pixel size.");
                    ClearRenderAtActualPixelSizeVars();
                } else {
                    // Check for changes in camera orthographic size while we are set to render at actual pixel size
                    if(camera.orthographicSize != orthographicSize_prev) { // orthographic size setting was changed
                        Debug.LogWarning("Camera orthographic size changed! No longer rendering at actual pixel size.");
                        ClearRenderAtActualPixelSizeVars();
                    }
                }
            }

            // Check for changes in renderAtActualPixelSize variable
            if(renderAtActualPixelSize != renderAtActualPixelSize_prev) { // the variable changed
                renderAtActualPixelSize_prev = renderAtActualPixelSize; // update the prev state
                if(renderAtActualPixelSize) SetCameraToActualPixelSize(); // was turned on, render it
                else RevertCameraSize(); // was turned off
            }

            // Check for changes in useResolutionTarget variable
            if(adjustForResolutionTarget != adjustForResolutionTarget_prev) {
                adjustForResolutionTarget_prev = adjustForResolutionTarget; // update the prev state
                SetCameraToActualPixelSize(); // was turned on, render it
            }
        }

        private bool GetCamera() {
            // Get camera component
            camera = GetComponent<Camera>();
            if(camera == null) {
                Debug.LogError("Camera component not found!");
                return false;
            }
            return true;
        }

        public void SetCameraToActualPixelSize() {
            if(!CheckRequired()) return;
            if(!camera.orthographic) { // make sure camera is orthographic
                Debug.LogWarning("Camera must be set to orthographic mode to render at actual pixel size. This camera has been changed to orthographic mode temporarily. You should set the camera to orthographic in the inspector.");
                camera.orthographic = true;
            }

            // Change camera size setting so 1 texel equals 1 pixel
            float pixelsPerUnit = gameSettings.pixelsPerUnit; // get pixels per unit setting from settings file
            float viewAreaHeightInUnits = camera.pixelHeight / pixelsPerUnit; // Viewport can fit this many units on it vertically

            if(!isActualPixelSize) origOrthographicSize = camera.orthographicSize; // save original camera setting before making changes
            float newOrthographicSize = viewAreaHeightInUnits * 0.5f; // orthographicSize represents 1/2 the number of units that fit vertically on the screen
            if(adjustForResolutionTarget && gameSettings.settings != null && gameSettings.settings.isResolutionTargetScaled) newOrthographicSize *= gameSettings.settings.resolutionTargetScaleInverseMultiplier;
            if(camera.orthographicSize != newOrthographicSize) camera.orthographicSize = newOrthographicSize; // set camera
            renderAtActualPixelSize = true; // flag it on
            renderAtActualPixelSize_prev = true; // set prev state
            isActualPixelSize = true;
            orthographicSize_prev = camera.orthographicSize; // save camera size setting
        }

        public void RevertCameraSize() {
            if(!CheckRequired()) return;
            if(!isActualPixelSize) return; // not at actual pixel size, nothing to revert

            ClearRenderAtActualPixelSizeVars();
            camera.orthographicSize = origOrthographicSize; // revert camera setting
        }

        private bool CheckRequired() {
            if(gameSettings == null) { // make sure settings file exists
                Debug.LogError("Sprite Factory internal data file not found! Cannot get sprite resolution. Sprites may not be rendered at actual pixel size! Make sure the variable is set in the insepctor. The file is located in Assets/SpriteFactory/Internal/Data/Data.prefab");
                renderAtActualPixelSize = false;
                renderAtActualPixelSize_prev = false; // set prev state
                isActualPixelSize = false;
                return false;
            }
            if(camera == null) { // make sure there is a camera
                GetCamera(); // get the camera if it hasn't been gotten yet
                if(camera == null) {
                    Debug.LogError("Camera not found! Cannot display at actual pixel size! This script must be attached to a camera.");
                    renderAtActualPixelSize = false;
                    renderAtActualPixelSize_prev = false; // set prev state
                    isActualPixelSize = false;
                    return false;
                }
            }
            return true;
        }

        private void ClearRenderAtActualPixelSizeVars() {
            isActualPixelSize = false;
            renderAtActualPixelSize = false;
            renderAtActualPixelSize_prev = false;
        }

        #region // EDITOR ONLY

        // Draw resolution gate on camera
        public void DrawOnGUI() {
            if(!showResolutionGate) return;
            if(camera == null) { // no camera has been set, try to get it
                if(!GetCamera()) return;
            }

            DrawResolutionGate(); // draw the resolution gate in camera
        }

        private void DrawResolutionGate() {
            float displayWidth;
            float displayHeight;
            
            // Get resolution of resolution gate
            if(resolutionGateSize == DisplayResolution.Custom) { // user-defined resolution
                // Validate user-defined resolution
                if(customGateHeight <= 50) customGateHeight = 50;
                if(customGateWidth <= 50) customGateWidth = 50;
            }
            GetDeviceResolution(resolutionGateSize, rotateLayout, out displayWidth, out displayHeight); // get the resolution from the choice

            // Draw a box showing the resolution gate
            float startX = camera.pixelWidth * 0.5f - displayWidth * 0.5f; // find x starting point of centered box
            float startY = camera.pixelHeight * 0.5f - displayHeight * 0.5f; // find y starting point of centered box
            Utils.GUITools.Solid.DrawBox(new Rect(startX, startY, displayWidth, displayHeight), resolutionGateColor);
        }

        private void GetDeviceResolution(DisplayResolution resolution, bool portraitLayout, out float width, out float height) {
            if(resolution == DisplayResolution.Custom) { // user defined resolution
                if(portraitLayout) { // portrait mode, swap width and height
                    width = customGateHeight;
                    height = customGateWidth;
                } else { // normal landscape mode
                    width = customGateWidth;
                    height = customGateHeight;
                }
                return;
            }

            switch(resolution) {
                case DisplayResolution._320x200:
                    width = 320;
                    height = 200;
                    break;
                case DisplayResolution._320x240:
                    width = 320;
                    height = 240;
                    break;
                case DisplayResolution._480x320:
                    width = 480;
                    height = 320;
                    break;
                case DisplayResolution._480x360:
                    width = 480;
                    height = 360;
                    break;
                case DisplayResolution._640x480:
                    width = 640;
                    height = 480;
                    break;
                case DisplayResolution._800x400:
                    width = 800;
                    height = 400;
                    break;
                case DisplayResolution._800x480:
                    width = 800;
                    height = 480;
                    break;
                case DisplayResolution._800x600:
                    width = 800;
                    height = 600;
                    break;
                case DisplayResolution._960x540:
                    width = 960;
                    height = 540;
                    break;
                case DisplayResolution._960x640:
                    width = 960;
                    height = 640;
                    break;
                case DisplayResolution._1024x600:
                    width = 1024;
                    height = 600;
                    break;
                case DisplayResolution._1024x768:
                    width = 1024;
                    height = 768;
                    break;
                case DisplayResolution._1136x640:
                    width = 1136;
                    height = 640;
                    break;
                case DisplayResolution._1152x864:
                    width = 1152;
                    height = 864;
                    break;
                case DisplayResolution._1280x720:
                    width = 1280;
                    height = 720;
                    break;
                case DisplayResolution._1280x768:
                    width = 1280;
                    height = 768;
                    break;
                case DisplayResolution._1280x800:
                    width = 1280;
                    height = 800;
                    break;
                case DisplayResolution._1280x960:
                    width = 1280;
                    height = 960;
                    break;
                case DisplayResolution._1280x1024:
                    width = 1280;
                    height = 1024;
                    break;
                case DisplayResolution._1360x768:
                    width = 1360;
                    height = 768;
                    break;
                case DisplayResolution._1366x768:
                    width = 1366;
                    height = 768;
                    break;
                case DisplayResolution._1600x900:
                    width = 1600;
                    height = 900;
                    break;
                case DisplayResolution._1600x1080:
                    width = 1600;
                    height = 1080;
                    break;
                case DisplayResolution._1600x1024:
                    width = 1600;
                    height = 1024;
                    break;
                case DisplayResolution._1600x1200:
                    width = 1600;
                    height = 1200;
                    break;
                case DisplayResolution._1680x1050:
                    width = 1680;
                    height = 1050;
                    break;
                case DisplayResolution._1920x1080:
                    width = 1920;
                    height = 1080;
                    break;
                case DisplayResolution._1920x1200:
                    width = 1920;
                    height = 1200;
                    break;
                case DisplayResolution._2048x1536:
                    width = 2048;
                    height = 1536;
                    break;
                case DisplayResolution._2560x1600:
                    width = 2560;
                    height = 1600;
                    break;
                case DisplayResolution._2880x1800:
                    width = 2880;
                    height = 1800;
                    break;
                case DisplayResolution.iPhone:
                    width = 480;
                    height = 320;
                    break;
                case DisplayResolution.iPhone3G:
                    width = 480;
                    height = 320;
                    break;
                case DisplayResolution.iPhone3Gs:
                    width = 480;
                    height = 320;
                    break;
                case DisplayResolution.iPhone4:
                    width = 960;
                    height = 640;
                    break;
                case DisplayResolution.iPhone4s:
                    width = 960;
                    height = 640;
                    break;
                case DisplayResolution.iPhone5:
                    width = 1136;
                    height = 640;
                    break;
                case DisplayResolution.iPad:
                    width = 1024;
                    height = 768;
                    break;
                case DisplayResolution.iPad2:
                    width = 1024;
                    height = 768;
                    break;
                case DisplayResolution.iPad3:
                    width = 2048;
                    height = 1536;
                    break;
                case DisplayResolution.iPad4:
                    width = 2048;
                    height = 1536;
                    break;
                case DisplayResolution.iPadMini:
                    width = 1024;
                    height = 768;
                    break;
                case DisplayResolution.GalaxyS3:
                    width = 1280;
                    height = 720;
                    break;
                case DisplayResolution.GalaxyS4:
                    width = 1920;
                    height = 1080;
                    break;
                case DisplayResolution.Nexus4:
                    width = 1280;
                    height = 768;
                    break;
                case DisplayResolution.Nexus10:
                    width = 2560;
                    height = 1600;
                    break;
                case DisplayResolution.KindleFire:
                    width = 1024;
                    height = 600;
                    break;
                case DisplayResolution.KindleFireHD_7:
                    width = 1280;
                    height = 800;
                    break;
                case DisplayResolution.KindleFireHD_89:
                    width = 1920;
                    height = 1200;
                    break;
                case DisplayResolution.MacbookProRetina15:
                    width = 2880;
                    height = 1800;
                    break;
                case DisplayResolution.MacbookProRetina13:
                    width = 2560;
                    height = 1600;
                    break;
                default:
                    width = 1024;
                    height = 768;
                    Debug.LogWarning("Invalid device resolution chosen. Defaulting to 1024x768.");
                    break;
            }

            // Swap width and height for portrait mode
            if(portraitLayout) {
                float origHeight = height;
                height = width;
                width = origHeight;
            }
        }

        #endregion

        #region // ENUMS

        public enum DisplayResolution {
            Custom = -1,
            _320x200 = 0, _320x240 = 1, _480x320 = 2, _480x360 = 3, _640x480 = 4, _800x400 = 5, _800x480 = 6, _800x600 = 7, _960x540 = 8, _960x640 = 9, _1024x600 = 10,
            _1024x768 = 11, _1136x640 = 12, _1152x864 = 13, _1280x720 = 14, _1280x768 = 15, _1280x800 = 16, _1280x960 = 17, _1280x1024 = 18, _1360x768 = 19, _1366x768 = 20,
            _1600x900 = 21, _1600x1080 = 22, _1600x1024 = 23, _1600x1200 = 24, _1680x1050 = 25, _1920x1080 = 26, _1920x1200 = 27, _2048x1536 = 28, _2560x1600 = 29, _2880x1800 = 30,
            iPhone = 100, iPhone3G = 101, iPhone3Gs = 102, iPhone4 = 103, iPhone4s = 104, iPhone5 = 105, iPad = 120, iPad2 = 121, iPad3 = 122, iPad4 = 123, iPadMini = 140,
            GalaxyS3 = 200, GalaxyS4 = 201,
            Nexus4 = 220, Nexus10 = 230,
            KindleFire = 250, KindleFireHD_7 = 251, KindleFireHD_89 = 252,
            MacbookProRetina15 = 300, MacbookProRetina13 = 301
        }

        #endregion
    }
}