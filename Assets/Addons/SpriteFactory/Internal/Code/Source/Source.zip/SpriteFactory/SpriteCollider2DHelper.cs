﻿using UnityEngine;
using System.Collections;
using SpriteFactory;

namespace SpriteFactory {
    [AddComponentMenu("")]
    public class SpriteCollider2DHelper : MonoBehaviour {

        // This class is an extra component to add with SpriteCollider to handle 2D collision detection
        // FixedUpdate runs every frame, so leaving this off when using 3D colliders makes it faster
        
        // Collision2DTracker is a wrapper around Unity's OnCollision2D events. It properly detects Enter, Stay, and Exit events when scaling or reshaping (animating) a Collider2D.

        [HideInInspector, SerializeField]
        private bool initialized;

        [HideInInspector, SerializeField]
        public Collision2DTracker collision2DTracker;
        [HideInInspector, SerializeField]
        private GameObject thisGameObject;

        private void Awake() {
            thisGameObject = gameObject;
            initialized = true;
        }

        public void Initialize(Collision2DTracker collision2DTracker) {
            this.collision2DTracker = collision2DTracker;
        }

        private void FixedUpdate() {
            // Update collision tracker
            collision2DTracker.Update();
        }

        private void OnDisable() {
            if(!initialized) return; // prevent it from running in the editor
            if(thisGameObject.activeInHierarchy) return; // prevent this from running on OnDestroy

            // Fire exit events if collider is disabled (or destroyed)
            if(collision2DTracker != null) collision2DTracker.Disabled();
        }
    }
}
