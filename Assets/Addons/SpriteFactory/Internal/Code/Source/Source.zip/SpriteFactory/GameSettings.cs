﻿using UnityEngine;
using System.Collections;

namespace SpriteFactory {

    public class GameSettings : ScriptableObject {

        public int pixelsPerUnit {
            get {
                if(settings == null) return 100;
                return settings.pixelsPerUnit;
            }
        }

        public Settings settings;
        public DefaultObjects defaultObjects;
    }

    [System.Serializable]
    public class DefaultObjects {
        public GameObject boxCollider;
        public GameObject boxColliderRB;
        public GameObject boxCollider2D;
        public Material defaultMaterial;
        public GameObject spriteLocator;
        public GameObject spritePlane;
        public GameObject spritePlaneTwoSided;
    }
}