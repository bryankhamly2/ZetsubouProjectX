using UnityEngine;
using System.Collections;

namespace SpriteFactory {

    public class SpriteUpdater : MonoBehaviour {

        #region // Enums

        public enum UpdateCycle { Update = 0, FixedUpdate = 1, LateUpdate = 2, Manual = 3 };

        #endregion

        #region // Variables

        // Inspector vars
        public UpdateCycle updateCycle = UpdateCycle.Update;
        public bool dontDestroyThisOnLoad = false;
        public int startingPoolSize = 250;
        public int poolExpansionIncrement = 250;
        public int maxPoolExpansions = 0; // 0 = unlimited

        // Working
        [HideInInspector]
        private bool initialized;
        [HideInInspector]
        private SpritePool sprites;

        // Prev state variables for detecting public variable changes
        [HideInInspector]
        private bool dontDestroyThisOnLoad_prev;

        #endregion

        #region // Events

        private void Awake() {
            initialized = true;
            if(dontDestroyThisOnLoad) DontDestroyOnLoad(gameObject);

            // initialize arrays
            sprites = new SpritePool(startingPoolSize, true, poolExpansionIncrement, maxPoolExpansions);

            // Store prev variables
            dontDestroyThisOnLoad_prev = dontDestroyThisOnLoad;
        }

        private void Update() {
            if(updateCycle == UpdateCycle.Update) UpdateSprites();
        }

        private void LateUpdate() {
            if(updateCycle == UpdateCycle.LateUpdate) UpdateSprites();
        }

        private void FixedUpdate() {
            if(updateCycle == UpdateCycle.FixedUpdate) UpdateSprites();
        }

        #endregion

        #region // Public Functions

        public void UpdateSprites() {
            if(!initialized) return; // called in the editor

            // Update every sprite
            sprites.UpdateSprites();

            // Check for variable changes
            if(dontDestroyThisOnLoad != dontDestroyThisOnLoad_prev) {
                if(dontDestroyThisOnLoad) DontDestroyOnLoad(gameObject);
                dontDestroyThisOnLoad = dontDestroyThisOnLoad_prev;
            }
        }

        public int AddSprite(Sprite sprite) {
            if(!initialized) return -1; // called in the editor

            int index = sprites.AddIfUnique(sprite);
            if(index == -2) Debug.LogWarning("Cannot add " + sprite.name + " to SpriteUpdater! You should raise the max Sprite limit under Advanced Settings.");
            else { // Added to list or already in
                sprite.SpriteUpdaterCallback(this); // assign the sprite updater in the sprite
            }
            return index;
        }

        public void AddAllSprites(GameObject gameObject) {
            if(!initialized) return; // called in the editor

            // Called in game
            Sprite[] children = gameObject.GetComponentsInChildren<Sprite>(true); // get all sprite components in instanced object including inactive
            if(children == null) return; // no sprite components

            // Add sprites to list
            int index;
            for(int i = 0; i < children.Length; i++) {
                index = sprites.AddIfUnique(children[i]);
                if(index == -2) Debug.LogWarning("Cannot add " + children[i].name + " to SpriteUpdater! You should raise the max Sprite limit under Advanced Settings.");
                else { // Added to list or already in
                    children[i].SpriteUpdaterCallback(this); // assign the sprite updater in the sprite
                }
            }
        }

        public void RemoveSprite(Sprite sprite, bool clearReferenceInSprite = true) {
            if(!initialized) return; // called in the editor
            if(sprite == null) return;

            sprites.Remove(sprite, false);
            if(clearReferenceInSprite) sprite.SpriteUpdaterCallback(null); // clear sprite updater in sprite
        }

        public void RemoveSpriteAt(int index, bool clearReferenceInSprite = true) {
            if(!initialized) return; // called in the editor

            if(clearReferenceInSprite) {
                Sprite sprite = sprites[index]; // get the sprite
                sprite.SpriteUpdaterCallback(null); // clear sprite updater in sprite
            }
            sprites.RemoveAt(index); // remove from list
        }

        /// <summary>
        /// Clone a GameObject and add all Sprite components to SpriteUpdater
        /// </summary>
        /// <param name="original">GameObject to clone</param>
        /// <returns>Clone of original GameObject</returns>
        public GameObject InstantiateSprite(GameObject original) {
            if(!initialized) return null; // called in the editor

            GameObject instance = (GameObject)Object.Instantiate(original);
            if(instance == null) return null; // object was not instanced

            Sprite[] children = instance.GetComponentsInChildren<Sprite>(true); // get all sprite components in instanced object including inactive
            if(children == null) return null; // no sprite components

            // Add sprites to list
            int index;
            for(int i = 0; i < children.Length; i++) {
                index = sprites.AddIfUnique(children[i]);
                if(index == -2) Debug.LogWarning("Cannot add " + children[i].name + " to SpriteUpdater! You should raise the max Sprite limit under Advanced Settings.");
                else { // Added to list or already in
                    children[i].SpriteUpdaterCallback(this); // assign the sprite updater in the sprite
                }
            }
            return instance;
        }

        /// <summary>
        /// Clone a GameObject and add all Sprite components to SpriteUpdater
        /// </summary>
        /// <param name="original">GameObject to clone</param>
        /// <param name="position">World position of clone</param>
        /// <param name="rotation">World rotation of clone</param>
        /// <returns>Clone of original GameObject</returns>
        public GameObject InstantiateSprite(GameObject original, Vector3 position, Quaternion rotation) {
            if(!initialized) return null; // called in the editor

            GameObject instance = (GameObject)Object.Instantiate(original, position, rotation);
            if(instance == null) return null; // object was not instanced

            Sprite[] children = instance.GetComponentsInChildren<Sprite>(true); // get all sprite components in instanced object including inactive
            if(children == null) return null; // no sprite components

            // Add sprites to list
            int index;
            for(int i = 0; i < children.Length; i++) {
                index = sprites.AddIfUnique(children[i]);
                if(index == -2) Debug.LogWarning("Cannot add " + children[i].name + " to SpriteUpdater! You should raise the max Sprite limit under Advanced Settings.");
                else { // Added to list or already in
                    children[i].SpriteUpdaterCallback(this); // assign the sprite updater in the sprite
                }
            }
            return instance;
        }

        public void Clear() {
            if(!initialized) return; // called in the editor

            // Remove all references to this updater in sprites
            for(int i = 0; i < sprites.Length; i++) {
                Sprite sprite = sprites[i];
                if(sprite == null) continue;
                sprite.SetSpriteUpdater(null); // clear sprite updater
            }

            // Reset the pool
            sprites = new SpritePool(startingPoolSize, true, poolExpansionIncrement, maxPoolExpansions);
        }

        #endregion

        #region // PRIVATE CLASSES ///////////////

        [System.Serializable]
        private class SpritePool : SpriteFactory.Utils.DataClasses.Pool<Sprite> {

            public SpritePool(int startingLength, bool allowExpansion, int increment = 0, int maxExpansions = 0)
                : base(startingLength, allowExpansion, increment, maxExpansions) {
            }

            public void UpdateSprites() {
                for(int i = 0; i < _filledCount; i++) {
                    if(list[i] != null) list[i].UpdateSprite();
                }
            }
        }

        #endregion
    }
}