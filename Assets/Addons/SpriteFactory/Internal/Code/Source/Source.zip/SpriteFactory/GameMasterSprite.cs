using UnityEngine;
using System.Collections;

namespace SpriteFactory {

    public class GameMasterSprite : ScriptableObject {

        public Sprite.Data data; // main sprite data for dynamic loading
        public Sprite.SharedData sharedData;
    }
}