﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using SpriteFactory.Editor.Libraries.Ionic.Zlib;

namespace SpriteFactory.Editor {

    namespace DataClasses {

        #region Public Serializable Classes

        [System.Serializable]
        public class AutoMeshSettings {

            public int extrudeAmount = 8;
            public SpriteFactory.Enums.TransparencyChannel transparencyChannel = SpriteFactory.Enums.TransparencyChannel.Alpha;
            public float transparencyCutoff = 0.0f; // any pixel > this will be opaque
            public bool shellFindBleedCorners = false;
            public bool outlineDrawEdgeCorners = false;
            public double edgeVertexReductionDistance = 5.0d; // the lower the more verts
            public Enums.ResolutionTarget resolutionTarget;
            public Enums.ImageResamplingMode resolutionTargetResamplingMode;
            public bool trim;

            public AutoMeshSettings() { }

            public AutoMeshSettings(AutoMeshSettings settings) { // create new object cloning incoming
                CopyData(settings, this);
            }

            public AutoMeshSettings Clone() {
                return new AutoMeshSettings(this);
            }

            public static AutoMeshSettings Clone(AutoMeshSettings settings) {
                if(settings == null) return null;
                return new AutoMeshSettings(settings);
            }

            private void CopyData(AutoMeshSettings source, AutoMeshSettings destination) {
                destination.extrudeAmount = source.extrudeAmount;
                destination.transparencyChannel = source.transparencyChannel;
                destination.transparencyCutoff = source.transparencyCutoff;
                destination.shellFindBleedCorners = source.shellFindBleedCorners;
                destination.outlineDrawEdgeCorners = source.outlineDrawEdgeCorners;
                destination.edgeVertexReductionDistance = source.edgeVertexReductionDistance;
                destination.resolutionTarget = source.resolutionTarget;
                destination.resolutionTargetResamplingMode = source.resolutionTargetResamplingMode;
                destination.trim = source.trim;
            }
        }

        #endregion

        #region Internal Classes

        internal class AssetData {
            public string path;
            public AssetType type;
            public string guid;

            public AssetData(string path, AssetType type) {
                this.path = path;
                guid = AssetDatabase.AssetPathToGUID(path);
                this.type = type;
            }

            public AssetData(string path, string guid, AssetData.AssetType type) {
                this.path = path;
                this.guid = guid;
                this.type = type;
            }

            public enum AssetType { None = 0, EditorMasterSprite = 1, EditorMasterSpriteCore = 2, GameMasterSprite = 3, SpriteGroup = 4, SpriteMesh = 10, EditorPreviewMaterial = 11, SourceImage = 20, SourceMaterial = 21, MaterialSetMaterial = 30, Atlas = 31, Prefab = 40, PrefabDependency = 41 }
        }

        internal class AtlasCellData {

            public int atlasWidth;
            public int atlasHeight;
            public SpriteFactory.Utils.DataClasses.IntRect pixelUVRect;
            public SpriteFactory.Utils.DataClasses.IntVector2 pixelTrimDiff;
            public int pixelsPerUnit;
            public bool trim;
            public bool useCustomMesh;
            public SpriteFactory.Enums.ResolutionTarget resolutionTarget;
        }

        internal class TextureLoader {

            private Texture2D _texture;
            private bool _isTemp;

            public Texture2D texture { get { return _texture; } }
            public bool isTemp { get { return _isTemp; } }

            public bool hasTexture { get { return _texture != null; } }

            public TextureLoader(Texture2D texture, bool isTemp) {
                this._texture = texture;
                this._isTemp = isTemp;
            }

            public TextureLoader(string guid) {
                this._texture = Utils.AssetTools.LoadAssetFromGUID<Texture2D>(guid);
                this._isTemp = false;
            }

            public ColorImage ConvertToColorImage(bool freeMemoryNow) {
                if(!hasTexture) return null;

                ColorImage colorImage = new ColorImage(_texture);
                if(freeMemoryNow) FreeMemory();

                return colorImage;
            }

            public void FreeMemory() {
                if(_isTemp) {
                    if(_texture != null) Object.DestroyImmediate(_texture);
                } else {
                    if(_texture != null) Utils.AssetTools.UnloadAsset(_texture);
                }
                _texture = null;
                _isTemp = false;
            }
        }

        internal class ColorImage {

            private string _name;
            private Color[] _colors;
            private int _width;
            private int _height;
            private TextureFormat _format;

            public string name { get { return _name; } }
            public Color[] colors { get { return _colors; } }
            public int width { get { return _width; } }
            public int height { get { return _height; } }
            public TextureFormat format { get { return _format; } }

            public int Length { get { if(_colors != null) return _colors.Length; return 0; } }
            public bool isValid { get { return CheckData(false); } }

            public ColorImage() { }

            public ColorImage(Color[] pixels, int width, int height, TextureFormat textureFormat) {
                if(pixels == null || pixels.Length == 0) throw new System.ArgumentNullException("colors");
                if(width <= 0 || height <= 0) throw new System.ArgumentOutOfRangeException("width and height must be > 0!");
                if(pixels.Length != width * height) throw new System.ArgumentOutOfRangeException("width and height must equal colors.length!");

                this._colors = pixels;
                this._width = width;
                this._height = height;
                this._format = textureFormat;
            }

            public ColorImage(Texture2D texture) {
                if(texture == null) throw new System.ArgumentNullException("texture");
                this._name = texture.name;
                this._colors = texture.GetPixels();
                this._width = texture.width;
                this._height = texture.height;
                this._format = texture.format;
            }

            public ColorImage(int width, int height, TextureFormat textureFormat) {
                if(width <= 0 || height <= 0) throw new System.ArgumentOutOfRangeException("width and height must be > 0!");
                _colors = new Color[width * height];
                this._format = textureFormat;
            }

            // Public Methods

            public bool ImportByteImageFile(byte[] rawBytes, bool useCompression, bool useZlibStream) {
                if(rawBytes == null || rawBytes.Length == 0) {
                    Debug.LogError("Invalid image data!");
                    return false;
                }

                byte[] uncompressedBytes;

                // Decompress image bytes
                if(useCompression) {

                    try {

                        uncompressedBytes = Utils.ZlibHelper.DecompressBytes(rawBytes, useZlibStream);

                    } catch(System.Exception e) {
                        Debug.LogError(e.Message);
                        Debug.LogError(e.StackTrace);
                        return false;
                    }

                    if(uncompressedBytes == null || uncompressedBytes.Length == 0) {
                        Debug.LogError("Error decompressing image!");
                        return false;
                    }

                } else { // not compressed, just use raw bytes
                    uncompressedBytes = rawBytes;
                }

                // Convert bytes to Color[]
                int width, height, colorChannels;
                ByteImage byteImage = new ByteImage(uncompressedBytes);
                Color[] colors = byteImage.ToColors(uncompressedBytes, out width, out height, out colorChannels);
                if(colors == null) {
                    Debug.LogError("Error converting decompressed image!");
                    return false;
                }

                // Copy data to this image
                this._colors = colors;
                this._width = width;
                this._height = height;
                this._format = GetTextureFormat(colorChannels);

                return true;
            }

            public byte[] GetByteImageFile(bool useCompression, bool useZlibStream, CompressionLevel compressionLevel) {
                if(!CheckData()) return null;

                // Convert pixel image to an uncompressed byte array including headers
                ByteImage byteImage = new ByteImage(_colors, _width, _height, GetColorChannelCount(_format));
                if(byteImage.isInvalid) return null;

                // Compress image bytes
                if(useCompression) {
                    try {

                        byte[] compressedBytes = Utils.ZlibHelper.CompressBytes(byteImage.bytes, compressionLevel, useZlibStream);
                        return compressedBytes;

                    } catch(System.Exception e) {
                        Debug.Log(e.Message);
                        Debug.Log(e.StackTrace);
                        Debug.Log("Error compressing image!");
                        return null;
                    }
                } else { // not compressed, use raw bytes
                    return byteImage.bytes;
                }
            }

            public bool CheckData(bool report = true) {
                if(_colors == null || _colors.Length == 0 || _width <= 0 || _height <= 0 || _colors.Length != _width * _height) {
                    if(report) Debug.LogError("Invalid image data!");
                    return false;
                }
                return true;
            }

            public void SetPixels(int x, int y, int blockWidth, int blockHeight, Color[] pixels) {
                if(pixels == null || pixels.Length == 0) return;
                if(blockWidth <= 0 || blockHeight <= 0 || blockWidth * blockHeight != pixels.Length) return;
                if(x < 0 || x >= _width || y < 0 || y >= _height) return;

                int blockIndex, targetIndex;

                for(int row = 0; row < blockHeight; row++) {
                    if(y + row >= _height) break; // beyond limit of target image

                    for(int col = 0; col < blockWidth; col++) {
                        if(x + col >= _width) break; // beyond limit of target image
                        
                        blockIndex = row * blockWidth + col;
                        targetIndex = (y * _width) + (x + col);

                        _colors[targetIndex].r = pixels[blockIndex].r;
                        _colors[targetIndex].g = pixels[blockIndex].g;
                        _colors[targetIndex].b = pixels[blockIndex].b;
                        _colors[targetIndex].a = pixels[blockIndex].a;
                    }
                }
            }

            // Private Methods

            private int GetColorChannelCount(TextureFormat textureFormat) {
                if(_format == TextureFormat.Alpha8) {
                    return 1;
                } else if(_format == TextureFormat.RGB24) return 3;
                else if(_format == TextureFormat.ARGB32) return 4;
                return 4;
            }

            private TextureFormat GetTextureFormat(int colorChannels) {
                if(colorChannels == 4) return TextureFormat.ARGB32;
                else if(colorChannels == 3) return TextureFormat.RGB24;
                else if(colorChannels == 1) return TextureFormat.Alpha8;
                return TextureFormat.ARGB32; // default
            }
        }

        internal class ByteImage {

            private const int headerLength = 12;
            private const int bytesPerChannelValue = 4; // float for each color channel value
            
            private byte[] _bytes;
            private bool _isInvalid;

            public byte[] bytes { get { return _bytes; } }
            public bool isInvalid { get { return _isInvalid; } }

            public ByteImage(byte[] bytes) {
                this._bytes = bytes;
            }

            public ByteImage(Color[] pixels, int width, int height, int colorChannels) {
                byte[] bytes = ColorsToByteImage(pixels, width, height, colorChannels);
                if(bytes == null) {
                    Debug.Log("Failed to create ByteImage!");
                    _isInvalid = true;
                    return;
                }
                this._bytes = bytes;
            }

            private byte[] ColorsToByteImage(Color[] pixels, int width, int height, int colorChannels) {
                if(pixels == null) return null;

                int channelOffset = colorChannels == 1 ? 3 : 0; // offset channel index if just alpha

                byte[] byteImage = new byte[pixels.Length * colorChannels * bytesPerChannelValue + headerLength];
                int byteImageIndex;

                // Write header first
                // Header length must match headerLength cost
                System.Array.Copy(System.BitConverter.GetBytes(colorChannels), 0, byteImage, 0, 4);
                System.Array.Copy(System.BitConverter.GetBytes(width), 0, byteImage, 4, 4);
                System.Array.Copy(System.BitConverter.GetBytes(height), 0, byteImage, 8, 4);

                int count = 0;

                for(int pixelIndex = 0; pixelIndex < pixels.Length; pixelIndex++) {
                    for(int channel = 0; channel < colorChannels; channel++) {
                        byte[] bytes = System.BitConverter.GetBytes(pixels[pixelIndex][channel + channelOffset]); // convert float color to bytes (4 bytes)
                        for(int b = 0; b < bytesPerChannelValue; b++) { // copy color bytes
                            byteImageIndex = headerLength + (pixelIndex * colorChannels * bytesPerChannelValue) + (channel * bytesPerChannelValue) + b;
                            byteImage[byteImageIndex] = bytes[b];
                            count++;
                        }
                    }
                }

                return byteImage;
            }

            public Color[] ToColors(byte[] byteImage, out int width, out int height, out int colorChannels) {
                if(byteImage == null || byteImage.Length < headerLength) {
                    width = 0;
                    height = 0;
                    colorChannels = 0;
                    return null;
                }

                // Read header first
                // Header length must match headerLength cost
                colorChannels = System.BitConverter.ToInt32(byteImage, 0);
                width = System.BitConverter.ToInt32(byteImage, 4);
                height = System.BitConverter.ToInt32(byteImage, 8);

                if(width == 0 || height == 0) return null;

                int channelOffset = colorChannels == 1 ? 3 : 0;  // offset channel index if just alpha
                byte[] bytes = new byte[bytesPerChannelValue];
                Color[] pixels = new Color[width * height];
                int byteImageIndex = 0;

                for(int pixelIndex = 0; pixelIndex < pixels.Length; pixelIndex++) {
                    for(int channel = 0; channel < 4; channel++) { // always check all 4 channels even if image has less

                        // Account for channels not saved in image - we're always working with ARGB32 since Color has 4 channels
                        if(channel >= colorChannels) { // fill any channels opaque that not specified by the image - this is so RGB24 images don't come in transparent
                            pixels[pixelIndex][channel + channelOffset] = 1.0f;
                            continue; // there is no data stored for this pixel, so done
                        }

                        // Copy each byte into a buffer so we can convert to float colors
                        for(int b = 0; b < bytesPerChannelValue; b++) { // copy bytes into buffer
                            byteImageIndex = headerLength + (pixelIndex * colorChannels * bytesPerChannelValue) + (channel * bytesPerChannelValue) + b;
                            bytes[b] = byteImage[byteImageIndex];
                        }

                        // Assign value to color channel
                        pixels[pixelIndex][channel + channelOffset] = System.BitConverter.ToSingle(bytes, 0); // convert bytes to float
                    }
                }
                return pixels;
            }

        }

        #endregion
    }
}
