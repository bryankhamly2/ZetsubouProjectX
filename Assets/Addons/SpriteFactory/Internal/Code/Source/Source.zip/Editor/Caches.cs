﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.IO;
using SpriteFactory.Editor.Libraries.Ionic.Zlib;
using SpriteFactory.Editor.DataClasses;
using SpriteFactory.Enums;
using Sprite = SpriteFactory.Sprite;
using Settings = SpriteFactory.Settings;

namespace SpriteFactory.Editor {

    public class CacheDataObject : ScriptableObject {

        public Settings settings;

        [SerializeField]
        private ResolutionTargetScalingTextureCache _resolutionTargetScalingTextureCache; // unity will create this automatically

        internal ColorImage GetResolutionTargetImage(string textureGuid) {
            if(settings == null) { // settings file is missing
                Debug.LogError("Settings file was not found!");
                return null;
            }

            bool setDirty;
            ColorImage image = _resolutionTargetScalingTextureCache.GetImage(textureGuid, settings.resolutionTarget, settings.resolutionTargetResamplingMode, out setDirty);

            // Flag for saving
            if(setDirty) {
                EditorUtility.SetDirty(this);
            }

            return image;
        }

        public void UpdateResolutionTargetCachePath(string path) {
            _resolutionTargetScalingTextureCache.UpdatePath(path);
        }

        [System.Serializable]
        private class ResolutionTargetScalingTextureCache {

            [SerializeField]
            private List<Entry> cache;

            // Working vars (not serialized)
            private ImageResamplingMode resamplingMode;
            private ResolutionTarget resolutionTarget;
            private string cacheSavePath;

            // Consts
            private readonly static bool disableCache = false;
            private const string fileExtension = "";
            private readonly static bool useCompression = true;
            private const CompressionLevel compressionLevel = CompressionLevel.BestSpeed;
            private const bool useZlibStream = false; // If you want a ZLIB stream, set this to true.  If you want a bare DEFLATE stream, set this to false.

            public ResolutionTargetScalingTextureCache() {
                cache = new List<Entry>();
            }

            public void UpdatePath(string path) {
                cacheSavePath = path;
            }

            public ColorImage GetImage(string textureGuid, ResolutionTarget resolutionTarget, ImageResamplingMode resamplingMode, out bool setDirty) {
                setDirty = false;
                
                // Update working vars
                this.resolutionTarget = resolutionTarget;
                this.resamplingMode = resamplingMode;

                // Validate data
                if(textureGuid == null || textureGuid == string.Empty) return null;
                if(resolutionTarget == ResolutionTarget.One) return LoadSourceImage(textureGuid); // don't use the cache for non scaled textures
                if(disableCache) return ScaleTexure(textureGuid); // bypass the cache entirely

                // Check and create paths
                if(!CheckSavePath()) return null;

                // Search the cache and see if the texture is already in it
                for(int i = 0; i < cache.Count; i++) {
                    if(!cache[i].Contains(textureGuid, resolutionTarget, resamplingMode)) continue; // not a match

                    // Found the texture in the cache
                    bool foundTexture;
                    ColorImage img = GetImageFromEntry(cache[i], out foundTexture, ref setDirty); // get the texture
                    if(foundTexture) {
                        return img; // return the texture, done
                    }

                    // failed to get texture
                    cache.RemoveAt(i); // delete outdated entry
                    break; // exit and add the texture normally
                }

                // Not found in cache so add it
                return AddTexture(textureGuid, ref setDirty);
            }

            private ColorImage AddTexture(string textureGuid, ref bool setDirty) {
                Entry entry = new Entry(textureGuid, resolutionTarget, resamplingMode);
                ColorImage image = UpdateEntry(entry, ref setDirty);
                cache.Add(entry);
                return image;
            }

            private ColorImage GetImageFromEntry(Entry entry, out bool success, ref bool setDirty) {
                if(!entry.IsCurrent()) { // entry is outdated, need to update it
                    success = true;
                    return UpdateEntry(entry, ref setDirty); // scale the image and save it and update the entry information
                }

                success = false;

                /* // Unity Texture version -- very slow to write because of import calls
                string fullPath = cacheSavePath + "/" + entry.targetFileNumber + fileExtension;
                Texture2D texture = (Texture2D)AssetDatabase.LoadAssetAtPath(fullPath, typeof(Texture2D));
                return texture;
                */

                string fullPath = GetFullPath(entry.sourceGuid, entry.resolutionTarget);

                // Check if the file exists
                if(!File.Exists(fullPath)) { // cache image was deleted
                    return null;
                }

                // Load the file from disk
                byte[] bytes = null;
                try {
                    using(FileStream fs = new FileStream(fullPath, FileMode.Open)) {
                        using(BinaryReader br = new BinaryReader(fs)) {
                            const int bufferSize = 4096;
                            using(var ms = new MemoryStream()) {
                                byte[] buffer = new byte[bufferSize];
                                int count;
                                while((count = br.Read(buffer, 0, buffer.Length)) != 0) {
                                    ms.Write(buffer, 0, count);
                                }
                                bytes = ms.ToArray();
                            }
                        }
                    }
                } catch { // failed to read file
                    return null;
                }
                if(bytes == null) return null; // failed to get file

                // Decode the file
                ColorImage image = new ColorImage();
                bool imported = image.ImportByteImageFile(bytes, useCompression, useZlibStream);
                if(!imported) return null; // failed to decode

                success = true;
                return image;
            }

            private ColorImage UpdateEntry(Entry entry, ref bool setDirty) {

                // Load the source texture
                ColorImage sourceImage = entry.LoadSourceImage();
                if(sourceImage == null) return null;

                // Scale the texture
                ColorImage scaledImage = ScaleTexure(entry.sourceGuid);
                if(scaledImage == null) return null;

                int count = 0;
                for(int i = 0; i < scaledImage.colors.Length; i++) {
                    if(scaledImage.colors[i].a > 0) count++;

                }

                // Encode the texture
                byte[] bytes = scaledImage.GetByteImageFile(useCompression, useZlibStream, compressionLevel);
                if(bytes == null) {
                    Debug.LogError("Error creating cache texture!");
                    return null;
                }

                // Save the encoded texture to disk
                SaveFile(entry.sourceGuid, resolutionTarget, bytes);

                // Update the timestamp
                entry.UpdateTimestamp();

                // Unity Texture version -- import calls are too dangerous potentially causing problems with prefab/ScriptableObject references
                /*
                // Convert colors to texture and get png
                Texture2D newTexture = new Texture2D(newWidth, newHeight);
                newTexture.hideFlags = HideFlags.DontSave;
                newTexture.SetPixels(colors);
                byte[] png = newTexture.EncodeToPNG();

                // Save the texture
                string fileName = entry.targetFileNumber + fileExtension;
                string fullPath = cacheSavePath + "/" + fileName;
                using(FileStream fs = new FileStream(fullPath, FileMode.Create)) {
                    using(BinaryWriter bw = new BinaryWriter(fs)) {
                        bw.Write(png);
                    }
                }

                // Update the timestamp
                entry.UpdateTimestamp();

                // Import asset (DANGER!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!)
                Debug.LogWarning("DANGER");

                AssetDatabase.ImportAsset(fullPath, ImportAssetOptions.ForceUpdate);
                AssetDatabase.Refresh();
                */

                // Flag cache object for saving
                setDirty = true;

                return scaledImage;
            }

            private bool CheckSavePath() {
                if(cacheSavePath == null || cacheSavePath == string.Empty) {
                    Debug.LogError("Cache save path was null! Cannot create cache!");
                    return false;
                }

                // Create directory if it doesn't exist
                if(!Directory.Exists(cacheSavePath)) {
                    try {
                        Directory.CreateDirectory(cacheSavePath);
                    } catch {
                        Debug.LogError("Error creating cache directory!");
                        return false;
                    }
                }

                return true;
            }

            private ColorImage ScaleTexure(string textureGuid) {
                ColorImage colorImage = Utils.AssetTools.LoadTextureFromGUIDAsColorImage(textureGuid);
                if(colorImage == null) return null;

                // Scale the texture
                int newWidth, newHeight;
                Utils.TextureTools.ScaleResolution(colorImage.width, colorImage.height, SpriteFactory.Utils.MiscTools.ResolutionTargetScale(resolutionTarget), out newWidth, out newHeight);
                return Utils.TextureTools.Scale(colorImage, newWidth, newHeight, resamplingMode);
            }

            private ColorImage LoadSourceImage(string textureGuid) {
                return Utils.AssetTools.LoadTextureFromGUIDAsColorImage(textureGuid);
            }

            private void SaveFile(string name, ResolutionTarget resolutionTarget, byte[] bytes) {

                string dirPath = GetCacheSaveDirPath(resolutionTarget);
                string fileName = name + fileExtension;
                string fullPath = dirPath + fileName;

                // create directory if necessary
                if(!Directory.Exists(dirPath)) {
                    Directory.CreateDirectory(dirPath);
                }

                Utils.FileTools.WriteBinaryFile(fullPath, bytes);
            }

            private string GetCacheSaveDirPath(ResolutionTarget resolutionTarget) {
                string resTargetName = SpriteFactory.Utils.EnumTools.GetName<ResolutionTarget>(resolutionTarget);
                if(resTargetName == null) throw new System.Exception("Invalid resolution target!");
                return cacheSavePath + Path.DirectorySeparatorChar + resTargetName + Path.DirectorySeparatorChar;
            }

            private string GetFullPath(string name, ResolutionTarget resolutionTarget) {
                return GetCacheSaveDirPath(resolutionTarget) + name + fileExtension;
            }

            // Classes

            [System.Serializable]
            public class Entry {

                // Information about the target image
                public ResolutionTarget resolutionTarget;
                public ImageResamplingMode resamplingMode;

                // Information about the source image
                public string sourceGuid;
                public SpriteFactory.Utils.DataClasses.SerializableULong sourceTimestamp;

                public Entry(string sourceGuid, ResolutionTarget resolutionTarget, ImageResamplingMode resamplingMode) {
                    this.sourceGuid = sourceGuid;
                    UpdateTimestamp();
                    this.resolutionTarget = resolutionTarget;
                    this.resamplingMode = resamplingMode;
                }

                // Public methods

                public bool Contains(string sourceGuid, ResolutionTarget resolutionTarget, ImageResamplingMode resamplingMode) {
                    if(sourceGuid == this.sourceGuid && resolutionTarget == this.resolutionTarget && resamplingMode == this.resamplingMode) return true;
                    return false;
                }

                public bool IsCurrent() {
                    // check timestamp

                    // Load the texture importer
                    TextureImporter importer = LoadSourceTextureImporter();
                    if(importer == null) return false;

                    ulong timestamp = importer.assetTimeStamp;
                    Utils.AssetTools.UnloadAsset(importer); // unload importer from memory in case it has to load the texture as well

                    // Check the timestamp
                    if(sourceTimestamp.value == timestamp) { // timestamp matche
                        return true;
                    }

                    return false;
                }

                public void UpdateTimestamp() {
                    // Load the texture importer
                    TextureImporter importer = LoadSourceTextureImporter();
                    if(importer == null) return;

                    ulong timestamp = importer.assetTimeStamp;
                   Utils.AssetTools.UnloadAsset(importer); // unload importer from memory in case it has to load the texture as well

                    sourceTimestamp = new SpriteFactory.Utils.DataClasses.SerializableULong();
                    sourceTimestamp.value = timestamp;
                }

                // Private methods

                internal ColorImage LoadSourceImage() {
                    return Utils.AssetTools.LoadTextureFromGUIDAsColorImage(sourceGuid);
                }

                public TextureImporter LoadSourceTextureImporter() {
                    string assetPath = GetSourceTexturePath();
                    if(assetPath == null || assetPath == string.Empty) return null;

                    // Load the texture importer
                    return (TextureImporter)TextureImporter.GetAtPath(assetPath);
                }

                private string GetSourceTexturePath() {
                    if(sourceGuid == null || sourceGuid == string.Empty) return null;

                    // Get the asset path
                    return AssetDatabase.GUIDToAssetPath(sourceGuid);
                }
            }
        }
    }
}
