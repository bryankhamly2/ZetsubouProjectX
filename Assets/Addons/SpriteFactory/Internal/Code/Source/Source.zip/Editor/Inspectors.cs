﻿using UnityEngine;
using UnityEditor;
using UnityEditorInternal;
using System.Collections;
using System.Reflection;

namespace SpriteFactory.Editor {

    public class SpriteInspector {

        private UnityEditor.Editor proxy;
        private SerializedObject serializedObject;
        private SerializedObject serializedMeshRenderer;

        private SerializedProperty selfUpdate;
        private SerializedProperty spriteUpdater;
        private SerializedProperty playAnimationOnStart;
        private SerializedProperty playDefaultAnimWhenIdle;
        private SerializedProperty playbackSpeed;
        private SerializedProperty animateOffCamera;
        private SerializedProperty defaultAnimationOverride;
        private SerializedProperty materialOverride;
        private SerializedProperty currentMaterialSetIndex;
        private SerializedProperty useBatchScaling;
        private SerializedProperty isBillboard;
        private SerializedProperty billboardUpAxis;
        private SerializedProperty scaleToActualPixelSize;
        private SerializedProperty activateLocatorsRecursively;

        private SerializedProperty xFlippedSP;
        private SerializedProperty yFlippedSP;
        private SerializedProperty isFlippedSP;
        private SerializedProperty gameMasterSpriteSP;

        private SerializedProperty sortingLayer;
        private SerializedProperty sortingLayerID;
        private SerializedProperty sortingOrder;

        private bool showAnimations;
        private bool showAdvanced;
        private Sprite sprite;

        public SpriteInspector(UnityEditor.Editor proxy) {
            this.proxy = proxy;
        }

        public void OnEnable() {
            serializedObject = proxy.serializedObject; // get the serialized object from the proxy

            // set up the serialized properties
            selfUpdate = serializedObject.FindProperty("selfUpdate");
            spriteUpdater = serializedObject.FindProperty("spriteUpdater");
            playAnimationOnStart = serializedObject.FindProperty("playAnimationOnStart");
            playDefaultAnimWhenIdle = serializedObject.FindProperty("playDefaultAnimWhenIdle");
            playbackSpeed = serializedObject.FindProperty("playbackSpeed");
            animateOffCamera = serializedObject.FindProperty("animateOffCamera");
            defaultAnimationOverride = serializedObject.FindProperty("defaultAnimationOverride");
            materialOverride = serializedObject.FindProperty("materialOverride");
            currentMaterialSetIndex = serializedObject.FindProperty("currentMaterialSetIndex");
            useBatchScaling = serializedObject.FindProperty("useBatchScaling");
            isBillboard = serializedObject.FindProperty("isBillboard");
            billboardUpAxis = serializedObject.FindProperty("billboardUpAxis");
            scaleToActualPixelSize = serializedObject.FindProperty("scaleToActualPixelSize");
            activateLocatorsRecursively = serializedObject.FindProperty("activateLocatorsRecursively");

            gameMasterSpriteSP = serializedObject.FindProperty("gameMasterSprite");
            xFlippedSP = serializedObject.FindProperty("_xAxisFlipped");
            yFlippedSP = serializedObject.FindProperty("_yAxisFlipped");
            isFlippedSP = serializedObject.FindProperty("_isFlipped");

            sprite = (Sprite)proxy.target;

            if(SpriteFactory.Utils.UnityTools.supportsSortingLayers) {
                MeshRenderer mr = sprite.GetComponent<MeshRenderer>();
                if(mr != null) {
                    serializedMeshRenderer = new SerializedObject(mr);
                    sortingLayer = serializedMeshRenderer.FindProperty("m_SortingLayer");
                    sortingLayerID = serializedMeshRenderer.FindProperty("m_SortingLayerID");
                    sortingOrder = serializedMeshRenderer.FindProperty("m_SortingOrder");
                }
            }
        }

        public void OnInspectorGUI() {
            // Update the serializedProperty - always do this in the beginning of OnInspectorGUI
            serializedObject.Update();

            // Get components
            MeshRenderer mr = sprite.GetComponent<MeshRenderer>();

            // Show the custom GUI controls

            // Determine label field width
            float width = 200.0f;
            EditorGUIUtility.LookLikeControls(width); // set width of label field for controls

            // Draw a preview of the sprite so its easier for users to browse prefabs
            DrawSpritePreview();
            DrawFlipButtons();

            bool isStatic = sprite.isStaticSprite;

            // Sorting Layer controls
            if(SpriteFactory.Utils.UnityTools.supportsSortingLayers) {
                if(serializedMeshRenderer != null && mr != null) {

                    GUILayout.Space(10.0f);
                    EditorGUILayout.LabelField("Rendering Settings");

                    serializedMeshRenderer.Update(); // start

                    // Get sorting layers and ids via reflection
                    System.Type internalEditorUtilityType = typeof(InternalEditorUtility);
                    PropertyInfo sortingLayerNamesProperty = internalEditorUtilityType.GetProperty("sortingLayerNames", BindingFlags.Static | BindingFlags.NonPublic);
                    string[] sortingLayerNames = (string[])sortingLayerNamesProperty.GetValue(null, new object[0]);
                    PropertyInfo sortingLayerUniqueIDsProperty = internalEditorUtilityType.GetProperty("sortingLayerUniqueIDs", BindingFlags.Static | BindingFlags.NonPublic);
                    int[] sortingLayerUniqueIDs = (int[])sortingLayerUniqueIDsProperty.GetValue(null, new object[0]);

                    // Sorting layer popup
                    
                    // Draw the popup
                    Utils.InspectorTools.DrawPopup(sortingLayerID, sortingLayerNames, sortingLayerUniqueIDs, new GUIContent("Sorting Layer", "The sorting layer this Sprite will be drawn on. This can be used to manually depth sort Sprites. You can edit sorting layers from the menu Project Settings -> Tags and Layers."));
                    int newLayer = sortingLayerID.intValue;

                    // Sorting order
                    Utils.InspectorTools.DrawInt(sortingOrder, -32768, 32767, new GUIContent("Order in Layer", "The render order within the current sorting layer. Higher numbers render in front. [-32768, 32767]"));
                    
                    serializedMeshRenderer.ApplyModifiedProperties(); // finish
                }
            }

            // Settings for animated sprites only
            if(!isStatic) {
                GUILayout.Space(10.0f);
                EditorGUILayout.LabelField("Animation Settings");

                Utils.InspectorTools.DrawToggle(playAnimationOnStart, new GUIContent("Play Animation on Start", "Start playing the default animation on start."));
                Utils.InspectorTools.DrawToggle(playDefaultAnimWhenIdle, new GUIContent("Play Default Anim When Idle", "Always play the default animation when no animation is currently playing."));
                Utils.InspectorTools.DrawFloat(playbackSpeed, 0.0f, 1000.0f, new GUIContent("Playback Speed", "Sets the animation playback speed multiplier. 1 = normal speed."));
                Utils.InspectorTools.DrawToggle(animateOffCamera, new GUIContent("Animate Off Camera", "Animate the sprite when off camera."));

                // Default Animation Override dropdown box
                string[] animNames = sprite.GetAnimationNames();
                Utils.InspectorTools.DrawPopupWithNone(defaultAnimationOverride, animNames);

                // Show the animations and frame counts
                showAnimations = EditorGUILayout.Foldout(showAnimations, "Animations"); // foldout
                if(showAnimations) {
                    int[] frameCounts = sprite.GetAnimationFrameCounts();
                    if(animNames != null) { // we have some animations
                        for(int i = 0; i < animNames.Length; i++) {
                            string str = animNames[i] + "   ";
                            str += "[" + frameCounts[i] + " ";
                            if(frameCounts[i] == 1) str += "frame]";
                            else str += "frames]";
                            if(sprite.defaultAnimationIndex == i) str += " (Default Animation)";
                            EditorGUILayout.LabelField(str);
                        }
                    } else { // no animations
                        EditorGUILayout.LabelField("This sprite contains no animations.");
                    }
                }
            }

            GUILayout.Space(10.0f);
            EditorGUILayout.LabelField("Misc Settings");

            //GUI.enabled = false;
            
            //Utils.InspectorTools.DrawToggle(ref isStatic, new GUIContent("Static Sprite", "True = Sprite is static. False = Sprite is animated. This property must be set in the editor and is shown here for reference only."));
            //GUI.enabled = true;

            Utils.InspectorTools.DrawToggle(selfUpdate, new GUIContent("Self Update", "If checked, Sprite will run the Update cycle on its own. If unchecked, you must assign a SpriteUpdater to the Sprite which will run the update cycle on the Sprite.\n\nUsing a SpriteUpdater to run the update cycle allows you to choose a different update cycle such as FixedUpdate or LateUpdate as well as allowing you to stop the update cycle on a group of Sprites for various purposes such pausing the game."));
            GUI.enabled = !selfUpdate.boolValue; // disable sprite updater field if selfUpdate is checked
            Utils.InspectorTools.DrawObjectField(spriteUpdater, typeof(SpriteUpdater), true, new GUIContent("Sprite Updater", "The SpriteUpdater responsible for running the main update cycle on the Sprite. The SpriteUpdater must be chosen from the scene."));
            GUI.enabled = true;

            // Billboard sprite settings
            Utils.InspectorTools.DrawToggle(isBillboard, new GUIContent("Is Billboard", "Set whether this sprite is a billboard. Billboards always face the main camera."));
            string[] billboardOptions = new string[12] { "World +X", "World +Y", "World +Z", "World -X", "World -Y", "World -Z", "Camera +X", "Camera +Y", "Camera +Z", "Camera -X", "Camera -Y", "Camera -Z" };
            GUI.enabled = isBillboard.boolValue;
            Utils.InspectorTools.DrawPopup(billboardUpAxis, billboardOptions, new GUIContent("Billboard Up Axis", "Rotates the billboard sprite's transform to point its up direction vector in the direction hinted at by this axis. This is only a hint vector."));
            GUI.enabled = true;

            // Batch scaling
            Utils.InspectorTools.DrawToggle(useBatchScaling, new GUIContent("Use Batch Scaling", "Allows dynamic batching with sprites of different scales to reduce draw calls. Set the desired scale in the inspector using the Transform scale as usual. When gameplay begins or sprite is instantiated, Transform.localScale will be reset to 1,1,1 and the sprite will be scaled by modifying the mesh vertex positions instead."));

            // Scale To Actual Pixel Size
            Utils.InspectorTools.DrawToggle(scaleToActualPixelSize, new GUIContent("Scale To Actual Pixel Size", "Scale the sprite to display at 1:1 pixel ratio in the main camera.\n\n"
            + "* IMPORTANT * This actually scales the Sprite's transform in order to match the pixel size. This could have a number of potentially unwanted side effects because while the Sprite scales, "
            + "things such as movement speeds and distances to other objects does not. If your intention is to display all the Sprites on the screen at actual pixel size, you do not want to use this setting. "
            + "Instead, you should add a SpriteCamera to the scene and use this camera for rendering. (SpriteCamera can be found in Assets/SpriteFactory/Prefabs/SpriteCamera)"));   

            // Activate Locator Children Recursively (Only show on Unity 3.5 since system was changed for v4)
            if(sprite.locatorCount > 0) {
                if(SpriteFactory.Utils.UnityTools.isSupportedVersion3) { // Unity version is 3.5
                    Utils.InspectorTools.DrawToggle(activateLocatorsRecursively, new GUIContent("Activate Loc. Children Recursively", "When a Sprite is activated or deactivated, locators will have their active state set as well. If you want all children of locators to have their active state set recursively "
                    + "when the locator is activated or deactivated, check this. NOTE: If unchecked, active state will be set only on first child objects of locator. If you are parenting Sprites to locators, generally you do not need to check this as the Sprite will automatically handle "
                    + "enabling or disabling its internal child objects. If you are parenting a nested Sprite hierarchy or other complex hierarchy to a locator, then you should check this box."));
                }
            }

            GUILayout.Space(10.0f);
            EditorGUILayout.LabelField("Material Settings");

            // Material Set popup
            string[] names = sprite.GetMaterialSetNames();
            Utils.InspectorTools.DrawPopup(currentMaterialSetIndex, names, new GUIContent("Material Set", "The current material set used by the sprite. The sprite will be drawn with the selected material on play."
            + "\n\nNote: The material displayed on the sprite in the scene view will always be from the default Material Set. When you press play, the sprite will be drawn with the chosen material."));

            // Material override
            Utils.InspectorTools.DrawObjectField(materialOverride, typeof(Material), false, new GUIContent("Material Override", "Use a custom material on this Sprite. This can be useful if you need to switch materials dynamically without a predefined Material Set."
            + "\n\n* It is recommended that you make a Material Set in the editor and select it above instead of using a Material Override. Material Override incurs a draw call for each sprite "
            + "instance of this sprite on screen because the override material is instanced for each sprite instance. However, Material Sets are shared among instances of the same sprite and do not incur extra draw calls. "
            + "\n\nNote: The material displayed on the sprite in the scene view will always be from the default Material Set. When you press play, the sprite will be drawn with the custom material."));

            // Check material shader for compatibility
            if(mr != null) {
                Material material = mr.sharedMaterial;
                if(material != null && !material.HasProperty("_MainTex")) {
                    Color c = GUI.color;
                    GUI.color = new Color(1.0f, 1.0f, 0.0f, 1.0f);
                    GUILayout.Space(10.0f);
                    EditorGUILayout.LabelField("Error! Currently assigned material does not");
                    EditorGUILayout.LabelField("have a \"_MainTex\" property and is incompatible!");
                    GUI.color = c;
                }
            }

            // Debug options foldout
            GUILayout.Space(10.0f);
            showAdvanced = EditorGUILayout.Foldout(showAdvanced, "Advanced");
            if(showAdvanced) {
                GUI.enabled = false;
                Utils.InspectorTools.DrawObjectField(gameMasterSpriteSP, typeof(GameMasterSprite), false, new GUIContent("Master Sprite", "The object reference to the Game Master Sprite used by this Sprite. This is displayed for reference only."));
                GUI.enabled = true;
            }

            GUILayout.Space(10.0f);

            // Apply changes to the serializedProperty - always do this in the end of OnInspectorGUI
            serializedObject.ApplyModifiedProperties();

            //DrawDefaultInspector();
        }

        private void DrawSpritePreview() {
            Texture2D texture;
            Rect uvs;
            bool foundFrame = sprite.GetEditorPreviewFrameData(out texture, out uvs);
            if(foundFrame) {
                float uvWidth = uvs.width;
                float uvHeight = uvs.height;
                float framePixelWidth = uvWidth * texture.width;
                float framePixelHeight = uvHeight * texture.height;
                Rect pos = new Rect(0, 0, framePixelWidth, framePixelHeight);
                Rect texCoords = new Rect(uvs.x, uvs.y, uvWidth, uvHeight);
                if(sprite.isFlipped) {
                    if(sprite.isFlippedX) {
                        texCoords.x += uvWidth;
                        texCoords.width *= -1.0f;
                    }
                    if(sprite.isFlippedY) {
                        texCoords.y += uvHeight;
                        texCoords.height *= -1.0f;
                    }
                }

                // shrink if bigger than max size
                float max = 200.0f;
                if(pos.width > pos.height) { // wide
                    if(pos.width > max) {
                        pos.height = max / pos.width * pos.height; // scale y
                        pos.width = max;
                    }
                } else if(pos.height > pos.width) { // tall
                    if(pos.height > max) {
                        pos.width = max / pos.height * pos.width; // scale x
                        pos.height = max;
                    }
                } else { // square
                    if(pos.width > max) {
                        pos.width = max;
                        pos.height = max;
                    }
                }

                float padding = 10.0f;
                GUILayoutUtility.GetRect(pos.width, pos.height + (padding * 2.0f)); // reserve a rect for image
                Rect lastRect = GUILayoutUtility.GetLastRect();
                pos.x = lastRect.x;
                pos.y = lastRect.y + padding;
                if(lastRect.width > pos.width) { // center if area is wide
                    pos.x += (lastRect.width * 0.5f) - (pos.width * 0.5f);
                }
                GUI.DrawTextureWithTexCoords(pos, texture, texCoords);
            }
        }

        private void DrawFlipButtons() {
            if(!Application.isPlaying) { // editor mode, change meshes
                // Make sure flip state is sync'd with mesh -- users could cause a mismatch by changing the mesh manually or reverting it to prefab default
                SyncMeshFlippedState();
            }

            EditorGUILayout.BeginHorizontal();

            // Draw flip buttons
            if(GUILayout.Button(new GUIContent("Flip X", "Flip the sprite in the X direction. All spawned colliders and locators will be flipped as well."))) {
                Flip(true, false);
            }
            if(GUILayout.Button(new GUIContent("Flip Y", "Flip the sprite in the Y direction. All spawned colliders and locators will be flipped as well."))) {
                Flip(false, true);
            }

            EditorGUILayout.EndHorizontal();
        }

        private void SyncMeshFlippedState() { // make sure mesh and flip state don't go out of sync
            MeshFilter mf = (MeshFilter)sprite.GetComponent(typeof(MeshFilter));
            if(mf == null) {
                Debug.LogWarning("No MeshFilter found!");
                return;
            }
            GameMasterSprite masterGameSprite = GetMasterGameSprite();
            if(masterGameSprite == null) return;

            // Get the editor mesh we should be using
            Mesh editorPreviewMesh = GetEditorPreviewMesh(masterGameSprite, xFlippedSP.boolValue, yFlippedSP.boolValue); // get the proper mesh based on current flip states
            if(editorPreviewMesh == null) return;

            SerializedObject meshFilterSO = new SerializedObject(mf);
            meshFilterSO.Update();
            SerializedProperty meshSP = meshFilterSO.FindProperty("m_Mesh");
            if(meshSP.objectReferenceValue != null) {
                Mesh assignedMesh = (Mesh)meshSP.objectReferenceValue; // set mesh in mesh filter

                if(assignedMesh != editorPreviewMesh) { // mesh is out of sync with flip states
                    Sprite.Data spriteData = masterGameSprite.data;
                    Mesh[] meshes = spriteData.editorPreviewMeshes;
                    int index = -1;
                    for(int i = 0; i < meshes.Length; i++) {
                        if(assignedMesh == meshes[i]) {// found the assigned mesh
                            index = i;
                            break;
                        }
                    }
                    if(index == -1) return; // mesh isn't an editor preview mesh, do nothing

                    // Make flip state match mesh
                    if(index == 0) {// no flip
                        isFlippedSP.boolValue = false;
                        xFlippedSP.boolValue = false;
                        yFlippedSP.boolValue = false;
                    } else if(index == 1) { // x-flip
                        isFlippedSP.boolValue = true;
                        xFlippedSP.boolValue = true;
                        yFlippedSP.boolValue = false;
                    } else if(index == 2) { // y-flip
                        isFlippedSP.boolValue = true;
                        xFlippedSP.boolValue = false;
                        yFlippedSP.boolValue = true;
                    } else if(index == 3) { // xy-flip
                        isFlippedSP.boolValue = true;
                        xFlippedSP.boolValue = true;
                        yFlippedSP.boolValue = true;
                    }
                }
            }
        }

        private void Flip(bool x, bool y) {
            if(Application.isPlaying) { // we are in gameplay mode
                sprite.Flip(x, y); // flip the meshes through Sprite instead
                return;
            }

            // We are in Editor mode -- flip by swapping meshes

            if(x) xFlippedSP.boolValue = !xFlippedSP.boolValue;
            if(y) yFlippedSP.boolValue = !yFlippedSP.boolValue;

            if(xFlippedSP.boolValue || yFlippedSP.boolValue) {
                if(!isFlippedSP.boolValue) isFlippedSP.boolValue = true;
            } else {
                if(isFlippedSP.boolValue) isFlippedSP.boolValue = false;
            }

            // Swap editor meshes in mesh filter
            MeshFilter mf = (MeshFilter)sprite.GetComponent(typeof(MeshFilter));
            if(mf == null) {
                Debug.LogWarning("No MeshFilter found!");
                return;
            }
            GameMasterSprite masterGameSprite = GetMasterGameSprite();
            if(masterGameSprite == null) return;

            // Update editor mesh on mesh filter
            Mesh editorPreviewMesh = GetEditorPreviewMesh(masterGameSprite, xFlippedSP.boolValue, yFlippedSP.boolValue); // get the proper mesh based on current flip states
            if(editorPreviewMesh == null) return;

            SerializedObject meshFilterSO = new SerializedObject(mf);
            meshFilterSO.Update();
            SerializedProperty meshSP = meshFilterSO.FindProperty("m_Mesh");
            meshSP.objectReferenceValue = editorPreviewMesh; // set mesh in mesh filter
            meshFilterSO.ApplyModifiedProperties(); // apply changes

            return;
        }

        private GameMasterSprite GetMasterGameSprite() {
            if(gameMasterSpriteSP.objectReferenceValue == null) return null;
            return (GameMasterSprite)gameMasterSpriteSP.objectReferenceValue;
        }

        private Mesh GetEditorPreviewMesh(GameMasterSprite masterGameSprite, bool xFlipped, bool yFlipped) {
            if(masterGameSprite == null) return null;
            Sprite.Data spriteData = masterGameSprite.data;
            if(spriteData.editorPreviewMeshes == null || spriteData.editorPreviewMeshes.Length == 0) return null;

            if(xFlipped) { // X is flipped
                if(yFlipped) return spriteData.editorPreviewMeshes[3]; // use xy-flipped
                else return spriteData.editorPreviewMeshes[1]; // use x-flipped
            } else { // x is not flipped
                if(yFlipped) return spriteData.editorPreviewMeshes[2]; // use y-flipped
                else return spriteData.editorPreviewMeshes[0]; // use normal
            }
        }
    }

    public class SpriteUpdaterInspector {

        private UnityEditor.Editor proxy;
        private SerializedObject serializedObject;

        private SerializedProperty updateCycle;
        private SerializedProperty dontDestroyThisOnLoad;
        private SerializedProperty startingPoolSize;
        private SerializedProperty poolExpansionIncrement;
        private SerializedProperty maxPoolExpansions;

        private bool advancedOptionsFoldout;

        public SpriteUpdaterInspector(UnityEditor.Editor proxy) {
            this.proxy = proxy;
        }

        public void OnEnable() {
            serializedObject = proxy.serializedObject; // get the serialized object from the proxy

            // set up the serialized properties
            updateCycle = serializedObject.FindProperty("updateCycle");
            dontDestroyThisOnLoad = serializedObject.FindProperty("dontDestroyThisOnLoad");
            startingPoolSize = serializedObject.FindProperty("startingPoolSize");
            poolExpansionIncrement = serializedObject.FindProperty("poolExpansionIncrement");
            maxPoolExpansions = serializedObject.FindProperty("maxPoolExpansions");
        }

        public void OnInspectorGUI() {
            // Update the serializedProperty - always do this in the beginning of OnInspectorGUI
            serializedObject.Update();

            // Show the custom GUI controls
            GUILayout.Space(10.0f);
            EditorGUIUtility.LookLikeControls(200.0f); // set width of label field for controls

            Utils.InspectorTools.DrawPopup(updateCycle, System.Enum.GetNames(typeof(SpriteUpdater.UpdateCycle)), new GUIContent("Update Cycle", "Sprites controlled by this SpriteUpdater will be updated on the chosen update cycle. Choose Manual if you want to update the Sprites yourself by calling SpriteUpdater.UpdateSprites()."));
            Utils.InspectorTools.DrawToggle(dontDestroyThisOnLoad, new GUIContent("Don't Destroy This On Load", "Check this to prevent this SpriteUpdater from being destroyed on level load."));

            advancedOptionsFoldout = EditorGUILayout.Foldout(advancedOptionsFoldout, "Advanced Options");
            if(advancedOptionsFoldout) {
                Utils.InspectorTools.DrawInt(startingPoolSize, 0, 100000, new GUIContent("Starting Pool Size", "The number of Sprites to track before expanding the pool size."));
                Utils.InspectorTools.DrawInt(poolExpansionIncrement, 1, 100000, new GUIContent("Pool Expansion Increment", "The number of entries added to the pool each time it is expanded."));
                Utils.InspectorTools.DrawInt(maxPoolExpansions, 0, 10000, new GUIContent("Max Pool Expansions", "The maximum number of times the pool can be expanded. 0 = Infinite."));
                GUI.enabled = false;
                string maxElementText;
                if(maxPoolExpansions.intValue == 0) maxElementText = "Unlimited";
                else maxElementText = (startingPoolSize.intValue + (poolExpansionIncrement.intValue * maxPoolExpansions.intValue)).ToString();
                EditorGUILayout.TextField(new GUIContent("Max Sprites", "Maximum number of Sprites this SpriteUpdater can update."), maxElementText);
                GUI.enabled = true;
            }


            GUILayout.Space(10.0f);

            // Apply changes to the serializedProperty - always do this in the end of OnInspectorGUI
            serializedObject.ApplyModifiedProperties();

            EditorGUIUtility.LookLikeControls(); // revert

            //DrawDefaultInspector();
        }
    }
}