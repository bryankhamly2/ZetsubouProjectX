﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using SpriteFactory.Editor.Libraries.Poly2Tri;
using SpriteFactory.Editor.DataClasses;

namespace SpriteFactory.Editor {

    internal static class MeshFrameGenerator {

        // Configuration variables -- Set these before calling GenerateMesh
        private static int _extrudeAmount;
        private static SpriteFactory.Enums.TransparencyChannel transparencyChannel;
        private static float _transparencyCutoff;
        private static bool shellFindBleedCorners;
        private static bool outlineDrawEdgeCorners;
        private static double _edgeVertexReductionDistance;
        private static bool trim;

        private static string workingTextureName;

        // Properties -- for configuration variables that need validation
        private static int extrudeAmount {
            get { return _extrudeAmount; }
            set {
                if(value < Settings.minAutoMeshExtrude) value = Settings.minAutoMeshExtrude;
                _extrudeAmount = value;
            }
        }
        private static float transparencyCutoff { get { return _transparencyCutoff; } set { if(value < 0.0f) value = 0.0f; _transparencyCutoff = value; } }
        private static double edgeVertexReductionDistance {
            get { return _edgeVertexReductionDistance; }
            set {
                if(value < Settings.minAutoMeshEdgeVertexReductionDistance) value = Settings.minAutoMeshEdgeVertexReductionDistance;
                _edgeVertexReductionDistance = value;
            }
        }
        
        public static MeshData GenerateMesh(string textureGuid, AutoMeshSettings settings, CacheDataObject cache) {
            if(textureGuid == null || textureGuid == string.Empty) throw new System.ArgumentNullException("texture");
            if(settings == null) throw new System.ArgumentNullException("settings");

            // Populate settings
            extrudeAmount = settings.extrudeAmount;
            transparencyChannel = settings.transparencyChannel;
            transparencyCutoff = settings.transparencyCutoff;
            shellFindBleedCorners = settings.shellFindBleedCorners;
            outlineDrawEdgeCorners = settings.outlineDrawEdgeCorners;
            edgeVertexReductionDistance = settings.edgeVertexReductionDistance;
            trim = settings.trim;

            // Scale the image before making the mesh if necessary
            ColorImage image = cache.GetResolutionTargetImage(textureGuid);
            if(image == null) return null;

            workingTextureName = image.name;

            // Create an opacity map from the texture
            OpacityMap opacityMap = new OpacityMap(image, transparencyChannel, _transparencyCutoff, _extrudeAmount);
            if(opacityMap == null || opacityMap.isInvalid) return null;

            // Extract shells from opacity map
            List<PixelShell> shells = opacityMap.ExtractShells(shellFindBleedCorners);
            if(shells == null) return null; // no shells found

            // Create a mesh from the shells
            Mesh2D mesh2D = new Mesh2D(opacityMap.trimInfo, image.width, image.height, outlineDrawEdgeCorners, _edgeVertexReductionDistance, _extrudeAmount);
            for(int i = 0; i < shells.Count; i++) {
                if(!shells[i].isValid) continue; // skip bad shells
                mesh2D.Add(shells[i]); // add the shell to the mesh
            }
            if(mesh2D.shellCount == 0) return null; // no shells added successfully

            // Create the mesh
            MeshData meshData = mesh2D.CreateMesh(settings.resolutionTarget);
            if(meshData == null) return null;

            return meshData;
        }

        // CLASSES

        private class OpacityMap {

            const int urPixelPad = 1; // a 1px padding to apply to the top and right to account for coord to pixel conversion issues.

            private bool[] map;
            public int width { get; private set; }
            public int height { get; private set; }

            private Utils.TextureTools.TrimInfo _trimInfo;
            public Utils.TextureTools.TrimInfo trimInfo { get { return _trimInfo; } }

            private bool _used;
            public bool used { get { return _used; } }
            private bool _isInvalid;
            public bool isInvalid { get { return _isInvalid; } }

            public OpacityMap(ColorImage image, SpriteFactory.Enums.TransparencyChannel transparencyChannel, float transparencyCutoff, int extrudeAmount) {
                if(image == null) {
                    _isInvalid = true;
                    return;
                }
                if(image == null) throw new System.ArgumentNullException("image");
                if(transparencyCutoff < 0.0f) transparencyCutoff = 0.0f;
                if(extrudeAmount < 0) extrudeAmount = 0;

                map = CreateOpacityMap(image, transparencyChannel, transparencyCutoff, extrudeAmount); // create a map of transparent/filled pixels
            }

            #region Indexers

            public bool this[int col, int row] {
                get {
                    if(col < 0 || row < 0 || col >= width || row >= height) throw new System.IndexOutOfRangeException();
                    return map[row * width + col];
                }
                set {
                    if(col < 0 || row < 0 || col >= width || row >= height) throw new System.IndexOutOfRangeException();
                    map[row * width + col] = value;
                }
            }

            public bool this[int index] {
                get {
                    if(index < 0 || index >= map.Length) throw new System.IndexOutOfRangeException();
                    return map[index];
                }
                set {
                    if(index < 0 || index >= map.Length) throw new System.IndexOutOfRangeException();
                    map[index] = value;
                }

            }

            #endregion

            private bool[] CreateOpacityMap(ColorImage image, SpriteFactory.Enums.TransparencyChannel transparencyChannel, float transparencyCutoff, int extrudeAmount) {

                // ISSUE TO BE AWARE OF:
                // Because pixels are square and because we go LL to UR, verts and UV coords translated from pixel positions
                // will ride the edge of upper right pixels.
                //
                // oo
                // xo <- UV coord is determined by LL corner of the pixel
                //
                // This affects everything by 1 px which is normally not noticeable, but for tiny extrude distances, its very noticeable.
                // 1px extrude will leave a proper 1px pad on the bottom and left sides but on top and right sides it will hug the image
                //
                // SOLUTION: Pad the opacity map by 1px right, up, and up-right so there's an extra pixel in this direction
                
                // Get pixels from the texture
                Color[] pixels = image.colors;

                // Get trim dimensions so we don't waste memory drawing a large bitmap or waste time iterating over empty rows / cols
                _trimInfo = new Utils.TextureTools.TrimInfo(pixels, image.width, image.height, transparencyChannel, transparencyCutoff);

                // Calculate dimensions of the final opacity map
                int width = _trimInfo.width + extrudeAmount * 2 + urPixelPad; // keep these local for speed
                int height = _trimInfo.height + extrudeAmount * 2 + urPixelPad; // the extra urPixelPad is to account for the pixel to coord LL corner issue to pad everything 1px toward UR
                this.width = width; // update property
                this.height = height;

                bool[] opacityMap = new bool[width * height]; // create the new opacity map
                //int blockSize = 1 + (extrudeAmount * 2) + urPixelPad;
                int rowOffset = extrudeAmount - _trimInfo.trimBottom;
                int colOffset = extrudeAmount - _trimInfo.trimLeft;
                int tRows = height;
                int tCols = width;
                int sRows = image.height;
                int sCols = image.width;
                int tRow, tCol;
                int tCurRowStartIndex;
                int sStartRow = _trimInfo.trimBottom;
                int sStartCol = _trimInfo.trimLeft;
                int sCurRowStartIndex;
                int sEndRow = sStartRow + _trimInfo.height;
                int sEndCol = sStartCol + _trimInfo.width;
                int tIndex;
                int sIndex;

                bool found = false;
                int transIndex = SpriteFactory.Utils.EnumTools.GetColorChannelIndex(transparencyChannel);
                bool opaque = transIndex < 0 ? true : false;
                int lastFilledXDistance;
                int[] lastFilledYDistance = extrudeAmount > 0 ? new int[width] : null;

                for(int sRow = sStartRow; sRow < sEndRow; sRow++) {
                    tRow = (sRow + rowOffset);
                    tCurRowStartIndex = tRow * tCols;
                    sCurRowStartIndex = sRow * sCols;
                    lastFilledXDistance = 0;

                    for(int sCol = sStartCol; sCol < sEndCol; sCol++) {
                        tCol = (sCol + colOffset);
                        sIndex = sCurRowStartIndex + sCol;

                        if(opaque || pixels[sIndex][transIndex] > transparencyCutoff) {
                            if(!found) found = true;

                            // Extrude the edges
                            if(extrudeAmount > 0) { // extruding the image out
                                Extrude(opacityMap, width, tRow, tCol, extrudeAmount, lastFilledXDistance, lastFilledYDistance[tCol]); // write pixels out around this pixel to pad it
                                lastFilledXDistance = 1; // mark the distance since the last x write for the next cycle
                                lastFilledYDistance[tCol] = 1; // mark the distance since the last y write for the next cycle
                            } else { // no extrusion
                                tIndex = tCurRowStartIndex + tCol;
                                opacityMap[tIndex] = true; // make pixel in map opaque
                            }
                        } else {
                            // We didn't write anything so increment the distance since the last write
                            // Except on a new row or if nothing has been written to Y yet so it handles the frame edges properly
                            if(lastFilledXDistance > 0) lastFilledXDistance += 1; // increase distance since last fill, only if we wrote at least 1 pixel this row
                            if(lastFilledYDistance != null && lastFilledYDistance[tCol] > 0) lastFilledYDistance[tCol] += 1; // increase distance since last Y fill, only if we wrote at least 1 pixel in this col
                        }
                    }
                }
                if(!found) _isInvalid = true; // no pixels found, map is empty
                
                return opacityMap;
            }

            private void Extrude(bool[] map, int width, int targetRow, int targetCol, int extrudeAmount, int lastFilledXDistance, int lastFilledYDistance) {
                int forwardExtrudeAmount = extrudeAmount + urPixelPad; // add the pixel pad to the forward edge (top or right) to pad it out
                int startY = targetRow + forwardExtrudeAmount; // start at top

                // Optimized
                // Only fills the number of columns on the right edge necessary based on the distance of the last pixel we filled. Does the same for rows.
                // On the test image, we saved writing over 10 million pixels versus the unoptimized method
                int blockSize = extrudeAmount * 2 + 1 + urPixelPad; // a square block with 1 px in center
                int leftMostFillCol = lastFilledXDistance > 0 && lastFilledXDistance < blockSize ? targetCol + forwardExtrudeAmount - lastFilledXDistance + 1 : targetCol - extrudeAmount;
                int bottomFillRow = lastFilledYDistance > 0 && lastFilledYDistance < blockSize ? targetRow + forwardExtrudeAmount - lastFilledYDistance + 1 : targetRow - extrudeAmount;

                // Unoptimized
                //int leftMostFillCol = targetCol - extrudeAmount;
                //int bottomFillRow = targetRow - extrudeAmount;

                // Fill vertically going from right to left
                for(int col = targetCol + forwardExtrudeAmount; col >= leftMostFillCol; col--) { // fill right to left
                    for(int row = startY; row >= bottomFillRow; row--) { // fill top to bottom
                        map[row * width + col] = true;
                    }
                }
            }

            private void SetBlock(bool[] map, int mapWidth, int blockWidth, int blockHeight, int startRow, int startCol, bool value) {
                for(int row = startRow; row < startRow + blockHeight; row++) {
                    int rowStartIndex = row * mapWidth;
                    for(int col = startCol; col < startCol + blockWidth; col++) {
                        int index = rowStartIndex + col;
                        if(map[index] != value) map[index] = value;
                    }
                }
            }

            public List<PixelShell> ExtractShells(bool bleedCorners = false) {
                if(this.map == null || this.map.Length <= 0) throw new System.ArgumentNullException();
                if(_used) {
                    Debug.Log("This shell is already used!");
                    return null;
                }
                _used = true; // we have extracted the data from the map and modified it, cannot use anymore

                List<PixelShell> shells = new List<PixelShell>();

                // Search the map for shells -- source map is modified removing the shells
                bool[] map = this.map; // cache for speed
                int width = this.width; // cache property for speed
                int height = this.height;
                bool found = false;
                for(int row = 0; row < height; row++) {
                    for(int col = 0; col < width; col++) {
                        if(!map[row * width + col]) continue; // pixel is empty
                        shells.Add(ExtractShell(map, width, height, row, col, bleedCorners)); // get the shell
                        if(!found) found = true;
                    }
                }
                if(!found) return null; // no shells found

                return shells;
            }

            private PixelShell ExtractShell(bool[] map, int width, int height, int row, int col, bool bleedCorners) {
                // We expect this pixel at row/col to be filled
                return new PixelShell(map, width, height, row, col, bleedCorners); // create the shell
            }

            public Texture2D GetTexture2D() {
                int count = width * height;
                Color[] pixels = new Color[count];
                for(int i = 0; i < count; i++) {
                    if(map[i]) pixels[i] = Color.black;
                    else pixels[i] = Color.white;
                }

                Texture2D tex = new Texture2D(width, height);
                tex.SetPixels(pixels);
                return tex;
            }

            public byte[] GetPng() {
                Texture2D tex = GetTexture2D();
                tex.hideFlags = HideFlags.DontSave;
                byte[] png = tex.EncodeToPNG();
                UnityEngine.Object.DestroyImmediate(tex);
                return png;
            }
        }

        private class PixelShell {
            //private PositionMap shellMap;
            private bool[] shellMap;
            //private bool[] edgeMap; // debug - use for visualizing the edge map
            private int width;
            private int height;

            private bool _isValid;
            public bool isValid { get { return _isValid; } }

            private bool searchDiagonals;

            /// <summary>
            /// Creates a PixelShell from a bool map image.
            /// WARNING: The contents of disposableMap will be cleared, so use a copy if you wish to retain your original image!
            /// </summary>
            public PixelShell(bool[] disposableMap, int width, int height, int row, int col, bool searchDiagonals) {
                // Looks for a shell connected to the selected pixel in the bool map.
                // If it finds one, it transfers the shell to the shellMap and removes it from the source map.
                if(width <= 0 || height <= 0) throw new System.Exception("width and height must be > 0!");
                if(disposableMap == null || disposableMap.Length == 0) throw new System.ArgumentNullException("map");
                if(disposableMap.Length != width * height) throw new System.Exception("map.Length must equal width * height!");
                if(!disposableMap[row * width + col]) { // no filled pixel at this coordinate
                    _isValid = false;
                    return;
                }

                //shellMap = new PositionMap(width, height);
                shellMap = new bool[width * height];
                this.width = width;
                this.height = height;
                this.searchDiagonals = searchDiagonals;

                // Move all pixels in this shell from the opacity map to the shell map
                if(searchDiagonals) {
                    FloodFill(disposableMap, row, col, searchDiagonals); // use stack version for diagonal filling
                } else {
                    FloodFillFast(disposableMap, row, col); // use faster flood filler if not doing diagonals
                }

                // Fill gaps
                FillSmallGapsAndCorners(shellMap);

                _isValid = true;

            }

            private void FloodFillFast(bool[] sourceMap, int row, int col) {
                QueueLinearFloodFiller qlff = new QueueLinearFloodFiller();
                qlff.FillIfValue = true;
                qlff.FillToValue = true;
                qlff.ClearSource = true;
                //qlff.FillDiagonally = true; // catch tiny floating corner pixels in the shell -- THIS DOES NOT WORK -- no code in the algorithm to do this
                qlff.SetBitmap(sourceMap, shellMap, width, height);
                qlff.FloodFill(col, row);
            }

            // Search by grabbing any adjacent pixels recursively - for every pixel, check up, down, left, right
            private void FloodFill(bool[] sourceMap, int row, int col, bool diagonalFill) {
                if(row < 0 || row >= this.height || col < 0 || col >= this.width) throw new System.IndexOutOfRangeException();

                // cache for speed
                bool[] shellMap = this.shellMap;
                int width = this.width;
                int height = this.height;

                Stack<int> stack = new Stack<int>(); // create a stack
                stack.Push(row * width + col); // add the first pixel to the stack

                // Fill
                while(stack.Count > 0) {

                    // Get next item from queue/stack
                    int index = stack.Pop();

                    // Find row/col from index
                    row = index == 0 ? 0 : index / width;
                    col = index - (row * width);

                    if(sourceMap[index]) { // cell is filled
                        sourceMap[index] = false; // clear the cell in the source
                        shellMap[index] = true; // fill the cell in the shell map
                        //shellMap.Add(col, row);
                        if(!_isValid) _isValid = true; // we found a pixel

                        // Find the left-most connected pixel we can fill
                        int curCol = col;
                        int leftmostCol = col;
                        while(curCol > 0) {
                            curCol -= 1;
                            int curIndex = row * width + curCol;
                            if(sourceMap[curIndex] == false) break; // the left pixel is invalid
                            leftmostCol = curCol; // this is the left-most valid pixel we can reach
                        }

                        // Find the right-most connected pixel we can fill
                        curCol = col;
                        int rightmostCol = col;
                        while(curCol < width - 1) {
                            curCol += 1;
                            int curIndex = row * width + curCol;
                            if(sourceMap[curIndex] == false) break; // the left pixel is invalid
                            rightmostCol = curCol; // this is the left-most valid pixel we can reach
                        }

                        // For each pixel, add the one above and below it to the stack
                        for(curCol = leftmostCol; curCol <= rightmostCol; curCol++) {
                            int curIndex = row * width + curCol;

                            // Do the "fill"
                            sourceMap[curIndex] = false; // clear the cell in the source
                            shellMap[curIndex] = true; // fill the cell in the shell map
                            //shellMap.Add(curCol, row);

                            // Check up and down and add pixels to stack if they're valid
                            if(row < height - 1 && sourceMap[(row + 1) * width + curCol]) // check up
                                stack.Push((row + 1) * width + curCol);
                            if(row > 0 && sourceMap[(row - 1) * width + curCol]) // check down
                                stack.Push((row - 1) * width + curCol);

                            // Handle diagonal filling
                            if(diagonalFill) {
                                if(row < height - 1) {
                                    if(curCol > 0) // up left
                                        stack.Push((row + 1) * width + (curCol - 1));
                                    if(curCol < width - 1) // up right
                                        stack.Push((row + 1) * width + (curCol + 1));

                                }
                                if(row > 0) {
                                    if(curCol > 0) // down left
                                        stack.Push((row - 1) * width + (curCol - 1));
                                    if(curCol < width - 1) // down right
                                        stack.Push((row - 1) * width + (curCol + 1));
                                }
                            }
                        }
                    }
                }
                // On a solid 4096x4096 image, the stack can grow to:
                // 4-way: 16,769,026 elements
                // 8-way: 83,841,031 elements
            }

            private void FillSmallGapsAndCorners(bool[] map) {
                // Fills small gaps in the image to try to prevent crossing lines when its turned into vertices
                // Seals up small holes that may cause a problem.

                int maxDistance = (int)System.Math.Ceiling(_edgeVertexReductionDistance * 2); // fill past Douglas Peucker tolerance distance

                int emptyXCount = -1;
                int[] emptyYCounts = new int[width];
                for(int i = 0; i < width; i++) { // fill blank
                    emptyYCounts[i] = -1;
                }

                for(int row = 0; row < height; row++) {
                    for(int col = 0; col < width; col++) {
                        int index = row * width + col;
                        if(map[index]) { // we hit a filled pixel

                            if(emptyXCount > 0 && emptyXCount <= maxDistance) { // fill the empty pixels we crossed
                                for(int i = col - emptyXCount; i < col; i++) {
                                    map[row * width + i] = true; // fill the pixel
                                }
                            }
                            int emptyYCount = emptyYCounts[col];
                            if(emptyYCount > 0 && emptyYCount <= maxDistance) {
                                for(int i = row - emptyYCount; i < row; i++) {
                                    map[i * width + col] = true; // fill the pixel
                                }
                            }
                            emptyXCount = 0; // reset counts
                            emptyYCounts[col] = 0;

                        } else { // this is an empty pixel

                            // Fill in corners
                            bool fill = false;
                            if(emptyXCount == 0) { // there is a solid pixel to our left
                                if(row < height - 1 && map[index + width]) { // there is a solid pixel up
                                    // ox
                                    // x0
                                    if(!map[index - 1 + width]) { // there is an empty pixel to the upper left
                                        fill = true;
                                    }
                                }
                                /* This case never happens because we are filling from bottom left to upper right
                                if(!fill && row > 0 && map[index - width]) { // there is a solid pixel below
                                    // x0
                                    // ox
                                    if(!map[index - 1 - width]) { // there is an empty pixel to the lower left
                                        fill = true;
                                    }
                                }*/
                            }
                            if(!fill && col < width - 1 && map[index + 1]) { // there is a solid pixel to our right
                                if(row < height - 1 && map[index + width]) { // there is a solid pixel up
                                    // xo
                                    // 0x
                                    if(!map[index + 1 + width]) { // there is an empty pixel to the upper right
                                        fill = true;
                                    }
                                }
                                /* This case never happens because we are filling from bottom left to upper right
                                if(!fill && row > 0 && map[index - width]) { // there is a solid pixel below
                                    // 0x
                                    // xo
                                    if(!map[index + 1 - width]) { // there is an empty pixel to the lower right
                                        fill = true;
                                    }
                                }*/
                            }

                            if(fill) { // we found a corner
                                map[index] = true; // fill the pixel
                                col--; // reduce the col count to force it to evaluate this filled pixel again as a solid and backfill if necessary
                            } else {

                                // Increment empty counts
                                if(emptyXCount >= 0) // we are on an empty pixel and have hit at least 1 filled pixel on this col and we still have more to check
                                    emptyXCount += 1; // start counting
                                if(emptyYCounts[col] >= 0)
                                    emptyYCounts[col] += 1;
                            }
                        }
                    }
                    emptyXCount = -1;
                }
            }

            public List<SpriteFactory.Utils.DataClasses.IntVector2> FindEdgePixels(bool edgeCorners) {
                if(!_isValid) {
                    Debug.LogError("This shell is invalid!");
                    return null;
                }

                // Find shell edges
                MarchingSquare ms = new MarchingSquare(shellMap, width, height, edgeCorners);
                List<SpriteFactory.Utils.DataClasses.IntVector2> edgePixels = ms.FindOuline();

                /* // PositionMap version
                // Create a bool map from shell map
                bool[] shellBoolMap = shellMap.GetBoolMap();

                // Find shell edges
                MarchingSquare ms = new MarchingSquare(shellBoolMap, shellMap.width, shellMap.height, edgeCorners);
                List<SpriteFactory.Utils.DataClasses.IntVector2> edgePixels = ms.DoMarch();

                // copy to edge bool map
                edgeMap = new bool[shellBoolMap.Length];
                for(int i = 0; i < edgePixels.Count; i++) {
                    edgeMap[edgePixels[i].y * shellMap.width + edgePixels[i].x] = true;
                }

                // Offset pixels to match original position in bitmap
                if(shellMap.hasOffset) {
                    int offsetX = shellMap.offsetX;
                    int offsetY = shellMap.offsetY;
                    if(offsetX > 0) {
                        if(offsetY > 0) { // offset X & Y
                            for(int i = 0; i < edgePixels.Count; i++) {
                                edgePixels[i].x += offsetX;
                                edgePixels[i].y += offsetY;
                            }
                        } else { // just offset X
                            for(int i = 0; i < edgePixels.Count; i++) {
                                edgePixels[i].x += offsetX;
                            }
                        }
                    } else { // just offset Y
                        for(int i = 0; i < edgePixels.Count; i++) {
                            edgePixels[i].y += offsetY;
                        }
                    }
                }
                */

                return edgePixels;
            }
            
            public ColorImage GetShellImage() {
                /* // POSITION MAP VERSION
                bool[] boolMap = shellMap.GetBoolMap();
                Color[] pixels = new Color[boolMap.Length];

                for(int i = 0; i < boolMap.Length; i++) {
                    if(boolMap[i]) pixels[i] = Color.black;
                }
                return new ColorImage(pixels, shellMap.width, shellMap.height);
                */

                Color[] pixels = new Color[width * height];

                for(int i = 0; i < shellMap.Length; i++) {
                    if(shellMap[i]) pixels[i] = Color.black;
                }

                return new ColorImage(pixels, width, height, TextureFormat.Alpha8);
            }
            /*

            public ColorImage GetEdgeImage() {
                Color[] pixels = new Color[width * height];

                for(int i = 0; i < edgeMap.Length; i++) {
                    if(edgeMap[i]) pixels[i] = Color.black;
                }

                return new ColorImage(pixels, width, height);
            }*/
        }

        private class PositionMap {

            private List<SpriteFactory.Utils.DataClasses.IntVector2> pixels;

            private int origWidth;
            private int origHeight;
            private int minX;
            private int minY;
            private int maxX;
            private int maxY;
            bool hasPixels;

            public int width { get { if(!hasPixels) return 0; return maxX + 1 - minX; } }
            public int height { get { if(!hasPixels) return 0; return maxY + 1 - minY; } }
            public int offsetX { get { if(!hasPixels) return 0; return minX; } }
            public int offsetY { get { if(!hasPixels) return 0; return minY; } }
            public bool hasOffset { get { if(!hasPixels) return false; if(minX > 0 || minY > 0) return true; return false; } }

            public PositionMap(int origWidth, int origHeight) {
                if(origWidth <= 0 || origHeight <= 0) throw new System.ArgumentOutOfRangeException();

                this.origWidth = origWidth;
                this.origHeight = origHeight;
                pixels = new List<SpriteFactory.Utils.DataClasses.IntVector2>();
                hasPixels = false;
            }

            public void Add(int sourceX, int sourceY) {
                if(sourceX < 0 || sourceX >= origWidth || sourceY < 0 || sourceY >= origHeight) throw new System.ArgumentOutOfRangeException();

                if(!hasPixels) {
                    minX = sourceX;
                    maxX = sourceX;
                    minY = sourceY;
                    maxY = sourceY;
                    hasPixels = true;
                } else {
                    if(sourceX < minX) minX = sourceX;
                    if(sourceX > maxX) maxX = sourceX;
                    if(sourceY < minY) minY = sourceY;
                    if(sourceY > maxY) maxY = sourceY;
                }
                pixels.Add(new SpriteFactory.Utils.DataClasses.IntVector2(sourceX, sourceY));
            }

            public bool[] GetBoolMap() {
                if(!hasPixels) return null;

                int width = this.width;
                bool[] map = new bool[width * height];

                for(int i = 0; i < pixels.Count; i++) {
                    map[(pixels[i].y - offsetY) * width + (pixels[i].x - offsetX)] = true;
                }
                return map;
            }

        }

        private class MarchingSquare {

            // Credit: Original MarchingSquare class by Phillip Spiess
            // Source: http://devblog.phillipspiess.com/2010/02/23/better-know-an-algorithm-1-marching-squares

            // THIS VERSION HAS BEEN HEAVILY MODIFIED FROM THE ORIGNAL by Augie Maddox
            // - Changed to use a boolean map instead of colors and thresholds
            // - Significant rewrite to fix problem where outline was drawn 1px right and down from the correct position causing failure to draw borders at bottom and right edges of image.
            // - Flipped Y direction to match Unity's Texture2D 0,0 = lower left of image scheme.
            // - Added hanging corner detection
            // - Made some optimizations

            private enum Direction { None, Up, Down, Left, Right }

            private bool[] map;
            private int width;
            private int height;
            private int writeCount;
            private int[] writeOffsetX;
            private int[] writeOffsetY;
            private const int writeBufferLength = 2; // we will only ever write up to 2 pixels at once
            private bool drawCornersAndHangingPixels;
            private Direction previousDir;
            private Direction currentDir;

            public MarchingSquare(bool[] map, int width, int height, bool drawCornersAndHangingPixels) {
                this.map = map;
                this.width = width;
                this.height = height;
                writeOffsetX = new int[writeBufferLength];
                writeOffsetY = new int[writeBufferLength];
                this.drawCornersAndHangingPixels = drawCornersAndHangingPixels;
            }

            public List<SpriteFactory.Utils.DataClasses.IntVector2> FindOuline() {
                // Find the first pixel to start the edge
                int startX;
                int startY;
                bool foundPixel = FindEdgePixel(out startX, out startY);
                if(!foundPixel) return null; // map is empty

                // Cache for speed
                int[] writeOffsetX = this.writeOffsetX;
                int[] writeOffsetY = this.writeOffsetY;

                List<SpriteFactory.Utils.DataClasses.IntVector2> foundPixels = new List<SpriteFactory.Utils.DataClasses.IntVector2>();
                int x = startX;
                int y = startY;
                int writeX;
                int writeY;

                // Loop until we get back to our starting pixel
                do {
                    Step(x, y);

                    // Write the pixel(s) from our write buffer
                    int bufferStartIndex;
                    if(!drawCornersAndHangingPixels && writeCount == 2) bufferStartIndex = 1; // skip the first pixel in the writing head
                    else bufferStartIndex = 0;

                    // Write pixels
                    for(int i = bufferStartIndex; i < writeCount; i++) {
                        writeX = x + writeOffsetX[i];
                        writeY = y + writeOffsetY[i];
                        // On a 1 pixel thick line, it will write pixels going both ways around it in the same locations
                        // it might be beneficial to filter out writing duplicate pixels if we're using them for verts, but we
                        // can skip this here because we will be using a extrude distance anway before we get here and never have 1px thick lines
                        // If using this algorithm for other stuff, consider adding this filter so it doesn't write the same pixels twice
                        foundPixels.Add(new SpriteFactory.Utils.DataClasses.IntVector2(writeX, writeY));
                    }

                    // Move the head
                    if(currentDir == Direction.Up) y++;
                    else if(currentDir == Direction.Left) x--;
                    else if(currentDir == Direction.Down) y--;
                    else if(currentDir == Direction.Right) x++;

                } while(x != startX || y != startY);

                return foundPixels;
            }

            private bool FindEdgePixel(out int x, out int y) {
                bool[] map = this.map; // cache for speed

                for(int row = 0; row < height; row++) {
                    int rowStartIndex = row * width;
                    for(int col = 0; col < width; col++) {
                        if(map[rowStartIndex + col]) { // pixel is filled
                            x = col;
                            y = row;
                            return true;
                        }
                    }
                }
                x = 0;
                y = 0;
                return false;
            }

            private void Step(int x, int y) {
                previousDir = currentDir; // save the previous step
                byte shapeId = 0x00; // the arrangement of pixels in the 4 area block

                // Assign value based on all current matching states
                if(IsOpaque(x - 1, y + 1)) shapeId += 0x01;
                if(IsOpaque(x, y + 1)) shapeId += 0x02;
                if(IsOpaque(x - 1, y)) shapeId += 0x04;
                if(IsOpaque(x, y)) shapeId += 0x08;

                // Determine step direction based on state and record the positions of the pixels we will write
                switch(shapeId) {
                    case 0x01: // 1
                        // xo
                        // oo
                        currentDir = Direction.Up;
                        // write nothing
                        writeCount = 0;
                        break;
                    case 0x02: // 2
                        // ox
                        // oo
                        currentDir = Direction.Right;
                        // write nothing
                        writeCount = 0;
                        break;
                    case 0x03: // 3
                        // xx
                        // oo
                        currentDir = Direction.Right;

                        // write UR pixel
                        writeOffsetX[0] = 0;
                        writeOffsetY[0] = 1;
                        writeCount = 1;
                        break;
                    case 0x04: // 4
                        // oo
                        // xo
                        currentDir = Direction.Left;
                        // write nothing
                        writeCount = 0;
                        break;
                    case 0x05: // 5
                        // xo
                        // xo
                        currentDir = Direction.Up;
                        // write UL pixel
                        writeOffsetX[0] = -1;
                        writeOffsetY[0] = 1;
                        writeCount = 1;
                        break;
                    case 0x06: // 6
                        // ox
                        // xo
                        writeCount = 1;
                        bool hanging = IsCornerHanging(shapeId, x, y); // determine if this is a hanging corner

                        if(previousDir == Direction.Up) {
                            currentDir = Direction.Left;
                            // write LL pixel
                            writeOffsetX[0] = -1;
                            writeOffsetY[0] = 0;
                            if(hanging) { // write the hanging pixel
                                writeOffsetX[1] = 0;
                                writeOffsetY[1] = 1;
                                writeCount += 1;
                            }
                        } else {
                            currentDir = Direction.Right;
                            // write UR pixel
                            writeOffsetX[0] = 0;
                            writeOffsetY[0] = 1;
                            if(hanging) { // write the hanging pixel
                                writeOffsetX[1] = -1;
                                writeOffsetY[1] = 0;
                                writeCount += 1;
                            }
                        }
                        break;
                    case 0x07: // 7
                        // xx
                        // xo
                        currentDir = Direction.Right;
                        // write UL pixel
                        writeOffsetX[0] = -1;
                        writeOffsetY[0] = 1;
                        // write UR pixel
                        writeOffsetX[1] = 0;
                        writeOffsetY[1] = 1;
                        writeCount = 2;
                        break;
                    case 0x08: // 8
                        // oo
                        // ox
                        currentDir = Direction.Down;
                        // write nothing
                        writeCount = 0;
                        break;
                    case 0x09: // 9
                        // xo
                        // ox
                        writeCount = 1;
                        hanging = IsCornerHanging(shapeId, x, y); // determine if this is a hanging corner

                        if(previousDir == Direction.Right) {
                            currentDir = Direction.Up;
                            // write UL pixel
                            writeOffsetX[0] = -1;
                            writeOffsetY[0] = 1;
                            if(hanging) { // write the hanging pixel
                                writeOffsetX[1] = 0;
                                writeOffsetY[1] = 0;
                                writeCount += 1;
                            }
                        } else {
                            currentDir = Direction.Down;
                            // write LR pixel
                            writeOffsetX[0] = 0;
                            writeOffsetY[0] = 0;
                            if(hanging) { // write the hanging pixel
                                writeOffsetX[1] = -1;
                                writeOffsetY[1] = 1;
                                writeCount += 1;
                            }
                        }
                        break;
                    case 0x0A: // 10
                        // ox
                        // ox
                        currentDir = Direction.Down;
                        // write LR pixel
                        writeOffsetX[0] = 0;
                        writeOffsetY[0] = 0;
                        writeCount = 1;
                        break;
                    case 0x0B: // 11
                        // xx
                        // ox
                        currentDir = Direction.Down;
                        // write UR pixel
                        writeOffsetX[0] = 0;
                        writeOffsetY[0] = 1;
                        // write LR pixel
                        writeOffsetX[1] = 0;
                        writeOffsetY[1] = 0;
                        writeCount = 2;
                        break;
                    case 0x0C: // 12
                        // oo
                        // xx
                        currentDir = Direction.Left;
                        // write LL pixel
                        writeOffsetX[0] = -1;
                        writeOffsetY[0] = 0;
                        writeCount = 1;
                        break;
                    case 0x0D: // 13
                        // xo
                        // xx
                        currentDir = Direction.Up;
                        // write LL pixel
                        writeOffsetX[0] = -1;
                        writeOffsetY[0] = 0;
                        // write UL pixel
                        writeOffsetX[1] = -1;
                        writeOffsetY[1] = 1;
                        writeCount = 2;
                        break;
                    case 0x0E: // 14
                        // ox
                        // xx
                        currentDir = Direction.Left;
                        // write LR pixel
                        writeOffsetX[0] = 0;
                        writeOffsetY[0] = 0;
                        // write LL pixel
                        writeOffsetX[1] = -1;
                        writeOffsetY[1] = 0;
                        writeCount = 2;
                        break;
                    default:
                        // oo  xx
                        // oo  xx
                        currentDir = Direction.None;
                        // write nothing
                        writeCount = 0;
                        break;
                }
            }

            private bool IsOpaque(int x, int y) {
                if(x < 0 || x >= width || y < 0 || y >= height) return false; // out of image area, always transparent
                return map[y * width + x];
            }

            private bool IsCornerHanging(int caseId, int x, int y) {
                if(caseId == 6) {
                    // ox
                    // xo

                    // Check borders of each filled pixel to see if we're hanging on one side
                    if(!IsOpaque(x - 2, y) && !IsOpaque(x - 1, y - 1)) {
                        return true;
                    }
                    if(!IsOpaque(x, y + 2) && !IsOpaque(x + 1, y + 1)) {
                        return true;
                    }

                } else if(caseId == 9) {
                    // xo
                    // ox

                    // Check borders of each filled pixel to see if we're hanging on one side
                    if(!IsOpaque(x, y - 1) && !IsOpaque(x + 1, y)) {
                        return true;
                    }
                    if(!IsOpaque(x - 2, y + 1) && !IsOpaque(x - 1, y + 2)) {
                        return true;
                    }
                } else
                    Debug.LogError("Unknown caseId! " + caseId);
                return false;
            }
        }

        private class DouglasPeuckerInt {

            public static SpriteFactory.Utils.DataClasses.IntVector2[] DouglasPeuckerReduction(List<SpriteFactory.Utils.DataClasses.IntVector2> points, double epsilon) {
                if(points == null || points.Count < 3) {
                    return points.ToArray();
                }

                int firstPoint = 0;
                int lastPoint = points.Count - 1;
                List<int> pointIndicesToKeep = new List<int>();

                //Add the first and last index to the keepers
                pointIndicesToKeep.Add(firstPoint);
                pointIndicesToKeep.Add(lastPoint);

                // The first and the last point cannot be the same
                while(points[firstPoint].Equals(points[lastPoint])) {
                    lastPoint--;
                }

                Reduce(points, firstPoint, lastPoint, epsilon, ref pointIndicesToKeep);

                pointIndicesToKeep.Sort(); // sort the points by index
                if(pointIndicesToKeep.Count > 0) pointIndicesToKeep.RemoveAt(pointIndicesToKeep.Count - 1); // remove the last point as its right next to the first point

                SpriteFactory.Utils.DataClasses.IntVector2[] returnPoints = new SpriteFactory.Utils.DataClasses.IntVector2[pointIndicesToKeep.Count];
                for(int i = 0; i < pointIndicesToKeep.Count; i++) {
                    returnPoints[i] = points[pointIndicesToKeep[i]];
                }
                return returnPoints;
            }

            private static void Reduce(List<SpriteFactory.Utils.DataClasses.IntVector2> points, int firstPoint, int lastPoint, double tolerance, ref List<int> pointIndicesToKeep) {
                double maxDistance = 0;
                int indexFarthest = 0;

                for(int index = firstPoint; index < lastPoint; index++) {
                    double distance = PerpendicularDistance(points[firstPoint], points[lastPoint], points[index]);
                    if(distance > maxDistance) {
                        maxDistance = distance;
                        indexFarthest = index;
                    }
                }

                if(maxDistance > tolerance && indexFarthest != 0) {
                    //Add the largest point that exceeds the tolerance
                    pointIndicesToKeep.Add(indexFarthest);

                    Reduce(points, firstPoint, indexFarthest, tolerance, ref pointIndicesToKeep);
                    Reduce(points, indexFarthest, lastPoint, tolerance, ref pointIndicesToKeep);
                }
            }

            public static double PerpendicularDistance(SpriteFactory.Utils.DataClasses.IntVector2 point1, SpriteFactory.Utils.DataClasses.IntVector2 point2, SpriteFactory.Utils.DataClasses.IntVector2 point) {
                //Area = |(1/2)(x1y2 + x2y3 + x3y1 - x2y1 - x3y2 - x1y3)|   *Area of triangle
                //Base = v((x1-x2)²+(x1-x2)²)                               *Base of Triangle*
                //Area = .5*Base*H                                          *Solve for height
                //Height = Area/.5/Base

                double area = System.Math.Abs(0.5d * (point1.x * point2.y + point2.x * point.y + point.x * point1.y - point2.x * point1.y - point.x * point2.y - point1.x * point.y));
                double bottom = System.Math.Sqrt(System.Math.Pow(point1.x - point2.x, 2) + System.Math.Pow(point1.y - point2.y, 2));
                double height = area / bottom * 2;

                return height;

                //Another option
                //Double A = Point.X - Point1.X;
                //Double B = Point.Y - Point1.Y;
                //Double C = Point2.X - Point1.X;
                //Double D = Point2.Y - Point1.Y;

                //Double dot = A * C + B * D;
                //Double len_sq = C * C + D * D;
                //Double param = dot / len_sq;

                //Double xx, yy;

                //if (param < 0)
                //{
                //    xx = Point1.X;
                //    yy = Point1.Y;
                //}
                //else if (param > 1)
                //{
                //    xx = Point2.X;
                //    yy = Point2.Y;
                //}
                //else
                //{
                //    xx = Point1.X + param * C;
                //    yy = Point1.Y + param * D;
                //}

                //Double d = DistanceBetweenOn2DPlane(Point, new Point(xx, yy));
            }
        }

        private class Mesh2D {

            private List<PolyShell> polyShells;
            private Utils.TextureTools.TrimInfo trimInfo;
            private bool edgeCorners;
            private double vertexReductionDistance;
            private int textureWidth;
            private int textureHeight;
            private int extrudeAmount;

            public int shellCount { get { return polyShells.Count; } }

            public Mesh2D(Utils.TextureTools.TrimInfo trimInfo, int textureWidth, int textureHeight, bool edgeCorners, double vertexReductionDistance, int extrudeAmount) {
                if(trimInfo == null) throw new System.ArgumentNullException("trimInfo");
                if(textureWidth < 0 || textureHeight < 0) throw new System.IndexOutOfRangeException("Image dimensions must be > 0!");

                this.textureWidth = textureWidth;
                this.textureHeight = textureHeight;
                this.trimInfo = trimInfo;
                this.edgeCorners = edgeCorners;
                if(vertexReductionDistance < 0.0f) vertexReductionDistance = 0.0f;
                this.vertexReductionDistance = vertexReductionDistance;
                if(extrudeAmount < 0) extrudeAmount = 0;
                this.extrudeAmount = extrudeAmount;
                polyShells = new List<PolyShell>();
            }

            public void Add(PixelShell pixelShell) {
                if(pixelShell == null || !pixelShell.isValid) {
                    Debug.Log("Bad shell data! Cannot add to mesh!");
                    return;
                }

                // Find the edge pixels of the shell
                List<SpriteFactory.Utils.DataClasses.IntVector2> edgePixels = pixelShell.FindEdgePixels(edgeCorners);
                if(edgePixels == null || edgePixels.Count < 3) return; // failed, do not add shell

                // Get vertices from edge outline
                SpriteFactory.Utils.DataClasses.IntVector2[] orderedVerts = FindVertices(edgePixels);
                if(orderedVerts == null || orderedVerts.Length <= 3) return; // failed, do not add shell

                // Triangulate the polygon
                PolyShell polyShell = new PolyShell(); // create a new poly shell for the pixel shell
                TriangulatePolygon(orderedVerts, polyShell); // triangulate the polygon

                polyShells.Add(polyShell); // add the poly shell to the list
            }

            private SpriteFactory.Utils.DataClasses.IntVector2[] FindVertices(List<SpriteFactory.Utils.DataClasses.IntVector2> edgePixels) {

                // Reduce edge points
                SpriteFactory.Utils.DataClasses.IntVector2[] points = DouglasPeuckerInt.DouglasPeuckerReduction(edgePixels, vertexReductionDistance); // reduce

                // copy to edge bool map
                //for(int i = 0; i < points.Length; i++) {
                //    edgeMap[(int)points[i].y * width + (int)points[i].x] = true;
                //}

                return points;
            }

            private void TriangulatePolygon(SpriteFactory.Utils.DataClasses.IntVector2[] orderedVerts, PolyShell polyShell) {

                // Poly2Tri
                // http://code.google.com/p/poly2tri/

                try {
                    int pointCount = orderedVerts.Length;

                    // Convert unity point array to Poly2Tri point array
                    PolygonPoint[] polyPoints = new PolygonPoint[pointCount];
                    for(int i = 0; i < pointCount; i++) {
                        polyPoints[i] = new PolygonPoint(orderedVerts[i].x, orderedVerts[i].y);
                    }

                    // Create the polygon from the ordered points
                    Polygon polygon = new Polygon(polyPoints);

                    // Triangulate the polygon
                    P2T.Triangulate(polygon);

                    IList<TriangulationPoint> pPoints = polygon.Points; // get the points from the triangulated polygon
                    pointCount = pPoints.Count; // update the count in case it changed, though it shouldn't ever change
                    IList<DelaunayTriangle> dTris = polygon.Triangles;
                    int dTriCount = dTris.Count;

                    // Find triangle indices for Unity's mesh format
                    int[] unityTriangles = new int[dTriCount * 3]; // 3 vertex indices for each triangle
                    for(int i = 0; i < dTriCount; i++) {
                        FixedArray3<TriangulationPoint> t = dTris[i].Points; // get the points of the triangle
                        // Find the index of each vert by comparing objects
                        int index = i * 3;
                        unityTriangles[index] = pPoints.IndexOf(t._2); // reverse the triangle winding order so normal faces the right way
                        unityTriangles[index + 1] = pPoints.IndexOf(t._1);
                        unityTriangles[index + 2] = pPoints.IndexOf(t._0);
                    }

                    // Convert PolygonPoints to Unity Vector3 vertices
                    Vector3[] unityVerts = new Vector3[pointCount];
                    for(int i = 0; i < pointCount; i++) {
                        unityVerts[i].x = (float)pPoints[i].X;
                        unityVerts[i].y = (float)pPoints[i].Y;
                    }

                    // Store data
                    polyShell.vertices = unityVerts;
                    polyShell.triangles = unityTriangles;

                } catch {

                    Debug.LogError("Bad geometry encountered while creating the polygon mesh for source image \"" + workingTextureName + "\"! Please report this error " +
                    " to support@guavaman.com with the source image file attached.");

                    // Use a simple triangle just so it doesn't crash
                    polyShell.vertices = new Vector3[3] {
                        new Vector3(0.0f, 0.0f, 0.0f),
                        new Vector3(1.0f, 1.0f, 0.0f),
                        new Vector3(1.0f, -1.0f, 0.0f)
                    };

                    polyShell.triangles = new int[3] {
                        0, 1, 2
                    };
                }
            }

            public MeshData CreateMesh(SpriteFactory.Enums.ResolutionTarget resolutionTarget) {
                if(polyShells == null || polyShells.Count == 0) {
                    Debug.Log("Invalid mesh data! Cannot create Mesh!");
                    return null;
                }

                bool[] badShells = new bool[polyShells.Count];
                int totalVertCount = 0;
                int totalTriangleIndexCount = 0;
                for(int i = 0; i < polyShells.Count; i++) {
                    // validate data
                    if(polyShells[i] == null || !polyShells[i].isValid) {
                        Debug.LogWarning("Invalid mesh data in poly shell! Skipping.");
                        badShells[i] = true; // mark shell bad
                        continue;
                    }
                    totalVertCount += polyShells[i].vertices.Length; // count up total verts
                    totalTriangleIndexCount += polyShells[i].triangles.Length; // count up total triangle indices
                }

                if(totalVertCount == 0) return null; // no vertices
                if(totalTriangleIndexCount == 0) return null; // no triangles

                // Combine shells into a mesh 
                Vector2[] vertices = new Vector2[totalVertCount];
                Vector2[] uvs = new Vector2[totalVertCount];
                int[] triangles = new int[totalTriangleIndexCount];
                float resolutionMultiplier = SpriteFactory.Utils.MiscTools.ResolutionTargetInverseScale(resolutionTarget); // scale vertices up so resolution target doesn't affect mesh size

                int cumulativeVertCount = 0;
                int cumulativeTriIndexCount = 0;

                for(int i = 0; i < polyShells.Count; i++) {
                    if(badShells[i]) continue; // skip bad shells

                    // Vertices and UVs
                    Vector3[] shellVerts = polyShells[i].vertices;
                    for(int j = 0; j < shellVerts.Length; j++) {
                        int targetVertIndex = cumulativeVertCount + j;
                        vertices[targetVertIndex].x = shellVerts[j].x * resolutionMultiplier; // copy the vert and scale if necessary
                        vertices[targetVertIndex].y = shellVerts[j].y * resolutionMultiplier;
                        // Bake extrude offset into uvs - this will be counteracted by final atlas frame padding
                        uvs[targetVertIndex].x = shellVerts[j].x - extrudeAmount; // copy the UV unscaled
                        uvs[targetVertIndex].y = shellVerts[j].y - extrudeAmount;
                    }

                    // Triangles
                    int[] shellTris = polyShells[i].triangles;
                    for(int j = 0; j < shellTris.Length; j++) {
                        triangles[cumulativeTriIndexCount + j] = shellTris[j] + cumulativeVertCount; // copy the triangle
                    }

                    // Increment cumulative counts
                    cumulativeVertCount += shellVerts.Length; // count of all the verts in shells up to this point
                    cumulativeTriIndexCount += shellTris.Length;
                }

                int trimLeft = trimInfo.trimLeft;
                int trimBottom = trimInfo.trimBottom;

                // Untrim the UVs if not trimming sprite images
                if(!trim) {
                    if(trimLeft > 0 || trimBottom > 0) {
                        for(int i = 0; i < totalVertCount; i++) {
                            uvs[i].x += trimLeft;
                            uvs[i].y += trimBottom;
                        }
                    }
                }

                // Calculate vert offsets so mesh is centered
                float centerOffsetX = (trimLeft - extrudeAmount - (textureWidth * 0.5f)) * resolutionMultiplier;
                float centerOffsetY = (trimBottom - extrudeAmount - (textureHeight * 0.5f)) * resolutionMultiplier;

                return new MeshData(vertices, triangles, uvs, centerOffsetX, centerOffsetY, transparencyChannel);
            }

            public Mesh CreateUnityMesh(SpriteFactory.Enums.ResolutionTarget resolutionTarget) {
                MeshData meshData = CreateMesh(resolutionTarget);
                if(meshData == null) return null;

                // Create unity mesh
                return meshData.CreateUnityMesh();
            }

            // Classes

            private class PolyShell {
                public Vector3[] vertices;
                public int[] triangles;

                public bool isValid {
                    get {
                        if(vertices == null || vertices.Length < 3) return false;
                        if(triangles == null || triangles.Length % 3 != 0) return false;
                        return true;
                    }

                }
            }
        }

        public class MeshData {

            public Vector2[] vertices;
            public int[] triangles;
            public Vector2[] uvs;

            public float pixelCenterOffsetX;
            public float pixelCenterOffsetY;

            public Enums.TransparencyChannel transparencyChannel;

            public MeshData(Vector2[] vertices, int[] triangles, Vector2[] uvs, float centerOffsetX, float centerOffsetY, Enums.TransparencyChannel transparencyChannel) {
                this.vertices = vertices;
                this.triangles = triangles;
                this.uvs = uvs;
                this.pixelCenterOffsetX = centerOffsetX;
                this.pixelCenterOffsetY = centerOffsetY;
                this.transparencyChannel = transparencyChannel;
            }

            public Mesh CreateUnityMesh() {
                Mesh mesh = new Mesh();
                Vector3[] vertices;
                if(this.vertices != null) {
                    vertices = new Vector3[this.vertices.Length];
                    for(int i = 0; i < vertices.Length; i++) {
                        vertices[i].x = this.vertices[i].x;
                        vertices[i].y = this.vertices[i].y;
                    }
                } else vertices = null;
                mesh.vertices = vertices;
                mesh.uv = uvs;
                mesh.triangles = triangles;
                mesh.RecalculateBounds();
                mesh.RecalculateNormals();
                return mesh;
            }
        }

        #region QueueLinearFloodFiller Class

        /// <summary>
        /// The base class that the flood fill algorithms inherit from. Implements the
        /// basic flood filler functionality that is the same across all algorithms.
        /// </summary>
        private abstract class AbstractFloodFiller {

            protected bool[] sourceBitmap;
            //protected TestMenu.MeshFrameGenerator.PositionMap targetMap;
            protected bool[] targetMap;
            protected bool fillToValue = true;
            protected bool fillIfValue = false;
            protected bool fillDiagonally = false;
            protected bool clearSource = false;

            //cached bitmap properties
            protected int bitmapWidth = 0;
            protected int bitmapHeight = 0;

            //internal, initialized per fill
            protected bool[] pixelsChecked;

            public AbstractFloodFiller() { }

            public bool FillDiagonally {
                get { return fillDiagonally; }
                set { fillDiagonally = value; }
            }

            public bool[] Bitmap {
                get { return sourceBitmap; }
            }

            public bool FillIfValue {
                get { return fillIfValue; }
                set { fillIfValue = value; }
            }

            public bool FillToValue {
                get { return fillToValue; }
                set { fillToValue = value; }
            }

            public bool ClearSource {
                get { return clearSource; }
                set { clearSource = value; }
            }

            public abstract void FloodFill(int x, int y);

            protected void PrepareForFloodFill() {
                pixelsChecked = new bool[sourceBitmap.Length];
            }

            //public void SetBitmap(bool[] sourceBitmap, TestMenu.MeshFrameGenerator.PositionMap targetMap, int width, int height) {
            public void SetBitmap(bool[] sourceBitmap, bool[] targetMap, int width, int height) {
                if(sourceBitmap == null || sourceBitmap.Length == 0) throw new System.ArgumentNullException("sourceBitmap");
                if(targetMap == null) throw new System.ArgumentNullException("targetBitmap");
                if(width <= 0 || height <= 0) throw new System.Exception("width and height must be >= 1");
                if(sourceBitmap.Length != width * height) throw new System.Exception("sourceBitmap.Length must equal width * height");
                if(sourceBitmap.Length != targetMap.Length) throw new System.Exception("sourceBitmap.Length must equal targetMap.Length");

                this.sourceBitmap = sourceBitmap;
                this.targetMap = targetMap;
                bitmapWidth = width;
                bitmapHeight = height;
            }

        }

        /// <summary>A queue of FloodFillRanges.</summary>
        private class FloodFillRangeQueue {
            FloodFillRange[] array;
            int size;
            int head;

            /// <summary>
            /// Returns the number of items currently in the queue.
            /// </summary>
            public int Count {
                get { return size; }
            }

            public FloodFillRangeQueue()
                : this(10000) {

            }

            public FloodFillRangeQueue(int initialSize) {
                array = new FloodFillRange[initialSize];
                head = 0;
                size = 0;
            }

            /// <summary>Gets the <see cref="FloodFillRange"/> at the beginning of the queue.</summary>
            public FloodFillRange First {
                get { return array[head]; }
            }

            /// <summary>Adds a <see cref="FloodFillRange"/> to the end of the queue.</summary>
            public void Enqueue(ref FloodFillRange r) {
                if(size + head == array.Length) {
                    FloodFillRange[] newArray = new FloodFillRange[2 * array.Length];
                    System.Array.Copy(array, head, newArray, 0, size);
                    array = newArray;
                    head = 0;
                }
                array[head + (size++)] = r;
            }

            /// <summary>Removes and returns the <see cref="FloodFillRange"/> at the beginning of the queue.</summary>
            public FloodFillRange Dequeue() {
                FloodFillRange range = new FloodFillRange();
                if(size > 0) {
                    range = array[head];
                    array[head] = new FloodFillRange();
                    head++;//advance head position
                    size--;//update size to exclude dequeued item
                }
                return range;
            }
        }

        /// <summary>
        /// Implements the QueueLinear flood fill algorithm using array-based pixel manipulation.
        /// </summary>
        private class QueueLinearFloodFiller : AbstractFloodFiller {

            //Queue of floodfill ranges. We use our own class to increase performance.
            //To use .NET Queue class, change this to:
            //<FloodFillRange> ranges = new Queue<FloodFillRange>();
            FloodFillRangeQueue ranges = new FloodFillRangeQueue();

            public QueueLinearFloodFiller() { }

            /// <summary>
            /// Fills the specified point on the bitmap with the currently selected fill color.
            /// </summary>
            /// <param name="x">The X starting point for the fill.</param>
            /// <param name="y">The Y starting point for the fill.</param>
            public override void FloodFill(int x, int y) {
                if(x < 0 || x >= bitmapWidth || y < 0 || y >= bitmapHeight) throw new System.IndexOutOfRangeException();

                //***Prepare for fill.
                PrepareForFloodFill();

                ranges = new FloodFillRangeQueue(((bitmapWidth + bitmapHeight) / 2) * 5);

                int idx = (bitmapWidth * y) + x; // get the index of the pixel

                bool[] pixelsChecked = this.pixelsChecked;

                //***Do first call to floodfill.
                LinearFill(ref x, ref y);

                //***Call floodfill routine while floodfill ranges still exist on the queue
                while(ranges.Count > 0) {
                    //**Get Next Range Off the Queue
                    FloodFillRange range = ranges.Dequeue();

                    //**Check Above and Below Each Pixel in the Floodfill Range
                    int downIdx = (bitmapWidth * (range.Y + 1)) + range.StartX;
                    int upIdx = (bitmapWidth * (range.Y - 1)) + range.StartX;
                    int upY = range.Y - 1;
                    int downY = range.Y + 1;
                    int tempIdx;
                    for(int i = range.StartX; i <= range.EndX; i++) {
                        //*Start Fill Upwards
                        //if we're not above the top of the bitmap and the pixel above this one is within the color tolerance
                        tempIdx = (bitmapWidth * upY) + i;
                        if(range.Y > 0 && (!pixelsChecked[upIdx]) && CheckPixel(ref tempIdx))
                            LinearFill(ref i, ref upY);

                        //*Start Fill Downwards
                        //if we're not below the bottom of the bitmap and the pixel below this one is within the color tolerance
                        tempIdx = (bitmapWidth * downY) + i;
                        if(range.Y < (bitmapHeight - 1) && (!pixelsChecked[downIdx]) && CheckPixel(ref tempIdx))
                            LinearFill(ref i, ref downY);
                        downIdx++;
                        upIdx++;
                    }

                }
            }

            /// <summary>
            /// Finds the furthermost left and right boundaries of the fill area
            /// on a given y coordinate, starting from a given x coordinate, filling as it goes.
            /// Adds the resulting horizontal range to the queue of floodfill ranges,
            /// to be processed in the main loop.
            /// </summary>
            /// <param name="x">The x coordinate to start from.</param>
            /// <param name="y">The y coordinate to check at.</param>
            void LinearFill(ref int x, ref int y) {

                //cache some bitmap and fill info in local variables for a little extra speed
                bool[] sourceBitmap = this.sourceBitmap;
                //TestMenu.MeshFrameGenerator.PositionMap targetBitmap = this.targetMap;
                bool[] targetBitmap = this.targetMap;
                bool[] pixelsChecked = this.pixelsChecked;
                int bitmapWidth = this.bitmapWidth;

                //***Find Left Edge of Color Area
                int lFillLoc = x; //the location to check/fill on the left
                int idx = (bitmapWidth * y) + x; //the index of the current location
                while(true) {
                    //**fill with the color
                    targetBitmap[idx] = fillToValue;
                    //targetBitmap.Add(lFillLoc, y);

                    if(clearSource) sourceBitmap[idx] = false; // clear the source pixel
                    //**indicate that this pixel has already been checked and filled
                    pixelsChecked[idx] = true;
                    //**de-increment
                    lFillLoc--;     //de-increment counter
                    idx -= 1;//de-increment index
                    //**exit loop if we're at edge of bitmap or color area
                    if(lFillLoc < 0 || (pixelsChecked[idx]) || !CheckPixel(ref idx))
                        break;

                }
                lFillLoc++;

                //***Find Right Edge of Color Area
                int rFillLoc = x; //the location to check/fill on the left
                idx = (bitmapWidth * y) + x;
                while(true) {
                    //**fill with the color
                    targetBitmap[idx] = fillToValue;
                    //targetBitmap.Add(rFillLoc, y);

                    if(clearSource) sourceBitmap[idx] = false; // clear the source pixel
                    //**indicate that this pixel has already been checked and filled
                    pixelsChecked[idx] = true;
                    //**increment
                    rFillLoc++;     //increment counter
                    idx++;        //increment pixel index
                    //**exit loop if we're at edge of bitmap or color area
                    if(rFillLoc >= bitmapWidth || pixelsChecked[idx] || !CheckPixel(ref idx))
                        break;

                }
                rFillLoc--;

                //add range to queue
                FloodFillRange r = new FloodFillRange(lFillLoc, rFillLoc, y);
                ranges.Enqueue(ref r);
            }

            ///<summary>Sees if a pixel is a candidate for filling.</summary>
            ///<param name="px">The index of the pixel to check, passed by reference to increase performance.</param>
            protected bool CheckPixel(ref int px) {
                return sourceBitmap[px] == fillIfValue;
            }
        }

        /// <summary>
        /// Represents a linear range to be filled and branched from.
        /// </summary>
        private struct FloodFillRange {
            public int StartX;
            public int EndX;
            public int Y;

            public FloodFillRange(int startX, int endX, int y) {
                StartX = startX;
                EndX = endX;
                Y = y;
            }
        }

        #endregion
    }
}