﻿using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using SpriteFactory;
using SpriteFactory.Editor.DataClasses;
using System.Threading;
using Sprite = SpriteFactory.Sprite;
using Settings = SpriteFactory.Settings;

namespace SpriteFactory.Editor {

    public partial class SpriteEditor {

        private class DB {

            #region VARIABLES

            // Working
            private bool _initialized = false;
            private SpriteFactoryData data;
            private CacheDataObject cache;

            // Default objects
            private GameSettings gameSettings;
            private Material _defaultSpriteMaterial;
            private GameObject _defaultSpritePlanePrefab;
            private GameObject _defaultSpriteLocatorPrefab;
            private GameObject _defaultTwoSidedSpritePlanePrefab;
            private GameObject _boxColliderPrefab;
            private GameObject _boxColliderRBPrefab;

            // Properties for easier access to global settings
            public int pixelsPerUnit {
                get {
                    CheckInitialized();
                    return data.settings.pixelsPerUnit;
                }
            }
            public bool trimSprites {
                get {
                    CheckInitialized();
                    return data.settings.trimSprites;
                }
            }
            public int framePadding {
                get {
                    CheckInitialized(); return data.settings.framePadding;
                }
            }
            public int maxAtlasSize {
                get {
                    CheckInitialized();
                    return data.settings.maxAtlasSize;
                }
            }
            public bool forceSquareAtlases {
                get {
                    CheckInitialized();
                    return data.settings.forceSquareAtlases;
                }
            }
            public bool useMipMaps {
                get {
                    CheckInitialized();
                    return data.settings.useMipMaps;
                }
            }
            public bool useTextureCompression {
                get {
                    CheckInitialized();
                    return data.settings.useTextureCompression;
                }
            }
            //public AtlasPackingMethod atlasPackingMethod {
            //    get {
            //       CheckInitialized();
            //        return data.settings.atlasPackingMethod;
            //    }
            //}
            public Enums.ResolutionTarget resolutionTarget {
                get {
                    CheckInitialized();
                    return data.settings.resolutionTarget;
                }
            }
            public Enums.ImageResamplingMode resolutionTargetResamplingMode {
                get {
                    CheckInitialized();
                    return data.settings.resolutionTargetResamplingMode;
                }
            }

            // Defaults
            public Material userDefaultMaterial {
                get {
                    CheckInitialized();
                    string guid = data.settings.defaultMaterialGUID;
                    if(guid == null || guid == string.Empty) return _defaultSpriteMaterial; // just use true default
                    string path = AssetDatabase.GUIDToAssetPath(guid);
                    if(path == null || path == string.Empty) return _defaultSpriteMaterial; // just use true default
                    Material mat = (Material)AssetDatabase.LoadAssetAtPath(path, typeof(Material));
                    if(mat == null) return _defaultSpriteMaterial; // just use true default
                    return mat;
                }
            }

            public FilterMode defaultFilterMode {
                get {
                    CheckInitialized();
                    return data.settings.defaultFilterMode;
                }
            }
            public int defaultAnisoLevel {
                get {
                    CheckInitialized();
                    return data.settings.defaultAnisoLevel;
                }
            }
            public bool defaultUseTwoSidedMesh {
                get {
                    CheckInitialized();
                    return data.settings.defaultUseTwoSidedMesh;
                }
            }
            public SpriteFactory.Enums.SpriteMeshType defaultMeshType {
                get {
                    CheckInitialized();
                    return data.settings.defaultMeshType;
                }
            }

            public SpriteFactory.Enums.TransparencyChannel defaultAutoMeshTransparencyChannel {
                get {
                    CheckInitialized();
                    return data.settings.defaultAutoMeshTransparencyChannel;
                }
            }
            public bool defaultUse2DColliders {
                get {
                    CheckInitialized();
                    return data.settings.defaultUse2DColliders;
                }
            }
            public SpriteFactory.AutomaticActionPolicy rebuildSpriteGroupOnSave {
                get {
                    CheckInitialized();
                    return data.settings.rebuildSpriteGroupOnSave;
                }
            }
            public SpriteFactory.AutomaticActionPolicy rebuildSpriteOnSave {
                get {
                    CheckInitialized();
                    return data.settings.rebuildSpriteOnSave;
                }
            }

            public int defaultAutoMeshEdgeExtrude {
                get {
                    CheckInitialized();
                    return data.settings.defaultAutoMeshEdgeExtrude;
                }
            }
            public int defaultAutoMeshVertexReductionDistance {
                get {
                    CheckInitialized();
                    return data.settings.defaultAutoMeshVertexReductionDistance;
                }
            }

            // Properties for default objects
            public Material defaultSpriteMaterial { get { CheckInitialized(); return _defaultSpriteMaterial; } }
            public GameObject defaultSpritePlanePrefab { get { CheckInitialized(); return _defaultSpritePlanePrefab; } }
            public GameObject defaultSpriteLocatorPrefab { get { CheckInitialized(); return _defaultSpriteLocatorPrefab; } }
            public GameObject defaultTwoSidedSpritePlanePrefab { get { CheckInitialized(); return _defaultTwoSidedSpritePlanePrefab; } }

            // Path properties for sprite editor
            static public string guiSkinFilePath {
                get {
                    return _guiSkinFilePath;
                }
            }

            // Other properties
            public bool initialized {
                get {
                    return _initialized;
                }
            }
            public float resolutionTargetScale {
                get {
                    CheckInitialized();
                    return data.settings.resolutionTargetScale;
                }
            }

            #endregion

            #region CONSTRUCTORS

            public DB(SpriteEditor editor) {
                Initialize(editor);
            }

            #endregion

            #region INITIALIZATION

            public bool Initialize(SpriteEditor editor, bool force = false) {
                if(!force && _initialized) return true;

                try {
                    FindRootPath(editor);
                    CheckCriticalFilesAndPaths();
                    LoadDefaultObjects();
                    LoadData(); // load the sprite editor data from disk
                    LoadOtherFiles();
                    VerifyObjectLinks();

                } catch(System.Exception e) {
                    Debug.LogError(e.Message);
                    return false;
                }

                _initialized = true;
                return true;
            }

            private void FindRootPath(SpriteEditor editor) {
                MonoScript ms = MonoScript.FromScriptableObject(editor);
                string projPathToEditorDLL = Utils.FileTools.ConvertBackslashes(System.IO.Path.GetDirectoryName(AssetDatabase.GetAssetPath(ms)));
                if(!projPathToEditorDLL.ToLower().EndsWith(editorDLLRelPath.ToLower())) throw new System.Exception("SpriteFactory directory structure has been modified! Failed to load Sprite Factory!");
                rootPath = projPathToEditorDLL.Substring(0, projPathToEditorDLL.Length - editorDLLRelPath.Length);
            }

            private void CheckCriticalFilesAndPaths() {
                // Check folders
                if(!DirectoryExistsRel(spriteEditorRoot)) throw new System.Exception(spriteEditorRoot + " folder not found. Please reinstall Sprite Factory.");
                if(!DirectoryExistsRel(spriteEditorInternalPath)) throw new System.Exception(spriteEditorInternalPath + " folder not found! Please reinstall Sprite Factory.");
                if(!DirectoryExistsRel(guiSkinsPath)) throw new System.Exception(guiSkinsPath + " folder not found! Please reinstall Sprite Factory.");
                if(!DirectoryExistsRel(internalDataPath)) throw new System.Exception(internalDataPath + " folder not found! Please reinstall Sprite Factory.");
                if(!FileExistsRel(gameSettingsFilePath)) throw new System.Exception(gameSettingsFilePath + " file not found! Please reinstall Sprite Factory.");
            }

            private void LoadData() {
                bool changed = false;

                LoadDataFile();

                // Make sure save data directory exists
                if(!DirectoryExistsRel(saveDataPath)) CreateDirectoryRel(saveDataPath);

                // Create data file if it doesn't exist
                if(data == null) { // no data file, create one
                    CreateDataFile();
                    LoadDataFile(); // try loading it again
                    if(data == null) throw new System.Exception("Could not load " + spriteEditorDataFile + "!");
                    data.programVersion = programVersion; // set the initial program version in the data file
                    data.dataVersion = dataVersion;
                    data.isTrial = isTrial;
                    changed = true;
                }

                // Create settings file if it doesn't exist, save reference in data
                if(data.settings == null) { // no settings file has been assigned
                    Settings settings = LoadSettingsFile(); // try loading the file first before creating it
                    if(settings == null) {
                        CreateSettingsFile();
                        settings = LoadSettingsFile(); // try to load the file again
                        if(settings == null) throw new System.Exception("Could not load " + spriteEditorDataSettingsFile + "!");
                        settings.defaultMaterialGUID = Utils.AssetTools.GetGUID(_defaultSpriteMaterial); // set the default sprite material in settings
                        EditorUtility.SetDirty(settings);
                    }
                    data.settings = settings; // store settings file
                    changed = true;
                }

                // Save
                if(changed) { // we made changes to the data file
                    EditorUtility.SetDirty(data); // flag for saving
                    AssetDatabase.SaveAssets(); // save changes now
                }
            }

            private void LoadDefaultObjects() {
                string failMsg = "Required files not found! Sprite Factory installation has been corrupted!";

                gameSettings = LoadAssetAtPathRel<GameSettings>(gameSettingsFilePath);
                if(gameSettings == null) throw new System.Exception(failMsg + "GameSettings file missing!");

                _defaultSpriteMaterial = gameSettings.defaultObjects.defaultMaterial;
                if(_defaultSpriteMaterial == null) throw new System.Exception(failMsg + " Default sprite material missing!");

                _defaultSpritePlanePrefab = gameSettings.defaultObjects.spritePlane;
                if(_defaultSpritePlanePrefab == null) throw new System.Exception(failMsg + " Default sprite plane prefab missing!");

                _defaultTwoSidedSpritePlanePrefab = gameSettings.defaultObjects.spritePlaneTwoSided;
                if(_defaultTwoSidedSpritePlanePrefab == null) throw new System.Exception(failMsg + " Default two-sided sprite plane prefab missing!");

                _defaultSpriteLocatorPrefab = gameSettings.defaultObjects.spriteLocator;
                if(_defaultSpriteLocatorPrefab == null) throw new System.Exception(failMsg + " Default sprite locator prefab missing!");

                _boxColliderPrefab = gameSettings.defaultObjects.boxCollider;
                if(_boxColliderPrefab == null) throw new System.Exception(failMsg + " Default box collider prefab missing!");

                _boxColliderRBPrefab = gameSettings.defaultObjects.boxColliderRB;
                if(_boxColliderRBPrefab == null) throw new System.Exception(failMsg + " Default box collider + rigidbody prefab missing!");
            }

            private void LoadOtherFiles() {
                
                // Load cache file

                // Create cache directory if it doesn't exist
                if(!DirectoryExistsRel(cacheObjectDirPath)) {
                    CreateDirectoryRel(cacheObjectDirPath);
                }

                // Create cache object if it doesn't exist
                cache = LoadCacheFile();
                if(cache == null) { // not found
                    CreateCacheFile();
                    cache = LoadCacheFile();
                    if(cache == null) throw new System.Exception("Could not create cache file!");
                }
            }

            private void VerifyObjectLinks() {
                // make sure links to the settings file are current
                bool save = false;

                // Verify link to settings file
                Settings settings = gameSettings.settings;
                if(settings == null) { // no settings file, rebuild link
                    settings = LoadAssetAtPathRel<Settings>(spriteEditorDataSettingsFile);
                    if(settings == null) throw new System.Exception(string.Format("Sprite Factory settings file is corrupt. Delete the file at {0} and run the editor to rebuild the settings file.", spriteEditorDataSettingsFile));

                    // Update the link to settings and save
                    gameSettings.settings = settings;
                    EditorUtility.SetDirty(gameSettings);
                    save = true;
                }

                // Verify links in cache object
                if(cache.settings != settings) {
                    cache.settings = settings;
                    EditorUtility.SetDirty(cache);
                    save = true;
                }

                // Save now
                if(save) AssetDatabase.SaveAssets();
            }

            private void CheckInitialized() {
                if(!_initialized) throw new System.Exception("Sprite Manager not initialized!");
            }

            #endregion

            #region MASTER SPRITE LIST FUNCTIONS

            public int AddNewMasterSprite() {
                CheckInitialized();
                return CreateNewMasterSprite();
            }

            public int AddNewMasterSpriteToGroup(int groupId) {
                CheckInitialized();
                return CreateNewMasterSpriteInGroup(groupId);
            }

            public void InsertNewMasterSprite(int spriteIndex) {
                CheckInitialized();
                CreateNewMasterSprite(spriteIndex);
            }

            public int InsertNewMasterSpriteInGroup(int groupId, int indexInGroup) {
                CheckInitialized();
                return CreateNewMasterSpriteInGroup(groupId, indexInGroup);
            }

            public void DuplicateMasterSprite(int spriteIndex, int listIndex, bool inGroup) {
                CheckInitialized();

                bool remakeAtlases = inGroup ? false : true; // remake atlases only if not in a group

                DuplicateSprite(spriteIndex, listIndex, remakeAtlases);
            }

            public void DeleteMasterSprite(int spriteIndex, bool refreshGroupAfterDelete, bool rebuildGroupAtlases = true, bool rebuildGroupMaterials = true) {
                CheckInitialized();

                string editorMasterSpriteFile = data.GetEditorSpriteFilePath(spriteIndex);
                string spriteName = data.GetSpriteName(spriteIndex);

                // Delete materials and meshes
                DeleteFileRel(data.GetSpriteEditorPreviewMeshFile(spriteIndex)); // delete editor preview mesh files
                DeleteFileRel(data.GetSpriteEditorPreviewMaterialFile(spriteIndex)); // delete editor preview material file

                // Delete master sprite files
                DeleteFileRel(data.GetEditorSpriteCoreFilePath(spriteIndex)); // delete the core file
                DeleteFileRel(data.GetGameSpriteFilePath(spriteIndex)); // delete game master sprite prefab

                // Delete atlases in sprite or remake/delete in group
                int groupId = data.GetSpriteGroupIdOfSpriteByIndex(spriteIndex); // get group of sprite
                if(groupId == -1) { // not in group
                    DeleteAtlasFiles(spriteName, null); // delete atlas files
                    DeleteMaterialSetFiles(spriteName, null); // delete material set files
                    data.DeleteSprite(spriteIndex); // delete sprite from the list (must do this after deleting the atlases if not in a group)
                } else { // in a group
                    data.DeleteSprite(spriteIndex); // delete sprite from the list (must do this before refreshing the sprite group)
                    if(refreshGroupAfterDelete) { // only refresh group if allowed (would not be allowed to ex: delete group
                        RefreshSpriteGroup(groupId, false, rebuildGroupAtlases, rebuildGroupMaterials, false); // will delete any leftover atlases 
                    }
                }

                DeleteFileRel(editorMasterSpriteFile); // delete editor master sprite prefab last

                EditorUtility.SetDirty(data); // tell unity to save the editor data prefab changes to disk
                AssetDatabase.SaveAssets(); // save assets now
            }

            public bool ReorderMasterSprite(int spriteIndex, int offset, bool reorderNow = true) {
                CheckInitialized();
                bool reordered = data.ReorderSprite(spriteIndex, offset, reorderNow);
                if(reorderNow && reordered) {
                    EditorUtility.SetDirty(data); // tell unity prefab on disk needs to be saved
                    AssetDatabase.SaveAssets(); // save assets now
                }
                return reordered;
            }

            public bool ReorderMasterSpriteInGroup(int groupId, int listIndex, int offset, bool reorderNow = true) {
                CheckInitialized();
                bool reordered = data.ReorderSpriteInGroup(groupId, listIndex, offset, reorderNow);
                if(reorderNow && reordered) {
                    EditorUtility.SetDirty(data); // tell unity prefab on disk needs to be saved
                    AssetDatabase.SaveAssets(); // save assets now
                }
                return reordered;
            }

            #endregion

            #region SPRITE GROUP LIST FUNCTIONS

            public void AddNewSpriteGroup() {
                CheckInitialized();
                CreateNewSpriteGroup();
                EditorUtility.SetDirty(data);
                AssetDatabase.SaveAssets();
            }

            public void InsertNewSpriteGroup(int groupIndex) {
                CheckInitialized();
                CreateNewSpriteGroup(groupIndex);
                EditorUtility.SetDirty(data);
                AssetDatabase.SaveAssets();
            }

            public void DuplicateSpriteGroup(int groupIndex) {
                CheckInitialized();
                int newGroupIndex = groupIndex + 1; // put copy below original

                EditorMasterSprite.SpriteGroup oldGroup = data.GetWorkingSpriteGroupByIndex(groupIndex); // get the old sprite group data
                string newGroupName = data.FindNewGroupName(oldGroup.name); // find a safe name for the new group
                CreateNewSpriteGroup(newGroupName, newGroupIndex); // create a new sprite group
                EditorMasterSprite.SpriteGroup newGroup = data.GetWorkingSpriteGroupByIndex(newGroupIndex); // get the new sprite group data
                newGroup.ImportSettings(oldGroup); // copy settings to the new group object
                newGroup.name = newGroupName; // copy the new name name
                data.SaveWorkingSpriteGroup(newGroup); // save the sprite group

                // Duplicate all sprites in group
                if(oldGroup.spriteIds != null && oldGroup.spriteIds.Length > 0) { // we have child sprites
                    for(int i = 0; i < oldGroup.spriteIds.Length; i++) {
                        int spriteIndex = data.FindSpriteIndexBySpriteId(oldGroup.spriteIds[i]);
                        if(spriteIndex < 0) {
                            Debug.Log("Master Sprite not found! Cannot duplicate!");
                            continue;
                        }
                        // Must duplicate sprites but put in THIS group, not in original group
                        // Also, don't rebuild atlases until all have been copied
                        DuplicateSprite(spriteIndex, -1, false, false, false, true, newGroup.groupId, false); // duplicate sprite but do not remake atlases yet, do not update groups so we don't keep remaking atlases
                    }
                }
                RefreshSpriteGroup(newGroup.groupId, false, true, true, false); // refresh the entire group and build atlases
                EditorUtility.SetDirty(data);
                AssetDatabase.SaveAssets();
            }

            public void DeleteSpriteGroup(int groupIndex) {
                CheckInitialized();

                // Delete sprites in group first
                int[] childSpriteIds = data.GetSpriteGroupSpriteIds(groupIndex);
                if(childSpriteIds != null) {
                    for(int i = 0; i < childSpriteIds.Length; i++) {
                        int spriteIndex = data.FindSpriteIndexBySpriteId(childSpriteIds[i]);
                        if(spriteIndex < 0) {
                            Debug.LogError("Master Sprite not found in list!");
                            continue;
                        }
                        //Debug.Log("Deleting sprite from group at groupIndex = " + groupIndex + " spriteId = " + childSpriteIds[i] + " spriteIndex = " + spriteIndex);
                        DeleteMasterSprite(spriteIndex, false); // delete the master sprite, do not refresh group with each delete
                    }
                }

                // Delete group atlases and materials
                string[] atlasFiles;
                string[] materialFiles;
                data.GetSpriteGroupAtlasAndMaterialFilePaths(groupIndex, out atlasFiles, out materialFiles);
                if(atlasFiles != null && atlasFiles.Length > 0) {
                    DeleteFilesRel(atlasFiles);
                }
                if(materialFiles != null && materialFiles.Length > 0) {
                    DeleteFilesRel(materialFiles);
                }

                // Delete Sprite Group object on disk
                string groupName = data.GetSpriteGroupName(groupIndex);
                DeleteFileRel(GetSpriteGroupFilePath(groupName)); // delete group file

                // Delete sprite group from data file
                data.DeleteSpriteGroup(groupIndex);

                EditorUtility.SetDirty(data); // tell unity to save the editor data prefab changes to disk
                AssetDatabase.SaveAssets(); // save assets now
            }

            public bool ReorderSpriteGroup(int groupIndex, int offset, bool reorderNow = true) {
                CheckInitialized();
                bool reordered = data.ReorderSpriteGroup(groupIndex, offset, reorderNow);
                if(reorderNow && reordered) {
                    EditorUtility.SetDirty(data); // tell unity prefab on disk needs to be saved
                    AssetDatabase.SaveAssets(); // save assets now
                }
                return reordered;
            }

            #endregion

            #region LOADING / SAVING

            private EditorMasterSprite LoadEditorMasterSprite(string path) {
                EditorMasterSprite sprite = LoadAssetAtPathRel<EditorMasterSprite>(path);
                if(sprite == null) throw new System.Exception("Master Sprite file \"" + path + "\" not found!");
                return sprite;
            }

            private GameMasterSprite LoadGameMasterSprite(string path) {
                GameMasterSprite sprite = LoadAssetAtPathRel<GameMasterSprite>(path);
                if(sprite == null) throw new System.Exception("Game Master Sprite file \"" + path + "\" not found!");
                return sprite;
            }

            public void SaveSprite(EditorMasterSprite.Data masterSpriteData, int spriteIndex, int currentGroupId, bool remakeAtlases, bool remakeMaterials, bool remakeMeshes, bool updateGroups, bool preventBuildingAssets, bool calledByDuplicate, bool isUpgradeRebuild) {
                CheckInitialized();

                // Override other settings if asset creation is forbidden
                if(preventBuildingAssets) {
                    remakeAtlases = false;
                    remakeMaterials = false;
                    remakeMeshes = false;
                    updateGroups = false;
                    data.FlagSpriteOrSpriteGroupForRebuilding(spriteIndex, currentGroupId, true);
                    EditorUtility.SetDirty(data);
                }

                // Determine if sprite we are saving is in a SpriteGroup
                int newGroupId = masterSpriteData.spriteGroupId; // this groupId would change if the user changed groups
                GroupChangeStatus groupChangeStatus = DetermineSpriteGroupChangeStatus(masterSpriteData, currentGroupId, newGroupId);
                bool inGroupOrChangingGroups = currentGroupId == -1 && newGroupId == -1 ? false : true;

                // Save the original states of these flags because they may be overridden by groups
                bool origRemakeAtlases = remakeAtlases;
                bool origRemakeMaterials = remakeMaterials;

                // Save sprite based on group/un-grouped status and changes to that status
                if(!inGroupOrChangingGroups) { // Sprite is not in a group and is not going into a group -- just an individual sprite

                    // Check for name changes and rename all assets
                    string oldSpriteName = data.GetSpriteName(spriteIndex);
                    if(masterSpriteData.name != oldSpriteName) { // this is a rename
                        data.RenameMasterSpriteAndChildFiles(oldSpriteName, ref masterSpriteData.name, spriteIndex, -1, -1);
                    }

                } else { // sprite is currently in a group or is changing group assignment

                    // Move sprite to group (or out of group), deletes unused assets, renames assets, etc.
                    HandleSpriteGroupOnSave(masterSpriteData, spriteIndex, currentGroupId, newGroupId, groupChangeStatus, remakeAtlases, remakeMaterials);

                    if(groupChangeStatus != GroupChangeStatus.RemovedFromGroup) {
                        // if sprite was just removed from a group, we need to save the sprite normally below
                        // otherwise override remake settings because group refresh will handle
                        remakeAtlases = false; // override the settings
                        remakeMaterials = false; // override the settings
                        if(!calledByDuplicate) remakeMeshes = false; // don't remake the meshes now if in a group EXCEPT when duplicating a sprite within a group because it must build its editor mesh
                    }
                }

                // Save to disk
                SaveSpriteToDisk(masterSpriteData, spriteIndex, newGroupId, remakeAtlases, remakeMaterials, remakeMeshes, isUpgradeRebuild); // save the sprite

                // Rebuild groups
                if(inGroupOrChangingGroups && updateGroups) {
                    RefreshSpriteGroupsOnSave(currentGroupId, newGroupId, groupChangeStatus, origRemakeAtlases, origRemakeMaterials);
                }

                // Collect garbage just in case
                System.GC.Collect();
            }

            private void SaveSpriteToDisk(EditorMasterSprite.Data masterSpriteData, int spriteIndex, int groupId, bool remakeAtlases, bool remakeMaterials, bool remakeMeshes, bool isUpgradeRebuild) {
                EditorMasterSprite masterSprite = masterSpriteData.editorMasterSprite; // get the master sprite

                int spriteId = data.GetSpriteId(spriteIndex); // find the sprite index in the database
                masterSprite = GetEditorMasterSprite(spriteIndex); // get the source sprite of the incoming master sprite
                if(masterSprite == null) return;

                if(spriteIndex == -1) throw new System.Exception("Error saving sprite! Sprite save data may be corrupted!");
                bool isCopy = masterSpriteData != masterSprite.data ? true : false; // the incoming master sprite is the saved source sprite on disk (happens during duplication and such)

                // Create atlases
                string[] newAtlasFiles = null;
                if(remakeAtlases) {
                    // DANGER - RemakeAtlasesOnSave includes calls to AssetDatabase.ImportAsset!
                    // This CAN cause loaded scriptableobject references to be lost!
                    // Editor master sprite must be reloaded after
                    RemakeAtlasesOnSave(masterSpriteData, spriteIndex, groupId, out newAtlasFiles);
                    remakeMaterials = true; // always remake materials if remaking atlases
                    remakeMeshes = true; // always remake meshes if remaking atlases

                    // Reload editor master sprite if it was lost
                    if(masterSprite == null) masterSprite = GetEditorMasterSprite(spriteIndex); // Reload it. Data should be fine though.

                } else { // not making new atlases, but still need to get the list
                    newAtlasFiles = data.GetSpriteAtlasFilePaths(spriteIndex); // get list of existing atlas file strings
                }

                // Create materials
                SpriteFactoryData.MaterialSetFiles[] newMaterialSetFiles = null;
                if(remakeMaterials) {
                    // DANGER - RemakeMaterialsOnSave includes calls to AssetDatabase.ImportAsset!
                    RemakeMaterialsOnSave(masterSpriteData, spriteIndex, groupId, out newMaterialSetFiles);

                    // Reload editor master sprite if it was lost
                    if(masterSprite == null) masterSprite = GetEditorMasterSprite(spriteIndex); // Reload it. Data should be fine though.

                } else { // not making new materials, but still need to get the list
                    newMaterialSetFiles = data.GetSpriteMaterialSetFiles(spriteIndex); // get existing material set files
                }

                // DO NOT USE masterSprite.data AGAIN AFTER REMAKE MATERIALS
                // Bug in Unity makes the scriptableObject.data instance change after calling AssetDatabase.CreateAssets()!!!!!
                // Must keep using this masterSpriteData until finished with modifications, then save it again over the data in the ScriptableObject

                // Create/update custom meshes if any
                if(remakeMeshes) { // this happens on atlas rebuild and mesh rebuild
                    // Atlas data MUST be up to date before we run this -- this will not run for group saves
                    masterSpriteData.GenerateAutoSpriteMeshes(gameSettings.settings, isUpgradeRebuild, cache);
                }

                // Finalize any data that has been changed in master sprite before saving/converting
                masterSpriteData.FinalizeChanges(); // does cacluations of data (conversions, etc)

                // Remake meshes
                // Must go after FinalizeChanges because it converts offsets from pixels to units which we need for updating the editor mesh
                if(remakeMeshes) { // remake meshes if we didn't already make atlases since it will remake them itself
                    // DANGER - UpdateEditorMesh includes calls to AssetDatabase.ImportAsset!
                    UpdateEditorMesh(masterSpriteData, groupId); // update the preview mesh size, offset, uvs

                    // Reload editor master sprite if it was lost
                    if(masterSprite == null) masterSprite = GetEditorMasterSprite(spriteIndex); // Reload it. Data should be fine though.
                }

                // Verify sprite assets exist, recreate if necessary
                VerifyMasterSpriteAssets(masterSpriteData, spriteIndex, groupId);

                // Copy MasterSpriteData to source MasterSprite if working on a copy
                // (must be done after all possible changes to masterspritedata are complete, like fixing errors)
                if(isCopy) { // we are working with a copy of a source sprite (coming in from the editor)
                    // Clone master sprite to save to disk because we don't want to directly modify the one on disk with the editor
                    EditorMasterSprite.Data newMasterSpriteData = masterSpriteData.DeepCopy(masterSprite);

                    // Save sprite data in source prefab
                    masterSprite.data = newMasterSpriteData; // replace the entire data structure in the stored sprite
                } else {
                    // Always copy data back into masterSprite to deal with Unity bug in AssetDatabase.CreateAssets() if materials were created
                    masterSprite.data = masterSpriteData;
                }

                // tell unity to save the source sprite changes to disk
                masterSprite.SetDirtyForSave(true); // save master and core

                // Save converted sprite data in game MasterSprite on disk
                Sprite.SharedData sharedData;
                Sprite.Data spriteData = masterSprite.data.ConvertToSpriteData(data.settings, out sharedData);
                GameMasterSprite gameDataMasterSprite = GetGameMasterSpriteByIndex(spriteIndex); // get the source sprite of the incoming master sprite
                if(gameDataMasterSprite != null) {
                    gameDataMasterSprite.data = spriteData; // replace the entire data structure in the stored sprite
                    gameDataMasterSprite.sharedData = sharedData;
                    EditorUtility.SetDirty(gameDataMasterSprite); // flag to save changes
                } else { // game master sprite was deleted, recreate it
                    Debug.LogError("MasterSprite game file not found! All Sprites based on this Master Sprite will be corrupt.");
                }

                // update sprite in SpriteFactoryData so the sprite stores the name, atlases, and other data
                data.SaveSpriteData(
                    spriteIndex,
                    masterSpriteData.name,
                    newAtlasFiles,
                    newMaterialSetFiles
                );

                if(remakeAtlases) data.FlagSpriteForRebuilding(spriteIndex, false);

                EditorUtility.SetDirty(data); // tell unity to save the editor data changes to disk
                AssetDatabase.SaveAssets(); // save assets now
            }

            // ATLASES ////

            private void RemakeAtlasesOnSave(EditorMasterSprite.Data masterSpriteData, int spriteIndex, int groupId, out string[] newAtlasFiles) {
                // Warning: AtlasMaker constructor now fixes texture importer settings so it contains AssetDatabase.ImportAsset calls which can
                // cause links to on-disk ScriptableObjects to be lost! Links to objects within those scriptable objects are okay though.
                AtlasMaker atlasData = new AtlasMaker(masterSpriteData, spriteIndex, this); // create new atlases from sprite, save to disk
                ProcessAtlases(atlasData, masterSpriteData.name, data.GetSpriteGroupNameById(groupId), out newAtlasFiles);
            }

            private void ProcessAtlases(AtlasMaker atlasData, string spriteName, string groupName, out string[] newAtlasFiles) {

                newAtlasFiles = null;
                DeleteAtlasFiles(spriteName, groupName); // delete atlas files for this sprite / group

                //// SaveFiles calles AssetDatabase.ImportAsset!!!!!!!!!!!!!!!!!!!!!!!!!!
                //// Possible loss of other loaded objects!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                //// Cannot rely on the loaded Editor Master Sprite being in memory still!!!!!!!!!!!!!!!!!!!!!!!!!
                // Data object loaded from EMS seems to persist, but EMS itself DOES NOT always

                atlasData.SaveFiles(spriteName, groupName, out newAtlasFiles); // save atlases to disk, get string of paths to atlas textures back
                atlasData.UpdateMasterSprites(); // updates atlases and frames in master sprite
                //atlasData.AtlasCreationFinished();
            }

            private bool DeleteAtlasFiles(string spriteName, string groupName) {
                // Get atlas file paths from the directory so we can delete any excess in case of an import
                if(!DirectoryExistsRel(atlasSavePath)) return false;

                string searchPattern = string.Format("{0}{1}*{2}", GetChildFilePrefix(spriteName, groupName), atlasFileNamePrefix, atlasExtension);
                string[] files = DirectoryGetFilesRel_FileNamesOnly(atlasSavePath, searchPattern, SearchOption.TopDirectoryOnly);
                if(files == null || files.Length == 0) return false;

                for(int i = 0; i < files.Length; i++)
                    files[i] = atlasSavePath + directoryDelimiter + files[i]; // prepend the atlas folder path
                DeleteFilesRel(files); // delete the atlases
                return true;
            }

            // MATERIALS ////

            private void RemakeMaterialsOnSave(EditorMasterSprite.Data masterSpriteData, int spriteIndex, int groupId, out SpriteFactoryData.MaterialSetFiles[] newMaterialFiles) {
                string spritePrefix = GetChildFilePrefix(masterSpriteData.name, data.GetSpriteGroupNameById(groupId));
                ProcessMaterialsForSprite(spriteIndex, spritePrefix, masterSpriteData, out newMaterialFiles);
                SetEditorMaterialToDefaultMaterialSet(masterSpriteData, groupId); // update editor material with the first material set material
            }

            private void ProcessMaterialsForSprite(int spriteIndex, string namePrefix, EditorMasterSprite.Data masterSpriteData, out SpriteFactoryData.MaterialSetFiles[] newMaterialFiles) {
                DeleteMaterialSetFiles(masterSpriteData.name, null); // delete the material set materials
                CreateMaterials(namePrefix, masterSpriteData.editorMaterialSets, masterSpriteData.GetAtlasTextureGUIDs(), out newMaterialFiles); // create the materials for the material sets and atlases
                UpdateAtlasMaterialsInSprite(masterSpriteData, newMaterialFiles); // updates atlases in master sprite with the new materials
            }

            private void CreateMaterials(string namePrefix, EditorMasterSprite.MaterialSet[] materialSets, string[] atlasTextureGuids, out SpriteFactoryData.MaterialSetFiles[] newMaterialFiles) {
                if(materialSets == null || atlasTextureGuids == null) { // no materials or atlases to work with
                    newMaterialFiles = null;
                    return;
                }

                // Create materials for material sets for atlas textures
                // 1 material per atlas per set
                int materialSetCount = materialSets.Length;
                newMaterialFiles = new SpriteFactoryData.MaterialSetFiles[materialSetCount];
                for(int i = 0; i < materialSetCount; i++) {
                    EditorMasterSprite.MaterialSet set = materialSets[i];
                    Material sourceMaterial;
                    if(set.useDefaultMaterial) sourceMaterial = userDefaultMaterial; // use the default sprite material instead
                    else sourceMaterial = set.sourceMaterial; // use the stored source material
                    string materialNamePrefix = materialSetFileNamePrefix + i; // combine sprite name & number and material name & number

                    string[] newFilesInSet;
                    string[] newFileRootNamesInSet; // the name part of the material file with no path or extension -- This is NOT the name used in the material set editor
                    CreateMaterialsInSet(namePrefix, materialNamePrefix, sourceMaterial, atlasTextureGuids, out newFilesInSet, out newFileRootNamesInSet);
                    newMaterialFiles[i] = new SpriteFactoryData.MaterialSetFiles(newFilesInSet, newFileRootNamesInSet);
                }
            }

            private void CreateMaterialsInSet(string namePrefix, string materialNamePrefix, Material sourceMaterial, string[] atlasTextureGuids, out string[] newMaterialFilesInSet, out string[] newMaterialFileRootNamesInSet) {
                newMaterialFilesInSet = null;
                newMaterialFileRootNamesInSet = null;
                if(atlasTextureGuids == null) return;

                // Create one material per atlas
                newMaterialFilesInSet = new string[atlasTextureGuids.Length];
                newMaterialFileRootNamesInSet = new string[atlasTextureGuids.Length];
                for(int i = 0; i < atlasTextureGuids.Length; i++) {
                    string materialName = materialNamePrefix + fileNameDelimiter + atlasFileNamePrefix + i; // append atlas and number
                    string fullPath = materialSavePath + directoryDelimiter + namePrefix + materialName + materialExtension; // full final path with extension of material
                    Material mat = CreateMaterial(fullPath, sourceMaterial, atlasTextureGuids[i], false); // create material on disk with atlas texture applied, defer saving
                    newMaterialFilesInSet[i] = GetAssetPathRel(mat); // save path to new material
                    newMaterialFileRootNamesInSet[i] = materialName;
                }
            }

            private void UpdateAtlasMaterialsInSprite(EditorMasterSprite.Data masterSpriteData, SpriteFactoryData.MaterialSetFiles[] newMaterialFiles) {
                // Go through atlases in sprite and update materials
                EditorMasterSprite.Atlas[] atlases = masterSpriteData.editorAtlases;
                if(atlases == null || atlases.Length == 0) return; // nothing to update
                int materialSetCount = newMaterialFiles.Length;

                for(int i = 0; i < atlases.Length; i++) {
                    string[] materialGUIDs = new string[materialSetCount];
                    for(int j = 0; j < materialSetCount; j++) {
                        string filePath = newMaterialFiles[j].materialFilePaths[i]; // get the material for this atlas in this set
                        string guid = GetAssetGUIDAtPathRel(filePath);
                        if(guid == null || guid == string.Empty) {
                            Debug.LogError("Required material file is missing!");
                            continue; // material missing!
                        }
                        materialGUIDs[j] = guid; // store material object
                    }
                    atlases[i].materialGUIDs = materialGUIDs; // save material guids in atlas replacing old array
                }
            }

            private void SetEditorMaterialToDefaultMaterialSet(EditorMasterSprite.Data masterSpriteData, int groupId) {
                Material sourceMaterial;

                if(masterSpriteData.editorMaterialSets[0].useDefaultMaterial) { // use default
                    sourceMaterial = userDefaultMaterial; // source was missing, use user default instead
                } else { // use custom
                    sourceMaterial = masterSpriteData.editorMaterialSets[0].sourceMaterial;
                    if(sourceMaterial == null) sourceMaterial = userDefaultMaterial; // source was missing, use user default instead
                }

                Shader sourceShader = sourceMaterial.shader;
                Material editorMaterial = masterSpriteData.GetEditorMaterial();

                if(editorMaterial == null) { // material was somehow broken, repair
                    editorMaterial = CreateEditorMaterial(masterSpriteData.name, groupId); // create or load sprite's material
                    masterSpriteData.SetEditorMaterial(editorMaterial); // reattach to master sprite
                }

                // Set the shader to match source
                if(editorMaterial.shader != sourceMaterial.shader) editorMaterial.shader = sourceShader;
                // KNOWN BUG: In Unity 3.5.7 (at least), setting the shader on the material causes a potential crash when viewing textures in the inspector!
                editorMaterial.CopyPropertiesFromMaterial(sourceMaterial);

                // Assign atlas texture to the material
                Texture2D defaultAtlasTex = masterSpriteData.GetEditorPreviewAtlasTexture();
                editorMaterial.mainTexture = defaultAtlasTex; // set atlas in material
            }

            private bool DeleteMaterialSetFiles(string spriteName, string groupName) {
                // Get atlas file paths from the directory so we can delete any excess in case of an import
                if(!DirectoryExistsRel(materialSavePath)) return false;

                string searchPattern = string.Format("{0}{1}*{2}", GetChildFilePrefix(spriteName, groupName), materialSetFileNamePrefix, materialExtension);
                string[] files = DirectoryGetFilesRel_FileNamesOnly(materialSavePath, searchPattern, SearchOption.TopDirectoryOnly);
                if(files == null || files.Length == 0) return false;

                for(int i = 0; i < files.Length; i++)
                    files[i] = materialSavePath + directoryDelimiter + files[i]; // prepend the material folder path
                DeleteFilesRel(files); // delete the materials
                return true;
            }

            // SPRITE GROUPS ////

            public void SaveSpriteGroup(EditorMasterSprite.SpriteGroup spriteGroup, bool remakeAtlases, bool remakeMaterials) {
                CheckInitialized();
                data.SaveWorkingSpriteGroup(spriteGroup); // save the sprite group first
                EditorUtility.SetDirty(data);
                AssetDatabase.SaveAssets();

                if(remakeAtlases) RefreshSpriteGroup(spriteGroup.groupId, false, true, true, false); // remake the atlases and materials in the group
                else if(remakeMaterials) MakeSpriteGroupMaterials(spriteGroup.groupId); // just remake the materials in the group
            }

            private void HandleSpriteGroupOnSave(EditorMasterSprite.Data masterSpriteDataWorking, int spriteIndex, int oldGroupId, int newGroupId, GroupChangeStatus groupChangeStatus, bool remakeAtlases, bool remakeMaterials) {
                int spriteId = data.GetSpriteId(spriteIndex);

                // Clean things up when adding/removing this sprite from a group
                if(groupChangeStatus == GroupChangeStatus.AddedToGroup) { // just added to group, was formerly a lone sprite

                    // Delete any sprite atlases and materials attributed to the sprite itself and not the group (would be leftover if we added this sprite to a group)
                    string[] spriteAtlases = data.GetSpriteAtlasFilePaths(spriteIndex);
                    string[] spriteMaterials = data.GetSpriteMaterialFilePaths(spriteIndex);
                    if(spriteAtlases != null && spriteAtlases.Length > 0) { // we have some left over atlases in the sprite which need to be cleared so we can use the group instead
                        DeleteFilesRel(spriteAtlases); // delete all the atlas files
                        DeleteFilesRel(spriteMaterials); // delete all the material files
                        data.ClearSpriteAtlasAndMaterialFiles(spriteIndex); // delete sprite atlases and materials from sprite editor data file
                    }

                    ChangeSpriteGroup(masterSpriteDataWorking, -1, newGroupId, spriteId);

                } else if(groupChangeStatus == GroupChangeStatus.RemovedFromGroup) { // just removed from group and now a lone sprite

                    masterSpriteDataWorking.editorMaterialSets = GetDefaultMaterialSets(); // reset material sets to default
                    SetEditorMaterialToDefaultMaterialSet(masterSpriteDataWorking, -1); // update editor material with the first material set material
                    ChangeSpriteGroup(masterSpriteDataWorking, oldGroupId, -1, spriteId);

                } else if(groupChangeStatus == GroupChangeStatus.ChangedGroup) { // groups sprite changed to a different group

                    ChangeSpriteGroup(masterSpriteDataWorking, oldGroupId, newGroupId, spriteId);

                } else { // no change

                    // Check for name changes and rename all assets
                    string oldSpriteName = data.GetSpriteName(spriteIndex);
                    if(masterSpriteDataWorking.name != oldSpriteName) { // this is a rename
                        data.RenameMasterSpriteAndChildFiles(oldSpriteName, ref masterSpriteDataWorking.name, spriteIndex, oldGroupId, oldGroupId);
                    }

                }
            }

            private void ChangeSpriteGroup(EditorMasterSprite.Data masterSpriteDataWorking, int oldGroupId, int newGroupId, int spriteId) {
                if(oldGroupId >= 0 && newGroupId >= 0) { // moving from group to group
                    data.ChangeSpriteGroup(masterSpriteDataWorking, oldGroupId, newGroupId, spriteId);
                } else { // moving in or out of a group
                    if(oldGroupId >= 0) { // was in an old group, remove it
                        data.RemoveSpriteFromSpriteGroup(masterSpriteDataWorking, oldGroupId, spriteId);
                    }
                    if(newGroupId >= 0) { // assigning to a new group
                        data.AddSpriteToSpriteGroup(masterSpriteDataWorking, newGroupId, spriteId);
                    }
                }
                EditorUtility.SetDirty(data); // flag data for saving
            }

            private void RefreshSpriteGroupsOnSave(int oldGroupId, int newGroupId, GroupChangeStatus groupChangeStatus, bool remakeAtlases, bool remakeMaterials) {
                if(groupChangeStatus != GroupChangeStatus.None) { // a group change
                    if(oldGroupId >= 0) RefreshSpriteGroup(oldGroupId, false, remakeAtlases, remakeMaterials, false);
                    if(newGroupId >= 0) RefreshSpriteGroup(newGroupId, false, remakeAtlases, remakeMaterials, false);
                } else { // no group change
                    // Might still need to remake atlases
                    if(newGroupId >= 0) { // this sprite is in a group, so update the group
                        if(remakeAtlases) RefreshSpriteGroup(newGroupId, false, true, true, false); // remake the atlases if necessary
                        else if(remakeMaterials) MakeSpriteGroupMaterials(newGroupId); // remake the materials
                    }
                }
            }

            private void RefreshSpriteGroup(int groupId, bool rebuildSprites, bool remakeAtlases, bool remakeMaterials, bool isUpgradeRebuild) {
                // Make sure group exists
                int groupIndex = data.FindSpriteGroupIndexBySpriteGroupId(groupId);
                if(groupIndex < 0) {
                    Debug.LogError("Group not found! Cannot update group!");
                    return;
                }

                // Flag the group rebuilt if we even want to remake atlases
                if(remakeAtlases) {
                    data.FlagSpriteGroupForRebuilding(groupIndex, false);
                    EditorUtility.SetDirty(data);
                }

                // Get all sprites in sprite group
                int[] spriteIds = data.GetSpriteGroupSpriteIds(groupIndex);

                // Check for empty group and delete files
                if(spriteIds == null || spriteIds.Length == 0) { // there are no more sprites in this group, delete all atlas and material files
                    DeleteSpriteGroupAtlasFiles(groupIndex); // delete atlases still stored in this group
                    DeleteSpriteGroupMaterialFiles(groupIndex); // delete materials still stored in this group
                    AssetDatabase.SaveAssets(); // save anyway
                    return; // no sprites in group, so done
                }

                // Get sprite group object
                EditorMasterSprite.SpriteGroup spriteGroup = data.GetWorkingSpriteGroupById(groupId);

                // Actually rebuild the sprites
                if(rebuildSprites) {
                    for(int i = 0; i < spriteIds.Length; i++) {
                        RebuildSprite(data.FindSpriteIndexBySpriteId(spriteIds[i]), false, false, false, false);
                    }

                    // Reload group if reference lost because of ImportAsset
                    if(spriteGroup == null) spriteGroup = data.GetWorkingSpriteGroupById(groupId);
                }

                // Recreate atlases for the whole group and assign to sprites
                if(remakeAtlases) {
                    
                    MakeSpriteGroupAtlases(spriteGroup, groupIndex, spriteIds, isUpgradeRebuild);
                    remakeMaterials = true; // always remake materials if remaking atlases
                    
                    // Reload group if reference lost because of ImportAsset
                    if(spriteGroup == null) spriteGroup = data.GetWorkingSpriteGroupById(groupId);

                }

                // Remake all materials for group and assign to sprites
                if(remakeMaterials) MakeSpriteGroupMaterials(spriteGroup, groupIndex, spriteIds);

                // Save
                AssetDatabase.SaveAssets();
            }

            private void MakeSpriteGroupAtlases(EditorMasterSprite.SpriteGroup spriteGroup, int groupIndex, int[] spriteIds, bool isUpgradeRebuild) {
                int groupId = spriteGroup.groupId;

                // Create atlases for sprite group
                AtlasMaker atlasData = new AtlasMaker(spriteGroup, this); // create new atlas maker object
                int[] spriteIndices = new int[spriteIds.Length];

                bool added = false;
                for(int i = 0; i < spriteIds.Length; i++) {
                    int spriteId = spriteIds[i];
                    int spriteIndex = data.FindSpriteIndexBySpriteId(spriteId);
                    spriteIndices[i] = spriteIndex; // store the indices
                    if(spriteIndex < 0) { // sprite not found
                        Debug.LogError("SpriteId " + spriteId + " not found, but is listed in SpriteGroupId " + groupId + "! Error in SpriteFactoryData!");
                        continue;
                    }
                    EditorMasterSprite editorMasterSprite = GetEditorMasterSprite(spriteIndex); // load the editor master sprite from disk

                    // WARNING - atlasData.AddSprite will call AssetDatabase.ImportAsset if a mesh was deleted by user!
                    atlasData.AddSprite(editorMasterSprite.data, spriteIndex); // add sprite to atlases
                    added = true;
                }

                string[] newAtlasFiles = null;
                if(added) { // had at least one valid sprite in group

                    // ProcessAtlases includes calls to AssetDatabase.ImportAsset
                    // This CAN destroy the scriptableobject variables loaded from disk
                    // We will have to reload these objects after calling it

                    ProcessAtlases(atlasData, null, data.GetSpriteGroupName(groupIndex), out newAtlasFiles); // create atlases, delete leftovers
                    atlasData.CommitToMasterSpritesOnDisk(); // copy the changes to the editor master sprites on disk now

                    // Reload the editor master sprites and game master sprites AFTER ProcessAtlases
                    // Update game sprites and flag master sprites that were updated for saving
                    for(int i = 0; i < spriteIndices.Length; i++) {
                        int spriteIndex = spriteIndices[i];
                        if(spriteIndex < 0) continue; // sprite not found, no need to warn again

                        // Load the master sprites
                        EditorMasterSprite editorMasterSprite = GetEditorMasterSprite(spriteIndex);
                        GameMasterSprite gameMasterSprite = GetGameMasterSpriteByIndex(spriteIndex);

                        if(editorMasterSprite == null) { // no editor master sprite
                            Debug.LogError("Editor Master Sprite at index " + i + " is missing! Skipping.");
                            continue;
                        }
                        if(gameMasterSprite == null) { // no game master sprite
                            Debug.LogError("Game Master Sprite at index " + i + " is missing! Skipping.");
                            continue;
                        }

                        // Update the editor master sprite dependencies
                        ////UpdateEditorMeshAndMaterial(editorMasterSprites[i].editorData); // update editor preview mesh and default material with newest preview frame -- NOW WE UPDATE IN MATERIAL AREA

                        // Remake the custom mesh frames and editor meshes if any changes happened that would warrant it...
                        // source images, frame padding, edge extrude changes, etc.
                        editorMasterSprite.data.GenerateAutoSpriteMeshes(gameSettings.settings, isUpgradeRebuild, cache); // remake custom meshes

                        // WARNING - UpdateEditorMesh MAY call AssetDatabase.ImportAsset if a mesh was deleted by user!
                        UpdateEditorMesh(editorMasterSprite.data, groupId); // update the preview mesh size, offset, uvs

                        // Check for reference loss and reload if necessary
                        if(editorMasterSprite == null) editorMasterSprite = GetEditorMasterSprite(spriteIndex); // reload if lost
                        if(gameMasterSprite == null) gameMasterSprite = GetGameMasterSpriteByIndex(spriteIndex); // reload if lost

                        editorMasterSprite.SetDirtyForSave(true); // flag for saving, save core too

                        // Update the game master sprite
                        Sprite.SharedData sharedData;
                        gameMasterSprite.data = editorMasterSprite.data.ConvertToSpriteData(data.settings, out sharedData); // store converted data in game master sprite
                        gameMasterSprite.sharedData = sharedData;
                        EditorUtility.SetDirty(gameMasterSprite); // flag for saving
                    }
                }

                // Update atlas list in SpriteFactoryData
                data.SaveSpriteGroupData_AtlasFiles(groupIndex, newAtlasFiles);
                EditorUtility.SetDirty(data); // flag for saving

                // Collect garbage now
                System.GC.Collect();
            }

            private void MakeSpriteGroupMaterials(int groupId) {
                // Make sure group exists
                int groupIndex = data.FindSpriteGroupIndexBySpriteGroupId(groupId);
                if(groupIndex < 0) {
                    Debug.LogError("Group not found! Cannot update group!");
                    return;
                }

                // Get all sprites in sprite group
                int[] spriteIds = data.GetSpriteGroupSpriteIds(groupIndex);

                // Check for empty group and delete files
                if(spriteIds == null || spriteIds.Length == 0) { // there are no more sprites in this group, delete all atlas and material files
                    DeleteSpriteGroupAtlasFiles(groupIndex); // delete atlases still stored in this group
                    DeleteSpriteGroupMaterialFiles(groupIndex); // delete materials still stored in this group
                    return; // no sprites in group, so done
                }

                // Get sprite group object
                EditorMasterSprite.SpriteGroup spriteGroup = data.GetWorkingSpriteGroupById(groupId);

                MakeSpriteGroupMaterials(spriteGroup, groupIndex, spriteIds);

                AssetDatabase.SaveAssets();
            }

            private void MakeSpriteGroupMaterials(EditorMasterSprite.SpriteGroup spriteGroup, int groupIndex, int[] spriteIds) {
                int groupId = spriteGroup.groupId;

                // Get atlas textures in group
                string[] atlasFileNames = data.GetSpriteGroupAtlasFilePaths(groupIndex);
                if(atlasFileNames == null) { // no atlases
                    DeleteSpriteGroupMaterialFiles(groupIndex); // delete materials still stored in this group
                    return;
                }
                string[] atlasTextureGuids = new string[atlasFileNames.Length];
                for(int i = 0; i < atlasTextureGuids.Length; i++) {
                    string guid = GetAssetGUIDAtPathRel(atlasFileNames[i]);
                    if(guid == null || guid == string.Empty) continue; // atlas texture missing
                    atlasTextureGuids[i] = guid;
                }

                // Create materials for this group
                DeleteMaterialSetFiles(null, data.GetSpriteGroupName(groupIndex)); // delete the material set materials
                SpriteFactoryData.MaterialSetFiles[] newMaterialFiles;
                string groupPrefix = GetSpriteGroupChildFilePrefix(spriteGroup.name);
                EditorMasterSprite.MaterialSet[] materialSets = spriteGroup.editorMaterialSets; // Get material sets from group
                CreateMaterials(groupPrefix, materialSets, atlasTextureGuids, out newMaterialFiles); // Create materials

                int newMaterialFileSetCount;
                if(newMaterialFiles == null) newMaterialFileSetCount = 0;
                else newMaterialFileSetCount = newMaterialFiles.Length;

                // Update materials in sprites in group
                for(int i = 0; i < spriteIds.Length; i++) {
                    int spriteId = spriteIds[i];
                    int spriteIndex = data.FindSpriteIndexBySpriteId(spriteId);
                    if(spriteIndex < 0) {
                        Debug.LogError("SpriteId " + spriteId + " not found, but is listed in SpriteGroupId " + groupId + "! Error in SpriteFactoryData!");
                        continue;
                    }

                    // Get the sprites
                    EditorMasterSprite editorMasterSprite = GetEditorMasterSprite(spriteIndex);
                    GameMasterSprite gameMasterSprite = GetGameMasterSpriteByIndex(spriteIndex);

                    // Update atlas materials and material sets in sprite
                    // Find group atlas from the sprite atlas so we can assign it
                    EditorMasterSprite.Data editorData = editorMasterSprite.data;
                    int spriteAtlasCount;
                    if(editorData.editorAtlases == null) spriteAtlasCount = 0;
                    else spriteAtlasCount = editorData.editorAtlases.Length;
                    // Create a new array of MaterialSetFiles containing only atlas materials used by this sprite
                    int[] spriteAtlasToGroupAtlasIndices = editorData.atlasToGroupAtlasIndices;
                    SpriteFactoryData.MaterialSetFiles[] spriteMaterialSetFiles = new SpriteFactoryData.MaterialSetFiles[newMaterialFileSetCount];
                    for(int j = 0; j < newMaterialFileSetCount; j++) { // for each material set
                        string[] newSetFiles = newMaterialFiles[j].materialFilePaths;
                        string[] newSetRootNames = newMaterialFiles[j].materialRootNames;
                        string[] spriteMaterialFilesInMaterialSet = new string[spriteAtlasCount];
                        string[] spriteMaterialRootNamesInMaterialSet = new string[spriteAtlasCount];
                        for(int k = 0; k < spriteAtlasCount; k++) {
                            int groupAtlasIndex = spriteAtlasToGroupAtlasIndices[k];
                            spriteMaterialFilesInMaterialSet[k] = newSetFiles[groupAtlasIndex];
                            spriteMaterialRootNamesInMaterialSet[k] = newSetRootNames[groupAtlasIndex];
                        }
                        spriteMaterialSetFiles[j] = new SpriteFactoryData.MaterialSetFiles(spriteMaterialFilesInMaterialSet, spriteMaterialRootNamesInMaterialSet);
                    }
                    UpdateAtlasMaterialsInSprite(editorMasterSprite.data, spriteMaterialSetFiles); // assign atlas materials to sprite

                    // Copy group material sets to sprite
                    if(materialSets == null) editorMasterSprite.data.editorMaterialSets = null;
                    else {
                        int setCount = materialSets.Length;
                        EditorMasterSprite.MaterialSet[] newSets = new EditorMasterSprite.MaterialSet[setCount];
                        for(int j = 0; j < setCount; j++) // clone the material sets
                            newSets[j] = materialSets[j].DeepCopy();
                        editorMasterSprite.data.editorMaterialSets = newSets; // copy to sprite
                    }

                    SetEditorMaterialToDefaultMaterialSet(editorMasterSprite.data, groupId); // update editor material with the first material set material

                    // Push update to game master sprite on disk
                    Sprite.SharedData sharedData;
                    gameMasterSprite.data = editorMasterSprite.data.ConvertToSpriteData(data.settings, out sharedData); // store converted data in game master sprite
                    gameMasterSprite.sharedData = sharedData;

                    // Set flags for saving
                    editorMasterSprite.SetDirtyForSave(true); // save master and core
                    EditorUtility.SetDirty(gameMasterSprite);
                }

                // Save sprite group
                data.SaveSpriteGroupData_MaterialSetFiles(groupIndex, newMaterialFiles); // save the material files in the group
                EditorUtility.SetDirty(data); // flag for saving
            }

            private void DeleteSpriteGroupAtlasFiles(int groupIndex, bool saveNow = false) {
                bool updated = false;
                if(DeleteAtlasFiles(null, data.GetSpriteGroupName(groupIndex))) {
                    data.ClearSpriteGroupAtlases(groupIndex); // clear from list
                    EditorUtility.SetDirty(data); // flag for save
                    updated = true;
                }
                if(updated && saveNow) AssetDatabase.SaveAssets(); // save
            }

            private void DeleteSpriteGroupMaterialFiles(int groupIndex, bool saveNow = false) {
                bool updated = false;
                if(DeleteMaterialSetFiles(null, data.GetSpriteGroupName(groupIndex))) { // there were some old materials left over
                    data.ClearSpriteGroupMaterialFiles(groupIndex); // clear from list
                    EditorUtility.SetDirty(data); // flag for save
                    updated = true;
                }
                if(updated && saveNow) AssetDatabase.SaveAssets(); // save
            }

            private GroupChangeStatus DetermineSpriteGroupChangeStatus(EditorMasterSprite.Data masterSpriteData, int oldGroupId, int newGroupId) {
                GroupChangeStatus groupChangeStatus;
                //oldGroupId = GetSpriteGroupIdOfSpriteById(masterSpriteData.masterSpriteId); // don't need to get the groupId like this anymore

                if(oldGroupId == newGroupId) groupChangeStatus = GroupChangeStatus.None;
                else if(newGroupId == -1) groupChangeStatus = GroupChangeStatus.RemovedFromGroup;
                else if(oldGroupId == -1) groupChangeStatus = GroupChangeStatus.AddedToGroup;
                else groupChangeStatus = GroupChangeStatus.ChangedGroup;
                return groupChangeStatus;
            }

            #endregion

            #region GET / FIND

            public string[] GetSavedSpriteNames() {
                CheckInitialized();
                return data.GetSpriteNames();
            }

            public int[] GetSavedSpriteIndices() {
                CheckInitialized();
                return data.GetSpriteIndices();
            }

            private EditorMasterSprite GetEditorMasterSprite(int spriteIndex) {
                try {
                    string spritePrefabFile = data.GetEditorSpriteFilePath(spriteIndex);
                    EditorMasterSprite masterSprite = LoadEditorMasterSprite(spritePrefabFile);
                    return masterSprite;
                } catch(System.Exception e) {
                    Debug.LogError(e.Message);
                }
                return null;
            }

            public EditorMasterSprite.Data GetEditorSpriteDataCopy(int spriteIndex) {
                CheckInitialized();

                try {
                    string path = data.GetEditorSpriteFilePath(spriteIndex);
                    EditorMasterSprite editorSprite = LoadEditorMasterSprite(path);
                    EditorMasterSprite.Data newData = editorSprite.data.DeepCopy(editorSprite); // Clone master sprite
                    return newData;
                } catch(System.Exception e) {
                    Debug.LogError(e.Message);
                }
                return null;
            }

            private GameMasterSprite GetGameMasterSpriteByIndex(int spriteIndex) {
                try {
                    string spritePrefabFile = data.GetGameSpriteFilePath(spriteIndex);
                    return LoadGameMasterSprite(spritePrefabFile);
                } catch(System.Exception e) {
                    Debug.LogError(e.Message);
                }
                return null;
            }

            private GameMasterSprite GetGameMasterSpriteById(int spriteId) {
                int spriteIndex = FindSpriteIndexBySpriteId(spriteId);
                if(spriteIndex == -1) {
                    Debug.LogError("Sprite id not found! Data corruption detected!");
                    return null;
                }
                return GetGameMasterSpriteByIndex(spriteIndex);
            }

            public int GetSpriteGroupIdOfSpriteById(int spriteId) {
                CheckInitialized();
                return data.GetSpriteGroupIdOfSpriteById(spriteId);
            }

            public int GetSpriteGroupIdOfSpriteByIndex(int spriteIndex) {
                CheckInitialized();
                return data.GetSpriteGroupIdOfSpriteByIndex(spriteIndex);
            }

            public int FindSpriteIndexBySpriteId(int spriteId) {
                CheckInitialized();
                return data.FindSpriteIndexBySpriteId(spriteId);
            }

            private void SetCurrentFrameTimestamps(EditorMasterSprite.Data editorSpriteData) {
                EditorMasterSprite.Animation[] anims = editorSpriteData.editorAnimations;
                if(anims == null || anims.Length == 0) return;
                for(int i = 0; i < anims.Length; i++) {
                    EditorMasterSprite.Animation anim = anims[i];
                    EditorMasterSprite.Frame[] frames = anim.editorFrames;
                    if(frames == null || frames.Length == 0) return;

                    for(int j = 0; j < frames.Length; j++) {
                        EditorMasterSprite.Frame frame = frames[j];
                        if(!frame.hasTexture) continue; // texture image file is missing
                        string texPath = frame.texturePath;
                        ulong timestamp = TextureImporter.GetAtPath(texPath).assetTimeStamp; // get timestamp of texture
                        frame.textureTimestamp = timestamp; // save timestamp in editor frame
                    }
                }
            }

            private int FindChangedSourceSprites(out int[] changedSpritesIndices, out int[] changedGroupIds) {

                // First check for sprites and groups that are flagged for updating
                changedSpritesIndices = data.GetSpriteIndicesFlaggedForRebuilding();
                changedGroupIds = data.GetSpriteGroupIndicesFlaggedForRebuilding();

                // Checks for changed source images by comparing timestamp to stored values
                int[] allSpriteIndices = data.GetSpriteIndices();
                if(allSpriteIndices == null || allSpriteIndices.Length == 0) return 0;

                int changedCount = 0;
                if(changedSpritesIndices != null) changedCount += changedSpritesIndices.Length;
                if(changedGroupIds != null) changedCount += changedGroupIds.Length;

                for(int i = 0; i < allSpriteIndices.Length; i++) {
                    int spriteIndex = allSpriteIndices[i];

                    // Filter out sprites if we've already added them or their group
                    int groupId = data.GetSpriteGroupIdOfSpriteByIndex(spriteIndex);
                    bool inGroup = groupId >= 0 ? true : false;
                    if(inGroup) {
                        if(data.IsSpriteGroupFlaggedForRebuilding(data.FindSpriteGroupIndexBySpriteGroupId(groupId))) continue; // this group is already flagged, don't check again
                        if(changedGroupIds != null && System.Array.IndexOf<int>(changedGroupIds, groupId) >= 0) continue; // group is already in list don't add again
                    } else {
                        if(data.IsSpriteFlaggedForRebuilding(spriteIndex)) continue; // this sprite is already flagged, don't check again
                        if(changedSpritesIndices != null && System.Array.IndexOf<int>(changedSpritesIndices, spriteIndex) >= 0) continue; // sprite is already in list, don't add again
                    }

                    // Check source images to see if they've been updated
                    EditorMasterSprite sprite = GetEditorMasterSprite(spriteIndex);
                    if(sprite == null) continue;
                    string[] textureGUIDs = sprite.data.GetFrameTextureGUIDs();
                    if(textureGUIDs == null || textureGUIDs.Length == 0) continue; // no textures
                    ulong[] timestamps = sprite.data.GetFrameTextureTimestamps(); // will always be same length as textures, and 1 to 1 association

                    for(int j = 0; j < textureGUIDs.Length; j++) {
                        if(textureGUIDs[j] == null || textureGUIDs[j] == string.Empty) continue; // this texture may have been deleted or stored broken
                        string texturePath = AssetDatabase.GUIDToAssetPath(textureGUIDs[j]);
                        // check stored timestamps and file lengths against current ones
                        ulong newTimestamp = TextureImporter.GetAtPath(texturePath).assetTimeStamp;

                        if(newTimestamp != timestamps[j]) { // new timestamp does not match!
                            changedCount++;

                            if(inGroup) {
                                SpriteFactory.Utils.ArrayTools.Add<int>(ref changedGroupIds, groupId); // save the groupId of this sprite
                            } else {
                                SpriteFactory.Utils.ArrayTools.Add<int>(ref changedSpritesIndices, spriteIndex); // save the sprite index
                            }

                            break; // just count once per fileData
                        }
                    }
                }
                return changedCount;
            }

            // Sprite Groups

            public bool GetSavedSpriteListsInGroup(int groupId, out int[] indices, out string[] names, bool prependRebuildRequired = false) {
                CheckInitialized();
                return data.GetSpriteNamesAndIndicesInGroup(groupId, out indices, out names, prependRebuildRequired);
            }

            public int GetSavedSpriteCountInGroup(int groupId) {
                CheckInitialized();
                return data.GetSpriteCountInGroup(groupId);
            }

            public string[] GetSavedSpriteGroupNames(bool appendSpriteCount = false, bool prependRebuildRequired = false) {
                CheckInitialized();
                return data.GetSpriteGroupNames(appendSpriteCount, prependRebuildRequired);
            }

            public int[] GetSavedSpriteGroupIndices() {
                CheckInitialized();
                return data.GetSpriteGroupIndices();
            }

            public int FindSpriteGroupIdByIndex(int groupIndex) {
                CheckInitialized();
                return data.GetSpriteGroupId(groupIndex);
            }

            public int FindSpriteGroupIndexById(int groupIndex) {
                CheckInitialized();
                return data.FindSpriteGroupIndexBySpriteGroupId(groupIndex);
            }

            public EditorMasterSprite.SpriteGroup GetSpriteGroupByIndex(int groupIndex) {
                CheckInitialized();
                return data.GetWorkingSpriteGroupByIndex(groupIndex);
            }

            #endregion

            #region FILE HANDLING

            private void LoadDataFile() {
                data = LoadAssetAtPathRel<SpriteFactoryData>(spriteEditorDataFile);
            }

            private Settings LoadSettingsFile() {
                return LoadAssetAtPathRel<Settings>(spriteEditorDataSettingsFile);
            }

            private CacheDataObject LoadCacheFile() {
                return LoadAssetAtPathRel<CacheDataObject>(cacheDataObjectFilePath);
            }

            private void CreatePrefab(string prefabName, string filePath, System.Type[] components) {
                // Create an empty prefab
                GameObject go = new GameObject(prefabName, components); // create a game object in the scene with the components added
                string dirPath = Path.GetDirectoryName(filePath);
                if(!DirectoryExistsRel(dirPath)) CreateDirectoryRel(dirPath); // create directory if it doesn't exist
                CreatePrefabRel(filePath, go); // create the prefab out of the game object
                ImportAssetRel(filePath, ImportAssetOptions.ForceUpdate); // import the new prefab
                Object.DestroyImmediate(go); // delete the game object in the scene
            }

            private void CreateScriptableObject<T>(string filePath) where T : ScriptableObject {
                // Create an empty scriptable object of type
                string dirPath = Path.GetDirectoryName(filePath);
                if(!DirectoryExistsRel(dirPath)) CreateDirectoryRel(dirPath); // create directory if it doesn't exist
                T so = ScriptableObject.CreateInstance<T>();
                CreateAssetRel(so, filePath);
                ImportAssetRel(filePath, ImportAssetOptions.ForceUpdate); // import the new prefab
            }

            private string GetSpriteSOPath(string spriteName, MasterSpriteType type, int groupId) {
                string groupName = data.GetSpriteGroupNameById(groupId); // returns null of ungrouped
                if(type == MasterSpriteType.Editor)
                    return GetEditorMasterSpriteFilePath(spriteName, groupName);
                else
                    return GetGameMasterSpriteFilePath(spriteName, groupName);
            }

            private string GetSpriteSOFileName(string spriteName, MasterSpriteType type, int groupId) {
                string groupName = data.GetSpriteGroupNameById(groupId); // returns null of ungrouped
                if(type == MasterSpriteType.Editor)
                    return GetEditorMasterSpriteFileNameOnly(spriteName, groupName);
                else
                    return GetGameMasterSpriteFileNameOnly(spriteName, groupName);
            }

            private string GetSpriteCorePath(string spriteName, int groupId) {
                string groupName = data.GetSpriteGroupNameById(groupId); // returns null of ungrouped
                return GetEditorMasterSpriteCoreFilePath(spriteName, groupName);
            }

            private string GetSpriteCoreFileName(string spriteName, int groupId) {
                string groupName = data.GetSpriteGroupNameById(groupId); // returns null of ungrouped
                return GetEditorMasterSpriteCoreFileNameOnly(spriteName, groupName);
            }

            #endregion

            #region CREATE

            private void CreateDataFile() {
                CreateScriptableObject<SpriteFactoryData>(spriteEditorDataFile); // create the so file
            }

            private void CreateSettingsFile() {
                CreateScriptableObject<Settings>(spriteEditorDataSettingsFile); // create the so file
            }

            private void CreateCacheFile() {
                CreateScriptableObject<CacheDataObject>(cacheDataObjectFilePath);

            }

            private int CreateNewMasterSprite(int newIndex = -1) {
                EditorMasterSprite sourceSprite;
                int spriteIndex;
                int spriteId;
                CreateNewMasterSprite(null, out sourceSprite, out spriteIndex, out spriteId, newIndex);
                return spriteIndex;
            }

            private int CreateNewMasterSpriteInGroup(int groupId, int newIndex = -1) {
                EditorMasterSprite sourceSprite;
                int spriteIndex;
                int spriteId;
                CreateNewMasterSprite(null, out sourceSprite, out spriteIndex, out spriteId, newIndex, groupId);
                return spriteIndex;
            }

            private void CreateNewMasterSprite(string desiredName, out EditorMasterSprite masterSprite, out int spriteIndex, out int spriteId, int newIndex = -1, int groupId = -1) {
                if(desiredName == null) desiredName = defaultSpriteName + "0"; // no name given, use the default

                string spriteName = data.FindNewSpriteName(desiredName, groupId); // get a new unique sprite name in this group

                // Create a new master sprite on disk to store editor data
                string editorMasterSpriteFileName = GetSpriteSOFileName(spriteName, MasterSpriteType.Editor, groupId);
                string editorMasterSpritePath = GetSpriteSOPath(spriteName, MasterSpriteType.Editor, groupId);
                CreateScriptableObject<EditorMasterSprite>(editorMasterSpritePath); // create the so on disk
                string editorMasterSpriteCorePath = GetSpriteCorePath(spriteName, groupId);
                CreateScriptableObject<EditorMasterSpriteCore>(editorMasterSpriteCorePath); // create core so file on disk
                ImportAssetRel(editorMasterSpritePath); // make sure new prefab is imported
                ImportAssetRel(editorMasterSpriteCorePath); // make sure new core prefab is imported
                masterSprite = LoadEditorMasterSprite(editorMasterSpritePath); // get the source sprite

                spriteIndex = data.CreateNewSpriteInGroup(editorMasterSpriteFileName, spriteName, groupId, newIndex); // create the sprite entry in data
                spriteId = data.GetSpriteId(spriteIndex); // get sprite id

                masterSprite.name = spriteName; // save the name in the master sprite also
                masterSprite.coreFileName = GetSpriteCoreFileName(spriteName, groupId);
                EditorMasterSprite.Data masterSpriteData = masterSprite.data = new EditorMasterSprite.Data(masterSprite, spriteName); // fill data in sprite and set parent to self
                masterSprite.data = masterSpriteData;
                masterSpriteData.spriteGroupId = groupId; // set group id
                masterSpriteData.useDefaultAtlasTextureFilterMode = true;
                masterSpriteData.atlasTextureFilterMode = defaultFilterMode; // set filter mode
                masterSpriteData.atlasTextureAnisoLevel = -1; // set aniso level to default
                masterSpriteData.editorMaterialSets = GetDefaultMaterialSets(); // create default material set
                masterSpriteData.editorUseTwoSidedMesh = BoolDefaultOption.Default; // set default two sided mesh use
                masterSpriteData.gameSettings = gameSettings; // store link to game settings

                // Create a new editor material on disk
                Material editorPreviewMaterial = CreateEditorMaterial(spriteName, groupId);
                masterSpriteData.SetEditorMaterial(editorPreviewMaterial); // save link to material

                // Create a mesh on disk
                CreateEditorMeshes(masterSprite.data, groupId, defaultUseTwoSidedMesh, false); // create meshes and save link in master sprite
                Mesh[] editorPreviewMeshes = masterSpriteData.editorPreviewMeshes;

                // Save
                masterSprite.SetDirtyForSave(true); // tell unity to save the sprite prefab changes to disk, save core too

                // Create a new master sprite on disk to store the finished Sprite data
                string gameMasterSpriteFileName = GetSpriteSOFileName(spriteName, MasterSpriteType.Game, groupId);
                string gameMasterSpritePath = GetSpriteSOPath(spriteName, MasterSpriteType.Game, groupId);
                CreateScriptableObject<GameMasterSprite>(gameMasterSpritePath); // create the so on disk
                ImportAssetRel(gameMasterSpritePath); // make sure new prefab is imported
                GameMasterSprite gameDataMasterSprite = LoadGameMasterSprite(gameMasterSpritePath); // get the source sprite
                Sprite.SharedData sharedData;
                gameDataMasterSprite.data = masterSprite.data.ConvertToSpriteData(data.settings, out sharedData); // create sprite data out of master data
                gameDataMasterSprite.sharedData = sharedData;
                EditorUtility.SetDirty(gameDataMasterSprite); // tell unity to save the sprite prefab changes to disk

                // Save prefab locations in sprite editor data
                data.SaveSpriteFileData(spriteIndex, groupId, editorMasterSpriteFileName, gameMasterSpriteFileName, Path.GetFileName(GetAssetPathRel(editorPreviewMeshes[0])), Path.GetFileName(GetAssetPathRel(editorPreviewMaterial)));
                EditorUtility.SetDirty(data); // tell unity to save the editor data prefab changes to disk

                AssetDatabase.SaveAssets(); // save assets now
            }

            private void CreateNewSpriteGroup(int index = -1) {
                CreateNewSpriteGroup(null, index); // create new group with default name  
            }

            private void CreateNewSpriteGroup(string desiredName, int index = -1) {
                if(desiredName == null) desiredName = defaultGroupName + "0"; // no name given, use the default

                // Create the group objects
                string newGroupName = data.FindNewGroupName(desiredName); // find the next available group name
                CreateScriptableObject<SpriteGroup>(GetSpriteGroupFilePath(newGroupName)); // create sprite group object

                // Create the group settings in data and group objects
                data.CreateNewSpriteGroup(newGroupName, userDefaultMaterial, defaultFilterMode, -1, index);
            }

            private Material CreateEditorMaterial(string spriteName, int groupId, Material sourceMaterial = null) { // called when creating an editor material or whatever. Source isn't necessarily expected.
                CheckMaterial(ref sourceMaterial, false); // check for problems on material, get default material if problems found

                string newMatPath = GetMaterialFilePath(editorMaterialSuffix, spriteName, data.GetSpriteGroupNameById(groupId));
                if(FileExistsRel(newMatPath)) return LoadAssetAtPathRel<Material>(newMatPath); // material already exists, just load it

                Material newMaterial = new Material(sourceMaterial); // clone the default material
                string dirPath = Path.GetDirectoryName(newMatPath);
                if(!DirectoryExistsRel(dirPath)) CreateDirectoryRel(dirPath); // create directory if it doesn't exist
                CreateAssetRel(newMaterial, newMatPath); // create new asset (deletes old if exists)
                ImportAssetRel(newMatPath);
                return LoadAssetAtPathRel<Material>(newMatPath);
            }

            private Material CreateMaterial(string fullPath, Material sourceMaterial, string mainTexGuid = null, bool saveNow = false) { // this is used when creating a MaterialSet material for an atlas, source is expected
                if(!fullPath.ToLower().EndsWith(materialExtension.ToLower())) fullPath += materialExtension; // append extension if missing
                CheckMaterial(ref sourceMaterial, true); // check for problems on material, get default material if problems found

                Material newMaterial = new Material(sourceMaterial); // clone the source material
                CreateAssetRel(newMaterial, fullPath); // create new asset (deletes old if exists)
                ImportAssetRel(fullPath);
                Material savedMat = LoadAssetAtPathRel<Material>(fullPath);

                // Apply texture to main tex and save
                if(mainTexGuid != null) {
                    TextureLoader tl = new TextureLoader(mainTexGuid);
                    savedMat.mainTexture = tl.texture; // set texture in material
                    tl.FreeMemory(); // free memory after loading the texture
                    EditorUtility.SetDirty(savedMat); // flag for saving
                    if(saveNow) AssetDatabase.SaveAssets(); // save assets now
                }

                return savedMat;
            }

            private void CheckMaterial(ref Material material, bool warnIfSubstituteDefault = false) {

                // Check source material for compatibility
                if(material == null) {
                    // try to get default material from editor properties first
                    material = userDefaultMaterial;
                    if(warnIfSubstituteDefault) Debug.LogWarning("Source material missing in MaterialSet! Substituting default sprite material!");
                }
                if(!CheckMaterialForCompatibility(material)) { // material is not compatible
                    Debug.LogWarning("Source material in MaterialSet does not have a \"_MainTex\" property and is incompatible!");

                    bool trueDefaultFailed = false;
                    Material userDefault = userDefaultMaterial;
                    if(material == userDefault) { // user default was incompatible, try using the regular default
                        if(material == _defaultSpriteMaterial) { // this is also the true default
                            trueDefaultFailed = true;
                        } else {
                            Debug.Log("User default sprite material does not have a \"_MainTex\" property on its shader!");
                            material = _defaultSpriteMaterial; // substitute the true default
                            if(!CheckMaterialForCompatibility(material)) { // true default failed too
                                trueDefaultFailed = true;
                            }
                        }
                    } else if(material == _defaultSpriteMaterial)
                        trueDefaultFailed = true;

                    if(material == _defaultSpriteMaterial && trueDefaultFailed) {
                        Debug.LogError("Default sprite material has been modified and does not have a \"_MainTex\" property on its shader! Cannot create atlases!");
                    } else {
                        Debug.LogWarning("Substituting default sprite material!");
                    }
                }
            }

            private int DuplicateSprite(int spriteIndex, int listIndex, bool remakeAtlases = true, bool remakeMaterials = true, bool remakeMeshes = true, bool overrideGroup = false, int groupOverrideId = -1, bool updateGroups = true) {
                EditorMasterSprite newSprite;
                EditorMasterSprite oldSprite = GetEditorMasterSprite(spriteIndex);
                if(oldSprite == null) { // master sprite is missing
                    Debug.LogError("Master Sprite file is missing! Cannot duplicate Master Sprite!");
                    return -1;
                }

                string oldSpriteName = data.GetSpriteName(spriteIndex);

                // Get groupId
                int groupId;
                if(overrideGroup) groupId = groupOverrideId; // override the group id with a different one to create sprite in a different group
                else groupId = data.GetSpriteGroupIdOfSpriteByIndex(spriteIndex);

                int newListIndex;
                if(listIndex >= 0) newListIndex = listIndex + 1; // put copy below original in list
                else newListIndex = -1; // ignore list position, just add to end
                int newSpriteIndex;
                int newSpriteId;

                CreateNewMasterSprite(oldSpriteName, out newSprite, out newSpriteIndex, out newSpriteId, newListIndex, groupId);

                // Backup some data before copying
                EditorMasterSprite.Data newSpriteData = newSprite.data;
                string backupEditorMaterialGUID = newSpriteData.editorMaterialGUID; // Store default material before deep copy so we don't lose the link to the new material. Kinda hacky but...
                Mesh[] backupEditorPreviewMeshes = newSpriteData.editorPreviewMeshes; // Store before deep copy so we don't lose the link to the new meshes. Kinda hacky but...

                // Copy sprite data from original to copy
                newSpriteData = oldSprite.data.DeepCopy(newSprite);

                // Copy backed-up data back
                newSpriteData.name = newSprite.name; // restore name after deep copy
                newSpriteData.editorMaterialGUID = backupEditorMaterialGUID; // restore the old default material after deep copy
                newSpriteData.editorPreviewMeshes = backupEditorPreviewMeshes; // restore the old meshes after deep copy
                newSpriteData.spriteGroupId = groupId; // set group id after deep copy because the group id set above would have been lost

                newSprite.data = newSpriteData; // copy the data into the sprite

                SaveSprite(newSprite.data, newSpriteIndex, groupId, remakeAtlases, remakeMaterials, remakeMeshes, updateGroups, false, true, false); // save sprite
                return newSpriteIndex;
            }

            private EditorMasterSprite.MaterialSet[] GetDefaultMaterialSets() {
                return new EditorMasterSprite.MaterialSet[1] { new EditorMasterSprite.MaterialSet(defaultMaterialSetName, true, userDefaultMaterial) };
            }

            #endregion

            #region EDITOR MESHES

            private void CreateEditorMeshes(EditorMasterSprite.Data masterSpriteData, int groupId, bool twoSided, bool saveNow = false) {
                Mesh[] meshes;

                string newMeshPath = GetEditorMeshFilePath(masterSpriteData.name, data.GetSpriteGroupNameById(groupId)); // meshSavePath + directoryDelimiter + spriteName + fileNameDelimiter + editorMeshSuffix + assetExtension;
                if(FileExistsRel(newMeshPath)) {
                    meshes = ConvertEditorMeshes(newMeshPath, twoSided, true); // mesh already exists, make sure right type, save changes now
                    masterSpriteData.editorPreviewMeshes = meshes; // assign to master sprite
                    return;
                }

                // Create 4 meshes, normal, xflipped, yflipped, and xyflipped
                meshes = new Mesh[4];

                Mesh mesh = RebuildEditorMesh(new Mesh(), twoSided); // start with normal
                string dirPath = Path.GetDirectoryName(newMeshPath);
                if(!DirectoryExistsRel(dirPath)) CreateDirectoryRel(dirPath); // create directory if it doesn't exist
                CreateAssetRel(mesh, newMeshPath); // create new asset (deletes old if exists)
                mesh.name = "mesh";
                EditorUtility.SetDirty(mesh);
                meshes[0] = mesh;

                // Add 3 other meshes to same object
                Mesh newMesh = RebuildEditorMesh(new Mesh(), twoSided); // x-flipped mesh
                newMesh.name = "mesh_xflipped";
                FlipMesh(newMesh, true, false); // flip mesh on x
                AssetDatabase.AddObjectToAsset(newMesh, mesh);
                meshes[1] = newMesh;

                newMesh = RebuildEditorMesh(new Mesh(), twoSided); // y-flipped mesh
                newMesh.name = "mesh_yflipped";
                FlipMesh(newMesh, false, true); // flip mesh on y
                AssetDatabase.AddObjectToAsset(newMesh, mesh);
                meshes[2] = newMesh;

                newMesh = RebuildEditorMesh(new Mesh(), twoSided); // xy-flipped mesh
                newMesh.name = "mesh_xyflipped";
                FlipMesh(newMesh, true, true); // flip mesh on xy
                AssetDatabase.AddObjectToAsset(newMesh, mesh);
                meshes[3] = newMesh;
                
                ImportAssetRel(newMeshPath);
                if(saveNow) AssetDatabase.SaveAssets(); // save to make sure changes to names stick

                masterSpriteData.editorPreviewMeshes = meshes; // assign to master sprite
            }

            private Mesh[] ConvertEditorMeshes(string path, bool convertToTwoSided, bool saveNow = false) {
                Mesh[] meshes = LoadAssetsAtPathRel<Mesh>(path);
                if(meshes == null) {
                    Debug.LogError("No mesh files found at path: " + path);
                    return null;
                }

                // Reorder editor meshes so they come in the order we expect
                Mesh[] reorderedMeshes = new Mesh[4];
                reorderedMeshes[0] = FindMeshByName(meshes, "mesh");
                reorderedMeshes[1] = FindMeshByName(meshes, "mesh_xflipped");
                reorderedMeshes[2] = FindMeshByName(meshes, "mesh_yflipped");
                reorderedMeshes[3] = FindMeshByName(meshes, "mesh_xyflipped");

                return ConvertEditorMeshes(reorderedMeshes, convertToTwoSided, saveNow);
            }

            private Mesh[] ConvertEditorMeshes(Mesh[] meshes, bool convertToTwoSided, bool saveNow = false) {
                for(int i = 0; i < meshes.Length; i++) {
                    Mesh mesh = meshes[i];

                    // We can no longer detect the type like this because of custom meshes. Just always rebuild.
                    //bool isMeshTwoSided = mesh.vertexCount == 8 ? true : false;
                    //if(isMeshTwoSided == convertToTwoSided) continue; // mesh is already the right type

                    RebuildEditorMesh(mesh, convertToTwoSided);
                    EditorUtility.SetDirty(mesh);
                }

                if(saveNow) AssetDatabase.SaveAssets(); // save

                return meshes;
            }

            private Mesh RebuildEditorMesh(Mesh mesh, bool twoSided) {
                Vector3[] newVertices;
                Vector2[] newUV;
                int[] newTriangles;

                if(!twoSided) { // single sided mesh
                    // +X = right
                    // +Y = up
                    // vert 0 = lower left
                    // vert 1 = lower right
                    // vert 2 = upper left
                    // vert 3 = upper right

                    newVertices = new Vector3[4] {
                        new Vector3(-0.5f, -0.5f, 0.0f), // lower left
                        new Vector3(0.5f, -0.5f, 0.0f), // lower right
                        new Vector3(-0.5f, 0.5f, 0.0f), // upper left
                        new Vector3(0.5f, 0.5f, 0.0f) // upper right
                    };

                    // +X = right
                    // +Y = up
                    // uv 0 = lower left
                    // uv 1 = lower right
                    // uv 2 = upper left
                    // uv 3 = upper right
                    newUV = new Vector2[4] {
                        new Vector2(0.0f, 0.0f), // lower left
                        new Vector2(1.0f, 0.0f), // lower right
                        new Vector2(0.0f, 1.0f), // upper left
                        new Vector2(1.0f, 1.0f) // upper right
                    };

                    // clockwise winding order to make sure normals face the right way
                    newTriangles = new int[6] {
                        0, 2, 1,
                        2, 3, 1
                    };

                } else { // two sided mesh

                    // +X = right
                    // +Y = up
                    // vert 0 = lower left
                    // vert 1 = lower right
                    // vert 2 = upper left
                    // vert 3 = upper right
                    // vert 4 = lower left (same as front)
                    // vert 5 = lower right (same as front)
                    // vert 6 = upper left (same as front)
                    // vert 7 = upper right (same as front)

                    newVertices = new Vector3[8] {
                        new Vector3(-0.5f, -0.5f, 0.0f), // lower left
                        new Vector3(0.5f, -0.5f, 0.0f), // lower right
                        new Vector3(-0.5f, 0.5f, 0.0f), // upper left
                        new Vector3(0.5f, 0.5f, 0.0f), // upper right
                        new Vector3(-0.5f, -0.5f, 0.0f), // lower left (back)
                        new Vector3(0.5f, -0.5f, 0.0f), // lower right (back)
                        new Vector3(-0.5f, 0.5f, 0.0f), // upper left (back)
                        new Vector3(0.5f, 0.5f, 0.0f) // upper right (back)
                    };

                    // +X = right
                    // +Y = up
                    // uv 0 = lower left
                    // uv 1 = lower right
                    // uv 2 = upper left
                    // uv 3 = upper right
                    // uv 4 = lower left (same as front)
                    // uv 5 = lower right (same as front)
                    // uv 6 = upper left (same as front)
                    // uv 7 = upper right (same as front)
                    newUV = new Vector2[8] {
                        new Vector2(0.0f, 0.0f), // lower left
                        new Vector2(1.0f, 0.0f), // lower right
                        new Vector2(0.0f, 1.0f), // upper left
                        new Vector2(1.0f, 1.0f), // upper right
                        new Vector2(0.0f, 0.0f), // lower left (back)
                        new Vector2(1.0f, 0.0f), // lower right (back)
                        new Vector2(0.0f, 1.0f), // upper left (back)
                        new Vector2(1.0f, 1.0f) // upper right (back)
                    };

                    // clockwise winding order to make sure normals face the right way
                    newTriangles = new int[12] {
                        0, 2, 1,
                        2, 3, 1,
                        5, 6, 4, // reverse order to flip normal to back
                        5, 7, 6  // reverse order to flip normal to back
                    };
                }

                mesh.Clear();
                mesh.colors = null; // clear colors - BUG - unity keeps adding colors back to meshes when mesh.Clear() is called I think
                mesh.vertices = newVertices;
                mesh.uv = newUV;
                mesh.triangles = newTriangles;
                mesh.RecalculateBounds(); // even though the docs say assigning triangles will do this, it does not and we must do it manually
                mesh.RecalculateNormals();

                return mesh;
            }

            private void UpdateEditorMesh(EditorMasterSprite.Data masterSpriteData, int groupId) {
                Mesh[] meshes = masterSpriteData.editorPreviewMeshes; // get the mesh on disk
                if(meshes == null || meshes.Length == 0 || meshes[0] == null) { // editor preview meshes are missing, recreate
                    CreateEditorMeshes(masterSpriteData, groupId, GetTwoSidedMode(masterSpriteData.editorUseTwoSidedMesh)); // this will try to load them first
                    meshes = masterSpriteData.editorPreviewMeshes;
                    // EditorUtility.SetDirty( can't do this here because we don't have the MasterSprite, so this MUST be done upstream
                }

                string failMsg = "! Sprite will not display correctly in the editor!";
                string spriteName = masterSpriteData.name;

                EditorMasterSprite.Frame editorPreviewFrame = masterSpriteData.GetEditorPreviewFrame();
                if(editorPreviewFrame == null) { // frame is missing
                    Debug.LogWarning("No frames found in the default animation on " + spriteName + failMsg);
                    return;
                }

                int atlasIndex = editorPreviewFrame.atlasIndex;
                if(atlasIndex < 0) {
                    Debug.LogWarning("Default animation is missing atlas on " + spriteName + failMsg);
                    return;
                }

                EditorMasterSprite.Atlas[] atlases = masterSpriteData.editorAtlases;
                if(atlases == null || atlases.Length == 0) {
                    Debug.LogWarning("No atlases found for the default animation on " + spriteName + failMsg);
                    return;
                }

                EditorMasterSprite.Atlas atlas = atlases[atlasIndex];
                if(atlas == null || !atlas.hasTexture) {
                    Debug.LogWarning("Default animation is missing atlas on " + spriteName + failMsg);
                    return;
                }

                bool twoSidedMesh = GetTwoSidedMode(masterSpriteData.editorUseTwoSidedMesh);
                Mesh mesh = meshes[0];
                Vector3[] verts;
                Vector2[] uvs;
                int[] triangles;
                Vector3[] normals = null;
                // Offset for frame offset
                float offsetX = editorPreviewFrame.frameOffset.x;
                float offsetY = editorPreviewFrame.frameOffset.y;

                if(!masterSpriteData.finalUseCustomMesh) { // using the default plane mesh

                    ConvertEditorMeshes(meshes, twoSidedMesh, false); // rebuild mesh making it 1 or 2 sided as necessary

                    // Get data from the mesh
                    verts = mesh.vertices;
                    uvs = mesh.uv;
                    triangles = mesh.triangles;
                    normals = mesh.normals;

                    float extentsX = editorPreviewFrame.meshExtents.x;
                    float extentsY = editorPreviewFrame.meshExtents.y;

                    if(!twoSidedMesh) { // one-sided mesh

                        // Update uv positions in mesh
                        Rect uvCoords = editorPreviewFrame.uvCoords;
                        uvs[0] = new Vector2(uvCoords.x, uvCoords.y); // lower left
                        uvs[1] = new Vector2(uvCoords.x + uvCoords.width, uvCoords.y); // lower right
                        uvs[2] = new Vector2(uvCoords.x, uvCoords.y + uvCoords.height); // upper left
                        uvs[3] = new Vector2(uvCoords.x + uvCoords.width, uvCoords.y + uvCoords.height); // upper right

                        // Update mesh shape
                        // vert 0 = lower left
                        // vert 1 = lower right
                        // vert 2 = upper left
                        // vert 3 = upper right

                        // Set vert positions to match the shape of our trimmed sprite
                        verts[0].x = -extentsX;
                        verts[0].y = -extentsY;
                        verts[1].x = extentsX;
                        verts[1].y = verts[0].y;
                        verts[2].x = verts[0].x;
                        verts[2].y = extentsY;
                        verts[3].x = verts[1].x;
                        verts[3].y = extentsY;

                        // Offset all verts if we have any trim or frame offset
                        if(offsetX != 0.0f || offsetY != 0.0f) { // we have some offset
                            verts[0].x += offsetX;
                            verts[0].y += offsetY;
                            verts[1].x += offsetX;
                            verts[1].y += offsetY;
                            verts[2].x += offsetX;
                            verts[2].y += offsetY;
                            verts[3].x += offsetX;
                            verts[3].y += offsetY;
                        }

                    } else { // two-sided mesh

                        // Update uv positions in mesh
                        Rect uvCoords = editorPreviewFrame.uvCoords;
                        uvs[0] = new Vector2(uvCoords.x, uvCoords.y); // lower left
                        uvs[1] = new Vector2(uvCoords.x + uvCoords.width, uvCoords.y); // lower right
                        uvs[2] = new Vector2(uvCoords.x, uvCoords.y + uvCoords.height); // upper left
                        uvs[3] = new Vector2(uvCoords.x + uvCoords.width, uvCoords.y + uvCoords.height); // upper right
                        uvs[4] = uvs[0];
                        uvs[5] = uvs[1];
                        uvs[6] = uvs[2];
                        uvs[7] = uvs[3];

                        // Update mesh shape
                        // vert 0 = lower left
                        // vert 1 = lower right
                        // vert 2 = upper left
                        // vert 3 = upper right

                        // Set vert positions to match the shape of our trimmed sprite
                        verts[0].x = -extentsX;
                        verts[0].y = -extentsY;
                        verts[1].x = extentsX;
                        verts[1].y = verts[0].y;
                        verts[2].x = verts[0].x;
                        verts[2].y = extentsY;
                        verts[3].x = verts[1].x;
                        verts[3].y = extentsY;
                        verts[4].x = verts[0].x;
                        verts[4].y = verts[0].y;
                        verts[5].x = verts[1].x;
                        verts[5].y = verts[1].y;
                        verts[6].x = verts[2].x;
                        verts[6].y = verts[2].y;
                        verts[7].x = verts[3].x;
                        verts[7].y = verts[3].y;

                        // Offset all verts if we have any trim or frame offset
                        if(offsetX != 0.0f || offsetY != 0.0f) { // we have some offset
                            verts[0].x += offsetX;
                            verts[0].y += offsetY;
                            verts[1].x += offsetX;
                            verts[1].y += offsetY;
                            verts[2].x += offsetX;
                            verts[2].y += offsetY;
                            verts[3].x += offsetX;
                            verts[3].y += offsetY;
                            verts[4].x = verts[0].x;
                            verts[4].y = verts[0].y;
                            verts[5].x = verts[1].x;
                            verts[5].y = verts[1].y;
                            verts[6].x = verts[2].x;
                            verts[6].y = verts[2].y;
                            verts[7].x = verts[3].x;
                            verts[7].y = verts[3].y;
                        }
                    }

                } else { // using a custom mesh

                    EditorMasterSprite.MeshFrame meshFrame = masterSpriteData.GetEditorPreviewMeshFrame();
                    if(meshFrame == null) return;

                    Vector2[] sourceVertices = meshFrame.vertices; // get the mesh vertices from the editor mesh frame
                    if(sourceVertices == null || sourceVertices.Length == 0) return; // failed

                    Vector2[] sourceUVs = meshFrame.uvs;
                    int[] sourceTriangles = meshFrame.triangles;
                    int vertexCount = sourceVertices.Length;
                    int triangleCount = sourceTriangles.Length;
                    int finalVertCount = twoSidedMesh ? vertexCount * 2 : vertexCount;
                    int finalTriangleCount = twoSidedMesh ? triangleCount * 2 : triangleCount;

                    // Get data from frame
                    SpriteFactory.Utils.DataClasses.IntVector2 framePixelOffset = editorPreviewFrame.framePixelOffset;
                    SpriteFactory.Utils.DataClasses.IntRect pixelUVRect = editorPreviewFrame.pixelUVRect;
                    int pixelOffsetX = framePixelOffset.x;
                    int pixelOffsetY = framePixelOffset.y;

                    // UVs - must go first because we will be modifying the vertices in the meshFrame

                    // Scale UVs to fit into atlas
                    // UVs must be laid out on original untrimmed texture size
                    // UVs may extend beyond 0-1 if we have extrude distance and the graphics go up to the edge

                    // Incoming UVs are already offset for trim and extrude

                    float uvScaleX = 1.0f / atlas.width; // the scale to fit this texture into the UV sheet
                    float uvScaleY = 1.0f / atlas.height;

                    // Copy the UVs and offset and scale
                    Vector2[] targetUVs = new Vector2[finalVertCount];
                    float resolutionTargetScale = this.resolutionTargetScale;
                    for(int i = 0; i < vertexCount; i++) {
                        targetUVs[i].x = (sourceUVs[i].x + pixelUVRect.x) * uvScaleX;
                        targetUVs[i].y = (sourceUVs[i].y + pixelUVRect.y) * uvScaleY;
                    }

                    // Vertices
                    float centerOffsetX = meshFrame.pixelCenterOffsetX;
                    float centerOffsetY = meshFrame.pixelCenterOffsetY;

                    // Apply frame offset
                    if(framePixelOffset != null) {
                        centerOffsetX += framePixelOffset.x;
                        centerOffsetY += framePixelOffset.y;
                    }

                    // Adjust to prevent 1/2 pixel misalignment to be consistent with the way we handle rect meshes
                    if(SpriteFactory.Utils.MathTools.IsNearOrWholeNumber(data.settings.resolutionTargetScaleInverseMultiplier)) { // only do pixel snap on resolution targets that have even scaling
                        SpriteFactory.Utils.MiscTools.SnapToPixel(ref centerOffsetX, ref centerOffsetY);
                    }

                    // Scale verts so mesh is the proper size and apply offset so its centered
                    float vertScale = 1.0f / (float)pixelsPerUnit; // the scale to make the mesh the proper size in the world
                    Vector3[] targetVertices = new Vector3[finalVertCount];
                    for(int i = 0; i < vertexCount; i++) {
                        targetVertices[i].x = (sourceVertices[i].x + centerOffsetX) * vertScale;
                        targetVertices[i].y = (sourceVertices[i].y + centerOffsetY) * vertScale;
                    }

                    // Set normals
                    normals = new Vector3[finalVertCount];
                    for(int i = 0; i < vertexCount; i++) { // front side normals
                        normals[i] = new Vector3(0.0f, 0.0f, -1.0f);
                    }

                    // Set Triangles
                    int[] targetTriangles = new int[finalTriangleCount];
                    for(int i = 0; i < triangleCount; i++) { // copy front side triangles
                        targetTriangles[i] = sourceTriangles[i];
                    }

                    // Bake two-sided meshes
                    if(twoSidedMesh) {

                        // Duplicate verts and uvs for backside
                        for(int i = vertexCount; i < finalVertCount; i++) {
                            targetVertices[i] = targetVertices[i - vertexCount];
                            targetUVs[i] = targetUVs[i - vertexCount];
                        }

                        // Triangles

                        // Copy reversing winding order of back side triangles to flip normal
                        for(int i = triangleCount; i < targetTriangles.Length; i += 3) {
                            int sourceIndex = i - triangleCount;
                            targetTriangles[i] = sourceTriangles[sourceIndex + 2] + vertexCount;
                            targetTriangles[i + 1] = sourceTriangles[sourceIndex + 1] + vertexCount;
                            targetTriangles[i + 2] = sourceTriangles[sourceIndex] + vertexCount;
                        }

                        // Set normals
                        for(int i = vertexCount; i < finalVertCount; i++) { // back side normals
                            normals[i] = new Vector3(0.0f, 0.0f, 1.0f);
                        }

                    }

                    // Set final arrays
                    verts = targetVertices;
                    uvs = targetUVs;
                    triangles = targetTriangles;
                }

                // Build the mesh
                mesh.Clear();
                mesh.colors = null; // clear colors - BUG - unity keeps adding colors back to meshes when mesh.Clear() is called I think
                mesh.vertices = verts; // update verts in the mesh
                mesh.uv = uvs; // update uvs in mesh
                mesh.triangles = triangles;
                if(normals == null) mesh.RecalculateNormals();
                else mesh.normals = normals;
                mesh.RecalculateBounds(); // update the bounds
                
                EditorUtility.SetDirty(mesh); // flag for saving

                // Remake flipped meshes with new shape
                CopyChangeToFlippedEditorMeshes(meshes, GetTwoSidedMode(masterSpriteData.editorUseTwoSidedMesh));
            }

            private void CopyChangeToFlippedEditorMeshes(Mesh[] meshes, bool twoSidedMesh) {
                Mesh primaryMesh = meshes[0];
                if(primaryMesh == null) {
                    Debug.LogError("Editor mesh missing!");
                    return;
                }

                Vector3[] verts = primaryMesh.vertices;
                Vector2[] uvs = primaryMesh.uv;
                int[] triangles = primaryMesh.triangles;
                Vector3[] normals = primaryMesh.normals;

                // Copy settings to other flipped meshes
                // Make it easier by reverting each mesh back to the normal state, then flipping

                // x-flipped
                Mesh mesh = meshes[1];
                if(mesh == null) {
                    Debug.LogError("Editor x mesh missing!");
                } else {
                    mesh.Clear();
                    mesh.colors = null; // clear colors - BUG - unity keeps adding colors back to meshes when mesh.Clear() is called I think
                    mesh.vertices = verts; // copy primary's verts to mesh
                    mesh.uv = uvs; // copy uvs to mesh
                    mesh.normals = normals;
                    mesh.triangles = triangles; // copy triangles to mesh
                    // we should recalc bounds but we'll do that in FlipMesh
                    FlipMesh(mesh, true, false); // flip mesh on X
                    EditorUtility.SetDirty(mesh); // flag for saving
                }

                // y-flipped
                mesh = meshes[2];
                if(mesh == null) {
                    Debug.LogError("Editor y mesh missing!");
                } else {
                    mesh.Clear();
                    mesh.colors = null; // clear colors - BUG - unity keeps adding colors back to meshes when mesh.Clear() is called I think
                    mesh.vertices = verts; // copy primary's verts to mesh
                    mesh.uv = uvs; // copy uvs to mesh
                    mesh.normals = normals;
                    mesh.triangles = triangles; // copy triangles to mesh
                    // we should recalc bounds but we'll do that in FlipMesh
                    FlipMesh(mesh, false, true); // flip mesh on Y
                    EditorUtility.SetDirty(mesh); // flag for saving
                }

                // xy-flipped
                mesh = meshes[3];
                if(mesh == null) {
                    Debug.LogError("Editor xy mesh missing!");
                } else {
                    mesh.Clear();
                    mesh.colors = null; // clear colors - BUG - unity keeps adding colors back to meshes when mesh.Clear() is called I think
                    mesh.vertices = verts; // copy primary's verts to mesh
                    mesh.uv = uvs; // copy uvs to mesh
                    mesh.normals = normals;
                    mesh.triangles = triangles; // copy triangles to mesh
                    // we should recalc bounds but we'll do that in FlipMesh
                    FlipMesh(mesh, true, true); // flip mesh on X and Y
                    EditorUtility.SetDirty(mesh); // flag for saving
                }
            }

            private void UpdateEditorPreviewMeshOnSprite(EditorMasterSprite masterSprite, int groupId, Sprite sprite) {
                EditorMasterSprite.Data masterSpriteData = masterSprite.data;

                string failMsg = "! Sprite will not display correctly in the editor!";
                string spriteName = sprite.gameObject.name;

                MeshFilter meshFilter = sprite.GetComponent<MeshFilter>(); // get mesh filter on sprite
                if(meshFilter == null) {
                    Debug.LogError("MeshFilter component missing on " + spriteName + failMsg);
                    return;
                }

                Mesh[] meshes = masterSpriteData.editorPreviewMeshes;
                if(meshes == null || meshes[0] == null) { // mesh may have been deleted, try to fix
                    CreateEditorMeshes(masterSpriteData, groupId, GetTwoSidedMode(masterSpriteData.editorUseTwoSidedMesh), false); // load or create the mesh again
                    masterSprite.SetDirtyForSave(true); // save master and core
                }
                Mesh mesh = meshes[0];
                if(meshFilter.sharedMesh != mesh) { // mesh changed, update on sprite
                    // do it via SerializedObject
                    SerializedObject so = new SerializedObject(meshFilter);
                    so.Update();

                    SerializedProperty sp = so.FindProperty("m_Mesh");
                    if(sp == null) Debug.LogError("m_Mesh not found in MeshRenderer!");
                    sp.objectReferenceValue = mesh; // restore default material

                    so.ApplyModifiedProperties();
                }
            }

            private void FlipMesh(Mesh mesh, bool flipX, bool flipY) {
                SpriteFactory.Utils.UnityTools.FlipMesh(mesh, mesh.vertices, mesh.triangles, flipX, flipY);
            }

            private Mesh FindMeshByName(Mesh[] meshes, string name) {
                if(meshes == null || meshes.Length == 0) return null;
                for(int i = 0; i < meshes.Length; i++) {
                    if(meshes[i].name == name) return meshes[i];
                }
                return null;
            }

            private bool GetTwoSidedMode(BoolDefaultOption twoSidedMode) {
                bool twoSided;
                if(twoSidedMode == BoolDefaultOption.Default) twoSided = defaultUseTwoSidedMesh;
                else if(twoSidedMode == BoolDefaultOption.True) twoSided = true;
                else twoSided = false;
                return twoSided;
            }

            #endregion

            #region UPDATE / REBUILD / REPAIR / ASSIGN

            public void RebuildAllSpritesAndGroups(bool isUpgradeRebuild = false) {
                CheckInitialized();

                // Go through each sprite and group and re-save remaking atlases and materials
                // Also rebuilds all sprites

                // Update all sprites not in a group
                int[] ungroupedSpriteIds = data.GetUngroupedSpriteIds();
                if(ungroupedSpriteIds != null && ungroupedSpriteIds.Length > 0) {
                    for(int i = 0; i < ungroupedSpriteIds.Length; i++) {
                        int spriteId = ungroupedSpriteIds[i];
                        int spriteIndex = data.FindSpriteIndexBySpriteId(spriteId);
                        if(spriteIndex < 0) continue;
                        RebuildSprite(spriteIndex, true, true, false, isUpgradeRebuild);
                    }
                }

                // Update all sprite groups INCLUDING all the sprites in the group
                int[] spriteGroupsIndices = data.GetSpriteGroupIndices();
                if(spriteGroupsIndices != null && spriteGroupsIndices.Length > 0) {
                    for(int i = 0; i < spriteGroupsIndices.Length; i++) {
                        int groupIndex = spriteGroupsIndices[i];
                        int groupId = data.GetSpriteGroupId(groupIndex);
                        RefreshSpriteGroup(groupId, true, true, true, isUpgradeRebuild); // refresh the entire group, rebuild all sprites in group, and build atlases
                    }
                }

                // Collect garbage now
                System.GC.Collect();
            }

            private void RebuildChangedAtlases(int[] changedSpriteIndices, int[] changedGroupIds) {

                // Separate into sprites in groups and ungrouped sprites
                if(changedSpriteIndices != null) {
                    for(int i = 0; i < changedSpriteIndices.Length; i++) {
                        RebuildSprite(changedSpriteIndices[i], true, true, false, false); // rebuild the sprite now
                    }
                }

                // For groups, rebuild whole group (does NOT rebuild each sprite in group)
                if(changedGroupIds != null) {
                    for(int i = 0; i < changedGroupIds.Length; i++) {
                        RefreshSpriteGroup(changedGroupIds[i], false, true, true, false); // rebuild the group
                    }
                }
            }

            public void RebuildAllAtlases() {
                CheckInitialized();

                // Go through each sprite and group and re-save remaking atlases and materials

                // Update all sprites not in a group
                int[] ungroupedSpriteIds = data.GetUngroupedSpriteIds();
                if(ungroupedSpriteIds != null && ungroupedSpriteIds.Length > 0) {
                    for(int i = 0; i < ungroupedSpriteIds.Length; i++) {
                        int spriteId = ungroupedSpriteIds[i];
                        int spriteIndex = data.FindSpriteIndexBySpriteId(spriteId);
                        if(spriteIndex < 0) continue;
                        RebuildSprite(spriteIndex, true, true, false, false);
                    }
                }

                // Update all sprite groups (does NOT rebuild each sprite in group)
                int[] spriteGroupsIndices = data.GetSpriteGroupIndices();
                if(spriteGroupsIndices != null && spriteGroupsIndices.Length > 0) {
                    for(int i = 0; i < spriteGroupsIndices.Length; i++) {
                        int groupIndex = spriteGroupsIndices[i];
                        int groupId = data.GetSpriteGroupId(groupIndex);
                        RefreshSpriteGroup(groupId, false, true, true, false); // refresh the entire group and build atlases
                    }
                }
            }

            public void RebuildAllMaterials() {
                CheckInitialized();

                // Go through each sprite and group and re-save remaking materials only

                // Update all sprites not in a group
                int[] ungroupedSpriteIds = data.GetUngroupedSpriteIds();
                if(ungroupedSpriteIds != null && ungroupedSpriteIds.Length > 0) {
                    for(int i = 0; i < ungroupedSpriteIds.Length; i++) {
                        int spriteId = ungroupedSpriteIds[i];
                        int spriteIndex = data.FindSpriteIndexBySpriteId(spriteId);
                        if(spriteIndex < 0) continue;
                        RebuildSprite(spriteIndex, false, true, false, false);
                    }
                }

                // Update all sprite groups (does NOT rebuild each sprite in group)
                int[] spriteGroupsIndices = data.GetSpriteGroupIndices();
                if(spriteGroupsIndices != null && spriteGroupsIndices.Length > 0) {
                    for(int i = 0; i < spriteGroupsIndices.Length; i++) {
                        int groupIndex = spriteGroupsIndices[i];
                        int groupId = data.GetSpriteGroupId(groupIndex);
                        RefreshSpriteGroup(groupId, false, false, true, false); // refresh the entire group and build atlases
                    }
                }
            }

            private void RebuildSprite(int spriteIndex, bool rebuildAtlases, bool rebuildMaterials, bool updateGroups, bool isUpgradeRebuild) {
                EditorMasterSprite editorSprite = GetEditorMasterSprite(spriteIndex);
                if(editorSprite == null) return;
                int groupId = data.GetSpriteGroupIdOfSpriteByIndex(spriteIndex);
                SaveSprite(editorSprite.data, spriteIndex, groupId, rebuildAtlases, rebuildMaterials, false, updateGroups, false, false, isUpgradeRebuild); // save the sprite again remaking atlases and materials
            }

            private void UpdateSprite(EditorMasterSprite masterSprite, int spriteIndex, Sprite sprite) {
                // Called by SpriteFactoryEditor when updating a sprite in-scene
                // Uses SerializedObject to make changes instead of changing component values directly

                EditorMasterSprite.Data editorData = masterSprite.data;

                // Update masterSprite assignment
                UpdateMasterSpriteAssignmentOnSprite(masterSprite, spriteIndex, sprite);

                // Update material
                UpdateMaterialOnSprite(editorData, sprite);

                // Update mesh so we can display the sprite in the editor
                UpdateEditorPreviewMeshOnSprite(masterSprite, data.GetSpriteGroupIdOfSpriteByIndex(spriteIndex), sprite);
            }

            private void UpdateMasterSpriteAssignmentOnSprite(EditorMasterSprite masterSprite, int spriteIndex, Sprite sprite) {
                // ONLY update the master sprite Id and link to master game sprite

                // do it via SerializedObject
                GameMasterSprite gameSprite = LoadGameMasterSprite(data.GetGameSpriteFilePath(spriteIndex)); // load the game master sprite
                if(gameSprite == null) return; // failed

                // Get serialized object
                SerializedObject so = new SerializedObject(sprite);
                so.Update();

                // Update masterSprite reference
                SerializedProperty sp = so.FindProperty("gameMasterSprite");
                if(sp == null) Debug.LogError("gameMasterSprite not found in Sprite!");
                sp.objectReferenceValue = gameSprite;

                so.ApplyModifiedProperties();
            }

            private void UpdateMaterialOnSprite(EditorMasterSprite.Data masterSpriteData, Sprite sprite) {
                string failMsg = "Cannot update material on " + sprite.gameObject.name + "!";

                MeshRenderer mr = sprite.GetComponent<MeshRenderer>();
                if(mr == null) {
                    Debug.LogError("Missing MeshRenderer on Sprite! " + failMsg);
                    return;
                }

                Material mat = mr.sharedMaterial;
                Material editorMaterial = masterSpriteData.GetEditorMaterial();
                if(mat == null || mat != editorMaterial) { // material was lost, replace with default
                    // do it via SerializedObject
                    SerializedObject so = new SerializedObject(mr);
                    so.Update();

                    // Materials array
                    SerializedProperty sp = so.FindProperty("m_Materials.Array.size"); // get array size
                    if(sp == null) Debug.LogError("m_Materials.Array.size not found!");
                    if(sp.intValue != 1) sp.intValue = 1; // set array size to 1
                    sp = so.FindProperty("m_Materials.Array.data[0]"); // get 1st entry in array
                    if(sp == null) Debug.LogError("m_Materials.Array.data[0] not found!");
                    if(sp.objectReferenceValue != editorMaterial) sp.objectReferenceValue = editorMaterial; // set to sprite's default material

                    so.ApplyModifiedProperties();
                    return;
                }
            }

            public void AssignSprite(Sprite sprite, int spriteIndex, EditorMasterSprite editorMasterSprite) {
                CheckInitialized();

                EditorMasterSprite masterSprite = GetEditorMasterSprite(spriteIndex);
                if(masterSprite == null) return; // failed
                UpdateSprite(masterSprite, spriteIndex, sprite);
                AssetDatabase.SaveAssets(); // save changes if we had to fix any problems on master sprite or mesh
            }

            private void VerifyMasterSpriteAssets(EditorMasterSprite.Data masterSpriteData, int spriteIndex, int groupId) {

                // Editor Material
                Material material = masterSpriteData.GetEditorMaterial();
                if(material == null) { // material may have been deleted, try to fix
                    masterSpriteData.SetEditorMaterial(CreateEditorMaterial(masterSpriteData.name, groupId));
                    // is set dirty upstream
                }

                // Editor Preview Mesh
                Mesh[] meshes = masterSpriteData.editorPreviewMeshes;
                if(meshes == null || meshes[0] == null) { // mesh may have been deleted, try to fix
                    CreateEditorMeshes(masterSpriteData, groupId, GetTwoSidedMode(masterSpriteData.editorUseTwoSidedMesh)); // load or create the mesh again
                    // is set dirty upstream
                }
            }

            public void UpdateCacheVars() {
                CheckInitialized();

                cache.UpdateResolutionTargetCachePath(resolutionTargetTextureCacheSavePath); // cache is stored outside project folder, so no relative path required
            }

            #endregion

            #region CHECK

            public bool CheckTextureSize(Texture2D texture) {
                CheckInitialized();
                int scaledWidth;
                int scaledHeight;
                Utils.TextureTools.ScaleResolution(texture.width, texture.height, resolutionTargetScale, out scaledWidth, out scaledHeight);
                if(scaledWidth < maxAtlasSize || scaledHeight < maxAtlasSize) return true;
                string message = "The image \"" + texture.name + "\" is " + texture.width + "x" + texture.height + " and is too big for the max atlas size of " + maxAtlasSize + "x" + maxAtlasSize + " and will be skipped! ";
                if(maxAtlasSize < 4096) message += "Either increase the max atlas size or reduce the size of the image.";
                else message += "Reduce the size of the image.";
                Debug.Log(message);
                return false;
            }

            public bool CheckIfAnythingNeedsToBeRebuilt() {
                CheckInitialized();

                // Check for changed timestamps
                int[] changedSpritesIndices;
                int[] changedGroupIds;
                int changeCount = FindChangedSourceSprites(out changedSpritesIndices, out changedGroupIds);

                if(changeCount > 0) { // we have some changed atlases
                    string need;
                    string s;
                    if(changeCount == 1) {
                        need = " needs";
                        s = "";
                    } else {
                        need = " need";
                        s = "s";
                    }
                    if(EditorUtility.DisplayDialog("Rebuild", changeCount + " Master Sprite" + s + " or Sprite Group" + s + need + " to be rebuilt. This may take some time. Are you sure?", "Rebuild", "Cancel")) {
                        RebuildChangedAtlases(changedSpritesIndices, changedGroupIds);
                        return true;
                    }
                } else { // no changed atlases
                    EditorUtility.DisplayDialog("No Update Required", "Atlases are up to date.", "Okay");
                }

                // Check for missing source images
                // these may have gone missing since save (deleted by user) or could not be saved because of size problems, or deleted by user during edit but before save

                return false;
            }

            public bool CheckIfSourceImagesChanged(EditorMasterSprite.Data masterSpriteDataCopy, int spriteIndex, int currentGroupId) {
                CheckInitialized();

                if(currentGroupId != masterSpriteDataCopy.spriteGroupId) { // group is changing
                    // changing groups automatically rebuilds atlases so we don't want to waste time checking here
                    return false;
                }

                if(masterSpriteDataCopy.spriteGroupId < 0) // not in a group
                    return CheckIfSourceImagesChangedInSprite(masterSpriteDataCopy);
                else // in a group
                    return CheckIfSourceImagesChangedInSpriteGroup(masterSpriteDataCopy, spriteIndex);
            }

            private bool CheckIfSourceImagesChangedInSprite(EditorMasterSprite.Data masterSpriteDataCopy) {
                return masterSpriteDataCopy.CheckIfAnySourceImagesHaveChanged();
            }

            private bool CheckIfSourceImagesChangedInSpriteGroup(EditorMasterSprite.Data masterSpriteDataCopy, int spriteIndex) {
                // check all sprites in the group and see if any had frames that changed
                if(masterSpriteDataCopy.spriteGroupId < 0) { // not in a group. this should never happen.
                    return CheckIfSourceImagesChangedInSprite(masterSpriteDataCopy); // just check this sprite
                }

                int[] spriteIds = data.GetSpriteGroupSpriteIdsBySpriteGroupId(masterSpriteDataCopy.spriteGroupId); // get ids of sprites in this group
                if(spriteIds == null || spriteIds.Length == 0) return false;

                for(int i = 0; i < spriteIds.Length; i++) {
                    int savedSpriteIndex = data.FindSpriteIndexBySpriteId(spriteIds[i]);
                    if(savedSpriteIndex < 0) continue; // invalid
                    EditorMasterSprite.Data emsData;

                    if(savedSpriteIndex == spriteIndex) emsData = masterSpriteDataCopy; // this is the same sprite, so just use the working data instead of loading it
                    else {
                        EditorMasterSprite ems = GetEditorMasterSprite(savedSpriteIndex);
                        if(ems == null) continue;
                        emsData = ems.data; // get data
                    }

                    if(CheckIfSourceImagesChangedInSprite(emsData)) // a source image changed
                        return true; // it only takes one in the whole group, done
                }
                return false;
            }

            public bool IsDataSaved() {
                CheckInitialized();
                return data.IsSpriteDataSaved();
            }

            public bool CheckMaterialForCompatibility(Material material) {
                if(!material.HasProperty("_MainTex")) {
                    Debug.LogWarning("Material does not have a \"_MainTex\" property and is incompatible!");
                    return false;
                }
                return true;
            }

            #endregion

            #region EDITOR PROPERTIES

            public void ChangeEditorProperties(EditorProperties editorProperties, EditorPropertyChangeType changeType) {
                CheckInitialized();

                Settings settings = data.settings;
                if(settings == null) return;

                bool updateAtlases = (changeType & EditorPropertyChangeType.Atlases) == EditorPropertyChangeType.Atlases;
                bool updateMaterials = (changeType & EditorPropertyChangeType.Materials) == EditorPropertyChangeType.Materials;

                if(updateAtlases) {
                    settings.pixelsPerUnit = editorProperties.pixelsPerUnit;
                    settings.trimSprites = editorProperties.trimSprites;
                    settings.framePadding = editorProperties.framePadding;
                    settings.maxAtlasSize = editorProperties.maxAtlasSize;
                    settings.forceSquareAtlases = editorProperties.forceSquareAtlases;
                    settings.useMipMaps = editorProperties.useMipMaps;
                    settings.useTextureCompression = editorProperties.useTextureCompression;
                    //settings.atlasPackingMethod = editorProperties.atlasPackingMethod;
                    settings.resolutionTarget = editorProperties.resolutionTarget;
                    settings.resolutionTargetResamplingMode = editorProperties.resolutionTargetResamplingMode;
                }

                // Defaults
                if(updateAtlases || updateMaterials) settings.defaultMaterialGUID = Utils.AssetTools.GetGUID(editorProperties.defaultMaterial);
                settings.defaultFilterMode = editorProperties.defaultFilterMode;
                settings.defaultAnisoLevel = editorProperties.defaultAnisoLevel;
                settings.defaultUseTwoSidedMesh = editorProperties.defaultUseTwoSidedMesh;
                settings.defaultUse2DColliders = editorProperties.defaultUse2DColliders;
                settings.defaultMeshType = editorProperties.defaultMeshType;
                settings.defaultAutoMeshTransparencyChannel = editorProperties.defaultAutoMeshTransparencyChannel;
                settings.defaultAutoMeshEdgeExtrude = editorProperties.defaultAutoMeshEdgeExtrude;
                settings.defaultAutoMeshVertexReductionDistance = editorProperties.defaultAutoMeshVertexReductionDistance;
                settings.rebuildSpriteOnSave = editorProperties.rebuildSpriteOnSave;
                settings.rebuildSpriteGroupOnSave = editorProperties.rebuildSpriteGroupOnSave;
                EditorUtility.SetDirty(settings); // tell unity to save the prefab changes to disk
                AssetDatabase.SaveAssets();

                // Rebuild assets if needed
                if(updateAtlases) {
                    RebuildAllAtlases();
                } else if(updateMaterials) {
                    RebuildAllMaterials();
                }
            }

            #endregion

            #region REBUILD DATA FILE

            public void RebuildDataFile(bool rebuildAll, bool silenceDependencyWarnings = false) {
                CheckInitialized();

                // Get a list of ungrouped sprites before clearing so we can preserve sort order
                string[] ungroupedSpriteFileNames = data.GetUngroupedSpriteFileNames();

                // Clear the data file
                data.ClearAll();

                int addedSpriteCount = 0;
                int addedGroupCount = 0;
                int failedSpriteCount = 0;
                int failedGroupCount = 0;
                List<string> processedMasterSprites = new List<string>();

                // Get list of all sprite groups found in directory
                if(DirectoryExistsRel(spriteGroupSavePath)) {
                    string[] spriteGroupFiles = DirectoryGetFilesRel_FileNamesOnly(spriteGroupSavePath, string.Format("*{0}{1}", spriteGroupFileNameSuffix, assetExtension), SearchOption.TopDirectoryOnly);

                    // Go through each group found in directory
                    for(int i = 0; i < spriteGroupFiles.Length; i++) {
                        TryAddGroupFile(spriteGroupFiles[i], processedMasterSprites, ref addedGroupCount, ref addedSpriteCount, ref failedGroupCount, ref failedSpriteCount, silenceDependencyWarnings);
                    }
                }

                // Get list of all master sprites found in directory
                if(DirectoryExistsRel(editorMasterSpriteSavePath)) {
                    string[] dirEditorMasterSpriteFiles = DirectoryGetFilesRel_FileNamesOnly(editorMasterSpriteSavePath, string.Format("*{0}{1}", editorMasterSpriteFileNameSuffix, assetExtension), SearchOption.TopDirectoryOnly);

                    // Combine the directory sprites with the ones found in the data list (if any) to preserve sort order
                    string[] editorMasterSpriteFiles = ungroupedSpriteFileNames;
                    if(dirEditorMasterSpriteFiles != null) { // we have some sprites in the directory, add them if unique
                        for(int i = 0; i < dirEditorMasterSpriteFiles.Length; i++) {
                            if(!SpriteFactory.Utils.ArrayTools.Contains(editorMasterSpriteFiles, dirEditorMasterSpriteFiles[i], true)) { // directory file is not already in list, add it
                                SpriteFactory.Utils.ArrayTools.Add<string>(ref editorMasterSpriteFiles, dirEditorMasterSpriteFiles[i]); // add to list
                            }
                        }
                    }

                    // Go through each sprite found in list and directory
                    for(int i = 0; i < dirEditorMasterSpriteFiles.Length; i++) {
                        if(processedMasterSprites.Contains(editorMasterSpriteFiles[i])) continue; // this master sprite was already added to a group, skip
                        TryAddEMSFile(editorMasterSpriteFiles[i], -1, ref addedSpriteCount, ref failedSpriteCount, silenceDependencyWarnings); // all groups should have been processed, the rest will be ungrouped
                    }
                }

                // Save
                EditorUtility.SetDirty(data);
                AssetDatabase.SaveAssets();

                // Refresh
                AssetDatabase.Refresh();

                // Clean up ANY files in the folders that were not imported and move to FailedImport
                // This is easier than doing it all by group, sprite, etc.

                // Report
                Debug.Log("Sprite Factory data file rebuild complete!");
                Debug.Log(string.Format("Found {0} valid Sprite Group{1}.", addedGroupCount, (addedGroupCount != 1 ? "s" : "")));
                Debug.Log(string.Format("Found {0} valid Master Sprite{1}.", addedSpriteCount, (addedSpriteCount != 1 ? "s" : "")));
                if(failedGroupCount > 0) Debug.LogWarning(string.Format("{0} Sprite Group{1} failed validation and {2} moved to {3}", failedGroupCount, (failedGroupCount != 1 ? "s" : ""), (failedGroupCount != 1 ? "were" : "was"), failedRebuildPath));
                if(failedSpriteCount > 0) Debug.LogWarning(string.Format("{0} Master Sprite{1} failed validation and {2} moved to {3}", failedSpriteCount, (failedSpriteCount != 1 ? "s" : ""), (failedSpriteCount != 1 ? "were" : "was"), failedRebuildPath));

                // Upgrade any outdated data formats
                UpgradeData();

                // Rebuild all sprites and groups
                if(rebuildAll) RebuildAllSpritesAndGroups(); // rebuild with upgrade check
            }

            private void TryAddGroupFile(string groupFileName, List<string> processedMasterSprites, ref int addedGroupCount, ref int addedSpriteCount, ref int failedGroupCount, ref int failedSpriteCount, bool silenceDependencyWarnings) {
                if(groupFileName == null || groupFileName == "" || groupFileName == string.Empty) return;

                string groupFilePath = AddSpriteGroupFilePath(groupFileName);

                // Check if file exists
                if(!FileExistsRel(groupFilePath)) { // file does not exist
                    MoveSpriteGroupToFailed(groupFileName, "File does not exist.");
                    failedGroupCount++;
                    return;
                }

                // Load the sprite group
                SpriteGroup spriteGroup = LoadAssetAtPathRel<SpriteGroup>(groupFilePath);
                if(spriteGroup == null) { // file matching group pattern had no sprite group component
                    MoveSpriteGroupToFailed(groupFileName, "Component is not found.");
                    failedGroupCount++;
                    return;
                }

                string[] masterSpriteFiles = spriteGroup.masterSpriteFiles;

                // Check dependencies
                if(!silenceDependencyWarnings) {
                    List<string> dependencyErrors = new List<string>();

                    // masterSpriteFiles
                    if(masterSpriteFiles != null) {
                        for(int i = 0; i < masterSpriteFiles.Length; i++) {
                            string masterSpriteFilePath = AddEditorMasterSpriteFilePath(masterSpriteFiles[i]);
                            if(masterSpriteFiles[i] == null || !FileExistsRel(masterSpriteFilePath)) { // file dependency was not found
                                dependencyErrors.Add(SpriteEditor.RelToAbsPath(masterSpriteFilePath));
                            }
                        }
                    }

                    // atlasFiles
                    string[] atlasFiles = spriteGroup.GetAtlasFilePaths();
                    if(atlasFiles != null) {
                        for(int i = 0; i < atlasFiles.Length; i++) {
                            if(atlasFiles[i] == null || !FileExistsRel(atlasFiles[i])) { // file dependency was not found
                                dependencyErrors.Add(SpriteEditor.RelToAbsPath(atlasFiles[i]));
                            }
                        }
                    }

                    // materialSetFiles
                    SpriteFactoryData.MaterialSetFiles[] materialSetFiles = spriteGroup.GetWorkingMaterialSetFiles();
                    if(materialSetFiles != null) {
                        for(int i = 0; i < materialSetFiles.Length; i++) {
                            string[] materialFilePaths = materialSetFiles[i].materialFilePaths;
                            if(materialFilePaths != null) {
                                for(int j = 0; j < materialFilePaths.Length; j++) {
                                    if(materialFilePaths[j] == null || !FileExistsRel(materialFilePaths[j])) { // file dependency was not found
                                        dependencyErrors.Add(SpriteEditor.RelToAbsPath(materialFilePaths[j]));
                                    }
                                }
                            }
                        }
                    }

                    // Report dependency errors
                    for(int j = 0; j < dependencyErrors.Count; j++) {
                        Debug.LogWarning(groupFileName + " references a dependency that does not exist! " + dependencyErrors[j]);
                    }
                }

                // Verify file name and group name match to prevent problems if user changed file name but not the serialized name
                string name = Path.GetFileNameWithoutExtension(groupFileName); // strip off extension
                if(name.ToLower().StartsWith(spriteGroupFileNamePrefix.ToLower())) name = name.Substring(spriteGroupFileNamePrefix.Length); // strip off prefix
                if(name.ToLower().EndsWith(spriteGroupFileNameSuffix.ToLower())) name = name.Substring(0, name.Length - spriteGroupFileNameSuffix.Length); // stip off suffix
                if(name != spriteGroup.name) { // name in sprite group does not match file name
                    if(!data.IsSpriteGroupNameInDataList(name)) { // the name is not used in the data list, so we'll change the name in the group object and add it
                        Debug.LogWarning(string.Format("Sprite Group {0} file name does not match stored name! Changing name in Sprite Group to match file name.", groupFileName));
                        spriteGroup.name = name;
                        spriteGroup.SetDirtyForSave(); // flag group object for saving
                    } else { // name is already used, cannot add this group
                        MoveSpriteGroupToFailed(groupFileName, "File name does not match stored name and cannot change Sprite Group's name to match because the group name is already in use.");
                        failedGroupCount++;
                        return;
                    }
                }

                // Create a new group in data with this file's name
                int groupIndex = data.CreateNewSpriteGroup(spriteGroup.name, userDefaultMaterial, defaultFilterMode, -1, -1, true);
                int groupId = data.GetSpriteGroupId(groupIndex);

                // Add group master sprite files we find in the sprite directory to the list in the group
                bool foundNewSprites = false;
                if(DirectoryExistsRel(editorMasterSpriteSavePath)) {
                    string[] dirMasterSpriteFiles = DirectoryGetFilesRel_FileNamesOnly(editorMasterSpriteSavePath, string.Format("{0}*{1}{2}", GetEditorMasterSpriteFilePrefix(spriteGroup.name), editorMasterSpriteFileNameSuffix, assetExtension), SearchOption.TopDirectoryOnly);
                    for(int i = 0; i < dirMasterSpriteFiles.Length; i++) { // merge with sprite list
                        if(!SpriteFactory.Utils.ArrayTools.Contains(masterSpriteFiles, dirMasterSpriteFiles[i], true)) { // add if not in list
                            SpriteFactory.Utils.ArrayTools.Add<string>(ref masterSpriteFiles, dirMasterSpriteFiles[i]);
                            foundNewSprites = true; // flag that the group sprite list must be updated
                        }
                    }
                }

                // Process the sprites in this group now so we can keep the order
                if(masterSpriteFiles == null || masterSpriteFiles.Length == 0) {
                    addedGroupCount++;
                    return; // there are no master sprites to add
                }

                // Try to add each master sprite to the group

                // Compact the list if there are any invalid ones
                string[] newMasterSpriteFiles = new string[0];
                for(int i = 0; i < masterSpriteFiles.Length; i++) {
                    if(masterSpriteFiles[i] == null) continue; // field was empty
                    bool result = TryAddEMSFile(masterSpriteFiles[i], groupId, ref addedSpriteCount, ref failedSpriteCount, silenceDependencyWarnings);
                    if(!result) continue; // failed to add
                    // Sprite was successfully added to the data list and the group id was updated in the master sprite
                    SpriteFactory.Utils.ArrayTools.Add<string>(ref newMasterSpriteFiles, masterSpriteFiles[i]); // add to compacted list
                    processedMasterSprites.Add(masterSpriteFiles[i]);
                }

                // Update the sprite list in the group file if any sprites were removed
                if(foundNewSprites || newMasterSpriteFiles.Length != masterSpriteFiles.Length) { // either found new sprites in directory or invalid ones were found and removed
                    spriteGroup.masterSpriteFiles = newMasterSpriteFiles; // replace the list in the sprite group object
                    spriteGroup.SetDirtyForSave(); // flag group for saving
                }

                addedGroupCount++;
            }

            private bool TryAddEMSFile(string emsFileName, int groupId, ref int addedSpriteCount, ref int failedSpriteCount, bool silenceDependencyWarnings) {
                if(emsFileName == null || emsFileName == "" || emsFileName == string.Empty) return false;

                string emsFilePath = AddEditorMasterSpriteFilePath(emsFileName); // get the relative path to the ems file

                // Test if master sprite file exists
                if(!FileExistsRel(emsFilePath)) {
                    MoveMasterSpriteToFailed(emsFileName, "File does not exist.");
                    failedSpriteCount++;
                    return false;
                }

                // Load the editor master sprite file
                EditorMasterSprite editorMasterSprite = LoadAssetAtPathRel<EditorMasterSprite>(emsFilePath); // try to load the ems file
                if(editorMasterSprite == null) { // file matching ems pattern had no component
                    MoveMasterSpriteToFailed(emsFileName, "Component is missing.");
                    failedSpriteCount++;
                    return false;
                }

                // Validate the master sprite
                if(!ValidateMasterSpriteFiles(emsFileName)) {
                    MoveMasterSpriteToFailed(emsFileName, "Validation failed.");
                    failedSpriteCount++;
                    return false;
                }

                // Check if this is an orphaned sprite from a failed or missing group
                if(groupId == -1 && editorMasterSprite.data.spriteGroupId != groupId) { // we're checking the non-grouped sprites, but this sprite was supposed to be in a group
                    MoveMasterSpriteToFailed(emsFileName, "Master Sprite was orphaned from a Sprite Group that was missing or failed to import.");
                    failedSpriteCount++;
                    return false;
                }

                // Check dependencies
                if(!silenceDependencyWarnings) {
                    List<string> dependencyErrors = new List<string>();

                    // editorPreviewMeshFileName
                    string editorPreviewMeshFilePath = AddEditorMeshFilePath(editorMasterSprite.editorPreviewMeshFileName);
                    if(!FileExistsRel(editorPreviewMeshFilePath)) { // file dependency was not found
                        dependencyErrors.Add(SpriteEditor.RelToAbsPath(editorPreviewMeshFilePath));
                    }

                    // editorPreviewMaterialFileName
                    string editorPreviewMaterialFilePath = AddMaterialFilePath(editorMasterSprite.editorPreviewMaterialFileName);
                    if(!FileExistsRel(editorPreviewMaterialFilePath)) { // file dependency was not found
                        dependencyErrors.Add(SpriteEditor.RelToAbsPath(editorPreviewMaterialFilePath));
                    }

                    // atlasFiles
                    string[] atlasFiles = editorMasterSprite.GetAtlasFilePaths();
                    if(atlasFiles != null) {
                        for(int i = 0; i < atlasFiles.Length; i++) {
                            if(!FileExistsRel(atlasFiles[i])) { // file dependency was not found
                                dependencyErrors.Add(SpriteEditor.RelToAbsPath(atlasFiles[i]));
                            }
                        }
                    }

                    // materialSetFiles
                    SpriteFactoryData.MaterialSetFiles[] materialSetFiles = editorMasterSprite.GetWorkingMaterialSetFiles();
                    if(materialSetFiles != null) {
                        for(int i = 0; i < materialSetFiles.Length; i++) {
                            string[] materialFilePaths = materialSetFiles[i].materialFilePaths;
                            if(materialFilePaths != null) {
                                for(int j = 0; j < materialFilePaths.Length; j++) {
                                    if(!FileExistsRel(materialFilePaths[j])) { // file dependency was not found
                                        dependencyErrors.Add(SpriteEditor.RelToAbsPath(materialFilePaths[j]));
                                    }
                                }
                            }
                        }
                    }

                    // Report dependency errors
                    for(int j = 0; j < dependencyErrors.Count; j++) {
                        Debug.LogWarning(emsFileName + " references a dependency that does not exist! " + dependencyErrors[j]);
                    }
                }

                // Verify file name and sprite name match to prevent problems if user changed file name but not the serialized name
                string name = Path.GetFileNameWithoutExtension(emsFileName); // strip off extension
                string prefix = GetEditorMasterSpriteFilePrefix(data.GetSpriteGroupNameById(groupId));

                if(name.ToLower().StartsWith(prefix.ToLower())) name = name.Substring(prefix.Length); // strip off prefix
                if(name.ToLower().EndsWith(editorMasterSpriteFileNameSuffix.ToLower())) name = name.Substring(0, name.Length - editorMasterSpriteFileNameSuffix.Length); // stip off suffix
                if(name != editorMasterSprite.name) { // name in sprite does not match file name, just fail
                    MoveMasterSpriteToFailed(emsFileName, "File name does not match stored name.");
                    failedSpriteCount++;
                    return false;
                }

                // Create a new master sprite in data with this file's name
                int spriteIndex = data.CreateNewSpriteInGroup(emsFileName, editorMasterSprite.name, groupId, -1, true);
                data.SaveSpriteFileData(spriteIndex, groupId, emsFileName, GetSpriteSOFileName(editorMasterSprite.name, MasterSpriteType.Game, groupId), editorMasterSprite.editorPreviewMeshFileName, editorMasterSprite.editorPreviewMaterialFileName);

                // Update the editor master sprite's group id
                if(editorMasterSprite.data.spriteGroupId != groupId) {
                    editorMasterSprite.data.spriteGroupId = groupId; // update the group id in master sprite data
                    editorMasterSprite.SetCoreDirtyForSave(); // flag core for saving
                }

                addedSpriteCount++;
                return true;
            }

            private bool ValidateMasterSpriteFiles(string fileName) {
                string filePath = AddEditorMasterSpriteFilePath(fileName);
                EditorMasterSprite editorMasterSprite = LoadAssetAtPathRel<EditorMasterSprite>(filePath);
                if(editorMasterSprite == null) return false;

                // core file
                string coreFilePath = AddEditorMasterSpriteCoreFilePath(editorMasterSprite.coreFileName);
                if(!FileExistsRel(coreFilePath)) { // file dependency was not found
                    return false; // this file is critical, so fail if missing
                }

                return true;
            }

            private void MoveMasterSpriteToFailed(string fileName, string errorMessage) {
                Debug.LogWarning(string.Format("Master Sprite {0} failed import. This Master Sprite will be moved to the {1} directory. Reason: {2}", fileName, failedRebuildPath, errorMessage));

                CreateFailedDirectories(); // Create directories if necessary

                // Move all the assets

                // Editor Master Sprite file
                string filePath = AddEditorMasterSpriteFilePath(fileName);
                if(DirectoryExistsRel(Path.GetDirectoryName(filePath)) && FileExistsRel(filePath))
                    MoveFileRel(filePath, failed_editorMasterSpriteSavePath + directoryDelimiter + fileName, true);

                string emsName;
                string groupName;
                if(!FindGroupAndMasterSpriteName(fileName, out emsName, out groupName)) return; // failed to parse file name

                // Core file
                string coreFileName = GetEditorMasterSpriteCoreFileNameOnly(emsName, groupName);
                string coreFilePath = AddEditorMasterSpriteFilePath(coreFileName);
                if(DirectoryExistsRel(Path.GetDirectoryName(coreFilePath)) && FileExistsRel(coreFilePath))
                    MoveFileRel(coreFilePath, failed_editorMasterSpriteSavePath + directoryDelimiter + coreFileName, true);

                // Game Master Sprite file
                string gmsFileName = GetGameMasterSpriteFileNameOnly(emsName, groupName);
                string gmsFilePath = AddGameMasterSpriteFilePath(gmsFileName);
                if(DirectoryExistsRel(Path.GetDirectoryName(gmsFilePath)) && FileExistsRel(gmsFilePath))
                    MoveFileRel(gmsFilePath, failed_gameMasterSpriteSavePath + directoryDelimiter + gmsFileName, true);

                string assetPrefix = GetSpriteChildFilePrefix(emsName, groupName);

                // Atlases
                if(DirectoryExistsRel(atlasSavePath)) {
                    string[] files = DirectoryGetFilesRel_FileNamesOnly(atlasSavePath, string.Format("{0}*{1}", assetPrefix, atlasExtension), SearchOption.TopDirectoryOnly);
                    if(files != null) {
                        for(int i = 0; i < files.Length; i++) {
                            MoveFileRel(AddAtlasFilePath(files[i]), failed_atlasSavePath + directoryDelimiter + files[i], true);
                        }
                    }
                }

                // Materials
                if(DirectoryExistsRel(materialSavePath)) {
                    string[] files = DirectoryGetFilesRel_FileNamesOnly(materialSavePath, string.Format("{0}*{1}", assetPrefix, materialExtension), SearchOption.TopDirectoryOnly);
                    if(files != null) {
                        for(int i = 0; i < files.Length; i++) {
                            MoveFileRel(AddMaterialFilePath(files[i]), failed_materialSavePath + directoryDelimiter + files[i], true);
                        }
                    }
                }

                // Meshes
                if(DirectoryExistsRel(meshSavePath)) {
                    string[] files = DirectoryGetFilesRel_FileNamesOnly(meshSavePath, string.Format("{0}{1}{2}", assetPrefix, editorMeshSuffix, assetExtension), SearchOption.TopDirectoryOnly);
                    if(files != null) {
                        for(int i = 0; i < files.Length; i++) {
                            MoveFileRel(AddEditorMeshFilePath(files[i]), failed_meshSavePath + directoryDelimiter + files[i], true);
                        }
                    }
                }
            }

            private void MoveSpriteGroupToFailed(string fileName, string errorMessage) {
                Debug.LogWarning(string.Format("Sprite Group {0} failed import. This Sprite Group will be moved to the {1} directory. Reason: {2}", fileName, failedRebuildPath, errorMessage));

                CreateFailedDirectories(); // Create directories if necessary

                // Move all the assets for the group

                // Group file
                string filePath = AddSpriteGroupFilePath(fileName);
                Debug.Log(filePath);
                if(DirectoryExistsRel(Path.GetDirectoryName(filePath)) && FileExistsRel(filePath))
                    MoveFileRel(filePath, failed_spriteGroupSavePath + directoryDelimiter + fileName, true);

                string groupName;
                if(!FindGroupName(fileName, out groupName)) return; // failed to parse file name

                Debug.Log("group name: " + groupName);
                string assetPrefix = GetSpriteGroupChildFilePrefix(groupName);

                // Atlases
                if(DirectoryExistsRel(atlasSavePath)) {
                    string[] files = DirectoryGetFilesRel_FileNamesOnly(atlasSavePath, string.Format("{0}*{1}", assetPrefix, atlasExtension), SearchOption.TopDirectoryOnly);
                    if(files != null) {
                        for(int i = 0; i < files.Length; i++) {
                            MoveFileRel(AddAtlasFilePath(files[i]), failed_atlasSavePath + directoryDelimiter + files[i], true);
                        }
                    }
                }

                // Materials
                if(DirectoryExistsRel(materialSavePath)) {
                    string[] files = DirectoryGetFilesRel_FileNamesOnly(materialSavePath, string.Format("{0}*{1}", assetPrefix, materialExtension), SearchOption.TopDirectoryOnly);
                    if(files != null) {
                        for(int i = 0; i < files.Length; i++) {
                            MoveFileRel(AddMaterialFilePath(files[i]), failed_materialSavePath + directoryDelimiter + files[i], true);
                        }
                    }
                }

                // Move all the sprites
                if(FileExistsRel(filePath)) {
                    SpriteGroup spriteGroup = LoadAssetAtPathRel<SpriteGroup>(filePath);
                    if(spriteGroup != null) {
                        string[] masterSpriteFiles = spriteGroup.masterSpriteFiles;
                        if(masterSpriteFiles != null) {
                            for(int i = 0; i < masterSpriteFiles.Length; i++) {
                                MoveMasterSpriteToFailed(masterSpriteFiles[i], "Master Sprite's parent Sprite Group failed to be imported properly.");
                            }
                        }
                    }
                }
            }

            private bool FindGroupName(string groupFileName, out string groupName) {
                groupName = null;

                // Parse file name to find group and sprite name
                string tempGroupName = Path.GetFileNameWithoutExtension(groupFileName);

                // Find group name and strip it off the group prefix and suffix
                if(tempGroupName.ToLower().StartsWith(spriteGroupFileNamePrefix.ToLower())) {
                    tempGroupName = tempGroupName.Substring(spriteGroupFileNamePrefix.Length);
                    int index = tempGroupName.ToLower().IndexOf(fileNameDelimiter);
                    if(index > -1) {
                        tempGroupName = tempGroupName.Substring(0, index); // just get the group name
                    } else return false; // error
                } else return false; // error

                groupName = tempGroupName;
                return true;
            }

            private bool FindGroupAndMasterSpriteName(string editorMasterSpriteFileName, out string editorMasterSpriteName, out string groupName) {
                int index;
                editorMasterSpriteName = null;
                groupName = null;

                // Parse file name to find group and sprite name
                string tempMSName = Path.GetFileNameWithoutExtension(editorMasterSpriteFileName);

                // Find group name and strip it off the master sprite name
                string tempGroupName = null;
                if(tempMSName.ToLower().StartsWith(spriteGroupFileNamePrefix.ToLower())) { // master sprite is in a group
                    tempGroupName = tempMSName.Substring(spriteGroupFileNamePrefix.Length);
                    index = tempGroupName.ToLower().IndexOf(fileNameDelimiter + editorMasterSpriteFileNamePrefix.ToLower());
                    if(index > -1) {
                        tempMSName = tempGroupName.Substring(index + 1); // just get the rest after the group, skip the mid delimiter
                        tempGroupName = tempGroupName.Substring(0, index); // just get the group name
                    } else return false; // error
                }

                // Strip off master sprite prefix
                if(tempMSName.ToLower().StartsWith(editorMasterSpriteFileNamePrefix.ToLower())) {
                    tempMSName = tempMSName.Substring(editorMasterSpriteFileNamePrefix.Length); // strip off prefix
                } else return false; // error

                // Get rid of everything after the name
                index = tempMSName.IndexOf(fileNameDelimiter);
                if(index > -1) {
                    tempMSName = tempMSName.Substring(0, index); // just get the name
                } else return false; // error

                editorMasterSpriteName = tempMSName;
                groupName = tempGroupName;
                return true;
            }

            private void CreateFailedDirectories() {
                bool createdDir = false;
                if(!DirectoryExistsRel(failedRebuildPath)) {
                    CreateDirectoryRel(failedRebuildPath); // failed import directory
                    createdDir = true;
                }
                if(!DirectoryExistsRel(failed_spriteSavePath)) {
                    CreateDirectoryRel(failed_spriteSavePath, false); // sprite directory
                    createdDir = true;
                }
                if(!DirectoryExistsRel(failed_editorMasterSpriteSavePath)) {
                    CreateDirectoryRel(failed_editorMasterSpriteSavePath, false); // editor master sprite directory
                    createdDir = true;
                }
                if(!DirectoryExistsRel(failed_gameMasterSpriteSavePath)) {
                    CreateDirectoryRel(failed_gameMasterSpriteSavePath, false); // game master sprite directory
                    createdDir = true;
                }
                if(!DirectoryExistsRel(failed_spriteGroupSavePath)) {
                    CreateDirectoryRel(failed_spriteGroupSavePath, false); // group directory
                    createdDir = true;
                }
                if(!DirectoryExistsRel(failed_atlasSavePath)) {
                    CreateDirectoryRel(failed_atlasSavePath, false); // atlases directory
                    createdDir = true;
                }
                if(!DirectoryExistsRel(failed_meshSavePath)) {
                    CreateDirectoryRel(failed_meshSavePath, false); // meshes directory
                    createdDir = true;
                }
                if(!DirectoryExistsRel(failed_materialSavePath)) {
                    CreateDirectoryRel(failed_materialSavePath, false); // materials directory
                    createdDir = true;
                }
                if(createdDir) AssetDatabase.Refresh(); // must refresh after creating a folder
            }

            #endregion

            #region IMPORT / EXPORT

            public ImportStatus ImportUnityPackage(string unitypackagePath, bool importFinished) {
                CheckInitialized();

                // Import the package
                // ImportPackage is deferred, so we must wait for it before rebuilding the data file
                if(!importFinished) {
                    if(!File.Exists(unitypackagePath)) {
                        Debug.LogError("Unitypackage is missing!");
                        return ImportStatus.Failed;
                    }
                    AssetDatabase.ImportPackage(unitypackagePath, false); // start the import
                    AssetDatabase.Refresh(); // refresh the asset database immediately
                    return ImportStatus.Started;
                }

                // The next cycle, importFinished = true and we rebuild the data

                // Collect garbage now
                System.GC.Collect();

                // Rebuild the data file
                RebuildDataFile(true, true); // and rebuild sprites and groups

                return ImportStatus.Completed;
            }

            public void ExportPackage(Exporter exporter) {
                if((exporter.groupIndicesToExport == null || exporter.groupIndicesToExport.Length <= 0) &&
                    (exporter.spriteIndicesToExport == null || exporter.spriteIndicesToExport.Length <= 0)) {
                    Debug.LogWarning("Nothing to export!");
                    return;
                }

                if(!Directory.Exists(Path.GetDirectoryName(exporter.savePath))) {
                    Debug.LogError("Save directory does not exist!");
                    return;
                }

                AssetData[] assetData = new AssetData[0];

                // Get files to export from editor properties
                // Get the user default material
                Material mat = userDefaultMaterial;
                if(mat != null) {
                    SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData, new AssetData(AssetDatabase.GetAssetPath(mat), AssetData.AssetType.SourceMaterial));
                }

                // Get files to export from groups
                int[] groupIndicies = exporter.groupIndicesToExport;
                if(groupIndicies != null) {
                    for(int i = 0; i < groupIndicies.Length; i++) {
                        SpriteFactory.Utils.ArrayTools.Combine<AssetData>(ref assetData, data.GetSpriteGroupExportAssets(groupIndicies[i]));
                    }
                }

                // Get files from ungrouped sprites
                int[] spriteIndices = exporter.spriteIndicesToExport;
                if(spriteIndices != null) {
                    for(int i = 0; i < spriteIndices.Length; i++) {
                        SpriteFactory.Utils.ArrayTools.Combine<AssetData>(ref assetData, data.GetSpriteExportAssets(spriteIndices[i]));
                    }
                }

                if(assetData.Length == 0) {
                    Debug.LogWarning("No valid assets were found to export.");
                    return;
                }

                // Get prefabs to be exported
                if(exporter.exportPrefabs) {

                    // Build a list of all game master sprites being exported
                    GameMasterSprite[] gameMasterSprites = null;
                    foreach(AssetData ad in assetData) {
                        if(ad.type != AssetData.AssetType.GameMasterSprite) continue;
                        GameMasterSprite gms = (GameMasterSprite)AssetDatabase.LoadAssetAtPath(ad.path, typeof(GameMasterSprite));
                        if(gms == null) continue;
                        SpriteFactory.Utils.ArrayTools.Add<GameMasterSprite>(ref gameMasterSprites, gms);
                    }

                    // Find all prefabs that use any of these game master sprites
                    if(gameMasterSprites != null) {

                        string[] allPrefabs = Directory.GetFiles(unityAssetsPath, "*.prefab", SearchOption.AllDirectories);
                        if(allPrefabs != null && allPrefabs.Length > 0) {

                            string[] exportPrefabPaths = null;

                            for(int i = 0; i < allPrefabs.Length; i++) {
                                string path = Utils.FileTools.ConvertBackslashes(allPrefabs[i]);
                                GameObject asset = (GameObject)AssetDatabase.LoadAssetAtPath(path, typeof(GameObject)); // load the asset
                                if(asset == null) continue; // no asset found

                                Sprite[] sprites = Utils.UnityTools.FindAllComponents<Sprite>(asset);
                                if(sprites == null) continue; // no assets found

                                // Check if any of the sprites link to the exported master sprites
                                bool export = false;
                                for(int j = 0; j < sprites.Length; j++) {
                                    if(SpriteFactory.Utils.ArrayTools.Contains<GameMasterSprite>(gameMasterSprites, sprites[j].masterSprite)) { // found a match
                                        export = true;
                                        break;
                                    }
                                }

                                if(export) { // found a sprite in this prefab that we are exporting
                                    string prefabPath = AssetDatabase.GetAssetPath(asset);
                                    SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData, new AssetData(prefabPath, AssetData.AssetType.Prefab)); // add prefab to list
                                    SpriteFactory.Utils.ArrayTools.Add<string>(ref exportPrefabPaths, prefabPath);
                                }
                            }

                            // Build a list of dependencies of the prefabs
                            if(exportPrefabPaths != null) {
                                string[] dependencies = AssetDatabase.GetDependencies(exportPrefabPaths);

                                // Remove the prefab paths themselves because we already handled them above
                                for(int i = 0; i < exportPrefabPaths.Length; i++) {
                                    SpriteFactory.Utils.ArrayTools.Remove(ref dependencies, exportPrefabPaths[i], true);
                                }

                                // Remove Sprite Factory internal dependencies
                                for(int i = 0; i < dependencies.Length; i++) {
                                    string pathL = dependencies[i].ToLower();
                                    if(pathL.StartsWith(RelToAbsPath(spriteEditorInternalPath + directoryDelimiter).ToLower()) || // within Internal directory
                                       pathL.StartsWith(RelToAbsPath(saveDataPath + directoryDelimiter).ToLower())) { // within SaveData directory
                                        dependencies[i] = null; // null out
                                    }
                                }
                                SpriteFactory.Utils.ArrayTools.Compact<string>(ref dependencies); // remove nulls

                                // Add the dependencies to the export list
                                if(dependencies != null) {
                                    for(int i = 0; i < dependencies.Length; i++) {
                                        SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData, new AssetData(dependencies[i], AssetData.AssetType.PrefabDependency));
                                    }
                                }
                            }
                        }
                    }
                }

                // Create export text file
                if(!CreateExportTextFile(assetData, exporter.savePath)) return;

                // Get asset paths from data
                string[] assetPaths = new string[assetData.Length];
                for(int i = 0; i < assetData.Length; i++) {
                    assetPaths[i] = assetData[i].path;
                }

                // Remove duplicates from string
                SpriteFactory.Utils.ArrayTools.Compact<string>(ref assetPaths); // remove any nulls
                SpriteFactory.Utils.ArrayTools.RemoveDuplicates(ref assetPaths, true);

                // Export Unitypackage
                try {
                    string savePath = exporter.savePath + ".unitypackage"; // append unitypackage to the path
                    AssetDatabase.ExportPackage(assetPaths, savePath);
                    Debug.Log("Export complete!");
                } catch(System.Exception e) {
                    Debug.LogError("Export failed! " + e.Message);
                }
            }

            private bool CreateExportTextFile(AssetData[] assetData, string savePath) {
                try {
                    using(StreamWriter sw = new StreamWriter(savePath, false, System.Text.Encoding.UTF8)) {
                        sw.WriteLine(rootPath); // write the sprite factory root path first

                        for(int i = 0; i < assetData.Length; i++) {

                            sw.WriteLine(assetData[i].guid); // write the GUID of the asset
                            sw.WriteLine(assetData[i].path); // write the path to the asset
                            sw.WriteLine(assetData[i].type.ToString());
                        }
                    }
                    return true;
                } catch(System.Exception e) {
                    Debug.LogError("Could not write " + exportTextExtension + " file! " + e.Message);
                    return false;
                }
            }

            #endregion

            #region UPGRADE

            public bool UpgradeRebuildRequired() {
                CheckInitialized();
                if(dataVersion > data.dataVersion) return true; // data version has changed
                if(!isTrial && data.isTrial) return true; // upgrading from data created with a trial version
                return false;
            }

            public bool CheckVersionChangeRequired() {
                CheckInitialized();
                if(programVersion != data.programVersion) return true;
                return false;
            }

            public void UpgradeRebuild() {
                CheckInitialized();
                UpgradeData();
                RebuildAllSpritesAndGroups(true);

                bool trialUpgraded = false;
                if(!isTrial && data.isTrial) trialUpgraded = true;

                // Update the data
                data.programVersion = programVersion;
                data.dataVersion = dataVersion;
                data.isTrial = isTrial;
                EditorUtility.SetDirty(data);
                AssetDatabase.SaveAssets();

                Debug.Log("Sprite Factory updated to version " + programVersion);
                if(trialUpgraded) {
                    EditorUtility.DisplayDialog("Sprite Factory Updated", "Your Sprite Factory trial has been upgraded to the full version! Thanks! :)", "Okay");
                }
            }

            public void UpdateProgramVersion() { // update the program version only
                CheckInitialized();

                // Update the data
                data.programVersion = programVersion;
                EditorUtility.SetDirty(data);
                AssetDatabase.SaveAssets();

                Debug.Log("Sprite Factory updated to version " + programVersion);
            }

            private void UpgradeData() {
                CheckInitialized();
                data.UpgradeData(_defaultSpriteMaterial);
            }

            #endregion

            #region // ATLAS MAKING CLASSES /////////////////////////

            private class AtlasMaker {

                #region Variables

                private bool inGroup;
                private DB db;
                private AMSpriteData[] spriteDatas;
                private AMAtlas[] atlases;
                private int atlasIdCounter = 0;
                private float resolutionTargetScale;
                private SpriteFactory.Enums.ResolutionTarget resolutionTarget;
                private SpriteFactory.Enums.ImageResamplingMode resolutionTargetResamplingMode;

                // group/sprite settings -- these are static so the AssetPostprocessor can get them
                public static bool settingsInitialized;
                public static FilterMode atlasTextureFilterMode;
                public static int atlasTextureAnisoLevel;
                public static int maxAtlasSize;
                public static bool useMipMaps;
                public static bool useTextureCompression;

                #endregion

                #region Constructors

                public AtlasMaker(EditorMasterSprite.SpriteGroup inSpriteGroup, DB inDB) { // constructor for a sprite group
                    db = inDB;
                    atlases = new AMAtlas[0];
                    resolutionTarget = db.resolutionTarget;
                    resolutionTargetScale = db.resolutionTargetScale;
                    resolutionTargetResamplingMode = db.resolutionTargetResamplingMode;

                    // get settings from sprite group
                    if(inSpriteGroup.atlasTextureFilterMode == -1) // use the default
                        atlasTextureFilterMode = db.defaultFilterMode;
                    else
                        atlasTextureFilterMode = (FilterMode)inSpriteGroup.atlasTextureFilterMode;

                    if(inSpriteGroup.atlasTextureAnisoLevel == -1) // use the default
                        atlasTextureAnisoLevel = db.defaultAnisoLevel;
                    else // use the stored value
                        atlasTextureAnisoLevel = inSpriteGroup.atlasTextureAnisoLevel;

                    UpdateSettngsVars(); // populate the other settings vars

                    inGroup = true;
                }

                public AtlasMaker(EditorMasterSprite.Data inMasterSpriteData, int masterSpriteIndex, DB inDB) { // constructor for a single sprite
                    db = inDB;
                    atlases = new AMAtlas[0];
                    resolutionTarget = db.resolutionTarget;
                    resolutionTargetScale = db.resolutionTargetScale;
                    resolutionTargetResamplingMode = db.resolutionTargetResamplingMode;

                    // get settings from sprite
                    if(inMasterSpriteData.useDefaultAtlasTextureFilterMode) // use the default
                        atlasTextureFilterMode = db.defaultFilterMode;
                    else
                        atlasTextureFilterMode = (FilterMode)inMasterSpriteData.atlasTextureFilterMode;

                    if(inMasterSpriteData.atlasTextureAnisoLevel == -1) // use the default
                        atlasTextureAnisoLevel = db.defaultAnisoLevel;
                    else // use the stored value
                        atlasTextureAnisoLevel = inMasterSpriteData.atlasTextureAnisoLevel;

                    UpdateSettngsVars(); // populate the other settings vars

                    AddSprite(inMasterSpriteData, masterSpriteIndex);
                }

                #endregion

                #region Methods

                private void UpdateSettngsVars() {
                    settingsInitialized = true;
                    maxAtlasSize = db.maxAtlasSize;
                    useMipMaps = db.useMipMaps;
                    useTextureCompression = db.useTextureCompression;
                }

                // CREATING ATLAS FUNCTIONS

                public void AddSprite(EditorMasterSprite.Data inMasterSpriteData, int masterSpriteIndex) {
                    //inMasterSpriteData.PrepareForAtlasCreation();
                    inMasterSpriteData.UpdateEdgeTiling(db.framePadding); // determine if edges need to be tiled
                    Utils.AssetTools.FixTextureImporterSettings(inMasterSpriteData.GetFrameTextureGUIDs()); // WARNING: This contains AssetDatabase.Import calls! Links to on-disk ScriptableObjects can be lost!
                    SpriteFactory.Utils.ArrayTools.Add<AMSpriteData>(ref spriteDatas, new AMSpriteData(this, inMasterSpriteData, masterSpriteIndex));
                }

                private void AddAnimToAtlases(AMAnimation anim, int animIndex, EditorMasterSprite.Data masterSpriteData) {
                    AMFrame[] frames = anim.frames;
                    if(frames == null || frames.Length == 0) return; // no frames

                    // Need to add each frame to an atlas
                    // search atlases for this frame
                    // add frame to atlas
                    // record what atlas this frame is in
                    // record what cell this frame is in
                    for(int i = 0; i < frames.Length; i++) {
                        AMFrame frame = frames[i];

                        // First verify frame textures exist and aren't too large for atlas
                        string error;
                        frame.VerifyTexture(db.maxAtlasSize, out error);
                        if(frame.corrupt) {
                            Debug.LogWarning("Problem creating atlas for " + masterSpriteData.name + ", Animation: " + anim.animation.name + ", Frame: " + i + "\n" + error + " This frame will be skipped!");
                            continue; // cannot add this frame to atlas because it is corrupt
                        }

                        // Try to add frame to existing atlas first
                        if(AddFrameToExistingAtlas(frame, masterSpriteData)) continue; // added to existing atlas, done

                        // Add frame to a new atlas since we didn't add it to an existing one
                        AddFrameToNewAtlas(frame, masterSpriteData); // create a new atlas for this frame and add it
                    }
                }

                private bool AddFrameToExistingAtlas(AMFrame frame, EditorMasterSprite.Data masterSpriteData) {
                    if(atlases == null || atlases.Length == 0) return false; // no existing atlases

                    // Cache some data
                    string textureGUID = frame.frame.textureGUID;
                    bool tile = masterSpriteData.tile;
                    bool tileTop = masterSpriteData.tileTop;
                    bool tileBottom = masterSpriteData.tileBottom;
                    bool tileLeft = masterSpriteData.tileLeft;
                    bool tileRight = masterSpriteData.tileRight;
                    bool useCustomMesh = masterSpriteData.finalUseCustomMesh;
                    int autoMeshExtrude = masterSpriteData.finalAutoMeshExtrude;

                    // Try to add this to an existing atlas that already contains this texture first
                    int atlasCount = atlases.Length;
                    for(int i = 0; i < atlasCount; i++) {
                        AMAtlas atlas = atlases[i];
                        int atlasCellIndex = atlas.FindTextureInAtlas(textureGUID, tile, tileTop, tileBottom, tileLeft, tileRight, useCustomMesh, autoMeshExtrude); // check if the texture is already in the atlas
                        if(atlasCellIndex > -1) { // texture was already in the atlas
                            frame.SetAtlas(atlas, atlasCellIndex); // save location in frame
                            return true; // done
                        }
                    }

                    // None of the atlases contained this texture, so try adding textures to any that have space
                    for(int i = 0; i < atlasCount; i++) {
                        AMAtlas atlas = atlases[i];
                        bool added = atlas.Add(frame, masterSpriteData); // try to add the texture to atlas
                        if(added) return true; // we found space and added it
                    }
                    return false;
                }

                private void AddFrameToNewAtlas(AMFrame frame, EditorMasterSprite.Data masterSpriteData) {
                    AMAtlas atlas = CreateNewAtlas(); // get a new atlas
                    bool added = atlas.Add(frame, masterSpriteData); // try to add the textures to the atlas
                    if(!added) { // still could not add the textures to the new atlas!
                        Debug.LogError("Cannot fit frame in a single atlas! Raise max atlas size or reduce the size of the texture!"); // texture does not fit in an atlas!
                    }
                }

                private AMAtlas CreateNewAtlas() {
                    int index = atlases.Length; // get index where we will add it
                    SpriteFactory.Utils.ArrayTools.Add<AMAtlas>(ref atlases, new AMAtlas(index, this)); // create atlas
                    return atlases[index];
                }

                // AFTER ATLASES ARE CREATED FUNCTIONS

                public void SaveFiles(string spriteName, string groupName, out string[] newAtlasFiles) {
                    newAtlasFiles = null;
                    if(atlases == null) return;

                    // Save atlas textures
                    for(int i = 0; i < atlases.Length; i++) {
                        int atlasIndex = i;
                        string fullAtlasPathAndName = GetAtlasFilePath(atlasFileNamePrefix + atlasIndex.ToString(), spriteName, groupName);
                        atlases[i].SaveTexture(fullAtlasPathAndName);
                        SpriteFactory.Utils.ArrayTools.Add<string>(ref newAtlasFiles, fullAtlasPathAndName);
                    }
                }

                private int GetNewAtlasId() {
                    int value = atlasIdCounter;
                    atlasIdCounter++;
                    return value;
                }

                public void UpdateMasterSprites() {
                    for(int i = 0; i < spriteDatas.Length; i++) {
                        spriteDatas[i].UpdateMasterSprite();
                    }
                }

                /*
                public void AtlasCreationFinished() {
                    for(int i = 0; i < spriteDatas.Length; i++) {
                        spriteDatas[i].AtlasCreationFinished();
                    }
                }*/

                public void CommitToMasterSpritesOnDisk() {
                    // Used to save data onto the original editor master sprite on disk
                    // Only called by sprite group saving

                    for(int i = 0; i < spriteDatas.Length; i++) {
                        AMSpriteData spriteData = spriteDatas[i];
                        if(spriteData == null) continue;

                        spriteData.CommitToMasterSpritesOnDisk();
                    }
                }

                #endregion

                #region PRIVATE CLASSES

                private class AMSpriteData {
                    public AtlasMaker atlasMaker;
                    public EditorMasterSprite.Data masterSpriteData;
                    public int masterSpriteIndex;
                    public AMAnimation[] animations;

                    public AMAtlas[] localAtlases; // atlases used in this sprite
                    public bool useCustomMesh;

                    public AMSpriteData(AtlasMaker inAtlasMaker, EditorMasterSprite.Data inMasterSpriteData, int masterSpriteIndex) {
                        atlasMaker = inAtlasMaker; // set up link to parent
                        masterSpriteData = inMasterSpriteData;
                        this.masterSpriteIndex = masterSpriteIndex;
                        useCustomMesh = masterSpriteData.finalUseCustomMesh;
                        ProcessSprite(masterSpriteData);
                    }

                    private void ProcessSprite(EditorMasterSprite.Data masterSpriteData) {
                        // Add all frames from each animation to atlases
                        EditorMasterSprite.Animation[] anims = masterSpriteData.editorAnimations; // get animations from editorSprite
                        if(anims == null || anims.Length == 0) // there are no animations in this sprite
                            return; // nothing to do

                        // Create objects to hold frame animation/frame/altas/cell relationships
                        animations = new AMAnimation[anims.Length];
                        for(int i = 0; i < anims.Length; i++) { // create one per animation
                            animations[i] = new AMAnimation(this, anims[i]);
                        }

                        // Add each animation to atlases
                        for(int i = 0; i < animations.Length; i++) {
                            atlasMaker.AddAnimToAtlases(animations[i], i, masterSpriteData); // add the animation to an atlas
                        }

                        // get atlases used by this sprite
                        localAtlases = GetAtlases();
                    }

                    private AMAtlas[] GetAtlases() {
                        AMAtlas[] atlases = null;
                        for(int i = 0; i < animations.Length; i++) {
                            AMAtlas[] atlasesInAnim = animations[i].GetAtlasesFromFrames();
                            if(atlasesInAnim == null) continue;
                            for(int j = 0; j < atlasesInAnim.Length; j++) {
                                if(SpriteFactory.Utils.ArrayTools.IndexOf<AMAtlas>(atlases, atlasesInAnim[j]) >= 0) continue; // already in list
                                SpriteFactory.Utils.ArrayTools.Add<AMAtlas>(ref atlases, atlasesInAnim[j]); // add atlas to list
                            }
                        }
                        return atlases;
                    }

                    // AFTER ATLASES ARE MADE FUNCTIONS

                    public void UpdateMasterSprite() {

                        // Copy data

                        if(animations == null || animations.Length == 0) { // no animations
                            masterSpriteData.editorAtlases = null; // make sure atlases are cleared if there are no more animations
                            return;
                        }

                        // Update atlas files in animations and frames

                        // Create sprite atlases out of AMAtlases
                        if(localAtlases == null || localAtlases.Length == 0) { // no atlases
                            masterSpriteData.editorAtlases = null; // null out atlases in master sprite
                            return;
                        }
                        int atlasCount = localAtlases.Length;
                        EditorMasterSprite.Atlas[] spriteAtlases = new EditorMasterSprite.Atlas[atlasCount];
                        for(int i = 0; i < atlasCount; i++) {
                            if(localAtlases[i] == null) continue; // skip null atlases
                            spriteAtlases[i] = localAtlases[i].ConvertToEditorMasterSpriteAtlas(); // convert to sprite atlas
                        }
                        masterSpriteData.editorAtlases = spriteAtlases; // store converted atlases in data

                        // Save group to atlas index map for sprites in a group
                        if(atlasMaker.inGroup) { // sprite is in a group
                            int[] atlasToGroupAtlasIndices = new int[atlasCount];
                            for(int i = 0; i < atlasCount; i++) {
                                atlasToGroupAtlasIndices[i] = localAtlases[i].atlasIndex; // save the group index
                            }
                            masterSpriteData.atlasToGroupAtlasIndices = atlasToGroupAtlasIndices; // save in sprite dta
                        } else // not in a group
                            masterSpriteData.atlasToGroupAtlasIndices = null; // clear just in case

                        // Update links to atlases in frames
                        for(int i = 0; i < animations.Length; i++) {
                            animations[i].UpdateAtlasesInMasterSprite();
                        }

                        // Update timestamps of frame images
                        atlasMaker.db.SetCurrentFrameTimestamps(masterSpriteData);

                        // Do final modifications to sprite data after creating atlases
                        masterSpriteData.FinalizeChangesOnAtlasUpdate();
                    }

                    public int ConvertTotalAtlasIndexToSpriteAtlasIndex(int totalAtlasIndex) {
                        // find local index from group index
                        if(totalAtlasIndex < 0 || totalAtlasIndex >= atlasMaker.atlases.Length) return -1;
                        AMAtlas atlas = atlasMaker.atlases[totalAtlasIndex]; // get the atlas
                        for(int i = 0; i < localAtlases.Length; i++) { // find the atlas in the sprite
                            if(localAtlases[i] == atlas) return i; // found the atlas
                        }
                        return -1;
                    }

                    public void CommitToMasterSpritesOnDisk() {
                        // Must reload the editor master sprite from disk because of issues with AssetDatabase.ImportAsset in the texture saving function
                        EditorMasterSprite editorMasterSpriteOnDisk = atlasMaker.db.GetEditorMasterSprite(masterSpriteIndex); // load it again because it may have been lost
                        if(editorMasterSpriteOnDisk == null) {
                            Debug.LogError("Editor master sprite at index " + masterSpriteIndex + " could not be loaded! Skipping.");
                            return;
                        }

                        // Copy modified data to the master sprite on disk
                        masterSpriteData.editorMasterSprite = editorMasterSpriteOnDisk; // replace the reference inside data to its new parent just in case
                        editorMasterSpriteOnDisk.data = masterSpriteData; // store the copy in the master sprite on disk
                        editorMasterSpriteOnDisk.SetDirtyForSave(true); // make sure everything is flagged for saving
                    }

                    /*
                    public void AtlasCreationFinished() {
                        if(masterSpriteData == null) return;
                        masterSpriteData.AtlasCreationFinished();
                    }*/
                }

                private class AMAnimation {
                    public AMSpriteData parent;
                    public EditorMasterSprite.Animation animation;
                    public AMFrame[] frames;


                    public AMAnimation(AMSpriteData inAMSpriteData, EditorMasterSprite.Animation inAnimation) {
                        parent = inAMSpriteData;
                        animation = inAnimation;

                        // Create an AMFrame for each editor frame in animation
                        EditorMasterSprite.Frame[] editorFrames = animation.editorFrames;
                        if(editorFrames == null) return; // no frames
                        frames = new AMFrame[editorFrames.Length];
                        for(int i = 0; i < editorFrames.Length; i++) {
                            frames[i] = new AMFrame(this, editorFrames[i]);
                        }
                    }


                    public void UpdateAtlasesInMasterSprite() {
                        if(frames == null) return;

                        bool useCustomMesh = parent.useCustomMesh;

                        // Update atlas files in animations and frames, which are the same objects that exist in the editorSprite data
                        // Get all AMAtlases as sprite atlases
                        for(int i = 0; i < frames.Length; i++) {
                            if(frames[i].corrupt) { // frame is corrupt
                                frames[i].frame.SetAtlas(-1); // clear atlas index
                                continue; // skip corrupt frames
                            }
                            int totalAtlasIndex = frames[i].atlas.atlasIndex; // get atlas index from the frame
                            int spriteAtlasIndex = parent.ConvertTotalAtlasIndexToSpriteAtlasIndex(totalAtlasIndex); // convert to local sprite atlas index for storage in frame
                            EditorMasterSprite.Frame frame = frames[i].frame;
                            frame.SetAtlas(spriteAtlasIndex); // store atlas index in the frame
                            frames[i].UpdateSpriteFrame(); // update the data in master sprite frame
                            if(useCustomMesh) {
                                int meshFrameUid = frame.meshFrameUid;
                                parent.masterSpriteData.UpdateMeshFramesOnAtlasUpadate(meshFrameUid, spriteAtlasIndex, frame.pixelUVRect); // update atlas indices and UVs in mesh frames
                            }
                        }
                    }

                    public AMAtlas[] GetAtlasesFromFrames() {
                        if(frames == null || frames.Length == 0) return null;
                        AMAtlas[] atlases = null;
                        for(int i = 0; i < frames.Length; i++) {
                            if(frames[i].corrupt) continue; // skip corrupt frames
                            SpriteFactory.Utils.ArrayTools.Add<AMAtlas>(ref atlases, frames[i].atlas);
                        }
                        return atlases;
                    }
                }

                private class AMFrame {
                    public AMAnimation parent;
                    public EditorMasterSprite.Frame frame;
                    public AMAtlas atlas;
                    public int atlasCellIndex;
                    public bool corrupt;
                    private float resolutionTargetScale;

                    public AMAtlasCell cell {
                        get {
                            if(atlas == null || atlasCellIndex == -1) return null;
                            return atlas.cells[atlasCellIndex];
                        }
                    }

                    // Constructor

                    public AMFrame(AMAnimation parent, EditorMasterSprite.Frame inFrame) {
                        this.parent = parent;
                        frame = inFrame;
                        atlasCellIndex = -1;
                        resolutionTargetScale = parent.parent.atlasMaker.resolutionTargetScale; // get the resolution target scale
                    }

                    // Methods

                    public void SetAtlas(AMAtlas inAtlas, int inAtlasCellIndex) {
                        atlas = inAtlas;
                        atlasCellIndex = inAtlasCellIndex;
                    }

                    public void UpdateSpriteFrame() { // update the data in master sprite frame
                        cell.CopyDataToFrame(frame, atlas);
                    }

                    public void VerifyTexture(int maxAtlasSize, out string error) {
                        // Check if texture is missing
                        if(!frame.hasTexture) { // texture is missing
                            corrupt = true;
                            error = "Source Image is missing!";
                            return;
                        }

                        // Update cached texture info in the frame in case the source image was changed by user and this might be a rebuild
                        frame.UpdateCachedTextureInfo();

                        // Check if texture fits atlas

                        // Need to know frame padding, mesh type, mesh padding
                        int extraSize = 0;
                        int framePadding = parent.parent.atlasMaker.db.framePadding * 2;
                        EditorMasterSprite.Data masterSpriteData = parent.parent.masterSpriteData;
                        int scaledFrameWidth;
                        int scaledFrameHeight;
                        Utils.TextureTools.ScaleResolution(frame.width, frame.height, resolutionTargetScale, out scaledFrameWidth, out scaledFrameHeight);

                        if(masterSpriteData.finalUseCustomMesh) {
                            extraSize = Mathf.Max(masterSpriteData.finalAutoMeshExtrude * 2, framePadding);
                        } else {
                            extraSize = framePadding;
                        }

                        if(scaledFrameWidth + extraSize >= maxAtlasSize || scaledFrameHeight + extraSize >= maxAtlasSize) { // texture is too large
                            corrupt = true;
                            error = "Source Image is too large for the current max atlas size (" + maxAtlasSize + " x " + maxAtlasSize + ")! Either shrink the image or increase the max atlas size!";
                            return;
                        }

                        error = string.Empty;
                    }
                }

                private class AMAtlas {
                    public AtlasMaker atlasMaker;
                    public int atlasIndex = -1;
                    private string _atlasGuid;
                    public List<AMAtlasCell> cells = new List<AMAtlasCell>();
                    private int _sizeX;
                    private int _sizeY;
                    private PixelMap pixelMap;
                    private TexturePacker texturePacker;
                    private bool useTexturePacker;

                    public string atlasGuid { get { return _atlasGuid; } } 
                    public int sizeX { get { return _sizeX; } }
                    public int sizeY { get { return _sizeY; } }

                    // Static working vars / consts
                    private static readonly int[] sizes;
                    private const int clearBlockSize = 64;
                    private static readonly Color[] clearPixelBlock;
                    private const int maxImagesPerGC = 20;

                    // Properties
                    public int maxAllowedSize { get { return Mathf.Min(atlasMaker.db.maxAtlasSize, AMAtlas.sizes[AMAtlas.sizes.Length - 1]); } }

                    // Constructors

                    static AMAtlas() { // static constructor
                        sizes = (int[])System.Enum.GetValues(typeof(AtlasSize));
                        clearPixelBlock = new Color[clearBlockSize * clearBlockSize]; // initialize a block of clear pixels to use for clearing the atlases to get around allocation issues. should be clear by default
                    }

                    public AMAtlas(int inAtlasIndex, AtlasMaker inParent) {
                        atlasMaker = inParent;
                        atlasIndex = inAtlasIndex;
                        _sizeX = (int)AtlasSize.p128; // start with smallest atlas first
                        _sizeY = _sizeX; // start square

                        useTexturePacker = true; // always use the texture packer for now

                        //AtlasPackingMethod method = atlasMaker.db.atlasPackingMethod;
                        //if(method == AtlasPackingMethod.Simple) { // pixel map
                        //    useTexturePacker = false;
                        //} else
                        //    useTexturePacker = true; // default to texture packer

                        if(useTexturePacker) texturePacker = new TexturePacker(_sizeX, _sizeY);
                        else pixelMap = new PixelMap(_sizeX, _sizeY);
                    }

                    // Methods

                    public bool Add(AMFrame frame, EditorMasterSprite.Data masterSpriteData) {

                        // Create temporary cell to work with while we try to find space
                        AMAtlasCell tempCell = new AMAtlasCell(masterSpriteData, frame.frame.textureGUID, atlasMaker.db.framePadding, masterSpriteData.finalAutoMeshExtrude, masterSpriteData.bleedPaddingPixels, atlasMaker.db.trimSprites, atlasMaker.db.pixelsPerUnit, atlasMaker.resolutionTarget, atlasMaker.resolutionTargetScale, atlasMaker.resolutionTargetResamplingMode, atlasMaker.db.cache);

                        // try to add incoming texture to atlas
                        bool foundSpace = false;
                        while(!foundSpace) { // expand until we find space or cannot expand anymore
                            if(useTexturePacker) foundSpace = TryAddCell_TexturePacker(tempCell); // test for space and adds to pixel map if space found
                            else foundSpace = TryAddCell(tempCell); // test for space and adds to pixel map if space found
                            if(foundSpace) break; // found space
                            if(!TryExpand()) { // failed to find space enough for these textures
                                return false;
                            }
                        }

                        // add cell to atlas
                        cells.Add(tempCell);

                        // save data in AMframe associating it to this atlas and the proper cell
                        int atlasCellIndex = cells.Count - 1;
                        frame.SetAtlas(this, atlasCellIndex);

                        return true;
                    }

                    public int FindTextureInAtlas(string textureGUID, bool tile, bool tileTop, bool tileBottom, bool tileLeft, bool tileRight, bool useCustomMesh, int autoMeshExtrude) {
                        return FindTextureInCells(cells, textureGUID, tile, tileTop, tileBottom, tileLeft, tileRight, useCustomMesh, autoMeshExtrude);
                    }

                    private int FindTextureInCells(List<AMAtlasCell> inCells, string textureGUID, bool tile, bool tileTop, bool tileBottom, bool tileLeft, bool tileRight, bool useCustomMesh, int autoMeshExtrude) {
                        if(inCells == null || inCells.Count == 0) return -1; // no cells
                        for(int i = 0; i < inCells.Count; i++) {
                            if(inCells[i].HasTexture(textureGUID)) { // found texture in a cell
                                if(inCells[i].DoesTilingMatch(tile, tileTop, tileBottom, tileLeft, tileRight) && // tiling settings must match to reuse the cell
                                   inCells[i].DoesMeshTypeMatch(useCustomMesh, autoMeshExtrude)) // use custom mesh setting must match also because of padding issues
                                    return i; // success
                            }
                        }
                        return -1;
                    }

                    private bool TryAddCell(AMAtlasCell cell) {
                        // see if there is room to add the texture
                        // try to add cell to pixel map
                        SpriteFactory.Utils.DataClasses.IntVector2 startPosition;
                        bool added = pixelMap.TryAddBlock(cell.width, cell.height, out startPosition); // try to add the cell to the pixel map
                        if(added) { // found space in the pixel map, added it
                            cell.SetStartPosition(startPosition); // set the start position of cell
                            return true;
                        }
                        return false;
                    }

                    private bool TryAddCell_TexturePacker(AMAtlasCell cell) {
                        // see if there is room to add the texture
                        // try to add cell to pixel map
                        SpriteFactory.Utils.DataClasses.IntVector2 startPosition;
                        bool added = texturePacker.Insert(cell.width, cell.height, out startPosition); // try to add the cell
                        if(added) { // found space in the pixel map, added it
                            cell.SetStartPosition(startPosition); // set the start position of cell
                            return true;
                        }
                        return false;
                    }

                    private bool TryExpand() { // increase size of the pixel grid
                        // Check if we have reached the max allowed size
                        if(_sizeX >= maxAllowedSize && _sizeY >= maxAllowedSize) return false; // already at the largest size we can use, failed

                        // Try to resize
                        bool forceSquare = atlasMaker.db.forceSquareAtlases;
                        for(int i = 0; i < AMAtlas.sizes.Length; i++) {
                            int nextSize = AMAtlas.sizes[i];
                            if(_sizeX >= nextSize && _sizeY == _sizeX) continue; // too small to consider

                            // Check if we want to expand horizontally or vertically
                            int newSizeX;
                            int newSizeY;

                            if(forceSquare) { // only square atlases allowed
                                newSizeX = nextSize;
                                newSizeY = nextSize;
                            } else { // rectangle atlases allowed
                                // Always expand X first, then expand Y to make square
                                newSizeX = _sizeX <= _sizeY ? nextSize : _sizeX; // expand horizontally if square
                                newSizeY = _sizeY < _sizeX ? nextSize : _sizeY; // expand vertically if not square
                            }

                            if(newSizeX > maxAllowedSize || newSizeY > maxAllowedSize) return false;
                            if(newSizeX > _sizeX || newSizeY > _sizeY) {
                                Expand(newSizeX, newSizeY);
                                return true;
                            }
                        }
                        return false;
                    }

                    private void Expand(int sizeX, int sizeY) {
                        this._sizeX = sizeX;
                        this._sizeY = sizeY;
                        if(useTexturePacker) {
                            texturePacker = new TexturePacker(sizeX, sizeY);
                            RecalculateTexturePacker(); // update the texture packer
                        } else {
                            pixelMap.Resize(sizeX, sizeY); // resize without having to rebuild
                            //pixelMap = new PixelMap(size, size);
                            //RecalculatePixelMap(); // update the pixel map
                        }
                    }

                    private void RecalculatePixelMap() {
                        pixelMap.Clear();

                        // Add texture from each cell back into pixel map
                        // there should always be space to re-add the same ones back so no need to verify space
                        AddCellsToPixelMap(cells);
                    }

                    private void RecalculateTexturePacker() {
                        texturePacker.Clear();

                        // Add texture from each cell back into pixel map
                        // there should always be space to re-add the same ones back so no need to verify space
                        AddCellsToTexturePacker(cells);
                    }

                    private void AddCellsToPixelMap(List<AMAtlasCell> inCells) { // used by recalculate pixel map -- should always be space to fit
                        for(int i = 0; i < inCells.Count; i++) {
                            AMAtlasCell cell = inCells[i];
                            if(cell == null) continue;

                            SpriteFactory.Utils.DataClasses.IntVector2 startPos;
                            if(!pixelMap.TryAddBlock(cell.width, cell.height, out startPos)) // add the block to the pixel map
                                throw new System.Exception("Failed to add block to pixel map!");
                            cell.SetStartPosition(startPos); // save cell's starting position in pixel grid
                        }
                    }

                    private void AddCellsToTexturePacker(List<AMAtlasCell> inCells) { // used by recalculate pixel map -- should always be space to fit
                        for(int i = 0; i < inCells.Count; i++) {
                            AMAtlasCell cell = inCells[i];
                            if(cell == null) continue;

                            SpriteFactory.Utils.DataClasses.IntVector2 startPos;
                            bool added = texturePacker.Insert(cell.width, cell.height, out startPos); // add the block to the map
                            if(!added) throw new System.Exception("Failed to add block to pixel map!");

                            cell.SetStartPosition(startPos); // save cell's starting position in pixel grid
                        }
                    }

                    private int FindTexture(Texture2D inTexture) {
                        string texturePath = AssetDatabase.GetAssetPath(inTexture);
                        if(texturePath == null || texturePath == string.Empty) return -1;
                        string guid = AssetDatabase.GUIDToAssetPath(texturePath);
                        if(guid == null || guid == string.Empty) return -1;

                        for(int i = 0; i < cells.Count; i++) {
                            if(cells[i].HasTexture(guid)) return i;
                        }
                        return -1;
                    }

                    public void SaveTexture(string atlasPath) {
                        CreateTextureMapFile(atlasPath);
                        System.GC.Collect(); // colldect garbage after every atlas saved
                    }

                    private void CreateTextureMapFile(string path) {
                        string pngPath = path;

                        // Create new texture for atlas
                        Texture2D newTex = new Texture2D(_sizeX, _sizeY, TextureFormat.ARGB32, atlasMaker.db.useMipMaps); // create new texture
                        newTex.hideFlags = HideFlags.DontSave;
                        ClearTexture(newTex); // clear the new texture to transparent

                        // Write each image in atlas cells to texture
                        // Do not bother trying to multi-thread this -- it doesn't help and causes a big increase in memory use
                        for(int i = 0; i < cells.Count; i++) {
                            AMAtlasCell cell = cells[i];
                            DrawToTexture(newTex, cell);
                        }

                        //newTex.Apply(); // apply the changes to the texture - not necessary since we're not loading it into GPU
                        byte[] png = newTex.EncodeToPNG(); // encode image to png
                        Object.DestroyImmediate(newTex); // prevent texture leaking
                        newTex = null;

                        // Save the png file
                        string dirPath = Path.GetDirectoryName(pngPath);
                        if(!DirectoryExistsRel(dirPath)) CreateDirectoryRel(dirPath); // create directory if it doesn't exist
                        using(FileStream fs = new FileStream(RelToAbsPath(pngPath), FileMode.Create)) { // overwrite if exists
                            using(BinaryWriter writer = new BinaryWriter(fs)) {
                                writer.Write(png);
                            }
                        }
                        png = null; // clear the PNG before the import call because import seems to do very effective garbage collection

                        // Import the png file
                        ImportAssetRel(pngPath, ImportAssetOptions.ForceUpdate);
                        // setting the import options has been moved to an AssetPostprocessor hook

                        // Store guid of atlas
                        _atlasGuid = GetAssetGUIDAtPathRel(pngPath);
                    }

                    private void ClearTexture(Texture2D texture) {
                        // Clear texture by stamping clear block over it multiple times
                        // This is done to reduce the impact of gigantic Color[] arrays on the Mono heap
                        // This is a compromise between writing every pixels with SetPixel which is slow and writing a huge block at once with SetPixels

                        // Gigantic array allocations cause memory leaks in Unity! (Tested 4.3.1f1)
                        // We cannot use texture.GetPixels() or create gigantic Color[] arrays or we'll eat up hundreds of megs
                        // and the Mono Heap will keep growing
                        // make the atlas clear

                        // This method is bad because it creates a gigantic array and Mono won't garbage collect it properly
                        //Color[] clearPixels = new Color[sizeX * sizeY];
                        //for(int i = 0; i < clearPixels.Length; i++) {
                        //    clearPixels[i].r = 0.0f;
                        //    clearPixels[i].g = 0.0f;
                        //    clearPixels[i].b = 0.0f;
                        //    clearPixels[i].a = 0.0f;
                        //}
                        //newTex.SetPixels(clearPixels);

                        int rows = texture.height / clearBlockSize;
                        int cols = texture.width / clearBlockSize;

                        for(int row = 0; row < rows; row++) {
                            for(int col = 0; col < cols; col++) {
                                texture.SetPixels(col * clearBlockSize, row * clearBlockSize, clearBlockSize, clearBlockSize, clearPixelBlock);
                            }
                        }
                    }

                    private void DrawToTexture(Texture2D texture, AMAtlasCell cell) {
                        Color[] pixels = cell.GetFinalPixels(); // get the pixels of the image trimmed and padded if necessary
                        if(pixels == null) return;

                        // Apply watermark if trial version
                        // Moved it here because we're already getting the pixels anyway, so this doesn't waste any extra heap memory
#if TRIALVERSION
                        Watermark.ApplyToTexture(pixels, cell.width, cell.height);
#endif
                        texture.SetPixels(cell.startPos.x, cell.startPos.y, cell.width, cell.height, pixels); // write pixels to the texture
                    }

                    public EditorMasterSprite.Atlas ConvertToEditorMasterSpriteAtlas() {
                        EditorMasterSprite.Atlas emsAtlas = new EditorMasterSprite.Atlas(); // create new sprite atlas
                        emsAtlas.textureMapGUID = _atlasGuid;
                        emsAtlas.width = _sizeX;
                        emsAtlas.height = _sizeY;
                        emsAtlas.trim = atlasMaker.db.trimSprites;
                        emsAtlas.padding = atlasMaker.db.framePadding;
                        return emsAtlas;
                    }
                }

                private class AMAtlasCell {

                    #region Variables

                    // All vars are in PIXELS, not UV coords

                    private string _textureGUID;
                    private int origTextureWidth; // original width of texture
                    private int origTextureHeight; // original height of texture
                    private bool _trim;
                    private int trimTop;
                    private int trimBot;
                    private int trimLeft;
                    private int trimRight;
                    private SpriteFactory.Utils.DataClasses.IntVector2 trimDiff;
                    private int padding;
                    private int _width; // final trimmed width + padding
                    private int _height; // final trimmed height + padding
                    private int trimmedWidth;
                    private int trimmedHeight;
                    private SpriteFactory.Utils.DataClasses.IntVector2 _startPos; // INCLUDES padding
                    private SpriteFactory.Utils.DataClasses.IntRect finalPixelRect; // trimmed pixel rect within the padding. This represents the actual displayed sprite rect area in pixels.
                    private int pixelsPerUnit;
                    private bool useCustomMesh;
                    private bool tile;
                    private bool tileTop;
                    private bool tileBottom;
                    private bool tileLeft;
                    private bool tileRight;
                    private SpriteFactory.Utils.DataClasses.IntPadding bleedPadding;
                    SpriteFactory.Enums.ResolutionTarget resolutionTarget;
                    SpriteFactory.Enums.ImageResamplingMode resolutionTargetResamplingMode;
                    private float resolutionTargetScale;
                    private CacheDataObject cache;

                    #endregion

                    #region Properties

                    public string textureGUID { get { return _textureGUID; } }
                    public bool trim { get { return _trim; } }
                    public int width { get { return _width; } }
                    public int height { get { return _height; } }
                    public SpriteFactory.Utils.DataClasses.IntVector2 startPos { get { return _startPos; } } // position of lower left pixel in pixel grid

                    #endregion

                    public AMAtlasCell(EditorMasterSprite.Data masterSpriteData, string textureGUID, int inPadding, int autoMeshExtrude, SpriteFactory.Utils.DataClasses.IntPadding inBleedPadding, bool inTrim, int inPixelsPerUnit, SpriteFactory.Enums.ResolutionTarget resolutionTarget, float resolutionTargetScale, SpriteFactory.Enums.ImageResamplingMode resamplingMode, CacheDataObject cache) {
                        this.cache = cache;
                        this._textureGUID = textureGUID;
                        this.resolutionTarget = resolutionTarget;
                        this.resolutionTargetScale = resolutionTargetScale;
                        resolutionTargetResamplingMode = resamplingMode;
                        ColorImage scaledImage = GetScaledTextureFromCache(); // load the scaled texture
                        padding = inPadding;
                        bleedPadding = inBleedPadding;
                        _trim = inTrim;
                        origTextureWidth = scaledImage.width;
                        origTextureHeight = scaledImage.height;
                        _width = origTextureWidth;
                        _height = origTextureHeight;
                        trimmedWidth = origTextureWidth;
                        trimmedHeight = origTextureHeight;
                        trimDiff = new SpriteFactory.Utils.DataClasses.IntVector2();
                        pixelsPerUnit = inPixelsPerUnit;
                        tile = masterSpriteData.tile;
                        tileTop = masterSpriteData.tileTop;
                        tileBottom = masterSpriteData.tileBottom;
                        tileLeft = masterSpriteData.tileLeft;
                        tileRight = masterSpriteData.tileRight;
                        useCustomMesh = masterSpriteData.finalUseCustomMesh;

                        // Set padding amount
                        if(useCustomMesh) { // using a custom mesh
                            padding = Mathf.Max(padding, autoMeshExtrude); // set padding to the larger of the two paddings
                            bleedPadding = new SpriteFactory.Utils.DataClasses.IntPadding(); // clear bleed padding because it does not work with custom meshes
                        }

                        if(_trim) Trim(scaledImage); // trim textures
                        AddPadding();
                    }
                    
                    private void Trim(ColorImage image) {
                        // calculate trim amounts, offset to realign, and final dimensions
                        Utils.TextureTools.TrimInfo trimInfo = new Utils.TextureTools.TrimInfo(image, Enums.TransparencyChannel.Alpha, 0.0f);
                        trimTop = trimInfo.trimTop;
                        trimBot = trimInfo.trimBottom;
                        trimLeft = trimInfo.trimLeft;
                        trimRight = trimInfo.trimRight;

                        // Recaclulate trimmed dimensions
                        trimmedWidth = trimInfo.width;
                        trimmedHeight = trimInfo.height;
                        _width = trimmedWidth;
                        _height = trimmedHeight;

                        // Find offsets -- not really true offset since that would be 1/2 each of these, but its the trim difference
                        trimDiff.x = trimRight - trimLeft;
                        trimDiff.y = trimTop - trimBot;
                    }

                    private void AddPadding() {
                        if(padding <= 0) return;

                        int totalPadding = padding * 2;
                        _width += totalPadding;
                        _height += totalPadding;
                    }

                    public void SetStartPosition(SpriteFactory.Utils.DataClasses.IntVector2 inStartPos) {
                        _startPos = inStartPos;
                        RecalulateFinalRect(); // calculate the final pixel rect with the new start positon
                    }

                    private void RecalulateFinalRect() {
                        // Calculate final pixel rect using new start position. This rect is the final trimmed rect.
                        // Include bleed padding in the final rect if any because we will draw these pixels
                        finalPixelRect = new SpriteFactory.Utils.DataClasses.IntRect(
                            _startPos.x + padding - bleedPadding.left,
                            _startPos.y + padding - bleedPadding.bottom,
                            trimmedWidth + bleedPadding.left + bleedPadding.right,
                            trimmedHeight + bleedPadding.top + bleedPadding.bottom
                        );
                    }

                    public bool HasTexture(string textureGUID) {
                        if(textureGUID == null || textureGUID == string.Empty) return false;
                        if(this._textureGUID == textureGUID) return true;
                        return false;
                    }

                    public Color[] GetFinalPixels() {
                        ColorImage scaledImage = GetScaledTextureFromCache();
                        WorkingImage image = new WorkingImage();

                        if(!trim) { // this is not trimmed
                            image.ImportTexture(scaledImage); // no trim, just use the whole texture
                        } else { // this is trimmed
                            image.ImportTexture(scaledImage);
                            image.Trim(trimTop, trimBot, trimLeft, trimRight); // trim the image
                        }
                        if(image.isInvalid) return null;
                        if(padding == 0) return image.pixels; // no padding, we are done

                        // We have padding
                        
                        // Pad the pixels
                        Color[] paddedPixels = new Color[_width * _height]; // create new block big enough to hold final padded image

                        // We must bleed the edges so we don't get artifacts
                        // Edges that are tiled will be bled out from the last pixel in the trimmed area
                        // Edges that are not tiled will be bled out from 1 pixel outside the trimmed area if we trimmed, or the last pixel in the image if we didn't trim

                        Color[] topEdge, bottomEdge, leftEdge, rightEdge;

                        // Copy edge pixels out to fill the pad so we bleed to the same pixel color

                        // Top edge
                        if((!tile || !tileTop) && trim && trimTop > 0) { // not tiled, we trimmed some pixels, use those
                            // get an edge of pixels we can use to bleed, prefer getting the edge before a trim if we have it
                            topEdge = image.GetPretrimmedEdgeBleed(WorkingImage.Edge.Top); // get 1 pixel edge of pixels just outside the trim
                        } else { // edge is tiled or no trimmed pixels available, so use the edge from the trimmed frame
                            topEdge = image.GetRow(WorkingImage.Edge.Top, 0);
                        }

                        // Bottom edge
                        if((!tile || !tileBottom) && trim && trimBot > 0) { // not tiled, we trimmed some pixels, use those
                            // get an edge of pixels we can use to bleed, prefer getting the edge before a trim if we have it
                            bottomEdge = image.GetPretrimmedEdgeBleed(WorkingImage.Edge.Bottom); // get 1 pixel edge of pixels just outside the trim
                        } else { // edge is tiled or no trimmed pixels available, so use the edge from the trimmed frame
                            bottomEdge = image.GetRow(WorkingImage.Edge.Bottom, 0);
                        }

                        // Left edge    
                        if((!tile || !tileLeft) && trim && trimLeft > 0) { // not tiled, we trimmed some pixels, use those
                            // get an edge of pixels we can use to bleed, prefer getting the edge before a trim if we have it
                            leftEdge = image.GetPretrimmedEdgeBleed(WorkingImage.Edge.Left); // get 1 pixel edge of pixels just outside the trim
                        } else { // edge is tiled or no trimmed pixels available, so use the edge from the trimmed frame
                            leftEdge = image.GetColumn(WorkingImage.Edge.Left, 0);
                        }

                        // Right edge
                        if((!tile || !tileRight) && trim && trimRight > 0) { // not tiled, we trimmed some pixels, use those
                            // get an edge of pixels we can use to bleed, prefer getting the edge before a trim if we have it
                            rightEdge = image.GetPretrimmedEdgeBleed(WorkingImage.Edge.Right); // get 1 pixel edge of pixels just outside the trim
                        } else { // edge is tiled or no trimmed pixels available, so use the edge from the trimmed frame
                            rightEdge = image.GetColumn(WorkingImage.Edge.Right, 0);
                        }

                        // Zero alpha on edges if we're not tiling because we just want the color for matte
                        if(!tile) {
                            ZeroAlpha(topEdge);
                            ZeroAlpha(bottomEdge);
                            ZeroAlpha(leftEdge);
                            ZeroAlpha(rightEdge);
                        } else {
                            if(!tileTop) ZeroAlpha(topEdge);
                            if(!tileBottom) ZeroAlpha(bottomEdge);
                            if(!tileLeft) ZeroAlpha(leftEdge);
                            if(!tileRight) ZeroAlpha(rightEdge);
                        }

                        // Copy edge pixels to padding
                        for(int i = 0; i < padding; i++) {
                            Utils.TextureTools.WriteRow(paddedPixels, _width, _height, topEdge, _height - padding + i, padding); // top row
                            Utils.TextureTools.WriteRow(paddedPixels, _width, _height, bottomEdge, i, padding); // bottom row
                            Utils.TextureTools.WriteColumn(paddedPixels, _width, _height, leftEdge, i, padding); // left column
                            Utils.TextureTools.WriteColumn(paddedPixels, _width, _height, rightEdge, _width - padding + i, padding); // right column
                        }

                        // Fill in the corners
                        Utils.TextureTools.FillRegion(paddedPixels, _width, _height, 0, 0, bottomEdge[0], padding, padding); // bottom left
                        Utils.TextureTools.FillRegion(paddedPixels, _width, _height, 0, _width - padding, bottomEdge[bottomEdge.Length - 1], padding, padding); // bottom right
                        Utils.TextureTools.FillRegion(paddedPixels, _width, _height, _height - padding, 0, topEdge[0], padding, padding); // top left
                        Utils.TextureTools.FillRegion(paddedPixels, _width, _height, _height - padding, _width - padding, topEdge[topEdge.Length - 1], padding, padding); // top right

                        // Copy the pixels to the proper location in the new image
                        // Remember: 0,0 is lower left pixel! Rows go UP!
                        Color[] pixels = image.pixels; // get pixels from the image
                        int rows = _height;
                        int cols = _width;
                        int rowsWriting = rows - padding; // only write out to the end before the pad
                        int colsWriting = cols - padding;
                        int count = 0;
                        for(int row = padding; row < rowsWriting; row++) {
                            for(int col = padding; col < colsWriting; col++) {
                                int index = row * cols + col;
                                paddedPixels[index] = pixels[count++]; // copy pixel
                            }
                        }

                        return paddedPixels;
                    }

                    private void ZeroAlpha(Color[] colors) {
                        for(int i = 0; i < colors.Length; i++)
                            colors[i].a = 0.0f;
                    }

                    private Color FindBackgroundColor() {
                        ColorImage sourceImage = GetSourceImage();
                        Color color = new Color();
                        FindBackgroundColor(sourceImage.colors, ref color);
                        return color;
                    }

                    private bool FindBackgroundColor(Color[] pixels, ref Color color) {
                        int pixelCount = pixels.Length;
                        int[] colorCount = new int[pixelCount]; // a count of how many pixels of that color we found, corresponding to pixels in the row
                        bool foundTransparent = false;

                        // Compare each pixel in the top row to every other pixel in the top row to find the most common color
                        for(int i = 0; i < pixelCount; i++) {
                            if(pixels[i].a > 0.0f) continue; // not a transparent pixel, skip

                            // compare to other pixels in the row
                            for(int j = 0; j < pixelCount; j++) {
                                if(i == j) continue; // don't compare to self
                                if(pixels[j].a > 0.0f) continue; // not a transparent pixel, skip

                                if(pixels[i] == pixels[j]) { // this pixel is the same color, count it
                                    colorCount[i]++;
                                    pixels[j].a = 1.0f; // make opaque so we don't count this color again
                                    if(!foundTransparent) foundTransparent = true;
                                }
                            }
                        }
                        if(foundTransparent) { // we found at least 1 transparent pixel
                            // determine which pixel color was repeated the most
                            int highest = -1;
                            int highestIndex = -1;
                            for(int i = 0; i < pixelCount; i++) {
                                if(colorCount[i] > highest) {
                                    highest = colorCount[i];
                                    highestIndex = i;
                                }
                            }
                            color = pixels[highestIndex]; // return the background color 
                            return true;
                        }
                        return false;
                    }

                    public bool DoesTilingMatch(bool inTile, bool inTileTop, bool inTileBottom, bool inTileLeft, bool inTileRight) {
                        if(tile == inTile) {
                            if(tile) {
                                if(tileTop == inTileTop && tileBottom == inTileBottom && tileLeft == inTileLeft && tileRight == inTileRight) return true;
                            } else return true; // other settings don't matter if !tile
                        }
                        return false;
                    }

                    public bool DoesMeshTypeMatch(bool useCustomMesh, int autoMeshExtrude) {
                        if(this.useCustomMesh != useCustomMesh) return false; // type does not match
                        if(!useCustomMesh) return true; // not a custom mesh so extrude doesn't matter

                        // types match but need to check extrude vs padding
                        if(autoMeshExtrude > padding) return false; // padding which is the Max of extrude or frame padding must be >= automesh extrude or we can't reuse the cell

                        return true;
                    }

                    public void CopyDataToFrame(EditorMasterSprite.Frame frame, AMAtlas atlas) {
                        int width;
                        int height;

                        string atlasPath = Utils.AssetTools.GetAssetPathFromGUID(atlas.atlasGuid);
                        if(atlasPath == null || atlasPath == string.Empty) {
                            width = 0;
                            height = 0;
                        } else {
                            width = atlas.sizeX;
                            height = atlas.sizeY;
                        }

                        // Gather all data to send to frame
                        AtlasCellData data = new AtlasCellData();
                        data.atlasWidth = width;
                        data.atlasHeight = height;
                        data.pixelUVRect = SpriteFactory.Utils.DataClasses.IntRect.Clone(finalPixelRect);
                        data.pixelTrimDiff = SpriteFactory.Utils.DataClasses.IntVector2.Clone(trimDiff);
                        data.pixelsPerUnit = pixelsPerUnit;
                        data.trim = _trim;
                        data.useCustomMesh = useCustomMesh;
                        data.resolutionTarget = resolutionTarget;

                        // Send the data to the frame
                        frame.ImportAtlasCellData(data);
                    }

                    private ColorImage GetSourceImage() {
                        return Utils.AssetTools.LoadTextureFromGUIDAsColorImage(_textureGUID);
                    }

                    private ColorImage GetScaledTextureFromCache() {
                        if(resolutionTarget == Enums.ResolutionTarget.One) return GetSourceImage(); // no scaling, just get the real texture
                        return cache.GetResolutionTargetImage(_textureGUID);
                    }

                    private class WorkingImage {

                        public enum Image { Default, Untrimmed }
                        public enum Edge { Top, Bottom, Left, Right }

                        private Color[] untrimmedImage;
                        private int untrimmedWidth;
                        private int untrimmedHeight;

                        private Color[] _pixels;
                        private int _width;
                        private int _height;

                        private int trimTop;
                        private int trimBottom;
                        private int trimLeft;
                        private int trimRight;

                        private bool isTrimmed;
                        private bool textureIsSet;

                        // Properties

                        public Color[] pixels { get { return _pixels; } }
                        public int width { get { return _width; } }
                        public int height { get { return _height; } }
                        public bool isInvalid { get; private set; }

                        // Constructors

                        public WorkingImage() { }

                        public WorkingImage(Texture2D texture) {
                            ImportTexture(texture);
                        }

                        // Methods

                        public void ImportTexture(Texture2D texture) {
                            if(textureIsSet) {
                                Debug.LogError("Texture is already set!");
                                return; // don't assign texture again
                            }
                            if(texture == null) {
                                Debug.LogError("Texture is null!");
                                return;
                            }
                            textureIsSet = true;

                            _pixels = texture.GetPixels();
                            _width = texture.width;
                            _height = texture.height;
                        }

                        public void ImportTexture(ColorImage image) {
                            if(textureIsSet) {
                                Debug.LogError("Texture is already set!");
                                return; // don't assign texture again
                            }
                            if(image == null || !image.isValid) {
                                Debug.LogError("Image is null or invalid!");
                                return;
                            }
                            textureIsSet = true;

                            _pixels = image.colors;
                            _width = image.width;
                            _height = image.height;
                        }

                        public void SetTrim() {

                        }

                        public void Scale(float scale, Enums.ImageResamplingMode resamplingMode) {
                            if(scale <= 0.0f || scale == 1.0f) return; // no scale

                            // Scale the image updating width and height
                            _pixels = ScalePixels(scale, _pixels, _width, _height, out _width, out _height, resamplingMode);

                            // Check and make sure returned image is valid
                            if(_pixels == null || pixels.Length == 0 || _width <= 0 || _height <= 0) {
                                isInvalid = true;
                            }
                        }

                        private Color[] ScalePixels(float scale, Color[] pixels, int width, int height, out int newWidth, out int newHeight, Enums.ImageResamplingMode resamplingMode) {
                            if(scale <= 0.0f || scale == 1.0f) {
                                newWidth = width;
                                newHeight = height;
                                return pixels;
                            }
                            if(width * height != pixels.Length) throw new System.ArgumentOutOfRangeException("pixels.length must equal width * height!");

                            // Scale the image
                            Utils.TextureTools.ScaleResolution(width, height, scale, out newWidth, out newHeight);

                            return Utils.TextureTools.Scale(pixels, width, height, newWidth, newHeight, resamplingMode);
                        }

                        public void Trim(int trimTop, int trimBottom, int trimLeft, int trimRight) {
                            if(isTrimmed) {
                                Debug.LogWarning("Already trimmed!");
                                return;
                            }
                            this.trimTop = trimTop;
                            this.trimBottom = trimBottom;
                            this.trimLeft = trimLeft;
                            this.trimRight = trimRight;
                            if(trimTop <= 0 && trimBottom <= 0 && trimLeft <= 0 && trimRight <= 0) return; // no trim

                            // save the untrimmed image for later
                            untrimmedImage = _pixels;
                            untrimmedWidth = _width;
                            untrimmedHeight = _height;

                            ApplyTrim(); // do the trim
                        }

                        private void ApplyTrim() {
                            if(isTrimmed) return;
                            if(_width * _height != this._pixels.Length) throw new System.ArgumentOutOfRangeException("pixels.length must equal width * height!");

                            isTrimmed = true;
                            int newWidth = _width - trimLeft - trimRight;
                            int newHeight = _height - trimTop - trimBottom;
                            if(newWidth == _width && newHeight == _height) return; // nothing to trim

                            Color[] targetPixels = new Color[newWidth * newHeight];
                            Color[] sourcePixels = this._pixels; // cache for speed
                            int rowEnd = _height - trimTop;
                            int colEnd = _width - trimRight;

                            for(int row = trimBottom; row < rowEnd; row++) {
                                int targetRow = row - trimBottom;
                                for(int col = trimLeft; col < colEnd; col++) {
                                    int index = row * _width + col;
                                    int targetCol = col - trimLeft;
                                    int targetIndex = targetRow * newWidth + targetCol;

                                    // Copy pixels
                                    targetPixels[targetIndex].r = sourcePixels[index].r;
                                    targetPixels[targetIndex].g = sourcePixels[index].g;
                                    targetPixels[targetIndex].b = sourcePixels[index].b;
                                    targetPixels[targetIndex].a = sourcePixels[index].a;
                                }
                            }
                            this._pixels = targetPixels;
                            this._width = newWidth;
                            this._height = newHeight;
                        }

                        public Color[] GetPixels(int startRow, int startCol, int width, int height, Image sourceImage = Image.Default) {
                            int sourceWidth, sourceHeight;
                            Color[] sourcePixels = GetImage(sourceImage, out sourceWidth, out sourceHeight);
                            return Utils.TextureTools.GetPixels(sourcePixels, sourceWidth, sourceHeight, startRow, startCol, width, height);
                        }

                        public Color[] GetRow(int row, Image sourceImage = Image.Default) {
                            int sourceWidth, sourceHeight;
                            Color[] sourcePixels = GetImage(sourceImage, out sourceWidth, out sourceHeight);
                            return Utils.TextureTools.GetRow(sourcePixels, sourceWidth, sourceHeight, row);
                        }

                        public Color[] GetRow(Edge edge, int row, Image sourceImage = Image.Default) {
                            if(edge == Edge.Left || edge == Edge.Right) throw new System.ArgumentOutOfRangeException("edge must be either Bottom or Top!");
                            int offset = GetEdgeOffset(edge, row, sourceImage);
                            return GetRow(offset, sourceImage);
                        }

                        public Color[] GetColumn(int col, Image sourceImage = Image.Default) {
                            int sourceWidth, sourceHeight;
                            Color[] sourcePixels = GetImage(sourceImage, out sourceWidth, out sourceHeight);
                            return Utils.TextureTools.GetColumn(sourcePixels, sourceWidth, sourceHeight, col);
                        }

                        public Color[] GetColumn(Edge edge, int col, Image sourceImage = Image.Default) {
                            if(edge == Edge.Bottom || edge == Edge.Top) throw new System.ArgumentOutOfRangeException("edge must be either Left or Right!");
                            int offset = GetEdgeOffset(edge, col, sourceImage);
                            return GetColumn(offset, sourceImage);
                        }

                        public Color[] GetPretrimmedEdgeBleed(Edge edge) {
                            if(!isTrimmed) throw new System.Exception("This cannot be called with no trim!");

                            int width;
                            int height;
                            Color[] sourceImage = GetImage(Image.Untrimmed, out width, out height);

                            if(edge == Edge.Left) {
                                return Utils.TextureTools.GetPixels(sourceImage, width, height, trimLeft - 1, trimBottom, 1, this._height);
                            } else if(edge == Edge.Right) {
                                return Utils.TextureTools.GetPixels(sourceImage, width, height, width - trimRight, trimBottom, 1, this._height);
                            } else if(edge == Edge.Top) {
                                return Utils.TextureTools.GetPixels(sourceImage, width, height, trimLeft, height - trimTop, this._width, 1);
                            } else if(edge == Edge.Bottom) {
                                return Utils.TextureTools.GetPixels(sourceImage, width, height, trimLeft, trimBottom - 1, this._width, 1);
                            } else {
                                throw new System.NotImplementedException();
                            }
                        }

                        private Color[] GetImage(Image type, out int width, out int height) {
                            if(!isTrimmed && type == Image.Untrimmed) type = Image.Default;

                            if(type == Image.Default) {
                                width = this._width;
                                height = this._height;
                                return _pixels;
                            } else if(type == Image.Untrimmed) {
                                width = this.untrimmedWidth;
                                height = this.untrimmedHeight;
                                return untrimmedImage;
                            } else {
                                throw new System.NotImplementedException();
                            }
                        }

                        private void GetImageDimensions(Image type, out int width, out int height) {
                            if(!isTrimmed && type == Image.Untrimmed) type = Image.Default;

                            if(type == Image.Default) {
                                width = this._width;
                                height = this._height;
                            } else if(type == Image.Untrimmed) {
                                width = this.untrimmedWidth;
                                height = this.untrimmedHeight;
                            } else {
                                throw new System.NotImplementedException();
                            }
                        }

                        private int GetEdgeOffset(Edge edge, int index, Image sourceImage) {
                            int width;
                            int height;
                            GetImageDimensions(sourceImage, out width, out height);

                            if(edge == Edge.Left || edge == Edge.Bottom) return index;
                            if(edge == Edge.Top) return height - index - 1;
                            return width - index - 1; // right edge
                        }
                    }
                }

                private class PixelMap {
                    private bool[] _map;
                    private int _freeSpace;
                    private int _width;
                    private int _height;

                    public bool[] map { get { return (bool[])_map.Clone(); } } // return a copy of map so no changes can be made to it
                    public int freeSpace { get { return _freeSpace; } }
                    public int width { get { return _width; } }
                    public int height { get { return _height; } }


                    public PixelMap(int inWidth, int inHeight) {
                        _width = inWidth;
                        _height = inHeight;
                        Clear();
                    }

                    public PixelMap(PixelMap inPixelMap) { // used for cloning
                        _map = inPixelMap.map;
                        _width = inPixelMap.width;
                        _height = inPixelMap.height;
                        CalculateFreeSpace();
                    }

                    public bool TryAddBlock(int pixelsX, int pixelsY, out SpriteFactory.Utils.DataClasses.IntVector2 startPos) {
                        bool spaceFound = FindSpace(pixelsX, pixelsY, out startPos);
                        if(!spaceFound) return false; // no space for block
                        ForceAddBlock(pixelsX, pixelsY, startPos);
                        return true;
                    }

                    public bool ForceAddBlock(int pixelsX, int pixelsY, SpriteFactory.Utils.DataClasses.IntVector2 startPos) {
                        int endRow = startPos.y + pixelsY;
                        int endCol = startPos.x + pixelsX;
                        if(endCol > _width || endRow > _height) return false; // block would run off edge

                        for(int row = startPos.y; row < endRow; row++) {
                            for(int col = startPos.x; col < endCol; col++) {
                                int index = row * _width + col;
                                _map[index] = true; // mark space used
                            }
                        }
                        _freeSpace -= pixelsX * pixelsY; // set amount of space free in map
                        return true;
                    }

                    public bool FindSpace(int pixelsX, int pixelsY, out SpriteFactory.Utils.DataClasses.IntVector2 outStartPos) {
                        if(pixelsX * pixelsY > _freeSpace) { // quick check against total free space -- not enough left
                            outStartPos = null;
                            return false; // fail
                        }

                        // look for space in the pixel map
                        for(int row = 0; row < _height; row++) {
                            if(row + pixelsY > _height) break; // too close to bottom to fit, fail
                            for(int col = 0; col < _width; col++) {
                                if(col + pixelsX > _width) break; // too close to edge to fit, go to next row
                                int index = row * _width + col;
                                if(_map[index]) continue; // pixel was used
                                if(IsBlockEmpty(pixelsX, pixelsY, col, row)) { // check if the whole block will fit
                                    outStartPos = new SpriteFactory.Utils.DataClasses.IntVector2(col, row);
                                    return true;
                                }
                            }
                        }
                        outStartPos = new SpriteFactory.Utils.DataClasses.IntVector2();
                        return false;
                    }

                    private bool IsBlockEmpty(int pixelsX, int pixelsY, int startX, int startY) {
                        int endRow = startY + pixelsY;
                        int endCol = startX + pixelsX;
                        if(endCol > _width || endRow > _height) return false; // block would run off edge

                        for(int row = startY; row < endRow; row++) {
                            for(int col = startX; col < endCol; col++) {
                                int index = row * _width + col;
                                if(_map[index]) return false;
                            }
                        }
                        return true;
                    }

                    private void CalculateFreeSpace() {
                        int count = 0;
                        for(int i = 0; i < _map.Length; i++) {
                            if(!_map[i]) count++;
                        }
                        _freeSpace = count;
                    }

                    public void Resize(int width, int height) {
                        if(width < _width || height < _height) throw new System.Exception("Cannot decrease size!");
                        int oldWidth = _width; // save the old width and height
                        int oldHeight = _height;
                        _width = width; // set the new width and height
                        _height = height;
                        bool[] newMap = new bool[width * height]; // create new bool map for new size

                        // Copy old map to new in a block
                        for(int row = 0; row < oldHeight; row++) {
                            for(int col = 0; col < oldWidth; col++) {
                                int oldIndex = row * oldWidth + col;
                                int newIndex = row * width + col;
                                newMap[newIndex] = _map[oldIndex];
                            }
                        }
                        _map = newMap; // replace map
                        CalculateFreeSpace();
                    }

                    public void Clear() {
                        _freeSpace = _width * _height;
                        _map = new bool[_freeSpace];
                    }

                    public PixelMap Clone() {
                        return new PixelMap(this);
                    }
                }

                private class TexturePacker {

                    private Node tree;
                    private int _width;
                    private int _height;

                    public TexturePacker(int width, int height) {
                        _width = width;
                        _height = height;
                        tree = new Node(_width, _height);
                    }

                    public bool Insert(int width, int height, out SpriteFactory.Utils.DataClasses.IntVector2 cellStartPosition) {
                        PixelRect image = new PixelRect(0, 0, width, height);
                        Node node = tree.Insert(image);
                        if(node != null) { // image was inserted successfully
                            cellStartPosition = new SpriteFactory.Utils.DataClasses.IntVector2(node.rect.x, node.rect.y);
                            return true;
                        } else { // could not fit image
                            cellStartPosition = null;
                            return false;
                        }
                    }

                    public void Clear() {
                        tree = new Node(_width, _height);
                    }

                    // PRIVATE CLASSES /////////

                    private class PixelRect : SpriteFactory.Utils.DataClasses.IntRect {

                        public PixelRect(int inX, int inY, int inWidth, int inHeight) : base(inX, inY, inWidth, inHeight) { }

                        public bool Contains(PixelRect rect) {
                            if(rect.width <= width && rect.height <= height) return true;
                            return false;
                        }

                        public int Fits(PixelRect rect) {
                            if(rect.width > width || rect.height > height) return -1; // too small
                            if(rect.width == width && rect.height == height) return 1; // fits perfectly
                            return 0; // too big
                        }
                    }

                    private class Node {

                        private Node[] children;
                        public PixelRect rect;
                        public bool isFilled;

                        public Node() {
                            children = new Node[2];
                        }

                        public Node(int width, int height)
                            : this() {
                            rect = new PixelRect(0, 0, width, height);
                        }

                        public Node Insert(PixelRect image) { // Based on formula from: http://www.blackpawn.com/texts/lightmaps/default.html
                            bool isBranch = children[0] != null || children[1] != null ? true : false; // if either child is populated, this is a branch and cannot be filled with an image

                            if(isBranch) { // this is a branch

                                // try inserting into first child
                                Node newNode = children[0].Insert(image);
                                if(newNode != null) return newNode;

                                // no room, insert into second
                                return children[1].Insert(image);

                            } else { // this is a leaf

                                if(isFilled) return null; // if there's already an image here, return

                                // Try to fit image into this space
                                int fit = rect.Fits(image);
                                if(fit == -1) return null; // image is too big, cannot fit
                                else if(fit == 1) { // fits perfectly, done
                                    isFilled = true;
                                    return this;
                                }

                                // Split the space and create child nodes
                                children[0] = new Node();
                                children[1] = new Node();

                                // decide which way to split
                                int extraWidth = rect.width - image.width;
                                int extraHeight = rect.height - image.height;

                                if(extraWidth > extraHeight) { // we have more extra width
                                    // split space down vertically making two columns
                                    children[0].rect = new PixelRect(rect.x, rect.y, image.width, rect.height); // make rect as tall as whole space but only as wide as the image
                                    children[1].rect = new PixelRect(rect.x + image.width, rect.y, extraWidth, rect.height); // make 2nd rect fill remaining horizontal space
                                } else { // we have more extra height
                                    // split space horizontally making two rows
                                    children[0].rect = new PixelRect(rect.x, rect.y, rect.width, image.height); // make rect as wide as whole space but only as tall as the image
                                    children[1].rect = new PixelRect(rect.x, rect.y + image.height, rect.width, extraHeight); // make 2nd rect fill remaining vertical space
                                }

                                // insert into first child
                                return children[0].Insert(image);
                            }
                        }
                    }
                }

                private class MyTexturePostprocessor : AssetPostprocessor {
                    private void OnPreprocessTexture() {
                        if(!AtlasMaker.settingsInitialized) return; // do nothing if settings haven't been loaded
                        
                        string pathL = assetPath.ToLower();
                        bool found = false;
                        bool setReadable = false;

                        if(pathL.Contains(SpriteEditor.atlasSavePath.ToLower())) { // atlases
                            found = true;
                        } else if(pathL.Contains(SpriteEditor.resolutionTargetTextureCacheSavePath.ToLower())) { // cache textures
                            found = true;
                            setReadable = true;
                        }

                        if(found) { 
                            TextureImporter importer = (TextureImporter)assetImporter;
                            // Make sure texture settings are correct on atlas
                            TextureImporterSettings settings = new TextureImporterSettings();
                            importer.ReadTextureSettings(settings); // load the current settings
                            importer.textureType = TextureImporterType.Advanced;
                            SetVersionRestrictedSettings(settings);
                            settings.maxTextureSize = AtlasMaker.maxAtlasSize;
                            settings.mipmapEnabled = AtlasMaker.useMipMaps;
                            if(AtlasMaker.useTextureCompression) settings.textureFormat = TextureImporterFormat.AutomaticCompressed; // compressed
                            else settings.textureFormat = TextureImporterFormat.AutomaticTruecolor; // uncompressed
                            settings.wrapMode = TextureWrapMode.Clamp;
                            settings.readable = false;
                            settings.filterMode = AtlasMaker.atlasTextureFilterMode;
                            settings.aniso = AtlasMaker.atlasTextureAnisoLevel;
                            settings.maxTextureSize = 4096;
                            if(setReadable) settings.readable = true; // set isReadable for certain textures
                            importer.SetTextureSettings(settings);
                            
                        }
                    }

                    private void SetVersionRestrictedSettings(TextureImporterSettings settings) {
                        if(SpriteFactory.Utils.UnityTools.unityVersion >= SpriteFactory.Utils.UnityTools.UnityVersion.UNITY_4_2) {
                            SetVersionRestrictedSettings_U42(settings);
                        }
                        if(SpriteFactory.Utils.UnityTools.supports2DColliders) {
                            SetVersionRestrictedSettings_U43(settings);
                        }
                    }

                    private void SetVersionRestrictedSettings_U42(TextureImporterSettings settings) {
                        settings.alphaIsTransparency = true;
                    }

                    private void SetVersionRestrictedSettings_U43(TextureImporterSettings settings) {
                        settings.spriteMode = 0; // none
                    }
                }

                #endregion
            }

            #endregion

        }
    }
}
