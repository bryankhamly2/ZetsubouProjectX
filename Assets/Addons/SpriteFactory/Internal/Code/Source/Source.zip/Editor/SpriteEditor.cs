using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using SpriteFactory.Enums;
using Sprite = SpriteFactory.Sprite;
using Settings = SpriteFactory.Settings;

namespace SpriteFactory.Editor {

    public partial class SpriteEditor : EditorWindow {

        #region VARIABLES

        #region Constants

        private const float buttonRowHeight = 20.0f;
        private const float listBoxLineHeight = 18.0f;

        #endregion

        // NOTE: Don't set any values up here because it will crash it when you first open the window -- Set them in OnEnable instead

        #region GUI Skins

        private GUISkin mainSkin;

        #endregion

        #region Styles

        private GUIStyle errorGUIStyle;
        private GUIStyle style_mainPageContainer;
        private GUIStyle style_mainColumns;
        private GUIStyle style_cellPad;
        private GUIStyle style_leftMargin;
        private GUIStyle style_labelNoLRPad;
        private GUIStyle style_importerOutput;
        private GUIStyle style_buttonRow;
        private GUIStyle style_blank;
        private GUIStyle style_leftPadFix;

        #endregion

        #region Flags

        private bool initialized;
        private bool initializationFailed;
        private bool upgradeRequired;
        private bool programVersionUpdateRequired;
        private bool stylesSet;
        private bool loaded;
        private bool unsavedChanges;
        private bool remakeAtlases;
        private bool remakeMaterials;
        private bool remakeMeshes;
        private bool refreshSpriteListOnSave;
        private bool refreshGroupListOnSave;
        private bool unappliedEditorPropertiesChanges;
        private bool refreshEditorPropertiesControls;
        private bool mainPageEnabled;
        private bool refreshColliderFrameProperties;
        private bool refreshLocatorFrameProperties;
        private bool refreshLightBoxAnimationsList;
        private bool refreshColliderGroupList;
        private bool masterSpriteSelectionChanged;

        #endregion

        #region Deferred save variables

        private ListboxAction pendingSpriteListboxAction;
        private ListboxAction pendingGroupListboxAction;
        private bool saveChanges;
        private bool saveButtonPressed;
        private EditMode saveChanges_editMode;
        private bool checkIfAtlasesNeedUpdating;
        private bool rebuildAllAtlases;
        private bool rebuildAllMaterials;
        private bool rebuildDataFile;
        private bool rebuildDataFile_rebuildAll;
        private bool import;
        private bool importFinished;
        private bool export;
        private bool createSpriteInScene;
        private bool assignMasterSpriteToSprite;
        private bool changeEditorProperties;
        private bool determineEdgeTiling;
        private bool busy;
        private bool preventRebuildSpriteAssets;
        private bool preventRebuildSpriteGroupAssets;
        private EditorPropertyChangeType editorPropertyChangeType;

        #endregion

        #region Reloading selection variables

        private bool reloadLastSelection;
        private int lastSelectedAnimationIndex;
        private int lastSelectedFrameIndex;

        #endregion

        #region Internal Windows

        private GUI.WindowFunction RenderWindow;
        private int openWindowId;
        private Rect innerWindowRect;
        private Vector2[] innerWindowScrollers;
        private Rect pageRect;
        private bool refreshInnerWindow;
        private bool windowJustOpened;
        private Color overlayColor = new Color(0.0f, 0.0f, 0.0f, 0.5f);

        #endregion

        #region Main window scroll area

        private Vector2 mainScrollPos;

        #endregion

        #region Controls

        // Editor properties
        private SimpleGUIIntField editorProperties_pixelsPerUnit;
        private SimpleGUIToggle editorProperties_trimSprites;
        private SimpleGUIIntField editorProperties_framePadding;
        private SimpleGUIPopup editorProperties_maxAtlasSize;
        private SimpleGUIToggle editorProperties_forceSquareAtlases;
        private SimpleGUIToggle editorProperties_defaultUseMipMaps;
        private SimpleGUIToggle editorProperties_defaultUseTextureCompression;
        //private SimpleGUIPopupEnum editorProperties_atlasPackingMethod;
        private SimpleGUIPopupEnum editorProperties_resolutionTarget;
        private SimpleGUIPopupEnum editorProperties_resolutionTargetResamplingMode;

        // Defaults
        private SimpleGUIObjectField editorProperties_defaultMaterial;
        private SimpleGUIPopupEnum editorProperties_defaultFilterMode;
        private SimpleGUIIntField editorProperties_defaultAnisoLevel;
        private SimpleGUIToggle editorProperties_defaultUseTwoSidedMesh;
        private SimpleGUIToggle editorProperties_defaultUse2DColliders;
        private SimpleGUIPopupEnum editorProperties_defaultMeshType;
        //private SimpleGUIPopupEnum editorProperties_defaultAutoMeshTransparencyChannel;
        private SimpleGUIIntField editorProperties_defaultAutoMeshEdgeExtrude;
        private SimpleGUIIntField editorProperties_defaultAutoMeshVertexReductionDistance;
        private SimpleGUIPopupEnum editorProperties_rebuildSpriteGroupOnSave;
        private SimpleGUIPopupEnum editorProperties_rebuildSpriteOnSave;

        // Sprite Group list box
        private SimpleGUIListBoxContainer<int> groupListBoxContainer;

        // Sprite list box
        private SimpleGUIListBoxContainer<int> spriteListBoxContainer;

        // Sprite properties
        private SimpleGUITextField spriteProperties_name;
        private SimpleGUIToggle spriteProperties_staticSprite;
        private SimpleGUIPopup spriteProperties_spriteGroup;
        private SimpleGUIIntField spriteProperties_defaultFrameRate;
        private SimpleGUIPopupEnum spriteProperties_defaultWrapMode;

        private SimpleGUIPopupEnum spriteProperties_filterMode;
        private SimpleGUIPopupEnum spriteProperties_anisoLevel;

        private SimpleGUIPopupEnum spriteProperties_useTwoSidedMesh;
        private SimpleGUIPopupEnum spriteProperties_tilingMode;
        private SimpleGUIToggle spriteProperties_tileTop;
        private SimpleGUIToggle spriteProperties_tileBottom;
        private SimpleGUIToggle spriteProperties_tileLeft;
        private SimpleGUIToggle spriteProperties_tileRight;
        private SimpleGUIPopupEnum spriteProperties_meshType;
        //private SimpleGUIPopupEnum spriteProperties_meshGenerationTransparencyChannel;
        private SimpleGUIToggle spriteProperties_useDefaultAutoMeshEdgeExtrude;
        private SimpleGUIIntField spriteProperties_autoMeshEdgeExtrude;
        private SimpleGUIToggle spriteProperties_useDefaultAutoMeshVertexReductionDistance;
        private SimpleGUIIntField spriteProperties_autoMeshVertexReductionDistance;

        // Animations scroll box
        private SimpleGUIListBoxContainer<EditorMasterSprite.Animation> animationListBoxContainer;

        // Animation properties
        private SimpleGUITextField animationProperties_name;
        private SimpleGUIPopupEnum animationProperties_wrapMode;
        private SimpleGUIIntField animationProperties_loopCount;
        private SimpleGUIIntField animationProperties_loopRestartFrame;
        private SimpleGUIIntField animationProperties_fps;

        // Animation preview
        private SimpleGUIDrawSpriteAnimation animationPreview;

        // Frames scroll box
        private SimpleGUIListBoxContainer<EditorMasterSprite.Frame> frameListBoxContainer;

        // Frame properties
        private SimpleGUIObjectField frameProperties_sourceImage;
        private SimpleGUIFloatField frameProperties_duration;
        private SimpleGUIIntField frameProperties_frameHold;
        private SimpleGUIIntField frameProperties_offsetX;
        private SimpleGUIIntField frameProperties_offsetY;
        private SimpleGUIToggle frameProperties_offsetAllFrames;
        private SimpleGUIToggle frameProperties_offsetColliders;
        private SimpleGUIToggle frameProperties_offsetStaticColliders;
        private SimpleGUIToggle frameProperties_offsetLocators;
        private SimpleGUIIntField frameProperties_offsetAllX;
        private SimpleGUIIntField frameProperties_offsetAllY;
        private SimpleGUITextField frameProperties_event;

        // Frame preview
        private SimpleGUIFrameEditor frameEditor;

        // Frame preview controls
        private SimpleGUIPopup framePreviewControls_LightboxAnimation;
        private SimpleGUIPopup framePreviewControls_LightboxFrame;

        // Collider Frame properties
        private SimpleGUIPopup colliderFrameProperties_editCollider;
        private SimpleGUIPopup colliderFrameProperties_visibleColliderGroup;
        private SimpleGUIToggle colliderFrameProperties_enabled;
        private SimpleGUIFloatField colliderFrameProperties_sizeX;
        private SimpleGUIFloatField colliderFrameProperties_sizeY;
        private SimpleGUIFloatField colliderFrameProperties_centerX;
        private SimpleGUIFloatField colliderFrameProperties_centerY;
        private SimpleGUIFloatField colliderFrameProperties_rotation;

        // Locator Frame properties
        private SimpleGUIPopup locatorFrameProperties_editLocator;
        private SimpleGUIToggle locatorFrameProperties_enabled;
        private SimpleGUIIntField locatorFrameProperties_positionX;
        private SimpleGUIIntField locatorFrameProperties_positionY;
        private SimpleGUIFloatField locatorFrameProperties_offsetZ;
        private SimpleGUIFloatField locatorFrameProperties_facing;
        private SimpleGUIToggle locatorFrameProperties_flipForwardVector;

        // Sprite Group Properties
        private SimpleGUITextField groupProperties_name;
        private SimpleGUIPopupEnum groupProperties_filterMode;
        private SimpleGUIPopupEnum groupProperties_anisoLevel;

        // Material Set Editor Window
        private SimpleGUIListBoxContainer<EditorMasterSprite.MaterialSet> materialSetListBoxContainer;
        private SimpleGUITextField materialSetProperties_name;
        private SimpleGUIToggle materialSetProperties_useDefaultMaterial;
        private SimpleGUIObjectField materialSetProperties_sourceMaterial;

        // Colliders Window
        private SimpleGUIListBoxContainer<Sprite.ColliderSet> colliderSetListBoxContainer;
        private SimpleGUIListBoxContainer<Sprite.ColliderGroup> colliderGroupListBoxContainer;
        // Collider Set Properties
        private SimpleGUITextField colliderSetProperties_name;
        private SimpleGUITextField colliderSetProperties_tag;
        private SimpleGUIPopup colliderSetProperties_group;
        private SimpleGUIColorField colliderSetProperties_previewColor;
        private SimpleGUIPopup colliderSetProperties_layer;
        // Collider vars
        private SimpleGUIPopupEnum colliderSetProperties_colliderType;
        private SimpleGUIToggle colliderSetProperties_is2D;
        private SimpleGUIToggle colliderSetProperties_isAnimated;
        private SimpleGUIToggle colliderSetProperties_enableInNewFrames;
        private SimpleGUIFloatField colliderSetProperties_sizeZ;
        private SimpleGUIFloatField colliderSetProperties_centerZ;
        private SimpleGUIToggle colliderSetProperties_isTrigger;
        private SimpleGUIObjectField colliderSetProperties_material;
        private SimpleGUIObjectField colliderSetProperties_material2D;
        // Rigidbody vars
        private SimpleGUIToggle colliderSetProperties_hasRigidbody;
        private SimpleGUIFloatField colliderSetProperties_mass;
        private SimpleGUIFloatField colliderSetProperties_drag;
        private SimpleGUIFloatField colliderSetProperties_angularDrag;
        private SimpleGUIToggle colliderSetProperties_useGravity;
        private SimpleGUIToggle colliderSetProperties_isKinematic;
        private SimpleGUIPopupEnum colliderSetProperties_rigidbodyInterpolation;
        private SimpleGUIPopupEnum colliderSetProperties_collisionDetectionMode;
        private SimpleGUIToggle colliderSetProperties_constraintsPosX;
        private SimpleGUIToggle colliderSetProperties_constraintsPosY;
        private SimpleGUIToggle colliderSetProperties_constraintsPosZ;
        private SimpleGUIToggle colliderSetProperties_constraintsRotX;
        private SimpleGUIToggle colliderSetProperties_constraintsRotY;
        private SimpleGUIToggle colliderSetProperties_constraintsRotZ;
        // Rigidbody2D vars
        private SimpleGUIFloatField colliderSetProperties_linearDrag2D;
        private SimpleGUIFloatField colliderSetProperties_angularDrag2D;
        private SimpleGUIFloatField colliderSetProperties_mass2D;
        private SimpleGUIFloatField colliderSetProperties_gravityScale;
        private SimpleGUIToggle colliderSetProperties_fixedAngle;
        private SimpleGUIPopupEnum colliderSetProperties_rigidbodyInterpolation2D;
        private SimpleGUIPopupEnum colliderSetProperties_sleepMode2D;
        private SimpleGUIPopupEnum colliderSetProperties_collisionDetectionMode2D;

        // Collider Group Properties
        private SimpleGUITextField colliderGroupProperties_name;
        //private SimpleGUIToggle colliderGroupProperties_useGroupCollisions;

        // Locator Sets Window
        private SimpleGUIListBoxContainer<Sprite.LocatorSet> locatorSetListBoxContainer;
        private SimpleGUITextField locatorSetProperties_name;
        private SimpleGUIColorField locatorSetProperties_previewColor;
        private SimpleGUIToggle locatorSetProperties_defaultToPosXIsForward;
        private SimpleGUIFloatField locatorSetProperties_defaultOffsetZ;

        // Export Window
        private SimpleGUIListBoxContainer<int> export_groupsListBoxContainer;
        private SimpleGUIListBoxContainer<int> export_groupsListBoxContainer_ToExport;
        private SimpleGUIListBoxContainer<int> export_ungroupedSpritesListBoxContainer;
        private SimpleGUIListBoxContainer<int> export_ungroupedSpritesListBoxContainer_ToExport;
        private SimpleGUIToggle export_exportPrefabs;

        // Import Window
        private SimpleGUIListBoxContainer<string> importMessagesListBoxContainer;

        #endregion

        #region Data

        private DB db;
        private EditorMasterSprite.Data masterSpriteData;
        private int selectedMasterSpriteIndex = -1;
        private EditorProperties editorProperties;
        private GameObject[] unitySelection;
        private bool sceneSelectionChanged;
        private GameObject selectedGameObject;
        private MaterialSetContainer materialSetContainer;

        private EditorMasterSprite.SpriteGroup selectedGroup;
        private int selectedGroupIndex = -1;

        private EditMode editMode;

        private Exporter exporter;
        private Importer importer;

        #endregion

        #region Other

        private FrameClipboard clipboard;

        #endregion

        #region Help GUI content

        private GUIContent help_spriteGroups;
        private GUIContent help_masterSprites;
        private GUIContent help_colliders;
        private GUIContent help_colliderGroups;
        private GUIContent help_locators;
        private GUIContent help_materialSets;
        private GUIContent help_lightbox;

        #endregion

        #region Persistent Vars

        [SerializeField]
        private bool importInProcess;

        [SerializeField]
        private bool editorIsPlaying;

        #endregion

        #region Static vars

        [SerializeField]
        private static SpriteEditor window;

        #endregion

        #endregion

        #region PROPERTIES

        private int selectedGroupId {
            get {
                if(selectedGroup == null) return -1;
                return selectedGroup.groupId;
            }
        }

        #endregion

        #region METHODS

#if TRIALVERSION
            [MenuItem("Window/Sprite Factory *Trial*")]
#else
        [MenuItem("Window/Sprite Factory")]
#endif
        private static void Init() {
            // Get existing open window or if none, make a new one:
            if(EditorApplication.isPlaying) {
                Debug.LogWarning("The Sprite Factory editor cannot be launched in Play mode.");
                return;
            }
            window = (SpriteEditor)EditorWindow.GetWindow(typeof(SpriteEditor));
            window.title = "Sprite Factory";
            window.WindowOpened();
            window.Show();
        }

        #region Events

        public void WindowOpened() {
            ClearPersistentVars(); // make sure persistent vars are cleared only when the window is opened since we can't clear them in Initialize because we need them to exist through a recompile
        }

        private void Initialize() {
            this.wantsMouseMove = true; // make window get mouse moves
            this.minSize = new Vector2(285.0f, 465.0f);

            if(db == null) { // initialize the sprite database
                db = new DB(this);
                if(!db.initialized) {
                    Debug.LogError("Failed to load Sprite Factory!");
                    return;
                }
                loaded = true;
            }

            // GUI Skins
            mainSkin = LoadAssetAtPathRel<GUISkin>(DB.guiSkinFilePath);
            if(mainSkin == null) {
                Debug.LogError("Sprite Factory skin file not found! Please reinstall Sprite Factory.");
                return;
            }

            Utils.GUITools.Engine.Initialize(); // initialize the GUI wrapper system

            if(db.initialized) initialized = true;
            else return;

            initializationFailed = false;
            upgradeRequired = false;
            programVersionUpdateRequired = false;
            editMode = EditMode.None;
            sceneSelectionChanged = false;
            selectedGameObject = null;
            selectedGroup = null;
            ClearCurrentSpriteListSelection();
            LoadEditorProperties();
            innerWindowRect = new Rect(10.0f, 10.0f, 0.0f, 0.0f);
            CloseInnerWindows(); // close inner windows
            refreshColliderFrameProperties = false;
            refreshLocatorFrameProperties = false;
            refreshLightBoxAnimationsList = false;
            refreshColliderGroupList = false;
            saveChanges = false;
            saveButtonPressed = false;
            checkIfAtlasesNeedUpdating = false;
            rebuildAllAtlases = false;
            rebuildAllMaterials = false;
            rebuildDataFile = false;
            rebuildDataFile_rebuildAll = false;
            import = false;
            importFinished = false;
            export = false;
            createSpriteInScene = false;
            assignMasterSpriteToSprite = false;
            changeEditorProperties = false;
            determineEdgeTiling = false;
            busy = false;
            preventRebuildSpriteAssets = false;
            preventRebuildSpriteGroupAssets = false;
            ClearMomentaryVars();
            GetUnitySelection();
            if(exporter == null) exporter = new Exporter();
            else exporter.Clear();
            if(importer == null) importer = new Importer();
            else importer.Clear();
            editorPropertyChangeType = EditorPropertyChangeType.None;

            // Set up other objects
            if(clipboard == null) clipboard = new FrameClipboard();

            // Instantiate or reset control containers

            #region // Editor

            // Editor properties
            if(editorProperties_pixelsPerUnit == null) {
                editorProperties_pixelsPerUnit = new SimpleGUIIntField(new GUIContent("Pixels Per Unit", "The scale of the sprite. Higher numbers will result in a smaller sprite in world units.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"), 1, 100000);
            } else
                editorProperties_pixelsPerUnit.Clear();

            if(editorProperties_trimSprites == null) {
                editorProperties_trimSprites = new SimpleGUIToggle(new GUIContent("Trim Empty Space", "Trims blank space around images to reduce wasted space in atlases.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"));
            } else
                editorProperties_trimSprites.Clear();

            if(editorProperties_framePadding == null) {
                editorProperties_framePadding = new SimpleGUIIntField(new GUIContent("Frame Padding", "Padding around each image in an atlas in pixels. Too small a padding may lead to edge bleeding problems with mip-mapping and filtered textures.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"), 0, 100);
            } else
                editorProperties_framePadding.Clear();

            if(editorProperties_maxAtlasSize == null) {
                string[] sizes = { "128x128", "256x256", "512x512", "1024x1024", "2048x2048", "4096x4096" }; // one for each Sprite.SpriteAtlasSize
                editorProperties_maxAtlasSize = new SimpleGUIPopup(new GUIContent("Max Atlas Size", "The maximum size allowed for atlases. This is useful if you need to limit the atlas size due to texture size limitations on some platforms.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"), sizes);
            } else
                editorProperties_maxAtlasSize.Clear();

            if(editorProperties_forceSquareAtlases == null) {
                editorProperties_forceSquareAtlases = new SimpleGUIToggle(new GUIContent("Square Atlases", "Force atlases to always be square. Otherwise, they may be rectangular or square as needed.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"));
            } else
                editorProperties_forceSquareAtlases.Clear();

            if(editorProperties_defaultUseMipMaps == null) {
                editorProperties_defaultUseMipMaps = new SimpleGUIToggle(new GUIContent("Create MipMaps", "Enable or disable creation of mip maps for atlas textures.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"));
            } else
                editorProperties_defaultUseMipMaps.Clear();

            if(editorProperties_defaultUseTextureCompression == null) {
                editorProperties_defaultUseTextureCompression = new SimpleGUIToggle(new GUIContent("Compress Textures", "Enable or disable texture compression for atlases. Compressed textures may result in reduced image quality. Uncompressed textures require more space.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"));
            } else
                editorProperties_defaultUseTextureCompression.Clear();

            //if(editorProperties_atlasPackingMethod == null) {
            //    string[] options = System.Enum.GetNames(typeof(SpriteFactory.AtlasPackingMethod));
            //    int[] values = (int[])System.Enum.GetValues(typeof(SpriteFactory.AtlasPackingMethod));
            //    editorProperties_atlasPackingMethod = new SimpleGUIPopupEnum(new GUIContent("Packing Method", "The method to use for atlas packing.\n\nDefault = .\n\nSimple = SLOWER"), options, values);
            //} else
            //    editorProperties_atlasPackingMethod.Clear();

            if(editorProperties_defaultFilterMode == null) {
                string[] modes = System.Enum.GetNames(typeof(FilterMode));
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(FilterMode));
                editorProperties_defaultFilterMode = new SimpleGUIPopupEnum(new GUIContent("Default Filter Mode", "Sets the default texture filter mode for sprite and group atlas textures. An individual sprite's or groups's texture filter mode can be changed at any time under Sprite Properties -> More Settings -> Texture Filter Mode for a sprite or Group Properties -> Texture Filter Mode for a sprite group.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"), modes, values);
            } else
                editorProperties_defaultFilterMode.Clear();

            if(editorProperties_defaultAnisoLevel == null) {
                editorProperties_defaultAnisoLevel = new SimpleGUIIntField(new GUIContent("Default Aniso Lvl", "Sets the default anisotropic level for sprite and group atlas textures. An individual sprite's or groups's anisotropic level can be changed at any time under Sprite Properties -> More Settings -> Aniso Level for a sprite or Group Properties -> Aniso Level for a sprite group.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"), 0, 9);
            } else
                editorProperties_defaultAnisoLevel.Clear();

            if(editorProperties_resolutionTarget == null) {
                string[] options = { "Actual Size", "Three Quarters", "Two Thrids", "Half", "Third", "Quarter", "Fifth", "Sixth", "Eighth", "Tenth" };
                int[] values = { (int)ResolutionTarget.One, (int)ResolutionTarget.ThreeQuarters, (int)ResolutionTarget.TwoThirds, (int)ResolutionTarget.Half, (int)ResolutionTarget.Third,
                                 (int)ResolutionTarget.Quarter, (int)ResolutionTarget.Fifth, (int)ResolutionTarget.Sixth, (int)ResolutionTarget.Eighth, (int)ResolutionTarget.Tenth };
                editorProperties_resolutionTarget = new SimpleGUIPopupEnum(new GUIContent("Resolution Target", "Scales the sprite textures to the specified size during atlas building. This is useful if you are targeting a specific platform that has a lower resolution screen.\n\nIMPORTANT NOTE:\nThis setting does not affect the size of sprites in the world. This setting is only for reducing the final texture resolution for while leaving the world-space size the same.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"), options, values);
            } else
                editorProperties_resolutionTarget.Clear();

            if(editorProperties_resolutionTargetResamplingMode == null) {
                string[] options = {
                    
                    "Box",
                    "Triangle",
                    "Hermite",
                    "Bell",
                    "Cubic B-Spline",
                    "Mitchell",
                    "Cosine",
                    "Catmull Rom",
                    "Quadratic",
                    "Quadratic B-Spline",
                    "Cubic Convolution",
                    "Lanczos 3",
                    "Lanczos 8 (slow)",

                    "Point (fast, LQ)",
                    "Bilinear (fast, LQ)",
                    //Trilinear = 22, // unused
                    //Bicubic = 23, // unused
                };
                int[] values = {
                    
                    (int)Enums.ImageResamplingMode.Box,
                    (int)Enums.ImageResamplingMode.Triangle,
                    (int)Enums.ImageResamplingMode.Hermite,
                    (int)Enums.ImageResamplingMode.Bell,
                    (int)Enums.ImageResamplingMode.CubicBSpline,
                    (int)Enums.ImageResamplingMode.Mitchell,
                    (int)Enums.ImageResamplingMode.Cosine,
                    (int)Enums.ImageResamplingMode.CatmullRom,
                    (int)Enums.ImageResamplingMode.Quadratic,
                    (int)Enums.ImageResamplingMode.QuadraticBSpline,
                    (int)Enums.ImageResamplingMode.CubicConvolution,
                    (int)Enums.ImageResamplingMode.Lanczos3,
                    (int)Enums.ImageResamplingMode.Lanczos8,

                    (int)Enums.ImageResamplingMode.Point,
                    (int)Enums.ImageResamplingMode.Bilinear,
                    //(int)Enums.ImageResamplingMode.Trilinear,
                    //(int)Enums.ImageResamplingMode.Bicubic,
                };
                editorProperties_resolutionTargetResamplingMode = new SimpleGUIPopupEnum(new GUIContent("RT Resampling Mode", "The resampling mode to use when scaling textures for resolution targets.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"), options, values);
            } else
                editorProperties_resolutionTargetResamplingMode.Clear();

            if(editorProperties_defaultMaterial == null) {
                editorProperties_defaultMaterial = new SimpleGUIObjectField(new GUIContent("Default Material", "Sets the default material to use for all Sprites. This material can be overridden on individual Sprites and Sprite Groups in the Material Set editor.\n* CHANGE REQUIRES ALL MATERIALS TO BE REBUILT *"), typeof(Material), false);
            } else
                editorProperties_defaultMaterial.Clear();

            if(editorProperties_defaultUseTwoSidedMesh == null) {
                editorProperties_defaultUseTwoSidedMesh = new SimpleGUIToggle(new GUIContent("Use 2-sided Meshes", "Sets the default 2-sided mesh setting for sprites. An individual sprites's 2-sided mesh setting can be changed at any time under Sprite Properties -> More Settings -> Two-Sided Mesh.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"));
            } else
                editorProperties_defaultUseTwoSidedMesh.Clear();

            if(editorProperties_defaultUse2DColliders == null) {
                editorProperties_defaultUse2DColliders = new SimpleGUIToggle(new GUIContent("Default to 2D Colliders", "Sets the default collider type to 2D for new colliders. When you create a collider set, this setting will determine what the initial collider type. Only available in Unity 4.3+. Note: Changing this default setting will not change any of your existing colliders, it will only affect new colliders added later."));
            } else
                editorProperties_defaultUse2DColliders.Clear();

            if(editorProperties_defaultMeshType == null) {
                string[] options = System.Enum.GetNames(typeof(SpriteFactory.Enums.SpriteMeshType));
                int[] values = (int[])System.Enum.GetValues(typeof(SpriteFactory.Enums.SpriteMeshType));
                editorProperties_defaultMeshType = new SimpleGUIPopupEnum(new GUIContent("Default Mesh Type", "Sets the default mesh generation type for sprites. An individual sprites's mesh type setting can be changed at any time under Sprite Properties -> More Settings -> Mesh Type.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"), options, values);
            } else
                editorProperties_defaultMeshType.Clear();

            /*
            if(editorProperties_defaultAutoMeshTransparencyChannel == null) {
                string[] options = System.Enum.GetNames(typeof(SpriteFactory.Enums.ColorChannel));
                int[] values = (int[])System.Enum.GetValues(typeof(SpriteFactory.Enums.ColorChannel));
                editorProperties_defaultAutoMeshTransparencyChannel = new SimpleGUIPopupEnum(new GUIContent("Default Mesh Gen Alpha", "Sets the default color channel used by the auto mesh generator when generating mesh shapes. The channel will be treated as transparency. An individual sprites's setting can be changed at any time under Sprite Properties -> More Settings.\n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *."), options, values);
            } else
                editorProperties_defaultAutoMeshTransparencyChannel.Clear();
            */

            if(editorProperties_defaultAutoMeshEdgeExtrude == null) {
                editorProperties_defaultAutoMeshEdgeExtrude = new SimpleGUIIntField(new GUIContent("Default Edge Extrude", "Sets the default edge extrusion distance for sprite meshes. An individual sprite's setting can be changed at any time under Sprite Properties -> More Settings. NOTE: This only has an affect if Mesh Type is set to AutoMesh. \n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"), 3, 50);
            } else
                editorProperties_defaultAutoMeshEdgeExtrude.Clear();

            if(editorProperties_defaultAutoMeshVertexReductionDistance == null) {
                editorProperties_defaultAutoMeshVertexReductionDistance = new SimpleGUIIntField(new GUIContent("Default Vert Distance", "Sets the default vertex reduction distance for sprite meshes. A higher number will result in a mesh with fewer vertices, but too a high a number could cause areas of the sprite to be cut off. An individual sprite's setting can be changed at any time under Sprite Properties -> More Settings. NOTE: This only has an affect if Mesh Type is set to AutoMesh. \n* CHANGE REQUIRES ALL ATLASES TO BE REBUILT *"), 3, 20);
            } else
                editorProperties_defaultAutoMeshVertexReductionDistance.Clear();

            if(editorProperties_rebuildSpriteOnSave == null) {
                string[] options = System.Enum.GetNames(typeof(SpriteFactory.AutomaticActionPolicy));
                int[] values = (int[])System.Enum.GetValues(typeof(SpriteFactory.AutomaticActionPolicy));
                editorProperties_rebuildSpriteOnSave = new SimpleGUIPopupEnum(new GUIContent("Rebuild Sprite Atlases", "Automatically rebuild Sprite atlases every time you save a Master Sprite? Sometimes you may want to turn this off because it takes a very long time to build the atlases and you need to make many changes to a Sprite. You will have to manually rebuild the Sprite when you are finished before your Sprites will function correctly."), options, values);
            } else
                editorProperties_rebuildSpriteOnSave.Clear();

            if(editorProperties_rebuildSpriteGroupOnSave == null) {
                string[] options = System.Enum.GetNames(typeof(SpriteFactory.AutomaticActionPolicy));
                int[] values = (int[])System.Enum.GetValues(typeof(SpriteFactory.AutomaticActionPolicy));
                editorProperties_rebuildSpriteGroupOnSave = new SimpleGUIPopupEnum(new GUIContent("Rebuild Group Atlases", "Automatically rebuild Sprite Group atlases every time you save a Master Sprite in the group? Sometimes you may want to turn this off because it takes a very long time to build the atlases and you need to make many changes to a Sprite Group. You will have to manually rebuild the Sprite when you are finished before your Sprites will function correctly."), options, values);
            } else
                editorProperties_rebuildSpriteGroupOnSave.Clear();

            #endregion

            #region // Sprites

            // Sprite Group list box
            if(groupListBoxContainer == null) {
                groupListBoxContainer = new SimpleGUIListBoxContainer<int>(mainSkin, true);
            } else
                groupListBoxContainer.ClearAll();

            // Sprite list box
            if(spriteListBoxContainer == null) {
                spriteListBoxContainer = new SimpleGUIListBoxContainer<int>(mainSkin);
                spriteListBoxContainer.parent = groupListBoxContainer;
            } else
                spriteListBoxContainer.ClearAll();

            // Sprite properties
            if(spriteProperties_name == null) {
                spriteProperties_name = new SimpleGUITextField(new GUIContent("Name", "The name of this sprite."));
                spriteProperties_name.parent = spriteListBoxContainer;
            } else
                spriteProperties_name.Clear();

            if(spriteProperties_staticSprite == null) {
                spriteProperties_staticSprite = new SimpleGUIToggle(new GUIContent("Is Static Sprite", "Set whether this sprite is static or animated. Static sprites have no animation and consist of a single frame. You can use static sprites for non-animated background elements, for example. Static sprites are faster than animated sprites, so if you have a sprite with only one frame, make it a static sprite. Note that you will almost always want to assign static sprites to groups as a static sprite outside a group would generate an atlas with only one frame wasting memory."));
                spriteProperties_staticSprite.parent = spriteListBoxContainer;
            } else
                spriteProperties_staticSprite.Clear();

            if(spriteProperties_spriteGroup == null) {
                string[] groups = new string[1] { "None" };
                // Group sprites together that will be frequently displayed together such as background elements  
                spriteProperties_spriteGroup = new SimpleGUIPopup(new GUIContent("Sprite Group", "The group this sprite is assigned to. Sprites in Sprite Groups share atlases and materials to reduce draw calls. Changing the assigned sprite group will require atlases and materials to be rebuilt for the group(s) and sprites affected."), groups);
                spriteProperties_spriteGroup.parent = spriteListBoxContainer;
            } else
                spriteProperties_spriteGroup.Clear();

            if(spriteProperties_defaultFrameRate == null) {
                spriteProperties_defaultFrameRate = new SimpleGUIIntField(new GUIContent("Default FPS", "The default playback speed in frames per second for new animations. When you create a new animation, this setting determines the initial frame rate of the animation. An individual animation's frame rate can be changed at any time under Animation Properties -> Frame Rate."), 1, 1000);
                spriteProperties_defaultFrameRate.parent = spriteListBoxContainer;
            } else
                spriteProperties_defaultFrameRate.Clear();

            if(spriteProperties_defaultWrapMode == null) {
                string[] wrapModes = System.Enum.GetNames(typeof(Sprite.WrapMode));
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(Sprite.WrapMode));
                spriteProperties_defaultWrapMode = new SimpleGUIPopupEnum(new GUIContent("Default Wrap Mode", "The default wrap mode for new animations. When you create a new animation, this setting determines the initial wrap mode of the animation. An individual animation's wrap mode can be changed at any time under Animation Properties -> Wrap Mode."), wrapModes, values);
                spriteProperties_defaultWrapMode.parent = spriteListBoxContainer;
            } else
                spriteProperties_defaultFrameRate.Clear();

            if(spriteProperties_filterMode == null) {
                string[] modes = System.Enum.GetNames(typeof(FilterMode));
                SpriteFactory.Utils.ArrayTools.Insert<string>(ref modes, 0, "Default");
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(FilterMode));
                SpriteFactory.Utils.ArrayTools.Insert<int>(ref values, 0, -1);
                spriteProperties_filterMode = new SimpleGUIPopupEnum(new GUIContent("Texture Filter Mode", "Sets the texture filter mode for atlas textures in this sprite."), modes, values);
                spriteProperties_filterMode.parent = spriteListBoxContainer;
            } else
                spriteProperties_filterMode.Clear();

            if(spriteProperties_anisoLevel == null) {
                string[] options = new string[11] { "Default", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
                int[] values = new int[11] { -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
                spriteProperties_anisoLevel = new SimpleGUIPopupEnum(new GUIContent("Aniso Level", "Sets the anisotropic level for atlas textures in this sprite."), options, values);
                spriteProperties_anisoLevel.parent = spriteListBoxContainer;
            } else
                spriteProperties_anisoLevel.Clear();

            if(spriteProperties_useTwoSidedMesh == null) {
                string[] modes = System.Enum.GetNames(typeof(BoolDefaultOption));
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(BoolDefaultOption));
                spriteProperties_useTwoSidedMesh = new SimpleGUIPopupEnum(new GUIContent("Two-Sided Mesh", "Set whether this sprite uses a single or double-sided mesh plane. Two-sided meshes can be useful if you are using a shader that culls backfaces yet you want the sprite to be double-sided."), modes, values);
                spriteProperties_useTwoSidedMesh.parent = spriteListBoxContainer;
            } else
                spriteProperties_useTwoSidedMesh.Clear();

            if(spriteProperties_tilingMode == null) {
                string[] modes = System.Enum.GetNames(typeof(EditorMasterSprite.TilingMode));
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(EditorMasterSprite.TilingMode));
                spriteProperties_tilingMode = new SimpleGUIPopupEnum(new GUIContent("Edge Tiling", "Sets the edge tiling mode for the sprite. This affects how the edges of the sprite are blended. In general, background tiles should be tilable, characters and objects should not. Auto will try to determine which edges should be tilable. If you are seeing artifacts at the edges of a tilable sprite, set it to Manual and select which edges should be tilable. When an edge is not tilable, extra padding will be added to eliminate bilinear/trilinear filtering cutoff at the edge of the mesh plane. This setting depends on the global frame padding setting in Editor Properties. If you have no padding, this setting will have no effect."), modes, values);
                spriteProperties_tilingMode.parent = spriteListBoxContainer;
            } else
                spriteProperties_tilingMode.Clear();

            if(spriteProperties_tileTop == null) {
                spriteProperties_tileTop = new SimpleGUIToggle(new GUIContent("   Top", "Makes the top edge tilable."));
                spriteProperties_tileTop.parent = spriteListBoxContainer;
            } else
                spriteProperties_tileTop.Clear();

            if(spriteProperties_tileBottom == null) {
                spriteProperties_tileBottom = new SimpleGUIToggle(new GUIContent("   Bottom", "Makes the bottom edge tilable."));
                spriteProperties_tileBottom.parent = spriteListBoxContainer;
            } else
                spriteProperties_tileBottom.Clear();

            if(spriteProperties_tileLeft == null) {
                spriteProperties_tileLeft = new SimpleGUIToggle(new GUIContent("   Left", "Makes the left edge tilable."));
                spriteProperties_tileLeft.parent = spriteListBoxContainer;
            } else
                spriteProperties_tileLeft.Clear();

            if(spriteProperties_tileRight == null) {
                spriteProperties_tileRight = new SimpleGUIToggle(new GUIContent("   Right", "Makes the right edge tilable."));
                spriteProperties_tileRight.parent = spriteListBoxContainer;
            } else
                spriteProperties_tileRight.Clear();

            if(spriteProperties_meshType == null) {
                string[] modes = System.Enum.GetNames(typeof(SpriteFactory.Enums.SpriteMeshType));
                SpriteFactory.Utils.ArrayTools.Insert<string>(ref modes, 0, "Default");
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(SpriteFactory.Enums.SpriteMeshType));
                SpriteFactory.Utils.ArrayTools.Insert<int>(ref values, 0, -1);
                spriteProperties_meshType = new SimpleGUIPopupEnum(new GUIContent("Mesh Type", "Sets the mesh generation type for this sprite."), modes, values);
                spriteProperties_meshType.parent = spriteListBoxContainer;
            } else
                spriteProperties_meshType.Clear();

            /*
            if(spriteProperties_meshGenerationTransparencyChannel == null) {
                string[] modes = System.Enum.GetNames(typeof(SpriteFactory.Enums.ColorChannel));
                SpriteFactory.Utils.ArrayTools.Insert<string>(ref modes, 0, "Default");
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(SpriteFactory.Enums.ColorChannel));
                SpriteFactory.Utils.ArrayTools.Insert<int>(ref values, 0, -1);
                spriteProperties_meshGenerationTransparencyChannel = new SimpleGUIPopupEnum(new GUIContent("Mesh Trans Chnl", "Sets the transparency channel the mesh generator will use to determine what areas of the image are transparent."), modes, values);
                spriteProperties_meshGenerationTransparencyChannel.parent = spriteListBoxContainer;
            } else
                spriteProperties_meshGenerationTransparencyChannel.Clear();
            */

            if(spriteProperties_useDefaultAutoMeshEdgeExtrude == null) {
                spriteProperties_useDefaultAutoMeshEdgeExtrude = new SimpleGUIToggle(new GUIContent("Default Edge Extrude", "Uncheck this to override the default mesh edge extrusion setting. NOTE: This only has an affect if Mesh Type is set to AutoMesh."));
                spriteProperties_useDefaultAutoMeshEdgeExtrude.parent = spriteListBoxContainer;
            } else
                spriteProperties_useDefaultAutoMeshEdgeExtrude.Clear();

            if(spriteProperties_autoMeshEdgeExtrude == null) {
                spriteProperties_autoMeshEdgeExtrude = new SimpleGUIIntField(new GUIContent("Edge Extrude", "Sets the edge extrusion distance for sprite meshes. NOTE: This only has an affect if Mesh Type is set to AutoMesh."), 3, 50);
                spriteProperties_autoMeshEdgeExtrude.parent = spriteListBoxContainer;
            } else
                spriteProperties_autoMeshEdgeExtrude.Clear();

            if(spriteProperties_useDefaultAutoMeshVertexReductionDistance == null) {
                spriteProperties_useDefaultAutoMeshVertexReductionDistance = new SimpleGUIToggle(new GUIContent("Default Vert Distance", "Uncheck this to override the default vertex reduction distance setting. NOTE: This only has an affect if Mesh Type is set to AutoMesh."));
                spriteProperties_useDefaultAutoMeshVertexReductionDistance.parent = spriteListBoxContainer;
            } else
                spriteProperties_useDefaultAutoMeshVertexReductionDistance.Clear();

            if(spriteProperties_autoMeshVertexReductionDistance == null) {
                spriteProperties_autoMeshVertexReductionDistance = new SimpleGUIIntField(new GUIContent("Vertex Distance", "Sets the vertex reduction distance for sprite meshes. A higher number will result in a mesh with fewer vertices, but too a high a number could cause areas of the sprite to be cut off. NOTE: This only has an affect if Mesh Type is set to AutoMesh."), 3, 20);
                spriteProperties_autoMeshVertexReductionDistance.parent = spriteListBoxContainer;
            } else
                spriteProperties_autoMeshVertexReductionDistance.Clear();

            #endregion

            #region // Animations

            // Animations list box
            if(animationListBoxContainer == null) {
                animationListBoxContainer = new SimpleGUIListBoxContainer<EditorMasterSprite.Animation>(mainSkin, AnimationSelectionChangeDelegate, true);
                animationListBoxContainer.parent = spriteListBoxContainer;
            } else animationListBoxContainer.ClearAll();

            // Animation properties
            if(animationProperties_name == null) {
                animationProperties_name = new SimpleGUITextField(new GUIContent("Name", "The name of this animation. This name must be unique as it is used to play the animation via scripting."));
                animationProperties_name.parent = animationListBoxContainer;
                animationProperties_name.AddChangePartner(animationListBoxContainer); // make animation list update when name changes
            } else animationProperties_name.Clear();

            if(animationProperties_wrapMode == null) {
                string[] wrapModes = System.Enum.GetNames(typeof(Sprite.WrapMode));
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(Sprite.WrapMode));
                animationProperties_wrapMode = new SimpleGUIPopupEnum(new GUIContent("Wrap Mode", "Wrap mode determines what happens after the last frame of an animation is played. For example, Loop causes the animation to immediately restart at the beginning."), wrapModes, values);
                animationProperties_wrapMode.parent = animationListBoxContainer;
            } else
                animationProperties_wrapMode.Clear();

            if(animationProperties_loopCount == null) {
                animationProperties_loopCount = new SimpleGUIIntField(new GUIContent("Loop Count (0 = inf)", "Determines how many loops are played before playback ends. 0 = Loop Continuously."), 0, 1000);
                animationProperties_loopCount.parent = animationListBoxContainer;
            } else
                animationProperties_loopCount.Clear();

            if(animationProperties_loopRestartFrame == null) {
                animationProperties_loopRestartFrame = new SimpleGUIIntField(new GUIContent("Loop Restart Frame", "Restart at this frame when loop cycles."), 0, 100000);
                animationProperties_loopRestartFrame.parent = animationListBoxContainer;
            } else
                animationProperties_loopRestartFrame.Clear();

            if(animationProperties_fps == null) {
                animationProperties_fps = new SimpleGUIIntField(new GUIContent("Frame Rate", "Playback speed in frames per second."), 1, 1000);
                animationProperties_fps.parent = animationListBoxContainer;
            } else
                animationProperties_fps.Clear();

            // Animation preview
            if(animationPreview == null) {
                animationPreview = new SimpleGUIDrawSpriteAnimation(mainSkin, 2048, 2048);
                animationPreview.parent = animationListBoxContainer;
            } else
                animationPreview.Clear();

            #endregion

            #region // Frames

            // Frames list box
            if(frameListBoxContainer == null) {
                frameListBoxContainer = new SimpleGUIListBoxContainer<EditorMasterSprite.Frame>(mainSkin, true);
                frameListBoxContainer.parent = animationListBoxContainer;
                frameListBoxContainer.AddChangePartner(animationPreview); // make the animation preview refresh when data changes are made to this control
                frameListBoxContainer.AddChangePartner(animationProperties_loopRestartFrame);
            } else frameListBoxContainer.ClearAll();

            // Frame Properties
            if(frameProperties_sourceImage == null) {
                frameProperties_sourceImage = new SimpleGUIObjectField(new GUIContent("Source Image"), typeof(Texture2D), false);
                frameProperties_sourceImage.parent = frameListBoxContainer;
                frameProperties_sourceImage.AddChangePartner(frameListBoxContainer); // make the frame name list update when image is changed
            } else
                frameProperties_sourceImage.Clear();

            if(frameProperties_duration == null) {
                frameProperties_duration = new SimpleGUIFloatField(new GUIContent("Duration", "The length of time in seconds that the current frame will be displayed. This is automatically calculated based on frame rate and frame hold and is displayed for your reference."), 0.001f, Mathf.Infinity);
                frameProperties_duration.parent = frameListBoxContainer;
                animationProperties_fps.AddChangePartner(frameProperties_duration); // add this duration as a change partner of FPS so this updates when FPS does -- had to declare it here instead of above because duration hadn't been initialized yet
            } else
                frameProperties_duration.Clear();

            if(frameProperties_frameHold == null) {
                frameProperties_frameHold = new SimpleGUIIntField(new GUIContent("Frame Hold", "The number of frames over which to display this frame during playback. You can use this to make a frame play longer to adjust animation timing. For example, if frame rate is 30 fps, a frame hold of 3 will display this frame over 3 frames for a total hold time of 1/10th of a second."), 1, 1000);
                frameProperties_frameHold.parent = frameListBoxContainer;
                frameProperties_frameHold.AddChangePartner(frameProperties_duration);
            } else
                frameProperties_frameHold.Clear();

            if(frameProperties_offsetX == null) {
                frameProperties_offsetX = new SimpleGUIIntField(new GUIContent("Offset X", "The X position of the sprite in the frame editor."), -1024, 1024);
                frameProperties_offsetX.parent = frameListBoxContainer;
            } else
                frameProperties_offsetX.Clear();

            if(frameProperties_offsetY == null) {
                frameProperties_offsetY = new SimpleGUIIntField(new GUIContent("Offset Y", "The Y position of the sprite in the frame editor."), -1024, 1024);
                frameProperties_offsetY.parent = frameListBoxContainer;
            } else
                frameProperties_offsetY.Clear();

            if(frameProperties_offsetAllFrames == null) {
                frameProperties_offsetAllFrames = new SimpleGUIToggle(new GUIContent("Offset All Frames", "Offset the position of all frames in this animation simultaneously. This is useful if you need to reposition the whole animation at once. To offset colliders on all frames as well, enable the Colliders checkbox also. Note that this setting affects changes to the OffsetX and OffsetY fields as well as repositioning of the sprite directly in the frame editor."));
                frameProperties_offsetAllFrames.parent = frameListBoxContainer;
            } else
                frameProperties_offsetAllFrames.Clear();

            if(frameProperties_offsetColliders == null) {
                // label text is set in SetStaticSpriteMode() so it can change
                frameProperties_offsetColliders = new SimpleGUIToggle(new GUIContent("", "Offset the position of collider frames as well when repositioning the sprite in the frame editor. This will not reposition static colliders unless you enable the Static checkbox as well. Note that this setting affects changes to the OffsetX and OffsetY fields as well as repositioning of the sprite directly in the frame editor."));
                frameProperties_offsetColliders.parent = frameListBoxContainer;
            } else
                frameProperties_offsetColliders.Clear();

            if(frameProperties_offsetStaticColliders == null) {
                // label text is set in SetStaticSpriteMode() so it can change
                frameProperties_offsetStaticColliders = new SimpleGUIToggle(new GUIContent("", "Offset the position of static colliders along with animated collider frames."));
                frameProperties_offsetStaticColliders.parent = frameListBoxContainer;
            } else
                frameProperties_offsetStaticColliders.Clear();

            if(frameProperties_offsetLocators == null) {
                // label text is set in SetStaticSpriteMode() so it can change
                frameProperties_offsetLocators = new SimpleGUIToggle(new GUIContent("", "Offset the position of Locators. Note that this setting affects changes to the OffsetX and OffsetY fields as well as repositioning of the sprite directly in the frame editor."));
                frameProperties_offsetLocators.parent = frameListBoxContainer;
            } else
                frameProperties_offsetLocators.Clear();

            if(frameProperties_offsetAllX == null) {
                frameProperties_offsetAllX = new SimpleGUIIntField(new GUIContent("*Offset X", "The relative X offset of the sprite in the frame editor. Currently offsetting all frames simultaneously."), -1024, 1024);
                frameProperties_offsetAllX.parent = frameListBoxContainer;
            } else
                frameProperties_offsetAllX.Clear();

            if(frameProperties_offsetAllY == null) {
                frameProperties_offsetAllY = new SimpleGUIIntField(new GUIContent("*Offset Y", "The relative Y offset of the sprite in the frame editor. Currently offsetting all frames simultaneously."), -1024, 1024);
                frameProperties_offsetAllY.parent = frameListBoxContainer;
            } else
                frameProperties_offsetAllY.Clear();

            if(frameProperties_event == null) {
                frameProperties_event = new SimpleGUITextField(new GUIContent("Event String", "If not left blank, when this frame plays, a SendMessage will be sent by Sprite which will pass the string you set here. This can be used to trigger an action each time a frame plays, for example, playing a sound effect during certain frames of a walk cycle or attack animation. To receive this message, place \"void OnSpriteFrameStart(Sprite.FrameEvent frameEvent) {}\" and/or \"void OnSpriteFrameEnd(Sprite.FrameEvent frameEvent) {}\" methods in a script and add the script as a component to the same game object with the Sprite component. Your string should be something that describes the event such as sword_attack_swing_finish."));
                frameProperties_event.parent = frameListBoxContainer;
            } else
                frameProperties_event.Clear();

            #endregion

            #region // Collider Frames

            // Collider Frame properties
            if(colliderFrameProperties_editCollider == null) {
                colliderFrameProperties_editCollider = new SimpleGUIPopup(new GUIContent("Edit Collider", "Select a collider to begin editing collider frames."), new string[1] { "None" });
                colliderFrameProperties_editCollider.parent = spriteListBoxContainer;
            } else
                colliderFrameProperties_editCollider.Clear();

            if(colliderFrameProperties_visibleColliderGroup == null) {
                string[] options = new string[2] { "Current", "All" };
                colliderFrameProperties_visibleColliderGroup = new SimpleGUIPopup(new GUIContent("Show", "Filter which collider groups to show in the frame editor."), options);
                colliderFrameProperties_visibleColliderGroup.parent = spriteListBoxContainer;
            } else
                colliderFrameProperties_visibleColliderGroup.Clear();

            if(colliderFrameProperties_enabled == null) {
                colliderFrameProperties_enabled = new SimpleGUIToggle(new GUIContent("Enabled", "Enable or disable this collider during this frame of animation."));
                colliderFrameProperties_enabled.parent = colliderFrameProperties_editCollider;
            } else
                colliderFrameProperties_enabled.Clear();

            if(colliderFrameProperties_sizeX == null) {
                colliderFrameProperties_sizeX = new SimpleGUIFloatField(new GUIContent("W", "The width of the collider."), 0.0f, 2048.0f);
                colliderFrameProperties_sizeX.parent = colliderFrameProperties_editCollider;
            } else
                colliderFrameProperties_sizeX.Clear();

            if(colliderFrameProperties_sizeY == null) {
                colliderFrameProperties_sizeY = new SimpleGUIFloatField(new GUIContent("H", "The height of the collider."), 0.0f, 2048.0f);
                colliderFrameProperties_sizeY.parent = colliderFrameProperties_editCollider;
            } else
                colliderFrameProperties_sizeY.Clear();

            if(colliderFrameProperties_centerX == null) {
                colliderFrameProperties_centerX = new SimpleGUIFloatField(new GUIContent("X", "The X position of the collider's center"), -1024.0f, 1024.0f);
                colliderFrameProperties_centerX.parent = colliderFrameProperties_editCollider;
            } else
                colliderFrameProperties_centerX.Clear();

            if(colliderFrameProperties_centerY == null) {
                colliderFrameProperties_centerY = new SimpleGUIFloatField(new GUIContent("Y", "The Y position of the collider's center"), -1024.0f, 1024.0f);
                colliderFrameProperties_centerY.parent = colliderFrameProperties_editCollider;
            } else
                colliderFrameProperties_centerY.Clear();

            if(colliderFrameProperties_rotation == null) {
                colliderFrameProperties_rotation = new SimpleGUIFloatField(new GUIContent("Rot", "The rotation of the collider."), -360.0f, 360.0f);
                colliderFrameProperties_rotation.parent = colliderFrameProperties_editCollider;
            } else
                colliderFrameProperties_rotation.Clear();

            #endregion

            #region // Locator Frames

            if(locatorFrameProperties_editLocator == null) {
                locatorFrameProperties_editLocator = new SimpleGUIPopup(new GUIContent("Edit Locator", "Select a locator to begin editing locator frames. If the sprite has no locators yet, you can add some under Sprite Properties -> Locators -> Edit."), new string[1] { "None" });
                locatorFrameProperties_editLocator.parent = spriteListBoxContainer;
            } else
                locatorFrameProperties_editLocator.Clear();

            if(locatorFrameProperties_enabled == null) {
                locatorFrameProperties_enabled = new SimpleGUIToggle(new GUIContent("Enabled", "Enable or disable this locator during this frame of animation."));
                locatorFrameProperties_enabled.parent = locatorFrameProperties_editLocator;
            } else
                locatorFrameProperties_enabled.Clear();

            if(locatorFrameProperties_positionX == null) {
                locatorFrameProperties_positionX = new SimpleGUIIntField(new GUIContent("X", "The X position of the locator in pixels."), -1024, 1024);
                locatorFrameProperties_positionX.parent = locatorFrameProperties_editLocator;
            } else
                locatorFrameProperties_positionX.Clear();

            if(locatorFrameProperties_positionY == null) {
                locatorFrameProperties_positionY = new SimpleGUIIntField(new GUIContent("Y", "The Y position of the locator in pixels."), -1024, 1024);
                locatorFrameProperties_positionY.parent = locatorFrameProperties_editLocator;
            } else
                locatorFrameProperties_positionY.Clear();

            if(locatorFrameProperties_offsetZ == null) {
                locatorFrameProperties_offsetZ = new SimpleGUIFloatField(new GUIContent("Z (u)", "The Z offset of the locator in world units (not pixels). -Z is forward toward the screen, +Z is back into the screen. This is useful if you are attaching another sprite to the lLocator and want the child sprite to display in front or behind the parent sprite. To display in front, use a negative value.\n\nNote: The \"Flip Fwd Dir\" setting does not change the direction of Z. -Z is ALWAYS toward the screen."));
                locatorFrameProperties_offsetZ.parent = locatorFrameProperties_editLocator;
            } else
                locatorFrameProperties_offsetZ.Clear();

            if(locatorFrameProperties_facing == null) {
                locatorFrameProperties_facing = new SimpleGUIFloatField(new GUIContent("Facing", "The Z-axis rotation of the locator."));
                locatorFrameProperties_facing.parent = locatorFrameProperties_editLocator;
            } else
                locatorFrameProperties_facing.Clear();

            if(locatorFrameProperties_flipForwardVector == null) {
                locatorFrameProperties_flipForwardVector = new SimpleGUIToggle(new GUIContent("Flip Fwd Dir", "Flip the X direction of the locator. By default, a locator facing right (+X) in the frame editor has its Y vector facing up. Check this if you need the locator to face left (-X) in the frame editor with the Y vector facing up. In most cases, if your sprite is drawn facing right, check this. If it is drawn facing left, uncheck this.\n\nNote: This setting does not change the direction of Z. -Z is ALWAYS toward the screen."));
                locatorFrameProperties_flipForwardVector.parent = locatorFrameProperties_editLocator;
            } else
                locatorFrameProperties_flipForwardVector.Clear();

            #endregion

            #region // Frame Editor

            // Frame preview
            if(frameEditor == null) {
                frameEditor = new SimpleGUIFrameEditor(frameListBoxContainer, clipboard, mainSkin, new Rect(0, 0, 512, 512), 2048, 2048, 25, 25, 400, 100);
                frameEditor.parent = frameListBoxContainer;
            } else
                frameEditor.Clear();

            // Frame preview controls
            if(framePreviewControls_LightboxAnimation == null) {
                framePreviewControls_LightboxAnimation = new SimpleGUIPopup(new string[1] { "Anim" });
                framePreviewControls_LightboxAnimation.parent = animationListBoxContainer;
            } else
                framePreviewControls_LightboxAnimation.Clear();

            if(framePreviewControls_LightboxFrame == null) {
                framePreviewControls_LightboxFrame = new SimpleGUIPopup(new string[1] { "Frame" });
                framePreviewControls_LightboxFrame.parent = animationListBoxContainer;
            } else
                framePreviewControls_LightboxFrame.Clear();

            #endregion

            #region // Sprite Groups

            // Sprite Group Properties
            if(groupProperties_name == null) {
                groupProperties_name = new SimpleGUITextField(new GUIContent("Name", "The name of this sprite group."));
                groupProperties_name.parent = groupListBoxContainer;
            } else
                groupProperties_name.Clear();

            if(groupProperties_filterMode == null) {
                string[] modes = System.Enum.GetNames(typeof(FilterMode));
                SpriteFactory.Utils.ArrayTools.Insert<string>(ref modes, 0, "Default");
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(FilterMode));
                SpriteFactory.Utils.ArrayTools.Insert<int>(ref values, 0, -1);
                groupProperties_filterMode = new SimpleGUIPopupEnum(new GUIContent("Texture Filter Mode", "Sets the texture filter mode for atlas textures in this group."), modes, values);
                groupProperties_filterMode.parent = groupListBoxContainer;
            } else
                groupProperties_filterMode.Clear();

            if(groupProperties_anisoLevel == null) {
                string[] options = new string[11] { "Default", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" };
                int[] values = new int[11] { -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
                groupProperties_anisoLevel = new SimpleGUIPopupEnum(new GUIContent("Aniso Level", "Sets the anisotropic level for atlas textures in this group."), options, values);
                groupProperties_anisoLevel.parent = groupListBoxContainer;
            } else
                groupProperties_anisoLevel.Clear();

            #endregion

            #region // Material Sets

            // Material Set Editor 
            if(materialSetListBoxContainer == null) {
                materialSetListBoxContainer = new SimpleGUIListBoxContainer<EditorMasterSprite.MaterialSet>(mainSkin);
            } else
                materialSetListBoxContainer.Clear();

            if(materialSetProperties_name == null) {
                materialSetProperties_name = new SimpleGUITextField(new GUIContent("Name", "The name of this material set. This name must be unique as it is used to change the currently displayed material on the sprite via scripting."));
                materialSetProperties_name.AddChangePartner(materialSetListBoxContainer);
                materialSetProperties_name.parent = materialSetListBoxContainer;
            } else
                materialSetProperties_name.Clear();

            if(materialSetProperties_useDefaultMaterial == null) {
                materialSetProperties_useDefaultMaterial = new SimpleGUIToggle(new GUIContent("Use Default Material", "Use the default material assigned in the Editor Properties. Uncheck this to assign a custom material."));
                materialSetProperties_useDefaultMaterial.AddChangePartner(materialSetListBoxContainer);
                materialSetProperties_useDefaultMaterial.parent = materialSetListBoxContainer;
            } else
                materialSetProperties_useDefaultMaterial.Clear();

            if(materialSetProperties_sourceMaterial == null) {
                materialSetProperties_sourceMaterial = new SimpleGUIObjectField(new GUIContent("Source Material", "The source material from which materials for this sprite will be generated in this material set. Note: The source material's shader must have a _MainTex property to work properly."), typeof(Material), false);
                materialSetProperties_sourceMaterial.parent = materialSetListBoxContainer;
            } else
                materialSetProperties_sourceMaterial.Clear();

            #endregion

            #region // Collider Sets

            // Collider set editor
            if(colliderSetListBoxContainer == null) {
                colliderSetListBoxContainer = new SimpleGUIListBoxContainer<Sprite.ColliderSet>(mainSkin);
            } else
                colliderSetListBoxContainer.Clear();

            if(colliderSetProperties_name == null) {
                colliderSetProperties_name = new SimpleGUITextField(new GUIContent("Name", "The name of this collider. This name can be used to access the collider through scripting and must be unique in this sprite."));
                colliderSetProperties_name.AddChangePartner(colliderSetListBoxContainer);
                colliderSetProperties_name.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_name.Clear();

            if(colliderSetProperties_tag == null) {
                colliderSetProperties_tag = new SimpleGUITextField(new GUIContent("Tag", "The tag which will be assigned to this collider's GameObject. You must create tags in the Unity tag inspector. The string you enter here must match a Unity tag name exactly. NOTE: If the collider is set to Parent, the tag will be set on the main Sprite GameObject."));
                colliderSetProperties_tag.AddChangePartner(colliderSetListBoxContainer);
                colliderSetProperties_tag.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_tag.Clear();

            if(colliderSetProperties_group == null) {
                string[] options = new string[] { "None" };
                colliderSetProperties_group = new SimpleGUIPopup(new GUIContent("Group", "The collider group this collider is in. The group can be used to filter collisions to a specific group of colliders through scripting."), options);
                colliderSetProperties_group.AddChangePartner(colliderSetListBoxContainer);
                colliderSetProperties_group.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_group.Clear();

            if(colliderSetProperties_previewColor == null) {
                colliderSetProperties_previewColor = new SimpleGUIColorField(new GUIContent("Preview Color", "The color the of the collider in the frame editor."));
                colliderSetProperties_previewColor.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_previewColor.Clear();

            if(colliderSetProperties_layer == null) {
                colliderSetProperties_layer = new SimpleGUIPopup(new GUIContent("Layer", "The layer the collider will be created on."), GetColliderLayerOptions());
                colliderSetProperties_layer.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_layer.Clear();

            // collider vars
            if(colliderSetProperties_colliderType == null) {
                string[] options = System.Enum.GetNames(typeof(ColliderType));
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(ColliderType));
                colliderSetProperties_colliderType = new SimpleGUIPopupEnum(new GUIContent("Collider Type", "The type of this collider. Currently, the only supported type is BoxCollider."), options, values);
                colliderSetProperties_colliderType.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_colliderType.Clear();

            if(colliderSetProperties_is2D == null) {
                colliderSetProperties_is2D = new SimpleGUIToggle(new GUIContent("2D Collider", "Is this collider 2D or 3D? Only available in Unity 4.3+"));
                colliderSetProperties_is2D.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_is2D.Clear();

            if(colliderSetProperties_isAnimated == null) {
                colliderSetProperties_isAnimated = new SimpleGUIToggle(new GUIContent("Animated Collider", "Is this collider animated or static? An animated collider can have its shape, relative position, and enabled state animated frame-by-frame during sprite animation. A static collider always exists in the same shape and relative position throughout every frame of the sprite animation."));
                colliderSetProperties_isAnimated.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_isAnimated.Clear();

            if(colliderSetProperties_enableInNewFrames == null) {
                colliderSetProperties_enableInNewFrames = new SimpleGUIToggle(new GUIContent("Enable in New Frames", "Enable this if you want this collider to be enabled by default in every new animation frame you add to the sprite."));
                colliderSetProperties_enableInNewFrames.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_enableInNewFrames.Clear();

            if(colliderSetProperties_sizeZ == null) {
                colliderSetProperties_sizeZ = new SimpleGUIFloatField(new GUIContent("Size Z", "The depth of the collider in units."));
                colliderSetProperties_sizeZ.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_sizeZ.Clear();

            if(colliderSetProperties_centerZ == null) {
                colliderSetProperties_centerZ = new SimpleGUIFloatField(new GUIContent("Center Z", "The center position of the collider in the Z axis. 0 represents a centered collider. -Z is toward you the viewer, +Z is deeper into the screen."));
                colliderSetProperties_centerZ.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_centerZ.Clear();

            if(colliderSetProperties_isTrigger == null) {
                colliderSetProperties_isTrigger = new SimpleGUIToggle(new GUIContent("Is Trigger", "Is this collider a trigger type collider?"));
                colliderSetProperties_isTrigger.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_isTrigger.Clear();

            if(colliderSetProperties_material == null) {
                colliderSetProperties_material = new SimpleGUIObjectField(new GUIContent("Physic Material", "You can assign a physic material if this collider will be controlled by a rigidbody."), typeof(PhysicMaterial), false);
                colliderSetProperties_material.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_material.Clear();

            if(colliderSetProperties_material2D == null) { // Physics Material 2D
                System.Type type = SpriteFactory.Utils.UnityTools.GetVersionRestrictedType(Enums.VersionRestrictedType.PhysicsMaterial2D);
                if(type == null) type = typeof(UnityEngine.Object); // for < Unity 4.3 just stub with Object
                colliderSetProperties_material2D = new SimpleGUIObjectField(new GUIContent("Physics Material", "You can assign a physics material if this collider will be controlled by a rigidbody."), type, false);
                colliderSetProperties_material2D.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_material2D.Clear();

            // rigidbody vars
            if(colliderSetProperties_hasRigidbody == null) {
                colliderSetProperties_hasRigidbody = new SimpleGUIToggle(new GUIContent("Use Rigidbody", "Create a rigidbody for this collider?"));
                colliderSetProperties_hasRigidbody.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_hasRigidbody.Clear();

            if(colliderSetProperties_mass == null) {
                colliderSetProperties_mass = new SimpleGUIFloatField(new GUIContent("Mass", "The mass of the body. [0.0000001, 1000000000]"), 0.0000001f, 1000000000.0f);
                colliderSetProperties_mass.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_mass.Clear();

            if(colliderSetProperties_drag == null) {
                colliderSetProperties_drag = new SimpleGUIFloatField(new GUIContent("Drag", "The linear drag coefficient. 0 means no damping. [0, infinity]"), 0.0f, Mathf.Infinity);
                colliderSetProperties_drag.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_drag.Clear();

            if(colliderSetProperties_angularDrag == null) {
                colliderSetProperties_angularDrag = new SimpleGUIFloatField(new GUIContent("Angular Drag", "The angular drag coefficient. 0 means no damping. [0, infinity]"), 0.0f, Mathf.Infinity);
                colliderSetProperties_angularDrag.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_angularDrag.Clear();

            if(colliderSetProperties_useGravity == null) {
                colliderSetProperties_useGravity = new SimpleGUIToggle(new GUIContent("Use Gravity"));
                colliderSetProperties_useGravity.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_useGravity.Clear();

            if(colliderSetProperties_isKinematic == null) {
                colliderSetProperties_isKinematic = new SimpleGUIToggle(new GUIContent("Is Kinematic"));
                colliderSetProperties_isKinematic.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_isKinematic.Clear();

            if(colliderSetProperties_rigidbodyInterpolation == null) {
                string[] options = System.Enum.GetNames(typeof(RigidbodyInterpolation));
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(RigidbodyInterpolation));
                colliderSetProperties_rigidbodyInterpolation = new SimpleGUIPopupEnum(new GUIContent("Rigidbody Interpolation", "This is used to prevent read back from kinematic rigidbodies."), options, values);
                colliderSetProperties_rigidbodyInterpolation.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_rigidbodyInterpolation.Clear();

            if(colliderSetProperties_collisionDetectionMode == null) {
                string[] options = System.Enum.GetNames(typeof(CollisionDetectionMode));
                int[] values = SpriteFactory.Utils.EnumTools.GetIntValues(typeof(CollisionDetectionMode));
                colliderSetProperties_collisionDetectionMode = new SimpleGUIPopupEnum(new GUIContent("Collision Detection Mode"), options, values);
                colliderSetProperties_collisionDetectionMode.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_collisionDetectionMode.Clear();

            if(colliderSetProperties_constraintsPosX == null) {
                colliderSetProperties_constraintsPosX = new SimpleGUIToggle();
                colliderSetProperties_constraintsPosX.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_constraintsPosX.Clear();

            if(colliderSetProperties_constraintsPosY == null) {
                colliderSetProperties_constraintsPosY = new SimpleGUIToggle();
                colliderSetProperties_constraintsPosY.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_constraintsPosY.Clear();

            if(colliderSetProperties_constraintsPosZ == null) {
                colliderSetProperties_constraintsPosZ = new SimpleGUIToggle();
                colliderSetProperties_constraintsPosZ.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_constraintsPosZ.Clear();

            if(colliderSetProperties_constraintsRotX == null) {
                colliderSetProperties_constraintsRotX = new SimpleGUIToggle();
                colliderSetProperties_constraintsRotX.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_constraintsRotX.Clear();

            if(colliderSetProperties_constraintsRotY == null) {
                colliderSetProperties_constraintsRotY = new SimpleGUIToggle();
                colliderSetProperties_constraintsRotY.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_constraintsRotY.Clear();

            if(colliderSetProperties_constraintsRotZ == null) {
                colliderSetProperties_constraintsRotZ = new SimpleGUIToggle();
                colliderSetProperties_constraintsRotZ.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_constraintsRotZ.Clear();

            // Rigidbody2D
            if(colliderSetProperties_mass2D == null) {
                colliderSetProperties_mass2D = new SimpleGUIFloatField(new GUIContent("Mass", "The mass of the body. [0.0001, 1000000]"), 0.0001f, 1000000.0f);
                colliderSetProperties_mass2D.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_mass2D.Clear();

            if(colliderSetProperties_linearDrag2D == null) {
                colliderSetProperties_linearDrag2D = new SimpleGUIFloatField(new GUIContent("Linear Drag", "The linear drag coefficient. 0 means no damping. [0, 1000000]"), 0.0f, 1000000.0f);
                colliderSetProperties_linearDrag2D.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_linearDrag2D.Clear();

            if(colliderSetProperties_angularDrag2D == null) {
                colliderSetProperties_angularDrag2D = new SimpleGUIFloatField(new GUIContent("Angular Drag", "The angular drag coefficient. 0 means no damping. [0, 1000000]"), 0.0f, 1000000.0f);
                colliderSetProperties_angularDrag2D.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_angularDrag2D.Clear();

            if(colliderSetProperties_gravityScale == null) {
                colliderSetProperties_gravityScale = new SimpleGUIFloatField(new GUIContent("Gravity Scale", "How much gravity affects this body. [-1000000, 1000000]"), -1000000.0f, 1000000.0f);
                colliderSetProperties_gravityScale.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_gravityScale.Clear();

            if(colliderSetProperties_fixedAngle == null) {
                colliderSetProperties_fixedAngle = new SimpleGUIToggle(new GUIContent("Fixed Angle", "Whether the body's angle is fixed or not."));
                colliderSetProperties_fixedAngle.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_fixedAngle.Clear();

            if(colliderSetProperties_rigidbodyInterpolation2D == null) {
                string[] options;
                int[] values;
                System.Type type = SpriteFactory.Utils.UnityTools.GetVersionRestrictedType(Enums.VersionRestrictedType.RigidbodyInterpolation2D);
                if(type != null && type.IsEnum) {
                    options = System.Enum.GetNames(type);
                    values = SpriteFactory.Utils.EnumTools.GetIntValues(type);
                } else {
                    options = new string[] { "None" };
                    values = null;
                }
                colliderSetProperties_rigidbodyInterpolation2D = new SimpleGUIPopupEnum(new GUIContent("Interpolate", "The per-frame update mode for the body."), options, values);
                colliderSetProperties_rigidbodyInterpolation2D.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_rigidbodyInterpolation.Clear();

            if(colliderSetProperties_sleepMode2D == null) {
                string[] options;
                int[] values;
                System.Type type = SpriteFactory.Utils.UnityTools.GetVersionRestrictedType(Enums.VersionRestrictedType.RigidbodySleepMode2D);
                if(type != null && type.IsEnum) {
                    options = System.Enum.GetNames(type);
                    values = SpriteFactory.Utils.EnumTools.GetIntValues(type);
                } else {
                    options = new string[] { "None" };
                    values = null;
                }
                colliderSetProperties_sleepMode2D = new SimpleGUIPopupEnum(new GUIContent("Sleeping Mode", "The sleeping mode for the body."), options, values);
                colliderSetProperties_sleepMode2D.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_sleepMode2D.Clear();

            if(colliderSetProperties_collisionDetectionMode2D == null) {
                string[] options;
                int[] values;
                //System.Type type = SpriteFactory.Utils.UnityTools.GetVersionRestrictedType("CollisionDetectionMode2D");
                System.Type type = typeof(SpriteFactory.CollisionDetectionMode2D); // replace with fixed enum because of naming bug in unity version
                if(type != null && type.IsEnum) {
                    options = System.Enum.GetNames(type);
                    values = SpriteFactory.Utils.EnumTools.GetIntValues(type);
                } else {
                    options = new string[] { "None" };
                    values = null;
                }
                colliderSetProperties_collisionDetectionMode2D = new SimpleGUIPopupEnum(new GUIContent("Collision Detection Mode", "The collision detection mode for the body."), options, values);
                colliderSetProperties_collisionDetectionMode2D.parent = colliderSetListBoxContainer;
            } else
                colliderSetProperties_collisionDetectionMode2D.Clear();

            // Collider Groups
            if(colliderGroupListBoxContainer == null) {
                colliderGroupListBoxContainer = new SimpleGUIListBoxContainer<Sprite.ColliderGroup>(mainSkin);
            } else
                colliderGroupListBoxContainer.Clear();

            if(colliderGroupProperties_name == null) {
                colliderGroupProperties_name = new SimpleGUITextField(new GUIContent("Name", "The name of this collider group. This name can be used to access the collider group through scripting and must be unique in this collider set."));
                colliderGroupProperties_name.AddChangePartner(colliderGroupListBoxContainer);
                colliderGroupProperties_name.parent = colliderGroupListBoxContainer;
            } else
                colliderGroupProperties_name.Clear();
            /*
            if(colliderGroupProperties_useGroupCollisions == null) {
                colliderGroupProperties_useGroupCollisions = new SimpleGUIToggle(new GUIContent("Use Group Collisions", "Check this if you want collision events to be sent on a group-basis instead " +
                "of individually. Normally, collision events are sent for every collider, but enabling group collisions will send only one Sprite collision event for the whole group. This is useful for fighting games "
                + "where you have many hit detection colliders and you want all the colliders to act as one so you don't receive dozens of hit events when an attack collider contacts multiple hit colliders.\n"
                + "OnCollision/TriggerEnter will be sent when any collider in the group enters a collision.\n"
                + "OnCollision/TriggerStay will be sent when any collider in the group stays in collision.\n"
                + "OnCollision/TriggerExit will be sent when all colliders in the group exit collision.\n" 
                + "NOTE: Collision contact point data will not be accurate since any one of the group colliders could be returning its collision contact point."));
                colliderGroupProperties_useGroupCollisions.parent = colliderGroupListBoxContainer;
            } else
                colliderGroupProperties_useGroupCollisions.Clear();
            */
            #endregion

            #region // Locator Sets

            if(locatorSetListBoxContainer == null) {
                locatorSetListBoxContainer = new SimpleGUIListBoxContainer<Sprite.LocatorSet>(mainSkin);
            } else
                locatorSetListBoxContainer.Clear();

            if(locatorSetProperties_name == null) {
                locatorSetProperties_name = new SimpleGUITextField(new GUIContent("Name", "The name of this locator. This name can be used to access the locator through scripting and must be unique in this sprite."));
                locatorSetProperties_name.AddChangePartner(locatorSetListBoxContainer);
                locatorSetProperties_name.parent = locatorSetListBoxContainer;
            } else
                locatorSetProperties_name.Clear();

            if(locatorSetProperties_previewColor == null) {
                locatorSetProperties_previewColor = new SimpleGUIColorField(new GUIContent("Preview Color", "The color the of the locator in the frame editor."));
                locatorSetProperties_previewColor.parent = locatorSetListBoxContainer;
            } else
                locatorSetProperties_previewColor.Clear();

            if(locatorSetProperties_defaultToPosXIsForward == null) {
                locatorSetProperties_defaultToPosXIsForward = new SimpleGUIToggle(new GUIContent("Default Forward = +X", "Start new frames with the forward direction of the locator set to +/- X. This affects the direction of the up vector. In essence, unchecking this rotates the locator 180 degrees on the Y axis so the +X vector faces left. Generally, if your sprites are drawn facing right, you should keep this checked." +
                    "\n\nNote: This setting does not change the direction of Z. -Z is ALWAYS toward the screen."));
                locatorSetProperties_defaultToPosXIsForward.parent = locatorSetListBoxContainer;
            } else
                locatorSetProperties_defaultToPosXIsForward.Clear();

            if(locatorSetProperties_defaultOffsetZ == null) {
                locatorSetProperties_defaultOffsetZ = new SimpleGUIFloatField(new GUIContent("Default Offset Z", "The starting Z offset of the locator in new frames in world units (not pixels). -Z is forward toward the screen, +Z is back into the screen. This is useful if you are attaching another sprite to the Locator and want the child sprite to display in front or behind the parent sprite. To display in front, use a negative value."));
                locatorSetProperties_defaultOffsetZ.parent = locatorSetListBoxContainer;
            } else
                locatorSetProperties_defaultOffsetZ.Clear();

            #endregion

            #region // Export Window

            if(export_groupsListBoxContainer == null) {
                export_groupsListBoxContainer = new SimpleGUIListBoxContainer<int>(mainSkin);
            } else
                export_groupsListBoxContainer.Clear();

            if(export_groupsListBoxContainer_ToExport == null) {
                export_groupsListBoxContainer_ToExport = new SimpleGUIListBoxContainer<int>(mainSkin);
                export_groupsListBoxContainer_ToExport.AddChangePartner(export_groupsListBoxContainer);
                export_groupsListBoxContainer.AddChangePartner(export_groupsListBoxContainer_ToExport);
            } else
                export_groupsListBoxContainer_ToExport.Clear();

            if(export_ungroupedSpritesListBoxContainer == null) {
                export_ungroupedSpritesListBoxContainer = new SimpleGUIListBoxContainer<int>(mainSkin);
            } else
                export_ungroupedSpritesListBoxContainer.Clear();

            if(export_ungroupedSpritesListBoxContainer_ToExport == null) {
                export_ungroupedSpritesListBoxContainer_ToExport = new SimpleGUIListBoxContainer<int>(mainSkin);
                export_ungroupedSpritesListBoxContainer_ToExport.AddChangePartner(export_ungroupedSpritesListBoxContainer);
                export_ungroupedSpritesListBoxContainer.AddChangePartner(export_ungroupedSpritesListBoxContainer_ToExport);
            } else
                export_ungroupedSpritesListBoxContainer_ToExport.Clear();

            if(export_exportPrefabs == null) {
                export_exportPrefabs = new SimpleGUIToggle(new GUIContent("Export Prefabs for Sprites and Groups", "Export all prefabs in the project which use any of the sprites queued for export. This will export all dependencies of the prefabs as well."));
            } else
                export_exportPrefabs.Clear();

            #endregion

            #region // Import Window

            if(importMessagesListBoxContainer == null) {
                importMessagesListBoxContainer = new SimpleGUIListBoxContainer<string>(mainSkin);
            } else
                importMessagesListBoxContainer.Clear();

            #endregion

            // Listbox Action objects

            if(pendingSpriteListboxAction != null) pendingSpriteListboxAction.Clear();
            else pendingSpriteListboxAction = new ListboxAction(spriteListBoxContainer);

            if(pendingGroupListboxAction != null) pendingGroupListboxAction.Clear();
            else pendingGroupListboxAction = new ListboxAction(groupListBoxContainer);

            #region // Help

            help_spriteGroups = new GUIContent("Sprite Groups (?)", "A Sprite Group is a group of sprites that share atlases thereby saving memory and draw calls. Sprite groups are particularly useful for grouping static sprites. Animated sprites also work well in groups, but some guidelines should be followed for best results (see note below)."
            + "\n\nSprites can be moved in and out of groups at will from Sprite Properties -> Sprite Group. Note that when moving a sprite to or from a group, atlases and materials will be rebuilt for both groups which can take some time depending on the number of sprites in each group."
            + "\n\nSprite Groups have certain properties which are shared by all sprites within the group: Atlas Properties and Material Sets. When a sprite is in a group, these properties can no longer be set in the sprite, but must be set in the group instead."
            + "\n\nNote about draw calls: If the frames in all the sprites in a group exceeds the atlas size, multiple atlases will be created to fit all the frames. This is the same way atlasing works in non-grouped sprites. But in a group, for maximum draw call efficiency, "
            + "you should follow a couple of guidelines: \n\n1) Group static sprites with static sprites, and animated sprites with animated sprites. Grouping static sprites with animated sprites works, but if the animation has many frames, it may push some static sprites onto other atlas sheets causing the static "
            + "sprites to not be able to batch their draw calls. For this reason, if you do mix static and animated sprites in a group, its best that you move the animated sprites to the bottom of the group so they will be atlased last after all the static sprites have been atlased onto as few sheets as possible. "
            + "\n\n2) Group animated sprites with fewer frames together. Sprites with many frames, like a main character, should probably be standalone sprites (not grouped). This is a very loose suggestion because there may be some cases where you would want to group sprites with many frames, but it all depends on your max atlas size, "
            + "sprite frame size, and number of frames."
            );

            help_masterSprites = new GUIContent("Master Sprites (?)", "A Master Sprite is a template for a sprite. All sprites, whether scene objects or prefabs, must reference a Master Sprite from which they will load their data on Awake(). "
            + "Note: Deleting a Master Sprite will cause all sprites in scene or in prefabs based on that Master Sprite to break because they cannot refer back to their template. These sprites can be assigned a different Master Sprite with the \"Assign Master Sprite to Selected Object\" command.");

            help_colliders = new GUIContent("Colliders (?)", "The sprite collider system allows you to define any number of colliders for your sprite and optionally animate "
            + "the colliders to match the animation of your sprite. You can set every property in the colliders just as you would with a normal collider component. "
            + "You can choose to add a rigidbody to each collider, or designate one collider + rigidbody as Parent so all the other colliders will share its rigidbody. "
            + "\n\nAnimated colliders can have their shape, relative position, and enabled state animated frame-by-frame. One example use case would be a damage trigger "
            + "in an animated character. For example, a fighting game character could have a trigger collider that stays disabled in most "
            + "animations but enables during an attack animation and animates size and relative position to match the sprite's attack animation."
            + "\n\nNote: The sprite collider system may not fit everyone's needs since at present only BoxColliders are supported. If this is the case, you can always add "
            + "colliders and rigidbodies manually on the sprite's game object.");

            help_colliderGroups = new GUIContent("Collider Groups (?)", "Collider can groups help you more easily determine what to do when a collision event occurs. You can test for a group name in a collision event "
            + "instead of having to test for individual collider names. For example, create a group called HitDetectors and assign all your hit detection colliders to this group. When a collision event occurs, just test for the group name and take action.\n\n"
            + "Collider groups also allow you to filter the visible colliders in the frame editor by group so you can work on a particular set of colliders without other unrelated colliders getting in your way while you work.");

            help_locators = new GUIContent("Locators (?)", "A locator is a Transform that you can animate frame-by-frame. They are useful for things like bullet or muzzle "
            + "flash origin points, attaching an object to a specific point on a sprite, and more. You can define any number of locators for your sprite and animate "
            + "them to match the animation of your sprite. Example: A character holding a gun as a separate sprite. The gun can be parented to a Locator positioned on the character's "
            + "hand that animates frame-by-frame rotating the gun to match the sprite animation. Rotation of the gun can be animated using the facing property of the locator.");

            help_materialSets = new GUIContent("Material Sets (?)",
            "Material Sets allow you to define multiple materials for a sprite. You can switch a sprite's material at any time by changing the currently used material set via scripting. This can be useful for effects that require a different shader."
            + "\n\nA material set requires a source material to be defined from which it will create materials for the sprite inheriting the source material's shader and settings. Create a material in your project, set the shader (must have a _MainTex property to work correctly), and drag and drop the material onto the Source Material field of your material set."
            + " You may use this source material on as many material sets across as many sprites/groups as you like."
            + " Note: It's important that the source material is never deleted from your project because it is used every time you make changes to the sprite/group. If you make changes to the source material later, in order for sprite materials to inherit the new material settings, you must update sprite materials by rebuilding the materials using the Rebuild All Materials command from the editor.");

            help_lightbox = new GUIContent("Lightbox:",
            "Select an animation from which to display a semi-transparent frame in the background of the frame editor to help with frame alignment."
            );

            #endregion

            // Import resume handling for if import was interrupted by re-compile
            if(importInProcess) {
                busy = true; // disable user control 
                importFinished = true; // continue the import process
            }

            // Check if data must be upgraded
            upgradeRequired = db.UpgradeRebuildRequired();
            if(!upgradeRequired) programVersionUpdateRequired = db.CheckVersionChangeRequired();
        }

        private void OnEnable() {
            // clear these every time windows is enabled (opened, scripts are recompiled, etc.)
            NotInitialized();
        }

        private void OnSelectionChange() {
            GetUnitySelection();
        }

        private void OnGUI() {
            //try { // REMOVED TRY / CATCH WRAPPER BECAUSE IT CAUSES ERRORS TO BE THROWN BY OBJECTFIELD PICKERS -- CANNOT BE SILENCED ON MAC


                // show a message when the editor is shown during Play mode
                if(editorIsPlaying) {
                    DrawSectionSpacer(15.0f);
                    EditorGUILayout.LabelField("The editor is disabled in Play mode.");
                    return;
                }
                if(!initialized) return;
                Utils.GUITools.Engine.Update();
                if(!stylesSet) SetStyles(); // set styles here once... so we can access GUI functions
                UpdateUnitySelection();
                DrawMainPage(); // draw the main page
                ClearMomentaryVars();
            //} catch(System.Exception e) {
            //    HandleExceptionError(e);
            //}
        }

        private void Update() {
            //try { // REMOVED TRY / CATCH WRAPPER BECAUSE IT CAUSES ERRORS TO BE THROWN BY OBJECTFIELD PICKERS -- CANNOT BE SILENCED ON MAC
                // Handle editor play mode changes
                if(!HandleEditorPlayModeChanges()) return;

                // Initialize the database -- moved it here instead of OnEnable because of upgrading SF when window open problems (OnEnable runs before assets are fully imported, and before AssetPostprocessor, can't find assets, throws an error. No way to detect upgrade import to close the window.)
                if(!initialized && !initializationFailed) {
                    Initialize();
                    if(!initialized) { // could not initialize it
                        initializationFailed = true; // prevent it from hammering initialization attempts, just one will do
                        return;
                    }
                }

                if(!UpgradeCheck()) return; // check if upgrade is required and notify user
                ProcessDeferredUpdates(); // do deferred updates first

                this.Repaint(); // Increase repainting speed so we get accurate animation updates. Seems to work up to around 50 fps even though docs say 100
            //} catch(System.Exception e) {
            //    HandleExceptionError(e);
            //}
        }

        void OnDestroy() {
            // Show save dialog for Unity 4.x + only -- 3.x has bug that requires deferred saving and cannot do it
            if(SpriteFactory.Utils.UnityTools.unityVersion >= SpriteFactory.Utils.UnityTools.UnityVersion.UNITY_4_0 && unsavedChanges) {
                ShowSaveChangesDialog();

                if(saveChanges) {
                    saveChanges = false; // flag off
                    SaveChanges(saveChanges_editMode); // save changes to the sprite/group IMMEDIATELY
                    if(busy) busy = false; // allow user input again
                }
            }
        }

        #endregion

        #region Main Updates

        private void ProcessDeferredUpdates() {
            // All actions that can cause AssetDatabase.SaveAssets() or AssetDatabase.ImportAsset() calls must be run here in Update instead of in OnGUI
            // because Unity 3.x has a bug that sometimes causes the OnGUI loop to end immediately when these functions are called.

            // Save Changes
            if(saveChanges) {
                // do deferred saving in update cycle because it can cause errors in the OnGUI cycle in Unity 3.x
                saveChanges = false; // flag off
                SaveChanges(saveChanges_editMode); // save changes to the sprite/group
            }

            // Process pending Master Sprite listbox actions
            if(pendingSpriteListboxAction.pending) {

                if(pendingSpriteListboxAction.action == ListboxAction.Action.ChangeSelection) { // change sprite selection

                    selectedMasterSpriteIndex = pendingSpriteListboxAction.objectIndex;
                    LoadListSelectedSprite(); // load the master sprite
                    ClearSpriteChangeVars(); // reset change detection vars

                } else if(pendingSpriteListboxAction.action == ListboxAction.Action.Reorder) { // Reorder Master Sprite

                    int listIndex = spriteListBoxContainer.selectedIndex;
                    int groupId = -1;
                    if(groupListBoxContainer.selectedIndex > 0) { // a real group is selected
                        groupId = db.FindSpriteGroupIdByIndex(groupListBoxContainer.selectedObject);
                    }
                    if(db.ReorderMasterSpriteInGroup(groupId, listIndex, pendingSpriteListboxAction.offset)) {
                        spriteListBoxContainer.selectedIndex += pendingSpriteListboxAction.offset;
                    }

                } else if(pendingSpriteListboxAction.action == ListboxAction.Action.Add) {

                    db.AddNewMasterSpriteToGroup(pendingSpriteListboxAction.groupId);
                    groupListBoxContainer.softRefresh = true; // refresh the name list in listbox without calling refresh down the line
                    if(pendingSpriteListboxAction.groupId >= 0) LoadListSelectedGroup(); // reload the selected group object when adding a new sprite (so we don't carry old in Group Properties and then save over new additions)

                } else if(pendingSpriteListboxAction.action == ListboxAction.Action.Insert) {

                    db.InsertNewMasterSpriteInGroup(pendingSpriteListboxAction.groupId, pendingSpriteListboxAction.listIndex); // create new master sprite and get the new sprite index
                    ForceListSelectSpriteAtIndex(pendingSpriteListboxAction.listIndex, pendingSpriteListboxAction.objectIndex);
                    groupListBoxContainer.softRefresh = true; // refresh the name list in listbox without calling refresh down the line

                } else if(pendingSpriteListboxAction.action == ListboxAction.Action.Duplicate) {

                    bool inGroup = masterSpriteData.spriteGroupId >= 0 ? true : false;
                    db.DuplicateMasterSprite(pendingSpriteListboxAction.objectIndex, pendingSpriteListboxAction.listIndex, inGroup);
                    groupListBoxContainer.softRefresh = true; // refresh the name list in listbox without calling refresh down the line

                } else if(pendingSpriteListboxAction.action == ListboxAction.Action.Delete) {

                    if(preventRebuildSpriteGroupAssets) db.DeleteMasterSprite(pendingSpriteListboxAction.objectIndex, true, false, false); // delete sprite in group without rebuilding atlases or materials
                    else db.DeleteMasterSprite(pendingSpriteListboxAction.objectIndex, true);

                    groupListBoxContainer.softRefresh = true; // refresh the name list in listbox without calling refresh down the line
                    RevertSpriteGroup(); // revert sprite group on delete so the group object doesn't carry old data
                }

                pendingSpriteListboxAction.Finish(); // reset object and refresh listbox

            }

            // Process pending Sprite Group listbox actions
            if(pendingGroupListboxAction.pending) {

                // Change selected sprite group
                if(pendingGroupListboxAction.action == ListboxAction.Action.ChangeSelection) { // change group selection
                    selectedGroupIndex = pendingGroupListboxAction.objectIndex;
                    LoadListSelectedGroup(); // load the group
                    ClearGroupChangeVars(); // reset change detection vars

                } else if(pendingGroupListboxAction.action == ListboxAction.Action.Reorder) { // Reorder Sprite Group

                    int groupIndex = groupListBoxContainer.selectedObject;
                    if(db.ReorderSpriteGroup(groupIndex, pendingGroupListboxAction.offset)) {
                        groupListBoxContainer.selectedIndex += pendingGroupListboxAction.offset;
                        groupListBoxContainer.selectedObject += pendingGroupListboxAction.offset;
                        selectedGroupIndex += pendingGroupListboxAction.offset;
                    }

                } else if(pendingGroupListboxAction.action == ListboxAction.Action.Add) {

                    db.AddNewSpriteGroup();

                } else if(pendingGroupListboxAction.action == ListboxAction.Action.Insert) {

                    db.InsertNewSpriteGroup(pendingGroupListboxAction.groupIndex);
                    ForceListSelectGroupAtIndex(groupListBoxContainer.selectedIndex, pendingGroupListboxAction.groupIndex);

                } else if(pendingGroupListboxAction.action == ListboxAction.Action.Duplicate) {

                    db.DuplicateSpriteGroup(pendingGroupListboxAction.objectIndex);

                } else if(pendingGroupListboxAction.action == ListboxAction.Action.Delete) {

                    db.DeleteSpriteGroup(pendingGroupListboxAction.objectIndex); // delete group and child sprites

                }

                pendingGroupListboxAction.Finish(); // reset object and refresh listbox

            }

            // Editor button commands

            if(createSpriteInScene) {
                createSpriteInScene = false;
                CreateListSelectedSpriteInScene();
            }

            if(assignMasterSpriteToSprite) {
                assignMasterSpriteToSprite = false;
                TryAssignSpriteToSelection();
            }

            if(checkIfAtlasesNeedUpdating) {
                checkIfAtlasesNeedUpdating = false;
                if(db.CheckIfAnythingNeedsToBeRebuilt()) {
                    Revert(); // reload or old data may stick around if sprite is selected that is being updated
                    // force sprite and group names to refresh in case we unflagged one for rebuilding
                    groupListBoxContainer.softRefresh = true;
                    spriteListBoxContainer.softRefresh = true;
                }
            }

            if(rebuildAllAtlases) {
                rebuildAllAtlases = false;
                db.RebuildAllAtlases();

                Revert(); // reload or old data may stick around if sprite is selected that is being updated
                // force sprite and group names to refresh in case we unflagged one for rebuilding
                groupListBoxContainer.softRefresh = true;
                spriteListBoxContainer.softRefresh = true;
            }

            if(rebuildAllMaterials) {
                rebuildAllMaterials = false;
                db.RebuildAllMaterials();
                Revert(); // reload or old data may stick around if sprite is selected that is being updated
            }

            if(rebuildDataFile) {
                rebuildDataFile = false;
                db.RebuildDataFile(rebuildDataFile_rebuildAll);
                // force sprite and group names to refresh in case we unflagged one for rebuilding
                groupListBoxContainer.softRefresh = true;
                spriteListBoxContainer.softRefresh = true;
            }

            if(import || importFinished) { // importing now or the import just finished
                if(import) import = false;

                // Import package happens at the end of the frame so we must wait until the next frame to rebuild the data
                // The 1st frame, importFinished = false, 2nd frame, importFinished = true
                ImportStatus status = db.ImportUnityPackage(importer.unitypackagePath, importFinished);
                if(status == ImportStatus.Failed) { // import failed
                    importFinished = false;
                } else if(status == ImportStatus.Started) { // import was started
                    importFinished = true; // the next frame we will rebuild the data
                    importInProcess = true; // flag to make sure import can continue if interrupted by a recompile if a script is imported
                } else if(status == ImportStatus.Completed) { // import complete
                    importFinished = false;
                    importInProcess = false;
                    // force sprite and group names to refresh in case we unflagged one for rebuilding
                    groupListBoxContainer.softRefresh = true;
                    spriteListBoxContainer.softRefresh = true;
                }
            }

            if(export) {
                export = false;
                Export(); // export
            }

            // Editor Properties changes
            if(changeEditorProperties) {
                changeEditorProperties = false;
                ApplyEditorProperties(editorPropertyChangeType); // apply changes

                if((editorPropertyChangeType & editorPropertyChangeType) == EditorPropertyChangeType.Atlases || (editorPropertyChangeType & editorPropertyChangeType) == EditorPropertyChangeType.Materials) {
                    Revert(); // reload or old data may stick around if sprite is selected that is being updated
                    // force sprite and group names to refresh in case we unflagged one for rebuilding
                    groupListBoxContainer.softRefresh = true;
                    spriteListBoxContainer.softRefresh = true;
                }
            }

            // Editor Window Updates

            // Edge tiling setting changed
            if(determineEdgeTiling) {
                determineEdgeTiling = false;
                if(masterSpriteData != null) {
                    if(masterSpriteData.tilingMode == EditorMasterSprite.TilingMode.Auto && !masterSpriteData.finalUseCustomMesh) { // auto mode, need to check the source images first
                        int defaultAnimationIndex = masterSpriteData.defaultAnimationIndex;
                        if(defaultAnimationIndex >= 0 && masterSpriteData.editorAnimations != null && masterSpriteData.editorAnimations.Length > 0) {
                            EditorMasterSprite.Animation anim = masterSpriteData.editorAnimations[defaultAnimationIndex]; // get the default animation
                            if(anim != null) {
                                Texture2D[] textures = anim.GetFrameTextures(); // get frame textures from default animation
                                if(textures != null && textures.Length > 0) {
                                    Utils.AssetTools.FixTextureImporterSettings(textures); // make sure texture importer settings are correct first
                                    masterSpriteData.UpdateEdgeTiling(db.framePadding); // auto-detect edge tiling
                                }
                            }
                        }
                    } else { // not auto mode, just update the edge tiling settings
                        masterSpriteData.UpdateEdgeTiling(db.framePadding);
                    }
                }
                refreshInnerWindow = true; // make the window controls redraw
            }

            // Clear flags
            if(preventRebuildSpriteAssets) preventRebuildSpriteAssets = false;
            if(preventRebuildSpriteGroupAssets) preventRebuildSpriteGroupAssets = false;
            if(busy) busy = false; // allow user input again
        }

        #endregion

        #region Drawing

        private void DrawMainPage() {
            Utils.GUITools.Tooltip.Begin(); // start the tooltip handler

            // override cursors on hover for controls -  prevents cursor controls from showing through windows
            // Side effect: also gets rid of all cursors inside windows
            // this must go before controls are drawn because the first-drawn cursor rect is dominant
            OverrideCursorForInnerWindows(); // this goes outside the scroll view because it always fills the entire window and isn't scrolled around

            // start a scroll view to contain the main page
            mainScrollPos = Utils.GUITools.EditorLayout.BeginScrollView(mainScrollPos);

            DrawLayout(); // draw controls
            DrawInnerWindow(); // draw inner windows after all other controls so they'll render in front

            Utils.GUITools.EditorLayout.EndScrollView();

            Utils.GUITools.Tooltip.End(); // draw the tooltips after everything else
        }

        private void DrawLayout() {
            float col1Width = 275.0f;
            float col2Width = 275.0f;
            float col3Width = 508.0f - style_leftMargin.margin.horizontal;
            float totalWidth = col1Width + col2Width + col3Width;

            float desiredColWidth; // cannot pass the calculated width to Layout controls because it was generated after layout. Cannot use calculated width with other auto layout controls via GUILayout.Width() because it will be 0 in layout!
            float autoLayoutColWidth = 0.0f; // this is filled when Repaint is finished, so it can't be used for passing GUILayout.Width() to any autolayout controls because it will be 0. It can be used for fixed GUI controls though.
            float adjustedColWidth; // column width - padding so our columns have the right amount of usable space

            Rect columnRect;
            GUIStyle curStyle;

            bool origMainPageEnabled = mainPageEnabled; // store state before modifying for busy
            if(busy) mainPageEnabled = false; // disable user input if busy

            GUI.enabled = mainPageEnabled;

            // Main Window Wrapper
            Utils.GUITools.EditorLayout.BeginHorizontal(style_mainPageContainer, GUILayout.Width(totalWidth - style_mainPageContainer.padding.horizontal));

            #region Main Column 1
            desiredColWidth = col1Width;
            curStyle = style_mainColumns;
            adjustedColWidth = desiredColWidth - curStyle.padding.horizontal;
            columnRect = Utils.GUITools.EditorLayout.BeginVertical(curStyle, GUILayout.Width(adjustedColWidth));
            autoLayoutColWidth = columnRect.width - curStyle.padding.horizontal; // adjust to find the cacluated max usable column width

            if(!loaded) ColumnFiller(desiredColWidth);
            DrawEditorProperties();
            DrawSectionSpacer();
            DrawGroupListBox(autoLayoutColWidth, 150.0f);
            DrawSectionSpacer();
            DrawSpriteListBox(autoLayoutColWidth, 160.0f);
            DrawSectionSpacer();
            DrawEditorButtons();
            DrawSectionSpacer(20.0f);
            DrawCommitButtons();

            Utils.GUITools.EditorLayout.EndVertical();
            #endregion End Main Column 1

            #region Main Column 2
            desiredColWidth = col2Width;
            curStyle = style_mainColumns;
            adjustedColWidth = desiredColWidth - curStyle.padding.horizontal;
            columnRect = Utils.GUITools.EditorLayout.BeginVertical(curStyle, GUILayout.Width(adjustedColWidth));
            autoLayoutColWidth = columnRect.width - curStyle.padding.horizontal; // adjust to find the cacluated max usable column width

            if(!loaded) ColumnFiller(desiredColWidth);
            DrawGroupProperties(autoLayoutColWidth, desiredColWidth);
            DrawSpriteProperties(autoLayoutColWidth, desiredColWidth);
            DrawSectionSpacer(14.0f);
            DrawAnimationListBox(autoLayoutColWidth);
            DrawSectionSpacer();
            DrawFrameListBox(autoLayoutColWidth);

            Utils.GUITools.EditorLayout.EndVertical();
            #endregion End Main Column 2

            #region Main Column 3
            desiredColWidth = col3Width;
            curStyle = style_mainColumns;
            adjustedColWidth = desiredColWidth - curStyle.padding.horizontal;
            columnRect = Utils.GUITools.EditorLayout.BeginVertical(curStyle, GUILayout.Width(adjustedColWidth));
            autoLayoutColWidth = columnRect.width - curStyle.padding.horizontal; // adjust to find the cacluated max usable column width

            float leftColWidth = 270.0f;
            float rightColWidth = desiredColWidth - leftColWidth;
            //splitColWidth = desiredColWidth * 0.5f; // Cannot use rect values here because layout hasn't finished determining size

            #region Row 1
            Utils.GUITools.EditorLayout.BeginHorizontal();

            // Col 1
            columnRect = Utils.GUITools.EditorLayout.BeginVertical(style_leftPadFix, GUILayout.Width(leftColWidth)); // leftPadFix = hack to fix inconsistent left padding with auto+fixed controls
            if(masterSpriteData != null && !masterSpriteData.isStaticSprite) {
                DrawAnimationProperties();
                DrawSectionSpacer();
            }
            DrawFrameProperties(leftColWidth - style_leftPadFix.padding.left);
            Utils.GUITools.EditorLayout.EndVertical();

            // Col 2
            Utils.GUITools.EditorLayout.BeginVertical(style_leftMargin, GUILayout.Width(rightColWidth));
            DrawAnimationPreview();
            Utils.GUITools.EditorLayout.EndVertical();

            Utils.GUITools.EditorLayout.EndHorizontal();
            #endregion end Row 1

            DrawSectionSpacer(8.0f);

            #region Row 2
            Utils.GUITools.EditorLayout.BeginHorizontal();

            // Col 1
            Utils.GUITools.EditorLayout.BeginVertical(style_leftPadFix, GUILayout.Width(leftColWidth)); // leftPadFix = hack to fix inconsistent left padding with auto+fixed controls
            DrawColliderFramePopup(leftColWidth);
            Utils.GUITools.EditorLayout.EndVertical();

            // Col 2
            Utils.GUITools.EditorLayout.BeginVertical(style_leftMargin, GUILayout.Width(rightColWidth));
            DrawLocatorFramePopup(rightColWidth);
            Utils.GUITools.EditorLayout.EndVertical();

            Utils.GUITools.EditorLayout.EndHorizontal();
            #endregion end Row 2

            #region Row 3
            Utils.GUITools.EditorLayout.BeginVertical(style_leftPadFix, GUILayout.Width(desiredColWidth)); // leftPadFix = hack to fix inconsistent left padding with auto+fixed controls
            DrawColliderFrameProperties(desiredColWidth);
            DrawLocatorFrameProperties(desiredColWidth);
            Utils.GUITools.EditorLayout.EndVertical();
            #endregion end Row 3

            DrawSectionSpacer(5.0f);

            #region Row 4
            Utils.GUITools.EditorLayout.BeginHorizontal();

            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(desiredColWidth));
            DrawFrameEditorControls(leftColWidth, rightColWidth);
            DrawSectionSpacer(5.0f);
            DrawFrameEditor(desiredColWidth);
            Utils.GUITools.EditorLayout.EndVertical();

            Utils.GUITools.EditorLayout.EndHorizontal();
            #endregion end Row 4

            Utils.GUITools.EditorLayout.EndVertical();
            #endregion End Main Column 3

            Utils.GUITools.EditorLayout.EndHorizontal();
            // end: Main Window Wrapper

            mainPageEnabled = origMainPageEnabled; // restore original gui state
            GUI.enabled = mainPageEnabled;
        }

        private void DrawEditorProperties() {
            if(!loaded) return;

            GUIContent buttonContent = new GUIContent("Editor Properties", "Set properties such as pixels per unit, max atlas size, trim, etc.");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog();
                OpenInnerWindow(2);
            }
        }

        private void DrawGroupListBox(float colWidth, float height) {
            if(!loaded) return;

            Utils.GUITools.Layout.Label(help_spriteGroups);

            int[] objectList = db.GetSavedSpriteGroupIndices();
            SpriteFactory.Utils.ArrayTools.Insert<int>(ref objectList, 0, -1); // insert entry for "None"
            int itemCount = objectList == null ? 0 : objectList.Length;

            // Create list of items to populate list box
            string[] nameList = db.GetSavedSpriteGroupNames(true, true);
            int noGroupSpriteCount = db.GetSavedSpriteCountInGroup(-1);
            SpriteFactory.Utils.ArrayTools.Insert<string>(ref nameList, 0, "None (" + noGroupSpriteCount + ")"); // insert entry for "None"

            // Draw the list box
            DrawListBox(groupListBoxContainer, itemCount, objectList, nameList, "empty", false, colWidth, height);
            UpdateGroupListSelection(); // update our selection vars as list box selection changes
            UpdateEditMode(); // update edit mode immediately when selection changes

            // Draw buttons
            DrawGroupListBoxButtons(groupListBoxContainer, colWidth, "Sprite Group");
        }

        private void DrawGroupListBoxButtons(SimpleGUIListBoxContainer<int> container, float colWidth, string objectName = "item") {
            if(!loaded) return;

            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            GUIContent buttonContent;
            bool isObjectSelected = false;
            if(container.hasSelection && container.selectedObject >= 0) isObjectSelected = true;
            int groupIndex = container.selectedObject;

            GUI.enabled = mainPageEnabled && isObjectSelected && db.ReorderSpriteGroup(groupIndex, -1, false);
            buttonContent = new GUIContent("UP", "Move selected " + objectName + " up");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog(); // offer to save changes before leaving the sprite
                pendingGroupListboxAction.action = ListboxAction.Action.Reorder;
                pendingGroupListboxAction.offset = -1;
                busy = true;
            }

            GUI.enabled = mainPageEnabled && isObjectSelected && db.ReorderSpriteGroup(groupIndex, 1, false);
            buttonContent = new GUIContent("DN", "Move selected " + objectName + " down");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog(); // offer to save changes before leaving the sprite
                pendingGroupListboxAction.action = ListboxAction.Action.Reorder;
                pendingGroupListboxAction.offset = 1;
                busy = true;
            }

            GUILayout.Space(10);

            GUI.enabled = mainPageEnabled;
            buttonContent = new GUIContent("+", "Add new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog(); // offer to save changes before leaving the sprite
                pendingGroupListboxAction.action = ListboxAction.Action.Add;
                busy = true;
            }

            GUI.enabled = mainPageEnabled && isObjectSelected;
            buttonContent = new GUIContent("Ins", "Insert new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog(); // offer to save changes before leaving the sprite
                pendingGroupListboxAction.action = ListboxAction.Action.Insert;
                pendingGroupListboxAction.groupIndex = groupIndex;
                busy = true;
            }

            GUI.enabled = mainPageEnabled && isObjectSelected;
            buttonContent = new GUIContent("Dup", "Duplicate " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog(); // offer to save changes before leaving the sprite
                pendingGroupListboxAction.action = ListboxAction.Action.Duplicate;
                pendingGroupListboxAction.objectIndex = groupIndex;
                busy = true;
            }

            GUILayout.Space(10);

            GUI.enabled = mainPageEnabled && isObjectSelected;
            buttonContent = new GUIContent("DEL", "Delete " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                int groupSpriteCount = db.GetSavedSpriteCountInGroup(db.FindSpriteGroupIdByIndex(groupIndex));
                bool deleteGroup = false;

                if(groupSpriteCount > 0) { // we have some sprites in group

                    if(EditorUtility.DisplayDialog("Delete Sprite Group", "Are you sure you want to delete this Sprite Group? All Master Sprites in this Sprite Group will be deleted. Orphaned sprites in scene or prefabs will be broken.", "Delete Sprite Group", "Cancel")) {
                        // Second warning
                        string s;
                        if(groupSpriteCount > 1) s = "s";
                        else s = "";
                        if(EditorUtility.DisplayDialog("Confirm Deletion", string.Format("FINAL WARNING! {0} Master Sprite{1} in this Sprite Group will be deleted! YOU CANNOT UNDO THIS!", groupSpriteCount, s), "Confirm Deletion", "Cancel")) {
                            deleteGroup = true;
                        }
                    }
                } else { // no sprite in group
                    if(EditorUtility.DisplayDialog("Delete Sprite Group", "Are you sure you want to delete this empty Sprite Group?", "Delete Sprite Group", "Cancel"))
                        deleteGroup = true;
                }

                if(deleteGroup) {
                    pendingGroupListboxAction.action = ListboxAction.Action.Delete;
                    pendingGroupListboxAction.objectIndex = groupIndex;
                    pendingGroupListboxAction.container.ClearSelection(); // clear the selection now instead of when delete is processed to avoid GUI layout/repaint errors
                    ClearCurrentGroupListSelection();
                    busy = true;
                }

            }

            if(!GUI.enabled) GUI.enabled = mainPageEnabled; // re-enable if disabled

            Utils.GUITools.EditorLayout.EndHorizontal();
        }

        private void DrawSpriteListBox(float colWidth, float height) {
            if(!loaded) return;

            if(!groupListBoxContainer.hasSelection) {
                ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            Utils.GUITools.Layout.Label(help_masterSprites);

            int[] objectList = null;
            string[] nameList = null;
            int itemCount = 0;
            int groupIndex = groupListBoxContainer.selectedObject;
            int groupId;

            // Show only the sprites in the selected group or sprites in no group if "None"
            if(groupListBoxContainer.selectedIndex <= 0) { // "None" is selected, show all sprites that are not in a group
                groupId = -1; // no group id
            } else { // A group is selected, show all sprites in this group
                groupId = db.FindSpriteGroupIdByIndex(groupIndex); // get group id of selected
            }

            int[] spriteIndices;
            string[] spriteNames;
            if(db.GetSavedSpriteListsInGroup(groupId, out spriteIndices, out spriteNames, true)) { // sprites found
                objectList = spriteIndices;
                nameList = spriteNames;
                itemCount = objectList.Length;
            }

            string emptyMsg = "There are no Master Sprites to display."; // message to display if list box is empty

            // Draw the list box
            DrawListBox(spriteListBoxContainer, itemCount, objectList, nameList, emptyMsg, true, colWidth, height);
            UpdateSpriteListSelection(); // update our selection vars as list box selection changes
            UpdateEditMode(); // update edit mode immediately when selection changes

            // Draw buttons
            DrawSpriteListBoxButtons(spriteListBoxContainer, colWidth, "Master Sprite");
        }

        private void DrawSpriteListBoxButtons(SimpleGUIListBoxContainer<int> container, float colWidth, string objectName = "item") {
            if(!loaded) return;

            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            GUIContent buttonContent;
            bool isObjectSelected = container.hasSelection;
            int spriteIndex = container.selectedObject;
            int listIndex = container.selectedIndex;
            int groupId = -1;
            if(groupListBoxContainer.selectedIndex > 0) { // a real group is selected
                groupId = db.FindSpriteGroupIdByIndex(groupListBoxContainer.selectedObject);
            }

            GUI.enabled = mainPageEnabled && isObjectSelected && db.ReorderMasterSpriteInGroup(groupId, listIndex, -1, false);
            buttonContent = new GUIContent("UP", "Move selected " + objectName + " up");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog(); // offer to save changes before leaving the sprite
                pendingSpriteListboxAction.action = ListboxAction.Action.Reorder;
                pendingSpriteListboxAction.offset = -1;
                busy = true;
            }

            GUI.enabled = mainPageEnabled && isObjectSelected && db.ReorderMasterSpriteInGroup(groupId, listIndex, 1, false);
            buttonContent = new GUIContent("DN", "Move selected " + objectName + " down");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog(); // offer to save changes before leaving the sprite
                pendingSpriteListboxAction.action = ListboxAction.Action.Reorder;
                pendingSpriteListboxAction.offset = 1;
                busy = true;
            }

            GUILayout.Space(10);

            GUI.enabled = mainPageEnabled;
            buttonContent = new GUIContent("+", "Add new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog(); // offer to save changes before leaving the sprite
                pendingSpriteListboxAction.action = ListboxAction.Action.Add;
                pendingSpriteListboxAction.groupId = groupId;
                busy = true;
            }

            GUI.enabled = mainPageEnabled && isObjectSelected;
            buttonContent = new GUIContent("Ins", "Insert new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog(); // offer to save changes before leaving the sprite
                pendingSpriteListboxAction.action = ListboxAction.Action.Insert;
                pendingSpriteListboxAction.objectIndex = spriteIndex;
                pendingSpriteListboxAction.groupId = groupId;
                pendingSpriteListboxAction.listIndex = listIndex;
                busy = true;
            }

            GUI.enabled = mainPageEnabled && isObjectSelected && masterSpriteData != null; // don't allow duplicating broken master sprites
            buttonContent = new GUIContent("Dup", "Duplicate " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog(); // offer to save changes before leaving the sprite
                pendingSpriteListboxAction.action = ListboxAction.Action.Duplicate;
                pendingSpriteListboxAction.objectIndex = spriteIndex;
                pendingSpriteListboxAction.listIndex = listIndex;
                busy = true;
            }

            GUILayout.Space(10);

            GUI.enabled = mainPageEnabled && isObjectSelected;
            buttonContent = new GUIContent("DEL", "Delete " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(EditorUtility.DisplayDialog("Delete Master Sprite", "Are you sure you want to delete this Master Sprite? All atlases in sprites based on this Master Sprite will no longer exist. Orphaned sprites in scene or prefabs will be broken.", "Delete Master Sprite", "Cancel")) {
                    pendingSpriteListboxAction.action = ListboxAction.Action.Delete;
                    pendingSpriteListboxAction.objectIndex = spriteIndex;
                    ShowRebuildGroupAtlasesDialog(); // give user option to not rebuild the atlases in the group on delete
                    ClearCurrentSpriteListSelection(); // clear sprite selection now before we actually delete it
                    busy = true;
                }
            }

            if(!GUI.enabled) GUI.enabled = mainPageEnabled; // re-enable if disabled

            Utils.GUITools.EditorLayout.EndHorizontal();

        }

        private void DrawEditorButtons() {
            if(!loaded) return;

            // SPRITE UTILITIES
            Utils.GUITools.Layout.Label("Create / Assign Sprites:");

            bool spriteSelectedInList = masterSpriteData != null ? true : false;

            GUI.enabled = mainPageEnabled && spriteSelectedInList;
            if(Utils.GUITools.Layout.Button("Create Sprite in Scene")) {
                ShowSaveChangesDialog();
                createSpriteInScene = true;
                busy = true;
            }

            if(!spriteSelectedInList || selectedGameObject == null) GUI.enabled = false; // make sure we have something to assign sprite to
            if(Utils.GUITools.Layout.Button("Assign Sprite to Selected Object")) {
                ShowSaveChangesDialog();
                assignMasterSpriteToSprite = true;
                busy = true;
            }

            if(!GUI.enabled) GUI.enabled = mainPageEnabled; // re-enable if disabled

            DrawSectionSpacer(20.0f);
            Utils.GUITools.Layout.Label("Utilities:");

            GUI.enabled = mainPageEnabled && (masterSpriteData != null || selectedGroup != null) && !unsavedChanges;

            string objectName = "";
            if(editMode == EditMode.Sprite) objectName = " Master Sprite";
            else if(editMode == EditMode.SpriteGroup) objectName = " Sprite Group";

            if(Utils.GUITools.Layout.Button(new GUIContent("Rebuild Selected" + objectName, "Rebuild all generated assets for the selected" + objectName + "."))) {
                if(EditorUtility.DisplayDialog("Rebuild Selected" + objectName, "This will rebuild all generated assets for the selected" + objectName + ".", "Rebuild", "Cancel")) {
                    remakeAtlases = true;
                    remakeMaterials = true;
                    SaveChangesDeferred(true);
                }
            }

            bool isDataSaved = db.IsDataSaved();

            GUI.enabled = mainPageEnabled && isDataSaved;
            if(Utils.GUITools.Layout.Button("Check if Atlases Need Updating")) {
                ShowSaveChangesDialog();
                checkIfAtlasesNeedUpdating = true;
                busy = true;
            }

            GUI.enabled = mainPageEnabled;
            if(Utils.GUITools.Layout.Button("More Utilities")) {
                ShowSaveChangesDialog();
                OpenInnerWindow(8); // open window
            }

            DrawSectionSpacer();

            GUI.enabled = mainPageEnabled;
            if(Utils.GUITools.Layout.Button("Documentation")) {
                Application.OpenURL("http://www.guavaman.com/projects/spritefactory/docs");
            }

            if(!GUI.enabled) GUI.enabled = mainPageEnabled; // re-enable if disabled
        }

        private void DrawSpriteProperties(float colWidth, float desiredColWidth) {
            if(!loaded) return;
            if(editMode != EditMode.Sprite) return;
            EditorMasterSprite.Data spriteData = masterSpriteData;
            if(spriteData == null) {
                ColumnFiller(desiredColWidth); // force column to not collapse
                return;
            }

            Utils.GUITools.Layout.Label("Sprite Properties");

            float labelWidth = colWidth * 0.54f;
            float fieldWidth = colWidth - labelWidth;
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, fieldWidth);

            // Name
            string name = spriteData.name;
            if(spriteProperties_name.Draw(ref name)) {
                name = SpriteFactory.Utils.StringTools.CleanUpName(name); // sanitize the sprite name
                if(name != spriteData.name) spriteData.name = name; // update name in the sprite data
                unsavedChanges = true;
                refreshSpriteListOnSave = true;
            }

            // Is Static Sprite
            bool isStatic = spriteData.isStaticSprite;
            if(spriteProperties_staticSprite.Draw(ref isStatic)) {
                if(spriteProperties_staticSprite.value) { // changing to static
                    if(spriteData.editorAnimations != null && spriteData.editorAnimations.Length > 0) { // sprite has animations
                        if(EditorUtility.DisplayDialog("Change to Static Sprite", "All animations will be lost! Are you sure? (Revert to undo this.)", "Make Static", "Cancel")) {
                            spriteData.ConvertToStaticSprite();
                            unsavedChanges = true;
                            remakeAtlases = true;
                            spriteListBoxContainer.refresh = true; // refresh everything below sprite
                            SetStaticSpriteMode(true);
                        }
                    } else { // no animations, do not warn
                        spriteData.ConvertToStaticSprite();
                        unsavedChanges = true;
                        remakeAtlases = true;
                        spriteListBoxContainer.refresh = true; // refresh everything below sprite
                        SetStaticSpriteMode(true);
                    }

                } else { // changing to animated
                    if(EditorUtility.DisplayDialog("Change to Animated Sprite", "Are you sure you want to change this static sprite to an animated sprite? (Revert to undo this.)", "Make Animated", "Cancel")) {
                        spriteData.ConvertToAnimatedSprite();
                        unsavedChanges = true;
                        remakeAtlases = true;
                        spriteListBoxContainer.refresh = true; // refresh everything below sprite
                        SetStaticSpriteMode(false);
                    }
                }
            }

            // Sprite Group
            if(masterSpriteSelectionChanged) { // rebuild name list every time master sprite selection changes
                string[] groups = db.GetSavedSpriteGroupNames();
                SpriteFactory.Utils.ArrayTools.Insert<string>(ref groups, 0, "None");
                spriteProperties_spriteGroup.SetOptions(groups); // update the list
            }

            int spriteGroupIndexSelection = db.FindSpriteGroupIndexById(spriteData.spriteGroupId) + 1; // offset for "None"
            if(spriteProperties_spriteGroup.Draw(spriteGroupIndexSelection)) {
                int newGroupIndex = spriteProperties_spriteGroup.selectionIndex - 1;
                if(newGroupIndex == -1) spriteData.spriteGroupId = -1;
                else spriteData.spriteGroupId = db.FindSpriteGroupIdByIndex(newGroupIndex); // offset for "None"
                unsavedChanges = true;
                remakeAtlases = true;
                refreshGroupListOnSave = true;
            }

            Utils.GUITools.Engine.SwitchToAutoWidth(); // revert

            GUILayout.Space(10.0f);

            GUIContent buttonContent;
            EditorGUIUtility.LookLikeControls(labelWidth, fieldWidth); // use real unity looklikecontrols here because fixed label + button doesn't distribute space right

            // More Settings window
            buttonContent = new GUIContent("Edit", "More settings for this sprite");
            Utils.GUITools.EditorLayout.BeginHorizontal();
            Utils.GUITools.EditorLayout.Label("More Settings:");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                OpenInnerWindow(3);
            }
            Utils.GUITools.EditorLayout.EndHorizontal();

            if(masterSpriteData.spriteGroupId == -1) { // sprite is not in a group, render the buttons. If in a group, these are handled in group properties

                // Material Sets Editor
                buttonContent = new GUIContent("Edit", "Edit materials sets for this sprite");
                Utils.GUITools.EditorLayout.BeginHorizontal();
                Utils.GUITools.EditorLayout.Label("Material Sets:");
                if(Utils.GUITools.Layout.Button(buttonContent)) {
                    OpenInnerWindow(0); // open Material Set Editor window
                }
                Utils.GUITools.EditorLayout.EndHorizontal();
            }

            // Collider Editor
            buttonContent = new GUIContent("Edit", "Edit colliders for this sprite");
            Utils.GUITools.EditorLayout.BeginHorizontal();
            Utils.GUITools.EditorLayout.Label("Colliders:");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                OpenInnerWindow(1); // open Collider Editor window
            }
            Utils.GUITools.EditorLayout.EndHorizontal();

            // Locator Editor
            buttonContent = new GUIContent("Edit", "Edit locators for this sprite");
            Utils.GUITools.EditorLayout.BeginHorizontal();
            Utils.GUITools.EditorLayout.Label("Locators:");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                OpenInnerWindow(5); // open Locator Editor window
            }
            Utils.GUITools.EditorLayout.EndHorizontal();

            EditorGUIUtility.LookLikeControls();

            GUILayout.Space(10.0f);

            if(!spriteData.isStaticSprite) {

                Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, fieldWidth); // revert

                // Default Wrap Mode
                if(spriteProperties_defaultWrapMode.DrawByValue((int)spriteData.defaultWrapMode)) {
                    spriteData.defaultWrapMode = (Sprite.WrapMode)spriteProperties_defaultWrapMode.selectionValue;
                    unsavedChanges = true;
                }

                // Default Frame Rate
                if(spriteProperties_defaultFrameRate.Draw(ref spriteData.defaultFrameRate))
                    unsavedChanges = true;

                Utils.GUITools.Engine.SwitchToAutoWidth(); // revert
            }
        }

        private void DrawGroupProperties(float colWidth, float desiredColWidth) {
            if(!loaded) return;
            if(editMode != EditMode.SpriteGroup) return;
            if(selectedGroup == null) {
                ColumnFiller(desiredColWidth); // force column to not collapse
                return;
            }

            GUIContent buttonContent;
            EditorMasterSprite.SpriteGroup spriteGroup = selectedGroup;

            Utils.GUITools.Layout.Label("Sprite Group Properties");

            float labelWidth = colWidth * 0.54f;
            float fieldWidth = colWidth - labelWidth;
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, fieldWidth);

            // Name
            string name = spriteGroup.name;
            if(groupProperties_name.Draw(ref name)) {
                name = SpriteFactory.Utils.StringTools.CleanUpName(name); // sanitize the sprite name
                if(name != spriteGroup.name) spriteGroup.name = name; // update name in the sprite group data
                unsavedChanges = true;
                refreshGroupListOnSave = true;
            }

            // Texture Filter Mode
            int filterMode = spriteGroup.atlasTextureFilterMode;
            if(groupProperties_filterMode.DrawByValue(filterMode)) {
                spriteGroup.atlasTextureFilterMode = groupProperties_filterMode.selectionValue; // update data
                unsavedChanges = true;
                remakeAtlases = true;
            }

            // Aniso Level
            if(filterMode == -1) { // set to default mode
                if(db.defaultFilterMode != FilterMode.Bilinear && db.defaultFilterMode != FilterMode.Trilinear) // default mode is one that has aniso
                    GUI.enabled = false;
            } else { // not default mode
                if(filterMode != (int)FilterMode.Bilinear && filterMode != (int)FilterMode.Trilinear)
                    GUI.enabled = false;
            }
            int anisoLevel = spriteGroup.atlasTextureAnisoLevel;
            if(groupProperties_anisoLevel.DrawByValue(anisoLevel)) {
                spriteGroup.atlasTextureAnisoLevel = groupProperties_anisoLevel.selectionValue; // update the data
                unsavedChanges = true;
                remakeAtlases = true;
            }
            if(!GUI.enabled) GUI.enabled = mainPageEnabled;

            Utils.GUITools.Engine.SwitchToAutoWidth();

            EditorGUIUtility.LookLikeControls(labelWidth, fieldWidth); // use real unity looklikecontrols here because fixed label + button doesn't distribute space right

            // Material Sets Editor
            buttonContent = new GUIContent("Edit", "Edit materials sets for this sprite group");
            Utils.GUITools.EditorLayout.BeginHorizontal();
            Utils.GUITools.EditorLayout.Label("Material Sets:");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                OpenInnerWindow(0); // open Material Set Editor window
            }
            Utils.GUITools.EditorLayout.EndHorizontal();

            EditorGUIUtility.LookLikeControls();
        }

        private void DrawCommitButtons() {
            if(!loaded) return;

            string objectName = "";
            if(editMode == EditMode.Sprite) objectName = "Master Sprite";
            else if(editMode == EditMode.SpriteGroup) objectName = "Sprite Group";

            Utils.GUITools.Layout.Label("Save / Revert:");

            GUI.enabled = mainPageEnabled && unsavedChanges;
            string saveButtonText = "Save " + objectName;
            if(unsavedChanges) saveButtonText += "*";
            if(Utils.GUITools.Layout.Button(saveButtonText)) {
                saveButtonPressed = true;
                SaveChangesDeferred();
            }

            if(unsavedChanges) {
                GUILayout.Space(10.0f);
                //GUISkin editorSkin = EditorGUIUtility.GetBuiltinSkin(EditorSkin.Inspector); // Cannot use... Bugged in Unity 4.3
                GUISkin editorSkin = GUI.skin; // just use current skin instead
                GUIStyle style = new GUIStyle(editorSkin.box);
                if(EditorGUIUtility.isProSkin)
                    style.normal.textColor = mainSkin.FindStyle("DropZone").normal.textColor;
                else
                    style.normal.textColor = mainSkin.FindStyle("DropZone").onNormal.textColor;

                //Utils.GUITools.EditorLayout.Label("You have unsaved changes! Your changes will be lost if you select another sprite or close this window!", style);
                // CANNOT use an Editor Layout here because it changes controlIds in the middle of typing when this label is generated! BUG
                Utils.GUITools.Layout.Label("You have unsaved changes! Your changes will be lost if you select another sprite or close this window!", style);
            }

            GUILayout.Space(15.0f);

            GUI.enabled = mainPageEnabled && unsavedChanges;
            if(Utils.GUITools.Layout.Button("Revert")) {
                if(EditorUtility.DisplayDialog("Revert " + objectName, "Are you sure? You will lose any changes you have made to the " + objectName + ".", "Revert", "Cancel"))
                    Revert();
            }

            if(!GUI.enabled) GUI.enabled = mainPageEnabled; // re-enable if disabled

            // Trial version buy button
#if TRIALVERSION

                DrawSectionSpacer(20.0f);
                
                Utils.GUITools.Layout.Label("* This is a trial version of Sprite Factory.");
                DrawSectionSpacer(5.0f);
                if(Utils.GUITools.Layout.Button("Buy Full Version Now!")) {
                    Application.OpenURL("http://www.guavaman.com/projects/spritefactory");
                }

#endif

            if(!GUI.enabled) GUI.enabled = mainPageEnabled; // re-enable if disabled
        }

        private void DrawAnimationListBox(float colWidth) {
            if(!loaded) return;

            if(masterSpriteData == null) {
                ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            float height;
            if(masterSpriteData.isStaticSprite) height = listBoxLineHeight; // smaller box for static sprites (height is static, auto-calculated height doesn't seem to be right... height = listBoxStyle.CalcSize(new GUIContent("fdsa"), 10.0f);
            else height = 160.0f; // bigger box for animated sprites

            Utils.GUITools.Layout.Label("Animations");

            EditorMasterSprite.Animation[] objectList = masterSpriteData.editorAnimations; // get animations from sprite as object
            int itemCount = objectList == null ? 0 : objectList.Length;

            // Create list of items to populate list box
            string[] nameList = null;
            if(itemCount > 0) {
                if(animationListBoxContainer.refresh) {
                    nameList = new string[itemCount];
                    for(int i = 0; i < itemCount; i++) {
                        nameList[i] = masterSpriteData.editorAnimations[i].name;
                        if(masterSpriteData.defaultAnimationIndex == i)
                            nameList[i] = "(D) " + nameList[i];
                    }
                }
            }

            string emptyMsg = "Please add an animation."; // message to display if list box is empty

            // Draw the list box
            DrawListBox(animationListBoxContainer, itemCount, objectList, nameList, emptyMsg, true, colWidth, height, reloadLastSelection, lastSelectedAnimationIndex);

            // Draw buttons
            if(!masterSpriteData.isStaticSprite) {
                DrawAnimationListBoxButtons(animationListBoxContainer, colWidth, "Animation");
            }

            if(animationListBoxContainer.refresh) refreshLightBoxAnimationsList = true; // force lightbox animation list to update any time the animation list box updates, but keep the update active until lightbox is displayed
        }

        private void DrawAnimationListBoxButtons(SimpleGUIListBoxContainer<EditorMasterSprite.Animation> container, float colWidth, string objectName = "item") {
            if(!loaded) return;

            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            EditorMasterSprite.Animation anim = container.selectedObject;
            bool changed = false;
            bool isObjectSelected = false;

            if(anim != null) { // an object is selected
                isObjectSelected = true;
            }

            GUIContent buttonContent;

            GUI.enabled = mainPageEnabled && isObjectSelected && masterSpriteData.ReorderAnimation(anim, -1, false);
            buttonContent = new GUIContent("UP", "Move selected " + objectName + " up");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(masterSpriteData.ReorderAnimation(anim, -1, true)) {
                    container.selectedIndex -= 1;
                    changed = true;
                    unsavedChanges = true;
                }
            }

            GUI.enabled = mainPageEnabled && isObjectSelected && masterSpriteData.ReorderAnimation(anim, 1, false);
            buttonContent = new GUIContent("DN", "Move selected " + objectName + " down");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(masterSpriteData.ReorderAnimation(anim, 1)) {
                    container.selectedIndex += 1;
                    changed = true;
                    unsavedChanges = true;
                }
            }

            GUILayout.Space(10);

            GUI.enabled = mainPageEnabled;
            buttonContent = new GUIContent("+", "Add new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.AddNewAnimation();
                changed = true;
                unsavedChanges = true;
            }

            GUI.enabled = mainPageEnabled && isObjectSelected;
            buttonContent = new GUIContent("Ins", "Insert new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                int newIndex = masterSpriteData.InsertNewAnimationBeforeSelected(anim);
                container.ChangeSelection(newIndex, true); // select the new animation index immediately
                changed = true;
                unsavedChanges = true;
            }

            GUI.enabled = mainPageEnabled && isObjectSelected;
            buttonContent = new GUIContent("Dup", "Duplicate " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.DuplicateAnimation(anim);
                changed = true;
                unsavedChanges = true;
            }

            GUILayout.Space(20);

            GUI.enabled = mainPageEnabled && isObjectSelected;
            buttonContent = new GUIContent("DEL", "Delete " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(EditorUtility.DisplayDialog("Delete " + objectName, "Are you sure you want to delete this " + objectName + "?", "Delete " + objectName, "Cancel")) {
                    masterSpriteData.RemoveAnimation(anim);
                    changed = true;
                    unsavedChanges = true;
                    remakeAtlases = true;
                    container.DeleteSelected(); // // clear the entry from the container
                }
            }

            Utils.GUITools.EditorLayout.EndHorizontal();

            GUI.enabled = mainPageEnabled && isObjectSelected;
            buttonContent = new GUIContent("Set to Default", "Set selected " + objectName + " to default");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.SetToDefaultAnimation(anim);
                changed = true;
                unsavedChanges = true;
                remakeAtlases = true;
            }

            if(changed) {
                container.refresh = true; // flag refresh of list info
            }

            if(!GUI.enabled) GUI.enabled = mainPageEnabled; // re-enable if disabled
        }

        private void DrawFrameListBox(float colWidth) {
            if(!loaded) return;
            if(animationListBoxContainer.selectedObject == null) return;

            bool changed = false;
            float height;
            if(masterSpriteData.isStaticSprite) height = listBoxLineHeight; // smaller box for static sprites (height is static, auto-calculated height doesn't seem to be right... height = listBoxStyle.CalcSize(new GUIContent("fdsa"), 10.0f);
            else height = 160.0f; // smaller boxes for static sprites

            SimpleGUIListBoxContainer<EditorMasterSprite.Frame> container = frameListBoxContainer;
            EditorMasterSprite.Animation animation = animationListBoxContainer.selectedObject;
            int animationIndex = animationListBoxContainer.selectedIndex;

            Utils.GUITools.Layout.Label("Frames");

            // Dropzone for adding frame texture files
            if(!masterSpriteData.isStaticSprite ||
                (masterSpriteData.isStaticSprite && (animation.editorFrames == null || animation.editorFrames.Length == 0))) { // show the dropzone if animated sprite, or if a static sprite and no frames exist yet
                int dropBoxY = 20;
                object[] objs = Utils.GUITools.DropZone("Drag & drop texture files to add frames", dropBoxY, (int)height, mainSkin);
                List<Texture2D> dropTextures = null;
                bool found = false;
                // Filter dropped items for Texture2D only
                if(objs != null) {
                    dropTextures = new List<Texture2D>();
                    for(int i = 0; i < objs.Length; i++) {
                        System.Type type = objs[i].GetType();
                        if(type == typeof(Texture2D)) {
                            dropTextures.Add((Texture2D)objs[i]); // add texture to list
                            found = true;
                            if(masterSpriteData.isStaticSprite) break; // only keep the first one added if static
                        }
                    }
                }
                if(found) { // found some textures
                    // Note: FixTextureSettings has a call to AssetDatabase.ImportAsset() which has been known to cause OnGUI to drop out after a dialog window. There is no dialog window
                    // here but if problems arise, this may have to be moved into a deferred process like save as well.
                    Utils.AssetTools.FixTextureImporterSettings(dropTextures.ToArray()); // make sure texture settings are okay

                    // Sort textures alphabetically
                    dropTextures.Sort((x, y) => string.Compare(x.name, y.name));

                    // Create new frames with textures in MasterSprite.MasterSpriteAnimation
                    for(int i = 0; i < dropTextures.Count; i++) {
                        Texture2D tex = dropTextures[i];
                        if(!db.CheckTextureSize(tex)) continue; // texture is too big for atlas size, skip it and warn user
                        ulong timestamp = TextureImporter.GetAtPath(AssetDatabase.GetAssetPath(tex)).assetTimeStamp;
                        masterSpriteData.AddNewFrame(animationIndex, tex, timestamp);
                    }

                    container.changed = true; // data in control changed
                    changed = true;
                    unsavedChanges = true;
                    remakeAtlases = true;
                }
            }

            EditorMasterSprite.Frame[] objectList = animation.editorFrames; // get animations from sprite as object
            int itemCount = objectList == null ? 0 : objectList.Length;

            // Create list of items to populate list box
            string[] nameList = null;
            if(itemCount > 0) {
                if(container.refresh) {
                    nameList = new string[objectList.Length];
                    for(int i = 0; i < objectList.Length; i++) {
                        Texture2D texture = objectList[i].GetTexture();
                        if(texture == null) // texture is missing!
                            nameList[i] = "[SOURCE IMAGE MISSING]";
                        else nameList[i] = texture.name;
                    }
                }
            }

            string emptyMsg = "No frames to display."; // message to display if list box is empty

            // Draw the list box
            DrawListBox(container, itemCount, objectList, nameList, emptyMsg, true, colWidth, height, reloadLastSelection, lastSelectedFrameIndex);

            // Draw buttons
            DrawFrameListBoxButtons(container, colWidth, "Frame");

            EditorMasterSprite.Frame frame = frameListBoxContainer.selectedObject;
            if(frame == null) {
                return;
            }

            DrawSectionSpacer(10.0f);

            // Source Image
            if(openWindowId < 0) { // only draw if no windows are open - this is to get around a bug that lets you click through a window and hit this control even if GUI.enabled = false
                Object textureObj = frame.GetTexture();
                if(frameProperties_sourceImage.Draw(ref textureObj)) {
                    Texture2D tex = (Texture2D)textureObj;
                    if(tex != null) {
                        if(db.CheckTextureSize(tex)) {
                            // Note: FixTextureSettings has a call to AssetDatabase.ImportAsset() which has been known to cause OnGUI to drop out after a dialog window. There is no dialog window
                            // here but if problems arise, this may have to be moved into a deferred process like save as well.
                            Utils.AssetTools.FixTextureImporterSettings(new Texture2D[] { tex }); // make sure texture settings are correct
                            frame.SetTexture(tex); // store in frame
                        }
                    } else
                        frame.SetTexture(null); // null it
                    changed = true;
                    unsavedChanges = true;
                    remakeAtlases = true;
                }
            }

            if(changed) {
                // flag changed again if adding frames via dropzone because the changed is processed immediately and nothing that depends on seeing this change can see it
                // Also do it for changes to source image so we update the lightbox frame list
                container.changed = true;
            }
        }

        private void DrawFrameListBoxButtons(SimpleGUIListBoxContainer<EditorMasterSprite.Frame> container, float colWidth, string objectName = "item") {
            if(!loaded) return;

            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            EditorMasterSprite.Animation selAnimation = animationListBoxContainer.selectedObject;
            if(selAnimation == null) {
                ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            int animationIndex = animationListBoxContainer.selectedIndex;
            EditorMasterSprite.Frame frame = container.selectedObject;
            int frameIndex = container.selectedIndex;
            bool changed = false;
            bool isObjectSelected = false;

            if(frame != null) { // an object is selected
                isObjectSelected = true;
            }

            GUIContent buttonContent;

            if(!masterSpriteData.isStaticSprite) {
                GUI.enabled = mainPageEnabled && isObjectSelected && masterSpriteData.ReorderFrame(animationIndex, frameIndex, -1, false);
                buttonContent = new GUIContent("UP", "Move selected " + objectName + " up");
                if(Utils.GUITools.Layout.Button(buttonContent)) {
                    if(masterSpriteData.ReorderFrame(animationIndex, frameIndex, -1, true)) {
                        container.selectedIndex -= 1;
                        changed = true;
                        unsavedChanges = true;
                    }
                }

                GUI.enabled = mainPageEnabled && isObjectSelected && masterSpriteData.ReorderFrame(animationIndex, frameIndex, 1, false);
                buttonContent = new GUIContent("DN", "Move selected " + objectName + " down");
                if(Utils.GUITools.Layout.Button(buttonContent)) {
                    if(masterSpriteData.ReorderFrame(animationIndex, frameIndex, 1, true)) {
                        container.selectedIndex += 1;
                        changed = true;
                        unsavedChanges = true;
                    }
                }

                GUILayout.Space(10);
            }

            if(!masterSpriteData.isStaticSprite) GUI.enabled = mainPageEnabled;
            else { // static sprite
                EditorMasterSprite.Frame[] objectList = animationListBoxContainer.selectedObject.editorFrames; // get animations from sprite as object
                int itemCount = objectList == null ? 0 : objectList.Length;
                GUI.enabled = mainPageEnabled && itemCount == 0; // only allow adding new frame we have none
            }

            buttonContent = new GUIContent("+", "Add new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.AddNewFrame(animationIndex);
                changed = true;
                unsavedChanges = true;
            }

            if(!masterSpriteData.isStaticSprite) {
                GUI.enabled = mainPageEnabled && isObjectSelected;
                buttonContent = new GUIContent("Ins", "Insert new " + objectName);
                if(Utils.GUITools.Layout.Button(buttonContent)) {
                    masterSpriteData.InsertNewFrameBeforeSelected(animationIndex, frameIndex);
                    container.ChangeSelection(frameIndex, true); // select the new animation index immediately
                    changed = true;
                    unsavedChanges = true;
                }

                GUI.enabled = mainPageEnabled && isObjectSelected;
                buttonContent = new GUIContent("Dup", "Duplicate " + objectName);
                if(Utils.GUITools.Layout.Button(buttonContent)) {
                    masterSpriteData.DuplicateFrame(animationIndex, frameIndex);
                    changed = true;
                    unsavedChanges = true;
                }
            }

            GUILayout.Space(10);

            GUI.enabled = mainPageEnabled && isObjectSelected;
            string buttonText;
            if(!masterSpriteData.isStaticSprite) buttonText = "DEL";
            else buttonText = "Delete " + objectName;
            buttonContent = new GUIContent(buttonText, "Delete " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(EditorUtility.DisplayDialog("Delete " + objectName, "Are you sure you want to delete this " + objectName + "?", "Delete " + objectName, "Cancel")) {
                    masterSpriteData.RemoveFrame(animationIndex, frameIndex);
                    changed = true;
                    unsavedChanges = true;
                    remakeAtlases = true;
                    container.DeleteSelected(); // // clear the entry from the container
                }
            }

            Utils.GUITools.EditorLayout.EndHorizontal();

            if(!masterSpriteData.isStaticSprite) {
                GUI.enabled = mainPageEnabled;
                buttonContent = new GUIContent("Reverse Frame Order", "Reverse order of all frames in this Animation.");
                if(Utils.GUITools.Layout.Button(buttonContent)) {
                    if(masterSpriteData.ReverseFrames(animationIndex)) {
                        container.selectedIndex = 0;
                        changed = true;
                        unsavedChanges = true;
                    }
                }

                GUILayout.Space(10);
            }


            if(changed) {
                container.changed = true; // flag data changed in control
            }

            if(!GUI.enabled) GUI.enabled = mainPageEnabled; // re-enable if disabled
        }

        private void DrawAnimationProperties() {
            if(!loaded) return;
            EditorMasterSprite.Animation animation = animationListBoxContainer.selectedObject;
            if(animation == null) return;
            if(masterSpriteData.isStaticSprite) return;

            Utils.GUITools.Layout.Label("Animation Properties");

            // Name
            string name = animation.name;
            if(animationProperties_name.Draw(ref name)) {
                masterSpriteData.ChangeAnimationName(animation, name);
                unsavedChanges = true;
            }

            // Wrap Mode
            if(animationProperties_wrapMode.DrawByValue((int)animation.wrapMode)) {
                animation.wrapMode = (Sprite.WrapMode)animationProperties_wrapMode.selectionValue;
                unsavedChanges = true;
            }

            // Loop options
            if(animation.wrapMode != Sprite.WrapMode.Loop && animation.wrapMode != Sprite.WrapMode.PingPong) GUI.enabled = false; // disable control of not on a wrap mode that needs loop count

            // Loop count
            if(animationProperties_loopCount.Draw(ref animation.loopCount)) {
                unsavedChanges = true;
            }

            // Loop restart frame
            int loopRestartFrame = animation.loopRestartFrame;
            if(loopRestartFrame < 0 || (animation.editorFrameCount > 0 && loopRestartFrame >= animation.editorFrameCount)) { // validate loop restart frame
                animation.loopRestartFrame = animation.editorFrameCount - 1;
                loopRestartFrame = animation.loopRestartFrame;
            }
            if(animationProperties_loopRestartFrame.Draw(ref loopRestartFrame)) {
                animation.loopRestartFrame = loopRestartFrame;
                unsavedChanges = true;
            }
            GUI.enabled = mainPageEnabled; // reenable controls

            // Frame Rate  (property, can't use ref on it)
            int newFrameRate;
            if(animationProperties_fps.Draw(animation.frameRate, out newFrameRate)) { // value changed
                animation.frameRate = newFrameRate; // update in object
                unsavedChanges = true;
            }
        }

        private void DrawAnimationPreview() {
            if(animationListBoxContainer.selectedObject == null) return;
            if(masterSpriteData.isStaticSprite) return;

            float size = 224.0f;

            DrawSectionSpacer();
            animationPreview.Draw(animationListBoxContainer.selectedObject, 1.0f, new Rect(0, 0, size, size), masterSpriteData.GetTotalBounds());
        }

        private void DrawFrameProperties(float colWidth) {
            if(!loaded) return;

            bool guiEnabled = GUI.enabled;
            bool colliderSelected = colliderFrameProperties_editCollider.selectionIndex > 0;
            bool locatorSelected = locatorFrameProperties_editLocator.selectionIndex > 0;

            EditorMasterSprite.Frame frame = frameListBoxContainer.selectedObject;
            if(frame == null) return;

            Utils.GUITools.Layout.Label("Frame Properties");

            if(!masterSpriteData.isStaticSprite) {
                // Duration - read-only
                float duration = frame.duration;
                frameProperties_duration.Draw(duration, out duration, true);

                // Frame Hold (property, can't use ref on it)
                int newFrameHold;
                if(frameProperties_frameHold.Draw(frame.frameHold, out newFrameHold)) { // value changed
                    frame.frameHold = newFrameHold;
                    unsavedChanges = true;
                }
            }

            if(colliderSelected || locatorSelected) {
                frameProperties_offsetAllFrames.value = false;
                frameProperties_offsetColliders.value = false;
                frameProperties_offsetStaticColliders.value = false;
                frameProperties_offsetLocators.value = false;
                GUI.enabled = false;
            }

            // Offset check boxes row
            float toggleWidth = EditorStyles.toggle.normal.background.width;
            float tinyLabelWidth = 18.0f;
            if(masterSpriteData.isStaticSprite) tinyLabelWidth = 60.0f;
            Utils.GUITools.EditorLayout.BeginHorizontal();

            // Offset All Frames
            Utils.GUITools.Engine.SwitchToFixedWidth(110.0f, toggleWidth);
            bool offsetAllFrames;
            if(!masterSpriteData.isStaticSprite) {
                offsetAllFrames = frameProperties_offsetAllFrames.value;
                bool origOffsetAllFrames = offsetAllFrames;
                frameProperties_offsetAllFrames.Draw(ref offsetAllFrames, 122.0f);
                if(origOffsetAllFrames && !offsetAllFrames) { // just toggled off
                    frameProperties_offsetAllX.Clear();
                    frameProperties_offsetAllY.Clear();
                    frameProperties_offsetX.refresh = true;
                    frameProperties_offsetY.refresh = true;
                }
            } else // static sprite
                offsetAllFrames = false;

            // Offset Colliders
            if(masterSpriteData.isStaticSprite) { // draw extra label field for static sprites
                Utils.GUITools.Engine.SwitchToFixedWidth(80.0f);
                Utils.GUITools.EditorLayout.Label("Offset:");
            } else
                DrawSectionSpacer();

            Utils.GUITools.Engine.SwitchToFixedWidth(tinyLabelWidth, toggleWidth);
            bool offsetColliders = frameProperties_offsetColliders.value;
            GUI.enabled = guiEnabled && masterSpriteData.liveColliderSetCount > 0 && !colliderSelected && !locatorSelected;
            if(frameProperties_offsetColliders.value && masterSpriteData.liveColliderSetCount <= 0) { // make sure offset colliders gets cleared when we no longer have colliders
                offsetColliders = false;
                frameProperties_offsetColliders.refresh = true;
            }
            frameProperties_offsetColliders.Draw(ref offsetColliders, toggleWidth + tinyLabelWidth);
            GUI.enabled = mainPageEnabled;

            DrawSectionSpacer();

            // Offset Static Colliders
            Utils.GUITools.Engine.SwitchToFixedWidth(tinyLabelWidth, toggleWidth);
            bool offsetStaticColliders;
            if(!masterSpriteData.isStaticSprite) {
                offsetStaticColliders = frameProperties_offsetStaticColliders.value;
                GUI.enabled = guiEnabled && offsetColliders && !masterSpriteData.isStaticSprite && !colliderSelected && !locatorSelected;
                if(!frameProperties_offsetColliders.value) { // make sure static clears if offsetColliders is false (non-static sprites)
                    offsetStaticColliders = false;
                    frameProperties_offsetStaticColliders.refresh = true;
                }
                frameProperties_offsetStaticColliders.Draw(ref offsetStaticColliders, toggleWidth + tinyLabelWidth);
                GUI.enabled = guiEnabled;
            } else {
                offsetStaticColliders = true; // always offset static colliders if static sprite
                if(!frameProperties_offsetStaticColliders.value) frameProperties_offsetStaticColliders.value = true;
            }

            DrawSectionSpacer();

            // Offset locators
            Utils.GUITools.Engine.SwitchToFixedWidth(tinyLabelWidth, toggleWidth);
            bool offsetLocators = frameProperties_offsetLocators.value;
            GUI.enabled = guiEnabled && masterSpriteData.liveLocatorSetCount > 0 && !colliderSelected && !locatorSelected;
            frameProperties_offsetLocators.Draw(ref offsetLocators, toggleWidth + tinyLabelWidth);
            GUI.enabled = mainPageEnabled;

            Utils.GUITools.Engine.SwitchToAutoWidth(); // reset to default look like
            Utils.GUITools.EditorLayout.EndHorizontal();

            if(colliderFrameProperties_editCollider.selectionIndex > 0) { // a collider is selected
                GUI.enabled = guiEnabled;
            }

            // Draw offset fields
            float labelWidth = 65.0f;
            float controlWidth = 60.0f;
            //float totalWidth = colWidth * 0.5f;
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth);
            Utils.GUITools.EditorLayout.BeginHorizontal();

            if(!offsetAllFrames) {
                // Offset X
                int prevX = frame.framePixelOffset.x;
                if(frameProperties_offsetX.Draw(ref frame.framePixelOffset.x)) {
                    if(offsetColliders) { // offset colliders too
                        int diff = frame.framePixelOffset.x - prevX;
                        OffsetAllColliderFramesInFrame(frame, diff, 0, offsetStaticColliders); // offset all colliders in this frame, including statics
                    }
                    if(offsetLocators) { // offset locators too
                        int diff = frame.framePixelOffset.x - prevX;
                        OffsetAllLocatorFramesInFrame(frame, diff, 0); // offset all locators in this frame
                    }
                    unsavedChanges = true;
                    remakeMeshes = true;
                }

                // Offset Y
                int prevY = frame.framePixelOffset.y;
                if(frameProperties_offsetY.Draw(ref frame.framePixelOffset.y)) {
                    if(offsetColliders) { // offset colliders too
                        int diff = frame.framePixelOffset.y - prevY;
                        OffsetAllColliderFramesInFrame(frame, 0, diff, offsetStaticColliders); // offset all colliders in this frame, including statics
                    }
                    if(offsetLocators) { // offset locators too
                        int diff = frame.framePixelOffset.y - prevY;
                        OffsetAllLocatorFramesInFrame(frame, 0, diff); // offset all locators in this frame
                    }
                    unsavedChanges = true;
                    remakeMeshes = true;
                }

            } else {
                // Offset X All
                int offsetX = frameProperties_offsetAllX.value;
                int prevX = offsetX;
                if(frameProperties_offsetAllX.Draw(ref offsetX)) {
                    frameProperties_offsetAllX.value = offsetX;
                    int diff = offsetX - prevX;
                    OffsetAllFrames(diff, 0);
                    if(offsetColliders) // offset colliders too
                        OffsetAllColliderFramesInAnimation(animationListBoxContainer.selectedObject, diff, 0, offsetStaticColliders);
                    if(offsetLocators) // offset locators too
                        OffsetAllLocatorFramesInAnimation(animationListBoxContainer.selectedObject, diff, 0);
                    unsavedChanges = true;
                    remakeMeshes = true;
                }

                // Offset Y All
                int offsetY = frameProperties_offsetAllY.value;
                int prevY = offsetY;
                if(frameProperties_offsetAllY.Draw(ref offsetY)) {
                    frameProperties_offsetAllY.value = offsetY;
                    int diff = offsetY - prevY;
                    OffsetAllFrames(0, diff);
                    if(offsetColliders) // offset colliders too
                        OffsetAllColliderFramesInAnimation(animationListBoxContainer.selectedObject, 0, diff, offsetStaticColliders);
                    if(offsetLocators) // offset locators too
                        OffsetAllLocatorFramesInAnimation(animationListBoxContainer.selectedObject, 0, diff);
                    unsavedChanges = true;
                    remakeMeshes = true;
                }
            }

            Utils.GUITools.EditorLayout.EndHorizontal();
            Utils.GUITools.Engine.SwitchToAutoWidth(); // reset to default look like

            // Event string
            if(!masterSpriteData.isStaticSprite) {
                if(frameProperties_event.Draw(ref frame.eventString)) { // value changed
                    unsavedChanges = true;
                }
            }
        }

        private void DrawColliderFramePopup(float colWidth) {
            if(!loaded) return;

            EditorMasterSprite.Frame frame = frameListBoxContainer.selectedObject;
            if(frame == null) {
                ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            //Utils.GUITools.Layout.Label("Collider Frame Properties");

            // Edit Collider
            // Update the sprite group list when the collider set list box container updates
            // need to refresh when:
            // changing sprites
            // something in collider sets changes
            if(masterSpriteSelectionChanged || refreshColliderFrameProperties) {
                refreshColliderFrameProperties = false;
                string[] options = masterSpriteData.GetColliderSetNames();
                if(options != null && options.Length > 0) { // tag static colliders
                    for(int i = 0; i < options.Length; i++) {
                        string prefix = "";
                        if(!masterSpriteData.colliderSets[i].isAnimated) prefix = "(S)"; // static collider
                        if(masterSpriteData.colliderSets[i].isParent) prefix = "(P)" + prefix; // parent collider
                        if(prefix != "") options[i] = prefix + " " + options[i]; // apply
                    }
                }
                SpriteFactory.Utils.ArrayTools.Insert<string>(ref options, 0, "None"); // insert none in list
                colliderFrameProperties_editCollider.SetOptions(options); // update the popup with new list
                colliderFrameProperties_editCollider.ChangeSelection(0); // select "None" and refresh children
            }

            // Draw the popup control
            GUI.enabled = mainPageEnabled && masterSpriteData.liveColliderSetCount > 0;
            if(colliderFrameProperties_editCollider.Draw(colliderFrameProperties_editCollider.selectionIndex)) { // selection changed
                if(locatorFrameProperties_editLocator.selectionIndex > 0) locatorFrameProperties_editLocator.ChangeSelection(0); // make sure edit locator is not set if editing collider
            }

            // Update collider frame controls when user changes frames/animations
            if(frameListBoxContainer.refresh) {
                colliderFrameProperties_editCollider.ClearChildren(); // refresh all collider frame controls when frame changes
            }

            GUI.enabled = mainPageEnabled;
        }

        private void DrawLocatorFramePopup(float colWidth) {
            if(!loaded) return;

            EditorMasterSprite.Frame frame = frameListBoxContainer.selectedObject;
            if(frame == null) {
                ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            //Utils.GUITools.Layout.Label("Locator Frame Properties");

            // Edit Locator
            // need to refresh when:
            // changing sprites
            // something in locator sets changes
            if(masterSpriteSelectionChanged || refreshLocatorFrameProperties) {
                refreshLocatorFrameProperties = false;
                string[] options = masterSpriteData.GetLocatorSetNames();
                SpriteFactory.Utils.ArrayTools.Insert<string>(ref options, 0, "None"); // insert none in list
                locatorFrameProperties_editLocator.SetOptions(options); // update the popup with new list
                locatorFrameProperties_editLocator.ChangeSelection(0); // select "None" and refresh children
            }

            // Dropdown box
            float labelWidth = 120.0f;
            EditorGUIUtility.LookLikeControls(labelWidth);
            GUI.enabled = mainPageEnabled && masterSpriteData.liveLocatorSetCount > 0;
            if(locatorFrameProperties_editLocator.Draw(locatorFrameProperties_editLocator.selectionIndex)) { // selection changed
                if(colliderFrameProperties_editCollider.selectionIndex > 0) colliderFrameProperties_editCollider.ChangeSelection(0); // make sure edit collider is not set if editing locator
            }
            EditorGUIUtility.LookLikeControls();

            GUI.enabled = mainPageEnabled;
        }

        private void DrawColliderFrameProperties(float colWidth) {
            if(colliderFrameProperties_editCollider.selectionIndex <= 0) return;

            EditorMasterSprite.Frame frame = frameListBoxContainer.selectedObject;
            if(frame == null) return;

            int editColliderSetIndex = colliderFrameProperties_editCollider.selectionIndex - 1; // offset for "None"
            int animIndex = animationListBoxContainer.selectedIndex;
            int frameIndex = frameListBoxContainer.selectedIndex;
            Sprite.ColliderFrame colliderFrame = masterSpriteData.GetColliderFrame(animIndex, frameIndex, editColliderSetIndex);

            // Draw the collider frame controls
            if(colliderFrame == null) return; // no edit collider is selected

            DrawSectionSpacer(5.0f);

            // set control vars locally first so we can display the controls disabled even when we have no collider frames
            bool enabled = false;
            float sizeX = 0;
            float sizeY = 0;
            float centerX = 0;
            float centerY = 0;
            float rotation = 0.0f;

            if(editColliderSetIndex >= 0) { // must have a collider set to enable controls
                GUI.enabled = mainPageEnabled;
                enabled = colliderFrame.enabled;
                sizeX = colliderFrame.size2D.x;
                sizeY = colliderFrame.size2D.y;
                centerX = colliderFrame.center2D.x;
                centerY = colliderFrame.center2D.y;
                rotation = colliderFrame.rotation;
            } else {
                GUI.enabled = false;
            }

            bool origGUIenabled = GUI.enabled;

            float labelWidth;// = 55.0f;
            //float totalWidth = (colWidth - (style_cellPad.padding.left + style_cellPad.padding.right)) * 0.25f;
            float controlWidth;// = totalWidth - labelWidth;

            // Put all controls into one row
            Utils.GUITools.EditorLayout.BeginHorizontal();

            labelWidth = 60.0f;
            controlWidth = 35.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth);

            // Enabled
            if(colliderFrameProperties_enabled.Draw(ref enabled)) { // value changed
                colliderFrame.enabled = enabled;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();

            labelWidth = 30.0f;
            controlWidth = 50.0f;
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth);

            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            GUI.enabled = mainPageEnabled && colliderFrame != null && colliderFrame.enabled; // only enable controls if collider frame is enabled
            if(colliderFrameProperties_sizeX.Draw(ref sizeX)) { // value changed
                colliderFrame.size2D.x = sizeX;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();

            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            if(colliderFrameProperties_sizeY.Draw(ref sizeY)) { // value changed
                colliderFrame.size2D.y = sizeY;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();

            labelWidth = 30.0f;
            controlWidth = 45.0f;
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth);

            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            if(colliderFrameProperties_centerX.Draw(ref centerX)) { // value changed
                colliderFrame.center2D.x = centerX;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();

            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            if(colliderFrameProperties_centerY.Draw(ref centerY)) { // value changed
                colliderFrame.center2D.y = centerY;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();

            if(masterSpriteData.colliderSets[editColliderSetIndex].isParent) GUI.enabled = false; // disable control if collider set is a parent, cannot rotate parent colliders
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            if(colliderFrameProperties_rotation.Draw(ref rotation)) { // value changed
                colliderFrame.rotation = rotation;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();
            if(GUI.enabled != origGUIenabled) GUI.enabled = origGUIenabled; // restore GUI

            Utils.GUITools.EditorLayout.EndHorizontal();

            Utils.GUITools.Engine.SwitchToAutoWidth(); // revert

            GUILayout.Space(5.0f);

            // Copy/Paste/Fit buttons
            Utils.GUITools.EditorLayout.BeginHorizontal();

            // Visible collider group popup

            // Get list of collider groups
            if(colliderFrameProperties_visibleColliderGroup.refresh || refreshColliderGroupList) { // must also update when we change sprites, which will filter down to colliderFrameProperties_visibleColliderGroup.refresh
                refreshColliderGroupList = false;
                Sprite.ColliderGroup[] colliderGroups = masterSpriteData.colliderGroups; // get from sprite as object
                string[] nameList = null;
                int itemCount = colliderGroups == null ? 0 : colliderGroups.Length;
                if(itemCount > 0) {
                    nameList = new string[itemCount + 2];
                    nameList[0] = "Current";
                    nameList[1] = "All";
                    for(int i = 2; i < itemCount + 2; i++) {
                        nameList[i] = colliderGroups[i - 2].name;
                        nameList[i] = i - 2 + ": " + nameList[i];
                    }
                } else { // no animations
                    nameList = new string[2] { "Current", "All" };
                }
                colliderFrameProperties_visibleColliderGroup.SetOptions(nameList);

                // Validate selection
                int selection = colliderFrameProperties_visibleColliderGroup.selectionIndex;
                if(selection < 0 || selection >= itemCount + 2) {
                    colliderFrameProperties_visibleColliderGroup.ChangeSelection(0); // always select Current if invalid selection
                }
            }

            // Collider Display Filter
            labelWidth = 50.0f;
            controlWidth = 90.0f;
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth);
            colliderFrameProperties_visibleColliderGroup.Draw(colliderFrameProperties_visibleColliderGroup.selectionIndex);

            // Copy button
            controlWidth = 80.0f;
            Utils.GUITools.Engine.SwitchToFixedWidth(0.0f, controlWidth);
            GUI.enabled = mainPageEnabled && colliderFrame != null;
            GUIContent buttonContent = new GUIContent("Copy", "Copy collider frame properties");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                clipboard.Copy(colliderFrame);
            }

            GUILayout.Space(8.0f);

            // Paste button
            Utils.GUITools.Engine.SwitchToFixedWidth(0.0f, controlWidth);
            GUI.enabled = mainPageEnabled && colliderFrame != null && clipboard.hasColliderFrame;
            buttonContent = new GUIContent("Paste", "Paste collider frame properties to current frame for the currently selected collider");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.SetColliderFrame(animIndex, frameIndex, editColliderSetIndex, clipboard.PasteColliderFrame()); // paste over frame
                masterSpriteData.GetColliderFrame(animIndex, frameIndex, editColliderSetIndex); // update the local frame var in case we need it again
                colliderFrameProperties_editCollider.refresh = true; // refresh collider frame settings
                unsavedChanges = true;
            }

            GUILayout.Space(15.0f);

            // Paste All button
            controlWidth = 80.0f;
            Utils.GUITools.Engine.SwitchToFixedWidth(0.0f, controlWidth);
            buttonContent = new GUIContent("Paste All", "Paste collider frame properties to all frames in this animation for the currently selected collider. NOTE: Does not affect static colliders.");
            if(!masterSpriteData.IsColliderAnimated(editColliderSetIndex)) GUI.enabled = false; // do not allow paste all operations on static colliders
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(EditorUtility.DisplayDialog("Paste to All Frames in Animation", "This will paste the collider frame properties to all frames in this animation for the currently selected collider. Existing collider frame properties will be overwritten.) Are you sure?", "Paste to All Frames", "Cancel")) {
                    EditorMasterSprite.Animation anim = animationListBoxContainer.selectedObject;
                    EditorMasterSprite.Frame[] editorFrames = anim.editorFrames;
                    if(editorFrames != null && editorFrames.Length > 0) {
                        for(int i = 0; i < editorFrames.Length; i++) {
                            editorFrames[i].colliderFrames[editColliderSetIndex] = clipboard.PasteColliderFrame(); // paste over frame
                        }
                        colliderFrame = frame.colliderFrames[editColliderSetIndex]; // update the local frame var in case we need it again
                        colliderFrameProperties_editCollider.refresh = true; // refresh collider frame settings
                        unsavedChanges = true;
                    }
                }
            }

            GUILayout.Space(15.0f);

            // Fit button
            controlWidth = 60.0f;
            Utils.GUITools.Engine.SwitchToFixedWidth(0.0f, controlWidth);
            GUI.enabled = mainPageEnabled && colliderFrame != null && colliderFrame.enabled;
            buttonContent = new GUIContent("Fit", "Fit collider to sprite");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(FitColliderToSprite(frame, colliderFrame)) {
                    colliderFrameProperties_editCollider.refresh = true;
                    unsavedChanges = true;
                }
            }

            Utils.GUITools.EditorLayout.EndHorizontal();

            GUI.enabled = mainPageEnabled;
        }

        private void DrawLocatorFrameProperties(float colWidth) {
            if(locatorFrameProperties_editLocator.selectionIndex <= 0) return;

            EditorMasterSprite.Frame frame = frameListBoxContainer.selectedObject;
            if(frame == null) return;

            int animIndex = animationListBoxContainer.selectedIndex;
            int frameIndex = frameListBoxContainer.selectedIndex;
            int editLocatorSetIndex = locatorFrameProperties_editLocator.selectionIndex - 1; // offset for "None"
            Sprite.LocatorFrame locatorFrame = masterSpriteData.GetLocatorFrame(animIndex, frameIndex, editLocatorSetIndex);

            // Draw locator frame controls
            if(locatorFrame == null) return; // no edit locator is selected

            DrawSectionSpacer(5.0f);

            // Update locator frame controls when user changes frames/animations
            if(frameListBoxContainer.refresh) {
                locatorFrameProperties_editLocator.ClearChildren(); // refresh all locator frame controls when frame changes
            }

            // set control vars locally first so we can display the controls disabled even when we have no locator frames
            bool enabled = false;
            int posX = 0;
            int posY = 0;
            float offsetZ = 0.0f;
            float facing = 0.0f;
            bool flipForwardVector = false;

            if(editLocatorSetIndex >= 0) { // must have a locator set to enable controls
                GUI.enabled = mainPageEnabled;
                enabled = locatorFrame.enabled;
                posX = locatorFrame.pixelPosition.x;
                posY = locatorFrame.pixelPosition.y;
                offsetZ = locatorFrame.offsetZ;
                facing = locatorFrame.facing;
                flipForwardVector = locatorFrame.flipForwardVector;
            } else {
                GUI.enabled = false;
            }

            float controlWidth;
            float labelWidth;
            //float totalWidth = (colWidth - (style_cellPad.padding.left + style_cellPad.padding.right)) * 0.5f;
            Utils.GUITools.EditorLayout.BeginHorizontal();

            // Enabled
            labelWidth = 60.0f;
            controlWidth = 20.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth);
            if(locatorFrameProperties_enabled.Draw(ref enabled)) { // value changed
                locatorFrame.enabled = enabled;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();

            // Pos X
            labelWidth = 25.0f;
            controlWidth = 40.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth);
            GUI.enabled = mainPageEnabled && locatorFrame != null && locatorFrame.enabled; // only enable controls if locator frame is enabled
            if(locatorFrameProperties_positionX.Draw(ref posX)) { // value changed
                locatorFrame.pixelPosition.x = posX;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();

            // Pos Y
            labelWidth = 25.0f;
            controlWidth = 40.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth);
            if(locatorFrameProperties_positionY.Draw(ref posY)) { // value changed
                locatorFrame.pixelPosition.y = posY;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();

            // Offset Z
            labelWidth = 45.0f;
            controlWidth = 40.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth);
            if(locatorFrameProperties_offsetZ.Draw(ref offsetZ, false)) { // value changed
                locatorFrame.offsetZ = offsetZ;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();

            // Facing
            labelWidth = 50.0f;
            controlWidth = 50.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth);
            if(locatorFrameProperties_facing.Draw(ref facing, false)) { // value changed
                facing = SpriteFactory.Utils.MathTools.ClampAngle360(facing);
                locatorFrame.facing = facing;
                locatorFrameProperties_facing.refresh = true;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();

            // Flip Forward Vector
            labelWidth = 80.0f;
            controlWidth = 20.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth + controlWidth));
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth);
            if(locatorFrameProperties_flipForwardVector.Draw(ref flipForwardVector)) { // value changed
                locatorFrame.facing = SpriteFactory.Utils.MathTools.ClampAngle360(SpriteFactory.Utils.MathTools.ReverseAngleRotationDirection(locatorFrame.facing)); // reverse so arrow points the same direction, but Y flips
                locatorFrameProperties_facing.refresh = true;
                locatorFrame.flipForwardVector = flipForwardVector;
                unsavedChanges = true;
            }
            Utils.GUITools.EditorLayout.EndVertical();

            Utils.GUITools.EditorLayout.EndHorizontal();
            Utils.GUITools.Engine.SwitchToAutoWidth(); // revert

            GUILayout.Space(5.0f);

            // Copy/Paste buttons
            Utils.GUITools.EditorLayout.BeginHorizontal();

            // Copy button
            Utils.GUITools.Engine.SwitchToFixedWidth(0.0f, 75.0f);
            GUI.enabled = mainPageEnabled && locatorFrame != null;
            GUIContent buttonContent = new GUIContent("Copy", "Copy locator frame properties");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                clipboard.Copy(locatorFrame);
            }

            DrawSectionSpacer(5.0f);

            // Paste button
            Utils.GUITools.Engine.SwitchToFixedWidth(0.0f, 75.0f);
            GUI.enabled = mainPageEnabled && locatorFrame != null && clipboard.hasLocatorFrame;
            buttonContent = new GUIContent("Paste", "Paste locator frame properties to current frame for the currently selected locator");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.SetLocatorFrame(animIndex, frameIndex, editLocatorSetIndex, clipboard.PasteLocatorFrame()); // paste over frame
                locatorFrame = masterSpriteData.GetLocatorFrame(animIndex, frameIndex, editLocatorSetIndex); // update the local frame var in case we need it again
                locatorFrameProperties_editLocator.refresh = true; // refresh locator frame settings
                unsavedChanges = true;
            }

            GUILayout.Space(15.0f);

            // Paste All button
            Utils.GUITools.Engine.SwitchToFixedWidth(0.0f, 75.0f);
            buttonContent = new GUIContent("Paste All", "Paste locator frame properties to all frames in this animation for the currently selected locator.");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(EditorUtility.DisplayDialog("Paste to All Frames in Animation", "This will paste the locator frame properties to all frames in this animation for the currently selected locator. Existing locator frame properties will be overwritten. (NOTE: Does not affect static locators!) Are you sure?", "Paste to All Frames", "Cancel")) {
                    EditorMasterSprite.Animation anim = animationListBoxContainer.selectedObject;
                    EditorMasterSprite.Frame[] editorFrames = anim.editorFrames;
                    if(editorFrames != null && editorFrames.Length > 0) {
                        for(int i = 0; i < editorFrames.Length; i++) {
                            editorFrames[i].locatorFrames[editLocatorSetIndex] = clipboard.PasteLocatorFrame(); // paste over frame
                        }
                        locatorFrame = frame.locatorFrames[editLocatorSetIndex]; // update the local frame var in case we need it again
                        locatorFrameProperties_editLocator.refresh = true; // refresh locator frame settings
                        unsavedChanges = true;
                    }
                }
            }

            Utils.GUITools.Engine.SwitchToAutoWidth(); // revert
            Utils.GUITools.EditorLayout.EndHorizontal();

            GUI.enabled = mainPageEnabled;
        }

        private void DrawFrameEditorControls(float col1Width, float col2Width) {
            if(!loaded) return;
            if(animationListBoxContainer.selectedObject == null) return;
            if(frameListBoxContainer.selectedObject == null) return;

            bool guiEnabled = GUI.enabled;

            Utils.GUITools.EditorLayout.BeginHorizontal(GUILayout.Width(col1Width + col2Width)); // main container

            // Lightbox column
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(col1Width));
            Utils.GUITools.EditorLayout.BeginHorizontal(style_leftPadFix); // leftPadFix = hack to fix inconsistent left padding with auto+fixed controls
            DrawLightboxControls();
            Utils.GUITools.EditorLayout.EndHorizontal();
            Utils.GUITools.EditorLayout.EndVertical();

            // Zoom control column
            Utils.GUITools.EditorLayout.BeginVertical(style_leftMargin, GUILayout.Width(col2Width));
            Utils.GUITools.EditorLayout.BeginHorizontal();
            Utils.GUITools.Layout.Label("Zoom %");
            GUILayout.Space(5.0f);
            Utils.GUITools.Engine.SwitchToFixedWidth(100.0f);
            frameEditor.zoomPercentInt = EditorGUILayout.IntSlider(frameEditor.zoomPercentInt, frameEditor.minZoomInt, frameEditor.maxZoomInt);
            Utils.GUITools.Engine.SwitchToAutoWidth();
            if(Utils.GUITools.Layout.Button(new GUIContent("X", "Reset View"))) {
                frameEditor.ResetView();
            }
            Utils.GUITools.EditorLayout.EndHorizontal();
            Utils.GUITools.EditorLayout.EndVertical();

            Utils.GUITools.EditorLayout.EndHorizontal(); // end: main container

            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled;
        }

        private void DrawLightboxControls() {
            bool guiEnabled = GUI.enabled;
            bool changed = false;

            // Draw Lightbox label
            Utils.GUITools.Engine.SwitchToFixedWidth(60.0f);
            Utils.GUITools.EditorLayout.Label(help_lightbox);

            float controlWidth = 85.0f;

            // Get list of animations
            if(animationListBoxContainer.refresh || refreshLightBoxAnimationsList) {
                refreshLightBoxAnimationsList = false;
                EditorMasterSprite.Animation[] animList = masterSpriteData.editorAnimations; // get animations from sprite as object
                string[] nameList = null;
                int itemCount = animList == null ? 0 : animList.Length;
                if(itemCount > 0) {
                    nameList = new string[itemCount + 1];
                    nameList[0] = "Anim";
                    for(int i = 1; i < itemCount + 1; i++) {
                        nameList[i] = masterSpriteData.editorAnimations[i - 1].name;
                        if(masterSpriteData.defaultAnimationIndex == i - 1)
                            nameList[i] = "(D) " + nameList[i];
                        nameList[i] = i - 1 + ": " + nameList[i];
                    }
                } else { // no animations
                    nameList = new string[1] { "Anim" };
                }
                framePreviewControls_LightboxAnimation.SetOptions(nameList);
                framePreviewControls_LightboxAnimation.ChangeSelection(0); // always select none when an animation changes
                changed = true;
            }

            // Lightbox Animation
            Utils.GUITools.Engine.SwitchToFixedWidth(0.0f, controlWidth);
            if(masterSpriteData.isStaticSprite) GUI.enabled = false;
            int selection = framePreviewControls_LightboxAnimation.selectionIndex;
            if(framePreviewControls_LightboxAnimation.Draw(selection)) {
                changed = true;
                selection = framePreviewControls_LightboxAnimation.selectionIndex;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state

            // Get list of frames
            if(selection > 0) { // an animation is selected
                EditorMasterSprite.Animation[] animList = masterSpriteData.editorAnimations; // get animations from sprite as object
                EditorMasterSprite.Animation curAnim = animationListBoxContainer.selectedObject;
                EditorMasterSprite.Animation selectedLightboxAnim = animList[selection - 1];

                // Check if a change was made to the frame list if lightbox is a frame of the currently selected animation
                // This detects when a material change is made to the list, not just a simple selection change
                if(curAnim == selectedLightboxAnim) { // lightbox from this animation is being displayed, must watch for frame changes
                    if(frameListBoxContainer.changed) {
                        changed = true;
                    }
                }

                if(changed) {
                    EditorMasterSprite.Frame[] frameList = selectedLightboxAnim.editorFrames;
                    int itemCount = frameList == null ? 0 : frameList.Length;
                    string[] nameList = null;
                    if(itemCount > 0) {
                        nameList = new string[itemCount];
                        for(int i = 0; i < itemCount; i++) {
                            if(!frameList[i].hasTexture) // texture is missing
                                nameList[i] = i + ": [SOURCE IMAGE MISSING]";
                            else
                                nameList[i] = i + ": " + frameList[i].textureName;
                        }
                    } else { // no frames
                        nameList = new string[1] { "Frame" };
                    }
                    framePreviewControls_LightboxFrame.SetOptions(nameList);
                    framePreviewControls_LightboxFrame.ChangeSelection(0); // always select first frame
                }
            } else { // no selection
                if(changed) {
                    framePreviewControls_LightboxFrame.SetOptions(new string[1] { "Frame" });
                    framePreviewControls_LightboxFrame.ChangeSelection(0); // select none
                }
            }

            // Lightbox Frame
            Utils.GUITools.Engine.SwitchToFixedWidth(0.0f, controlWidth);
            if(selection <= 0 || masterSpriteData.isStaticSprite) GUI.enabled = false; // disable GUI if Animation hasn't been chosen
            selection = framePreviewControls_LightboxFrame.selectionIndex;
            if(framePreviewControls_LightboxFrame.Draw(selection)) {
                // do stuff
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state

            Utils.GUITools.Engine.SwitchToAutoWidth();
        }

        private void DrawFrameEditor(float colWidth) {
            if(!loaded) return;
            if(frameListBoxContainer.selectedObject == null) return;

            EditorMasterSprite.Frame frame = frameListBoxContainer.selectedObject;
            int frameIndex = frameListBoxContainer.selectedIndex;
            int animIndex = animationListBoxContainer.selectedIndex;
            EditorMasterSprite.Animation lightboxAnim = null;
            EditorMasterSprite.Frame lightboxFrame = null;

            // Get lightbox frame
            if(framePreviewControls_LightboxAnimation.selectionIndex > 0 && framePreviewControls_LightboxFrame.selectionIndex >= 0) {
                EditorMasterSprite.Animation[] spriteAnims = masterSpriteData.editorAnimations;
                if(spriteAnims != null && spriteAnims.Length > 0 && framePreviewControls_LightboxAnimation.selectionIndex <= spriteAnims.Length) {
                    lightboxAnim = spriteAnims[framePreviewControls_LightboxAnimation.selectionIndex - 1]; // offset for "None"
                    if(lightboxAnim != null) {
                        EditorMasterSprite.Frame[] lightboxFrames = lightboxAnim.editorFrames;
                        if(lightboxFrames != null && lightboxFrames.Length > 0 && framePreviewControls_LightboxFrame.selectionIndex < lightboxFrames.Length) {
                            lightboxFrame = lightboxFrames[framePreviewControls_LightboxFrame.selectionIndex];
                        }
                    }
                }
            }

            // Get colliders to display
            int colliderSetIndex = colliderFrameProperties_editCollider.selectionIndex - 1;
            int locatorSetIndex = locatorFrameProperties_editLocator.selectionIndex - 1;
            Sprite.ColliderFrame editColliderFrame = null;
            Sprite.LocatorFrame editLocatorFrame = null;
            Sprite.ColliderSet editColliderSet = null;
            Sprite.LocatorSet editLocatorSet = null;
            if(colliderSetIndex >= 0) {
                editColliderFrame = masterSpriteData.GetColliderFrame(animIndex, frameIndex, colliderSetIndex);
                editColliderSet = masterSpriteData.colliderSets[colliderSetIndex];
            }
            if(locatorSetIndex >= 0) {
                editLocatorFrame = masterSpriteData.GetLocatorFrame(animIndex, frameIndex, locatorSetIndex);
                editLocatorSet = masterSpriteData.locatorSets[locatorSetIndex];
            }

            int editingMode;
            if(editColliderSet != null && editColliderFrame != null) editingMode = 1; // collider
            else if(editLocatorSet != null && editLocatorFrame != null && locatorFrameProperties_enabled.value) editingMode = 2; // locator
            else editingMode = 0; // sprite

            if(editingMode == 1) { // editing collider

                Sprite.ColliderSet[] allColliderSets = masterSpriteData.colliderSets;

                // Create a bool mask to determine which colliders to hide in the display
                bool[] showMask = null;
                if(allColliderSets != null && allColliderSets.Length > 0) {
                    showMask = new bool[allColliderSets.Length];

                    // Filter colliders to show based on popup selection
                    int selection = colliderFrameProperties_visibleColliderGroup.selectionIndex;
                    // 0 = Current
                    // 1 = All
                    // 2+ = a group index

                    if(selection == 0) { // show current only
                        for(int i = 0; i < showMask.Length; i++) {
                            if(allColliderSets[i] == editColliderSet) {
                                showMask[i] = true; // show just this collider
                                break;
                            }
                        }
                    } else if(selection == 1) { // show all
                        for(int i = 0; i < showMask.Length; i++) {
                            showMask[i] = true; // show all colliders
                        }
                    } else if(selection > 1) { // a group
                        int groupIndex = selection - 2;
                        if(masterSpriteData.colliderGroups != null && groupIndex < masterSpriteData.colliderGroups.Length) {
                            int groupId = masterSpriteData.colliderGroups[groupIndex].id; // get the id of the group
                            for(int i = 0; i < showMask.Length; i++) {
                                if(allColliderSets[i] == editColliderSet) showMask[i] = true; // always show the working collider
                                if(allColliderSets[i].groupId == groupId) showMask[i] = true; // show collider if its in the right group
                            }
                        }
                    }
                }

                Sprite.ColliderFrame[] allColliderFrames = masterSpriteData.GetAllMixedColliderFrames(animIndex, frameIndex); // get all collider frames for this current anim/frame
                int newSelectedColliderId;

                if(frameEditor.Draw(frame, lightboxFrame, editColliderSet, editColliderFrame, allColliderSets, allColliderFrames, showMask, out newSelectedColliderId)) {
                    unsavedChanges = true;
                    colliderFrameProperties_sizeX.refresh = true;
                    colliderFrameProperties_sizeY.refresh = true;
                    colliderFrameProperties_centerX.refresh = true;
                    colliderFrameProperties_centerY.refresh = true;
                    colliderFrameProperties_rotation.refresh = true;
                }

                // check for active collider selection change
                if(newSelectedColliderId != -1) { // a different collider was selected
                    colliderFrameProperties_editCollider.ChangeSelection(newSelectedColliderId + 1);
                }

            } else if(editingMode == 2) { // editing locator

                if(frameEditor.Draw(frame, lightboxFrame, editLocatorSet, editLocatorFrame)) {
                    unsavedChanges = true;
                    locatorFrameProperties_positionX.refresh = true;
                    locatorFrameProperties_positionY.refresh = true;
                    locatorFrameProperties_facing.refresh = true;
                }

            } else { // editing sprite position

                Vector2 offset = new Vector2();
                frameEditor.Draw(frame, lightboxFrame, ref offset);

                // Handle offset
                if(offset.x != 0.0f || offset.y != 0.0f) {
                    bool offsetAllFrames = frameProperties_offsetAllFrames.value;
                    if(!offsetAllFrames) { // Offset just this frame

                        int prevX = frame.framePixelOffset.x;
                        int prevY = frame.framePixelOffset.y;
                        frame.framePixelOffset.x += (int)offset.x;
                        frame.framePixelOffset.y += (int)offset.y;
                        frameProperties_offsetX.refresh = true;
                        frameProperties_offsetY.refresh = true;
                        if(frameProperties_offsetColliders.value && masterSpriteData.liveColliderSetCount > 0) { // offset colliders too
                            OffsetAllColliderFramesInFrame(frame, frame.framePixelOffset.x - prevX, frame.framePixelOffset.y - prevY, frameProperties_offsetStaticColliders.value);
                        }
                        if(frameProperties_offsetLocators.value && masterSpriteData.liveLocatorSetCount > 0) { // offset locators too
                            OffsetAllLocatorFramesInFrame(frame, frame.framePixelOffset.x - prevX, frame.framePixelOffset.y - prevY);
                        }
                        unsavedChanges = true;
                        remakeMeshes = true;

                    } else { // Offset all frames in animation

                        // Offset X All
                        int offsetX = (int)offset.x;
                        int offsetY = (int)offset.y;
                        frameProperties_offsetAllX.value += offsetX;
                        frameProperties_offsetAllY.value += offsetY;
                        OffsetAllFrames(offsetX, offsetY);
                        if(frameProperties_offsetColliders.value && masterSpriteData.liveColliderSetCount > 0) { // offset colliders too
                            OffsetAllColliderFramesInAnimation(animationListBoxContainer.selectedObject, offsetX, offsetY, frameProperties_offsetStaticColliders.value);
                        }
                        if(frameProperties_offsetLocators.value && masterSpriteData.liveLocatorSetCount > 0) { // offset locators too
                            OffsetAllLocatorFramesInAnimation(animationListBoxContainer.selectedObject, offsetX, offsetY);
                        }
                        unsavedChanges = true;
                        remakeMeshes = true;

                    }
                }
            }
        }

        // Window Contents

        private void DrawMaterialSetListBox(float colWidth, float height) {
            if(!loaded) return;

            Utils.GUITools.EditorLayout.BeginHorizontal();
            Utils.GUITools.Layout.Label(help_materialSets);
            Utils.GUITools.EditorLayout.EndHorizontal();

            // Load material sets
            EditorMasterSprite.MaterialSet[] objectList = materialSetContainer.materialSets;
            int itemCount = objectList == null ? 0 : objectList.Length;

            // Create list of items to populate list box
            string[] nameList = null;
            if(itemCount > 0) {
                nameList = new string[itemCount];
                for(int i = 0; i < itemCount; i++) {
                    nameList[i] = i + ": " + objectList[i].name;
                }
            }

            // Make sure something is selected - Select 0 if nothing is selected
            if(Event.current.type == EventType.layout) {
                if(!materialSetListBoxContainer.hasSelection) {
                    materialSetListBoxContainer.ChangeSelection(0);
                }
            }

            // Draw the list box
            DrawListBox(materialSetListBoxContainer, itemCount, objectList, nameList, "empty", false, colWidth, height);

            // Draw buttons
            DrawMaterialSetListBoxButtons(materialSetListBoxContainer, colWidth, "Material Set");
        }

        private void DrawMaterialSetListBoxButtons(SimpleGUIListBoxContainer<EditorMasterSprite.MaterialSet> container, float colWidth, string objectName = "item") {
            if(!loaded) return;

            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            GUIContent buttonContent;
            bool changed = false;
            bool isObjectSelected = false;
            EditorMasterSprite.MaterialSet materialSet = container.selectedObject;
            int selectionIndex = container.selectedIndex;
            if(container.hasSelection && materialSet != null) isObjectSelected = true;

            bool guiEnabled = GUI.enabled; // get current state of GUI

            GUI.enabled = guiEnabled && isObjectSelected && materialSetContainer.ReorderMaterialSet(selectionIndex, -1, false);
            buttonContent = new GUIContent("UP", "Move selected " + objectName + " up");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(materialSetContainer.ReorderMaterialSet(selectionIndex, -1)) {
                    container.ChangeSelection(container.selectedIndex - 1);
                    changed = true;
                }
            }

            GUI.enabled = guiEnabled && isObjectSelected && materialSetContainer.ReorderMaterialSet(selectionIndex, 1, false);
            buttonContent = new GUIContent("DN", "Move selected " + objectName + " down");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(materialSetContainer.ReorderMaterialSet(selectionIndex, 1)) {
                    container.ChangeSelection(container.selectedIndex + 1);
                    changed = true;
                }
            }

            GUILayout.Space(10.0f);

            GUI.enabled = guiEnabled;
            buttonContent = new GUIContent("+", "Add new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                materialSetContainer.AddNewMaterialSet();
                changed = true;
            }

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Ins", "Insert new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                materialSetContainer.InsertNewMaterialSet(selectionIndex);
                container.ChangeSelection(selectionIndex); // select the new inserted material
                changed = true;
            }

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Dup", "Duplicate " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                materialSetContainer.DuplicateMaterialSet(selectionIndex);
                changed = true;
            }

            GUILayout.Space(10);

            GUI.enabled = guiEnabled && isObjectSelected && materialSetContainer.materialSetCount > 1; // don't allow deletion of last set
            buttonContent = new GUIContent("DEL", "Delete " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(EditorUtility.DisplayDialog("Delete " + objectName, "Are you sure you want to delete this " + objectName + "?", "Delete " + objectName, "Cancel")) {
                    materialSetContainer.DeleteMaterialSet(selectionIndex); // delete group and child sprites
                    changed = true;
                    container.DeleteSelected(); // // clear the entry from the container
                }
            }

            if(changed) {
                container.refresh = true; // flag refresh of list info
                unsavedChanges = true;
                remakeMaterials = true;
            }

            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state

            Utils.GUITools.EditorLayout.EndHorizontal();

        }

        private void DrawMaterialSetProperties(float colWidth) {
            if(materialSetListBoxContainer.selectedIndex < 0) return;

            EditorMasterSprite.MaterialSet materialSet = materialSetListBoxContainer.selectedObject;
            if(materialSet == null) {
                ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            Utils.GUITools.Layout.Label("Material Set Properties");

            // Name
            string setName = materialSet.name;
            if(materialSetProperties_name.Draw(ref setName)) {
                materialSet.name = materialSetContainer.VerifyName(setName, materialSetListBoxContainer.selectedIndex);
                unsavedChanges = true;
                remakeMaterials = true;
            }

            // Use default material
            if(materialSetProperties_useDefaultMaterial.Draw(ref materialSet.useDefaultMaterial)) {
                if(materialSet.useDefaultMaterial) { // set to true
                    materialSet.sourceMaterial = null; // clear the material
                } else { // set to false
                    materialSet.sourceMaterial = db.userDefaultMaterial; // load default material from the editor properties
                }
                unsavedChanges = true;
                remakeMaterials = true;
            }

            // Source material
            if(!materialSet.useDefaultMaterial) { // only show if not using default
                Object sourceMaterial = materialSet.sourceMaterial;
                if(materialSetProperties_sourceMaterial.Draw(ref sourceMaterial)) {
                    materialSet.sourceMaterial = (Material)sourceMaterial; // update the source material
                    unsavedChanges = true;
                    remakeMaterials = true;
                }
            }
        }

        private void DrawColliderSetListBox(float colWidth, float height) {
            if(!loaded) return;

            Utils.GUITools.Layout.Label(help_colliders);

            // Load collider sets
            Sprite.ColliderSet[] objectList = masterSpriteData.colliderSets;
            int itemCount = objectList == null ? 0 : objectList.Length;

            // Create list of items to populate list box
            string[] nameList = null;
            if(itemCount > 0) {
                nameList = new string[itemCount];
                for(int i = 0; i < itemCount; i++) {
                    nameList[i] = i + ": " + objectList[i].name;
                    if(objectList[i].isParent) nameList[i] = "(P) " + nameList[i]; // prepend parent status on parent
                }
            }

            // Make sure something is selected - Select 0 if nothing is selected
            //if(Event.current.type == EventType.layout) {
            //if(!colliderSetListBoxContainer.hasSelection && !colliderGroupListBoxContainer.hasSelection) { // nothing is selected yet
            //colliderSetListBoxContainer.ChangeSelection(0);
            //}
            //}

            // Draw the list box
            DrawListBox(colliderSetListBoxContainer, itemCount, objectList, nameList, "There are no colliders in this sprite.", false, colWidth, height);

            // Draw buttons
            DrawColliderSetListBoxButtons(colliderSetListBoxContainer, colWidth, "Collider");

            // Clear collider group selection if selecting a set
            if(colliderSetListBoxContainer.selectionChanged) {
                colliderGroupListBoxContainer.ClearSelection();
            }
        }

        private void DrawColliderSetListBoxButtons(SimpleGUIListBoxContainer<Sprite.ColliderSet> container, float colWidth, string objectName = "item") {
            if(!loaded) return;

            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            GUIContent buttonContent;
            bool changed = false;
            bool isObjectSelected = false;
            Sprite.ColliderSet colliderSet = container.selectedObject;
            int selectionIndex = container.selectedIndex;
            if(container.hasSelection && colliderSet != null) isObjectSelected = true;
            bool guiEnabled = GUI.enabled; // get current state of GUI

            GUI.enabled = guiEnabled && isObjectSelected && masterSpriteData.ReorderColliderSet(selectionIndex, -1, false);
            buttonContent = new GUIContent("UP", "Move selected " + objectName + " up");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(masterSpriteData.ReorderColliderSet(selectionIndex, -1)) {
                    container.ChangeSelection(container.selectedIndex - 1);
                    changed = true;
                }
            }

            GUI.enabled = guiEnabled && isObjectSelected && masterSpriteData.ReorderColliderSet(selectionIndex, 1, false);
            buttonContent = new GUIContent("DN", "Move selected " + objectName + " down");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(masterSpriteData.ReorderColliderSet(selectionIndex, 1)) {
                    container.ChangeSelection(container.selectedIndex + 1);
                    changed = true;
                }
            }

            GUILayout.Space(10);

            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state
            buttonContent = new GUIContent("+", "Add new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.AddNewColliderSet(db.defaultUse2DColliders);
                changed = true;
            }

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Ins", "Insert new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.InsertNewColliderSet(db.defaultUse2DColliders, selectionIndex);
                container.ChangeSelection(selectionIndex); // select the new inserted material
                changed = true;
            }

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Dup", "Duplicate " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.DuplicateColliderSet(selectionIndex);
                changed = true;
            }

            GUILayout.Space(10);

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("DEL", "Delete " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(EditorUtility.DisplayDialog("Delete " + objectName, "Are you sure you want to delete this " + objectName + "?", "Delete " + objectName, "Cancel")) {
                    masterSpriteData.DeleteColliderSet(selectionIndex); // delete group and child sprites
                    changed = true;
                    container.DeleteSelected(); // // clear the entry from the container
                }
            }

            Utils.GUITools.EditorLayout.EndHorizontal();

            // Button Row 2
            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            GUI.enabled = guiEnabled && isObjectSelected;
            if(!isObjectSelected || !colliderSet.isParent) {
                buttonContent = new GUIContent("Set to Parent", "Make selected collider the parent of all other colliders. The parent collider will be added to the main Sprite game object. All others will be children of the parent in the hierarchy. Normally, the parent collider would be the main movement collider for your sprite. It is also useful if you want all child colliders to share a rigidbody. NOTE: Parent colliders cannot be rotated. If you set an existing collider to Parent that has been rotated in any frames, all rotations will be lost.");
                if(Utils.GUITools.Layout.Button(buttonContent)) {
                    bool go = false;
                    if(masterSpriteData.ColliderSetHasRotatedFrames(colliderSet)) {
                        if(EditorUtility.DisplayDialog("Set Collider to Parent", "This collider has been rotated in one or more frames. Colliders set to Parent cannot be rotated. The rotation of this collider in any frames will be lost. Are you sure?", "Set to Parent", "Cancel")) {
                            go = true;
                        }
                    } else go = true;

                    if(go) {
                        masterSpriteData.SetColliderSetParent(selectionIndex);
                        colliderSetListBoxContainer.softRefresh = true; // update name list
                        changed = true;
                    }
                }
            } else { // this object is the parent, allow to un-set parent
                buttonContent = new GUIContent("Unparent", "Make selected collider no longer be the parent of all other colliders.");
                if(Utils.GUITools.Layout.Button(buttonContent)) {
                    masterSpriteData.ClearColliderSetParent();
                    colliderSetListBoxContainer.softRefresh = true; // update name list
                    changed = true;
                }
            }

            Utils.GUITools.EditorLayout.EndHorizontal();

            if(changed) {
                container.refresh = true; // flag refresh of list info
                unsavedChanges = true;
            }

            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state
        }

        private void DrawColliderSetProperties(float colWidth, float labelWidth, float controlWidth) {
            if(colliderSetListBoxContainer.selectedIndex < 0) {
                //ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            Sprite.ColliderSet colliderSet = colliderSetListBoxContainer.selectedObject;
            if(colliderSet == null) {
                //ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            int colliderSetIndex = colliderSetListBoxContainer.selectedIndex;
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth); // set width of labels/controls
            bool guiEnabled = GUI.enabled; // get current state of GUI

            Utils.GUITools.Layout.Label("Collider Set Properties");

            // Name
            string setName = colliderSet.name;
            if(colliderSetProperties_name.Draw(ref setName)) {
                colliderSet.name = masterSpriteData.VerifyColliderSetName(setName, colliderSetListBoxContainer.selectedIndex);
                unsavedChanges = true;
            }

            // Tag
            if(colliderSetProperties_tag.Draw(ref colliderSet.tag)) {
                unsavedChanges = true;
            }

            // Collider Group

            // Get names an values for the popup selections
            string[] groupOptions;
            int[] groupIds;
            Sprite.ColliderGroup[] groups = masterSpriteData.colliderGroups;
            if(groups != null && groups.Length != 0) {
                groupOptions = new string[groups.Length + 1];
                groupIds = new int[groups.Length + 1];
                groupOptions[0] = "None";
                groupIds[0] = -1;
                for(int i = 1; i < groupOptions.Length; i++) {
                    groupOptions[i] = groups[i - 1].name;
                    groupIds[i] = groups[i - 1].id;
                }
            } else {
                groupOptions = new string[1] { "None" };
                groupIds = new int[1] { -1 };
            }
            colliderSetProperties_group.SetOptions(groupOptions);

            // Find list index for the selected groupId
            int selectedGroupId = colliderSet.groupId;
            int selectedGroupOptionIndex = System.Array.IndexOf<int>(groupIds, selectedGroupId);

            // Validate group id
            if(Event.current.type != EventType.layout) { // do not allow to change values in layout or it will error if it changes the value in Layout!
                if(selectedGroupOptionIndex == -1) { // group id was invalid
                    colliderSet.groupId = -1;
                    selectedGroupOptionIndex = 0; // select None
                    colliderSetProperties_group.refresh = true;
                    unsavedChanges = true;
                }
            }

            // Draw the group popup
            if(colliderSetProperties_group.Draw(selectedGroupOptionIndex)) {
                colliderSet.groupId = groupIds[colliderSetProperties_group.selectionIndex];
                unsavedChanges = true;
            }

            // Preview color
            if(colliderSetProperties_previewColor.Draw(ref colliderSet.previewColor)) {
                unsavedChanges = true;
            }

            // Layer
            GUI.enabled = guiEnabled && !colliderSet.isParent; // disable layer selection if parent. layer is set in sprite itself instead
            colliderSetProperties_layer.SetOptions(GetColliderLayerOptions()); // update layer names in case user changes them while editor is open
            if(colliderSet.isParent) { // make sure set to inherit from sprite when layer is set to parent
                if(!colliderSet.inheritLayer) {
                    colliderSet.inheritLayer = true;
                    colliderSet.layer = -1;
                }
            }
            int layerInt = colliderSet.layer + 1; // offset for "Inherit"
            if(colliderSetProperties_layer.Draw(layerInt)) {
                colliderSet.layer = colliderSetProperties_layer.selectionIndex - 1; // offset for "Inherit"
                if(colliderSet.layer >= 0) colliderSet.inheritLayer = false;
                else colliderSet.inheritLayer = true;
                unsavedChanges = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            // Collider Properties
            GUILayout.Space(10.0f);
            Utils.GUITools.Layout.Label("Box Collider Properties");

            // Collider type
            //GUI.enabled = false;
            //int colliderTypeInt = (int)colliderSet.colliderType;
            //if(colliderSetProperties_colliderType.Draw(colliderTypeInt)) {
            //    colliderSet.colliderType = (Sprite.ColliderType)colliderTypeInt;
            //    unsavedChanges = true;
            //}
            //if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            // Is 2D Collider
            if(!SpriteFactory.Utils.UnityTools.supports2DColliders) GUI.enabled = false; // only allow 2D colliders for Unity 4.3+
            bool is2D = colliderSet.is2D;
            if(colliderSetProperties_is2D.Draw(ref is2D)) {
                bool hasRB = masterSpriteData.colliderSets[colliderSetIndex].hasRigidbody;
                if(hasRB) { // this collider has a rigidbody, warn about changing type
                    string newType;
                    string oldType;
                    if(!is2D) { // just changed from 2D to 3D
                        newType = "3D";
                        oldType = "2D";
                    } else {
                        newType = "2D";
                        oldType = "3D";
                    }
                    if(EditorUtility.DisplayDialog(string.Format("Change to {0} Collider", newType), string.Format("Changing a collider to {0} will cause any some {1}-specific rigidbody information to be lost. Are you sure?", newType, oldType), "Change to " + newType, "Cancel")) {
                        masterSpriteData.ChangeColliderSet_Is2D(colliderSetIndex, is2D);
                    }
                } else // no RB, just change type
                    masterSpriteData.ChangeColliderSet_Is2D(colliderSetIndex, is2D);

                colliderSetListBoxContainer.refresh = true;
                unsavedChanges = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            // Is Animated
            GUI.enabled = guiEnabled && !masterSpriteData.isStaticSprite; // disable if static sprite
            bool isAnimated = colliderSet.isAnimated;
            if(colliderSetProperties_isAnimated.Draw(ref isAnimated)) {
                if(!isAnimated) { // user is changing animated collider to static
                    if(EditorUtility.DisplayDialog("Change to Static Collider", "Changing an animated collider to a static collider will cause any saved animations for this collider to be lost. Are you sure?", "Change to Static", "Cancel")) {
                        masterSpriteData.ChangeColliderSet_IsAnimated(colliderSetIndex, isAnimated);
                        unsavedChanges = true;
                    }
                } else {
                    masterSpriteData.ChangeColliderSet_IsAnimated(colliderSetIndex, isAnimated);
                    unsavedChanges = true;
                }
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            // Enable in New Frames
            if(colliderSet.isAnimated) {
                if(colliderSetProperties_enableInNewFrames.Draw(ref colliderSet.enableInNewFrames)) {
                    unsavedChanges = true;
                }
            }

            // 3D-Only Properties for collider
            if(!is2D) {

                // Z Thickness
                if(colliderSetProperties_sizeZ.Draw(ref colliderSet.sizeZ, false)) {
                    unsavedChanges = true;
                }

                // Z Offset
                if(colliderSetProperties_centerZ.Draw(ref colliderSet.centerZ, false)) {
                    unsavedChanges = true;
                }
            }

            // Is Trigger
            if(colliderSetProperties_isTrigger.Draw(ref colliderSet.isTrigger)) {
                unsavedChanges = true;
            }

            // Physics Material
            if(!is2D) {
                // Physic Material
                Object material = colliderSet.material;
                if(colliderSetProperties_material.Draw(ref material)) {
                    colliderSet.material = (PhysicMaterial)material; // update the physic material
                    unsavedChanges = true;
                }
            } else {
                // Physics Material 2D
                Object material2D = colliderSet.material2D;
                if(colliderSetProperties_material2D.Draw(ref material2D)) {
                    colliderSet.material2D = material2D; // update the physics material
                    unsavedChanges = true;
                }
            }

            // Rigidbody Properties
            GUILayout.Space(10.0f);
            Utils.GUITools.Layout.Label("Rigidbody Properties");

            // Has Rigidbody
            if(colliderSetProperties_hasRigidbody.Draw(ref colliderSet.hasRigidbody)) {
                unsavedChanges = true;
            }

            if(colliderSet.hasRigidbody) {

                // Is Kinematic
                if(colliderSetProperties_isKinematic.Draw(ref colliderSet.isKinematic)) {
                    unsavedChanges = true;
                }

                // 3D-only rigidbody properties
                if(!is2D) {

                    // Mass
                    if(colliderSetProperties_mass.Draw(ref colliderSet.mass, false)) {
                        unsavedChanges = true;
                    }

                    // Drag
                    if(colliderSetProperties_drag.Draw(ref colliderSet.drag, false)) {
                        unsavedChanges = true;
                    }

                    // Angular Drag
                    if(colliderSetProperties_angularDrag.Draw(ref colliderSet.angularDrag, false)) {
                        unsavedChanges = true;
                    }

                    // Use Gravity
                    if(colliderSetProperties_useGravity.Draw(ref colliderSet.useGravity)) {
                        unsavedChanges = true;
                    }

                    // Rigidbody Interpolation
                    int rigidbodyInterpolationInt = (int)colliderSet.interpolation;
                    if(colliderSetProperties_rigidbodyInterpolation.DrawByValue(rigidbodyInterpolationInt)) {
                        colliderSet.interpolation = (RigidbodyInterpolation)colliderSetProperties_rigidbodyInterpolation.selectionValue;
                        unsavedChanges = true;
                    }

                    // Collision Detection Mode
                    int collisionDetectionModeInt = (int)colliderSet.collisionDetectionMode;
                    if(colliderSetProperties_collisionDetectionMode.DrawByValue(collisionDetectionModeInt)) {
                        colliderSet.collisionDetectionMode = (CollisionDetectionMode)colliderSetProperties_collisionDetectionMode.selectionValue;
                        unsavedChanges = true;
                    }

                    // Constraints

                    // Position Constraints
                    Utils.GUITools.Engine.SwitchToFixedWidth(20.0f, 20.0f);
                    Utils.GUITools.EditorLayout.BeginHorizontal();
                    Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth));
                    Utils.GUITools.Layout.Label("Freeze Position:");
                    Utils.GUITools.EditorLayout.EndVertical();

                    Utils.GUITools.EditorLayout.Label("X", GUILayout.Width(16.0f));
                    bool constraintPosX = colliderSet.constraintPosX;
                    if(colliderSetProperties_constraintsPosX.Draw(ref constraintPosX)) {
                        colliderSet.constraintPosX = constraintPosX;
                        unsavedChanges = true;
                    }
                    Utils.GUITools.EditorLayout.Label("Y", GUILayout.Width(16.0f));
                    bool constraintPosY = colliderSet.constraintPosY;
                    if(colliderSetProperties_constraintsPosY.Draw(ref constraintPosY)) {
                        colliderSet.constraintPosY = constraintPosY;
                        unsavedChanges = true;
                    }
                    Utils.GUITools.EditorLayout.Label("Z", GUILayout.Width(16.0f));
                    bool constraintPosZ = colliderSet.constraintPosZ;
                    if(colliderSetProperties_constraintsPosZ.Draw(ref constraintPosZ)) {
                        colliderSet.constraintPosZ = constraintPosZ;
                        unsavedChanges = true;
                    }

                    Utils.GUITools.EditorLayout.EndHorizontal();

                    // Rotation Constraints

                    Utils.GUITools.EditorLayout.BeginHorizontal();
                    Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(labelWidth));
                    Utils.GUITools.Layout.Label("Freeze Rotation:");
                    Utils.GUITools.EditorLayout.EndVertical();

                    Utils.GUITools.EditorLayout.Label("X", GUILayout.Width(16.0f));
                    bool constraintRotX = colliderSet.constraintRotX;
                    if(colliderSetProperties_constraintsRotX.Draw(ref constraintRotX)) {
                        colliderSet.constraintRotX = constraintRotX;
                        unsavedChanges = true;
                    }
                    Utils.GUITools.EditorLayout.Label("Y", GUILayout.Width(16.0f));
                    bool constraintRotY = colliderSet.constraintRotY;
                    if(colliderSetProperties_constraintsRotY.Draw(ref constraintRotY)) {
                        colliderSet.constraintRotY = constraintRotY;
                        unsavedChanges = true;
                    }
                    Utils.GUITools.EditorLayout.Label("Z", GUILayout.Width(16.0f));
                    bool constraintRotZ = colliderSet.constraintRotZ;
                    if(colliderSetProperties_constraintsRotZ.Draw(ref constraintRotZ)) {
                        colliderSet.constraintRotZ = constraintRotZ;
                        unsavedChanges = true;
                    }
                    Utils.GUITools.EditorLayout.EndHorizontal();

                } else { // 2D-only rigidbody properties

                    // Mass
                    if(colliderSetProperties_mass2D.Draw(ref colliderSet.mass2D, false)) {
                        unsavedChanges = true;
                    }

                    // Linear Drag
                    if(colliderSetProperties_linearDrag2D.Draw(ref colliderSet.linearDrag2D, false)) {
                        unsavedChanges = true;
                    }

                    // Angular Drag
                    if(colliderSetProperties_angularDrag2D.Draw(ref colliderSet.angularDrag2D, false)) {
                        unsavedChanges = true;
                    }

                    // gravityScale
                    if(colliderSetProperties_gravityScale.Draw(ref colliderSet.gravityScale, false)) {
                        unsavedChanges = true;
                    }

                    // fixedAngle
                    if(colliderSetProperties_fixedAngle.Draw(ref colliderSet.fixedAngle)) {
                        unsavedChanges = true;
                    }

                    // interpolation
                    int interpolation2DInt = colliderSet.interpolation2D;
                    if(colliderSetProperties_rigidbodyInterpolation2D.DrawByValue(interpolation2DInt)) {
                        Enums.VersionRestrictedType eType = Enums.VersionRestrictedType.RigidbodyInterpolation2D;
                        System.Type type = SpriteFactory.Utils.UnityTools.GetVersionRestrictedType(eType);
                        if(type == null) throw new System.Exception(eType.ToString() + " not found! 2D colliders are only compatible with Unity 4.3+!");
                        colliderSet.interpolation2D = colliderSetProperties_rigidbodyInterpolation2D.selectionValue;
                        unsavedChanges = true;
                    }

                    // sleepMode
                    int sleepMode2DInt = colliderSet.sleepMode2D;
                    if(colliderSetProperties_sleepMode2D.DrawByValue(sleepMode2DInt)) {
                        Enums.VersionRestrictedType eType = Enums.VersionRestrictedType.RigidbodySleepMode2D;
                        System.Type type = SpriteFactory.Utils.UnityTools.GetVersionRestrictedType(eType);
                        if(type == null) throw new System.Exception(eType.ToString() + " not found! 2D colliders are only compatible with Unity 4.3+!");
                        colliderSet.sleepMode2D = colliderSetProperties_sleepMode2D.selectionValue;
                        unsavedChanges = true;
                    }

                    // collisionDetectionMode
                    int collisionDetectionMode2DInt = colliderSet.collisionDetectionMode2D;
                    if(colliderSetProperties_collisionDetectionMode2D.DrawByValue(collisionDetectionMode2DInt)) {
                        Enums.VersionRestrictedType eType = Enums.VersionRestrictedType.CollisionDetectionMode2D;
                        System.Type type = SpriteFactory.Utils.UnityTools.GetVersionRestrictedType(eType);
                        if(type == null) throw new System.Exception(eType.ToString() + " not found! 2D colliders are only compatible with Unity 4.3+!");
                        colliderSet.collisionDetectionMode2D = colliderSetProperties_collisionDetectionMode2D.selectionValue;
                        unsavedChanges = true;
                    }
                }
            }
            Utils.GUITools.Engine.SwitchToAutoWidth(); // revert
        }

        private void DrawColliderGroupListBox(float colWidth, float height) {
            if(!loaded) return;

            Utils.GUITools.Layout.Label(help_colliderGroups);

            // Load collider sets
            Sprite.ColliderGroup[] objectList = masterSpriteData.colliderGroups;
            int itemCount = objectList == null ? 0 : objectList.Length;

            // Create list of items to populate list box
            string[] nameList = null;
            if(itemCount > 0) {
                nameList = new string[itemCount];
                for(int i = 0; i < itemCount; i++) {
                    nameList[i] = i + ": " + objectList[i].name;
                }
            }

            // Draw the list box
            DrawListBox(colliderGroupListBoxContainer, itemCount, objectList, nameList, "There are no collider groups.", false, colWidth, height);

            // Draw buttons
            DrawColliderGroupListBoxButtons(colliderGroupListBoxContainer, colWidth, "Group");

            // Clear collider set selection if selecting a group
            if(colliderGroupListBoxContainer.selectionChanged) {
                colliderSetListBoxContainer.ClearSelection();
            }
        }

        private void DrawColliderGroupListBoxButtons(SimpleGUIListBoxContainer<Sprite.ColliderGroup> container, float colWidth, string objectName = "item") {
            if(!loaded) return;

            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            GUIContent buttonContent;
            bool changed = false;
            bool isObjectSelected = false;
            Sprite.ColliderGroup colliderGroup = container.selectedObject;
            int selectionIndex = container.selectedIndex;
            if(container.hasSelection && colliderGroup != null) isObjectSelected = true;
            bool guiEnabled = GUI.enabled; // get current state of GUI

            GUI.enabled = guiEnabled && isObjectSelected && masterSpriteData.ReorderColliderGroup(selectionIndex, -1, false);
            buttonContent = new GUIContent("UP", "Move selected " + objectName + " up");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(masterSpriteData.ReorderColliderGroup(selectionIndex, -1)) {
                    container.ChangeSelection(container.selectedIndex - 1);
                    changed = true;
                }
            }

            GUI.enabled = guiEnabled && isObjectSelected && masterSpriteData.ReorderColliderGroup(selectionIndex, 1, false);
            buttonContent = new GUIContent("DN", "Move selected " + objectName + " down");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(masterSpriteData.ReorderColliderGroup(selectionIndex, 1)) {
                    container.ChangeSelection(container.selectedIndex + 1);
                    changed = true;
                }
            }

            GUILayout.Space(10);

            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state
            buttonContent = new GUIContent("+", "Add new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.AddNewColliderGroup();
                changed = true;
            }

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Ins", "Insert new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.InsertNewColliderGroup(selectionIndex);
                container.ChangeSelection(selectionIndex); // select the new inserted material
                changed = true;
            }

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Dup", "Duplicate " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.DuplicateColliderGroup(selectionIndex);
                changed = true;
            }

            GUILayout.Space(10);

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("DEL", "Delete " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(EditorUtility.DisplayDialog("Delete " + objectName, "Are you sure you want to delete this " + objectName + "?", "Delete " + objectName, "Cancel")) {
                    masterSpriteData.DeleteColliderGroup(selectionIndex); // delete group and child sprites
                    changed = true;
                    container.DeleteSelected(); // // clear the entry from the container
                }
            }

            Utils.GUITools.EditorLayout.EndHorizontal();

            if(changed) {
                container.refresh = true; // flag refresh of list info
                unsavedChanges = true;
            }

            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state
        }

        private void DrawColliderGroupProperties(float colWidth, float labelWidth, float controlWidth) {
            if(colliderGroupListBoxContainer.selectedIndex < 0) {
                //ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            Sprite.ColliderGroup colliderGroup = colliderGroupListBoxContainer.selectedObject;
            if(colliderGroup == null) {
                //ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            int colliderSetIndex = colliderSetListBoxContainer.selectedIndex;
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth); // set width of labels/controls
            bool guiEnabled = GUI.enabled; // get current state of GUI

            Utils.GUITools.Layout.Label("Collider Group Properties");

            // Name
            string groupName = colliderGroup.name;
            if(colliderGroupProperties_name.Draw(ref groupName)) {
                colliderGroup.name = masterSpriteData.VerifyColliderGroupName(groupName, colliderGroupListBoxContainer.selectedIndex);
                unsavedChanges = true;
            }

            // Group collisions
            /*
            bool useGroupCollisions = colliderGroup.useGroupCollisions;
            if(colliderGroupProperties_useGroupCollisions.Draw(ref useGroupCollisions)) {
                colliderGroup.useGroupCollisions = useGroupCollisions;
                unsavedChanges = true;
            }
            */

            Utils.GUITools.Engine.SwitchToAutoWidth(); // revert
        }

        private void DrawLocatorSetListBox(float colWidth, float height) {
            if(!loaded) return;

            Utils.GUITools.Layout.Label(help_locators);

            // Load locator sets
            Sprite.LocatorSet[] objectList = masterSpriteData.locatorSets;
            int itemCount = objectList == null ? 0 : objectList.Length;

            // Create list of items to populate list box
            string[] nameList = null;
            if(itemCount > 0) {
                nameList = new string[itemCount];
                for(int i = 0; i < itemCount; i++) {
                    nameList[i] = i + ": " + objectList[i].name;
                }
            }

            // Make sure something is selected - Select 0 if nothing is selected
            if(Event.current.type == EventType.layout) {
                if(!locatorSetListBoxContainer.hasSelection) {
                    locatorSetListBoxContainer.ChangeSelection(0);
                }
            }

            // Draw the list box
            DrawListBox(locatorSetListBoxContainer, itemCount, objectList, nameList, "There are no locators in this sprite.", false, colWidth, height);

            // Draw buttons
            DrawLocatorSetListBoxButtons(locatorSetListBoxContainer, colWidth, "Locator");

            refreshLocatorFrameProperties = true; // force locator frames to refresh every cycle the window is open
        }

        private void DrawLocatorSetListBoxButtons(SimpleGUIListBoxContainer<Sprite.LocatorSet> container, float colWidth, string objectName = "item") {
            if(!loaded) return;

            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            GUIContent buttonContent;
            bool changed = false;
            bool isObjectSelected = false;
            Sprite.LocatorSet locatorSet = container.selectedObject;
            int selectionIndex = container.selectedIndex;
            if(container.hasSelection && locatorSet != null) isObjectSelected = true;
            bool guiEnabled = GUI.enabled; // get current state of GUI

            GUI.enabled = guiEnabled && isObjectSelected && masterSpriteData.ReorderLocatorSet(selectionIndex, -1, false);
            buttonContent = new GUIContent("UP", "Move selected " + objectName + " up");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(masterSpriteData.ReorderLocatorSet(selectionIndex, -1)) {
                    container.ChangeSelection(container.selectedIndex - 1);
                    changed = true;
                }
            }

            GUI.enabled = guiEnabled && isObjectSelected && masterSpriteData.ReorderLocatorSet(selectionIndex, 1, false);
            buttonContent = new GUIContent("DN", "Move selected " + objectName + " down");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(masterSpriteData.ReorderLocatorSet(selectionIndex, 1)) {
                    container.ChangeSelection(container.selectedIndex + 1);
                    changed = true;
                }
            }

            GUILayout.Space(10);

            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state
            buttonContent = new GUIContent("+", "Add new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.AddNewLocatorSet();
                changed = true;
            }

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Ins", "Insert new " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.InsertNewLocatorSet(selectionIndex);
                container.ChangeSelection(selectionIndex); // select the new inserted material
                changed = true;
            }

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Dup", "Duplicate " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                masterSpriteData.DuplicateLocatorSet(selectionIndex);
                changed = true;
            }

            GUILayout.Space(10);

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("DEL", "Delete " + objectName);
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(EditorUtility.DisplayDialog("Delete " + objectName, "Are you sure you want to delete this " + objectName + "?", "Delete " + objectName, "Cancel")) {
                    masterSpriteData.DeleteLocatorSet(selectionIndex); // delete group and child sprites
                    changed = true;
                    container.DeleteSelected(); // // clear the entry from the container
                }
            }

            Utils.GUITools.EditorLayout.EndHorizontal();

            if(changed) {
                container.refresh = true; // flag refresh of list info
                unsavedChanges = true;
            }

            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state
        }

        private void DrawLocatorSetProperties(float colWidth, float labelWidth, float controlWidth) {
            if(locatorSetListBoxContainer.selectedIndex < 0) {
                ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            Sprite.LocatorSet locatorSet = locatorSetListBoxContainer.selectedObject;
            if(locatorSet == null) {
                ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            //int locatorSetIndex = locatorSetListBoxContainer.selectedIndex;
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, controlWidth); // set width of labels/controls

            Utils.GUITools.Layout.Label("Properties");

            // Name
            string setName = locatorSet.name;
            if(locatorSetProperties_name.Draw(ref setName)) {
                locatorSet.name = masterSpriteData.VerifyLocatorSetName(setName, locatorSetListBoxContainer.selectedIndex);
                unsavedChanges = true;
            }

            // Preview color
            if(locatorSetProperties_previewColor.Draw(ref locatorSet.previewColor)) {
                unsavedChanges = true;
            }

            // Default Forward Vector
            if(locatorSetProperties_defaultToPosXIsForward.Draw(ref locatorSet.defaultToPosXIsForward)) {
                unsavedChanges = true;
            }

            if(locatorSetProperties_defaultOffsetZ.Draw(ref locatorSet.defaultOffsetZ)) {
                unsavedChanges = true;
            }

            Utils.GUITools.Engine.SwitchToAutoWidth(); // revert
        }

        private void DrawExportGroupsListBox(float colWidth, float height) {
            SimpleGUIListBoxContainer<int> container = export_groupsListBoxContainer;
            bool guiEnabled = GUI.enabled; // get current state of GUI

            int[] objectList = exporter.groupIndices;
            string[] nameList = exporter.groupNames;
            int itemCount = objectList == null ? 0 : objectList.Length;

            // Label the list box
            Utils.GUITools.EditorLayout.Label(new GUIContent("Sprite Groups -->", "Exporting a Sprite Group will export all sprites within that group."));
            GUILayout.Space(6.0f);

            // Draw the list box
            DrawListBox(container, itemCount, objectList, nameList, "There are no Sprite Groups.", false, colWidth, height);

            // Draw the buttons below the list box
            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            GUIContent buttonContent;
            bool isObjectSelected = false;
            if(container.hasSelection && container.selectedObject >= 0) isObjectSelected = true;
            int groupIndex = container.selectedObject;

            GUI.enabled = guiEnabled && container.itemCount > 0;
            buttonContent = new GUIContent("Add All", "Add all to export list");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                exporter.AddAllGroupsToExportList();
                container.Clear();
                container.changed = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state

            GUILayout.Space(50.0f);

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Add", "Add selected to export list");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                exporter.AddGroupToExportList(container.selectedIndex);
                container.DeleteSelected();
                container.changed = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            Utils.GUITools.EditorLayout.EndHorizontal();
        }

        private void DrawExportSpritesListBox(float colWidth, float height) {
            SimpleGUIListBoxContainer<int> container = export_ungroupedSpritesListBoxContainer;
            bool guiEnabled = GUI.enabled; // get current state of GUI

            int[] objectList = exporter.spriteIndices;
            string[] nameList = exporter.spriteNames;
            int itemCount = objectList == null ? 0 : objectList.Length;

            // Label the list box
            Utils.GUITools.EditorLayout.Label("Ungrouped Master Sprites -->");
            GUILayout.Space(6.0f);

            // Draw the list box
            DrawListBox(container, itemCount, objectList, nameList, "There are no Master Sprites.", false, colWidth, height);

            // Draw the buttons below the list box
            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            GUIContent buttonContent;
            bool isObjectSelected = false;
            if(container.hasSelection && container.selectedObject >= 0) isObjectSelected = true;
            int groupIndex = container.selectedObject;

            GUI.enabled = guiEnabled && container.itemCount > 0;
            buttonContent = new GUIContent("Add All", "Add all to export list");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                exporter.AddAllSpritesToExportList();
                container.Clear();
                container.changed = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            GUILayout.Space(50.0f);

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Add", "Add selected to export list");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                exporter.AddSpriteToExportList(container.selectedIndex);
                container.DeleteSelected();
                container.changed = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            Utils.GUITools.EditorLayout.EndHorizontal();
        }

        private void DrawExportGroupsToExportListBox(float colWidth, float height) {
            SimpleGUIListBoxContainer<int> container = export_groupsListBoxContainer_ToExport;
            bool guiEnabled = GUI.enabled; // get current state of GUI

            int[] objectList = exporter.groupIndicesToExport;
            string[] nameList = exporter.groupNamesToExport;
            int itemCount = objectList == null ? 0 : objectList.Length;

            // Label the list box
            Utils.GUITools.EditorLayout.Label("Sprite Groups to be Exported");
            GUILayout.Space(6.0f);

            // Draw the list box
            DrawListBox(container, itemCount, objectList, nameList, "Please add a Sprite Group to export.", false, colWidth, height);

            // Draw the buttons below the list box
            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            GUIContent buttonContent;
            bool isObjectSelected = false;
            if(container.hasSelection && container.selectedObject >= 0) isObjectSelected = true;
            int groupIndex = container.selectedObject;

            GUI.enabled = guiEnabled && container.itemCount > 0;
            buttonContent = new GUIContent("Remove All", "Remove all from export list");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                exporter.RemoveAllGroupsFromExportList();
                container.Clear();
                container.changed = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            GUILayout.Space(50.0f);

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Remove", "Remove selected from export list");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                exporter.RemoveGroupFromExportList(container.selectedIndex);
                container.DeleteSelected();
                container.changed = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            Utils.GUITools.EditorLayout.EndHorizontal();
        }

        private void DrawExportSpritesToExportListBox(float colWidth, float height) {
            SimpleGUIListBoxContainer<int> container = export_ungroupedSpritesListBoxContainer_ToExport;
            bool guiEnabled = GUI.enabled; // get current state of GUI

            int[] objectList = exporter.spriteIndicesToExport;
            string[] nameList = exporter.spriteNamesToExport;
            int itemCount = objectList == null ? 0 : objectList.Length;

            // Label the list box
            Utils.GUITools.EditorLayout.Label("Master Sprites to be Exported");
            GUILayout.Space(6.0f);

            // Draw the list box
            DrawListBox(container, itemCount, objectList, nameList, "Please add a Master Sprite to export.", false, colWidth, height);

            // Draw the buttons below the list box
            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Width(colWidth), GUILayout.Height(buttonRowHeight));

            GUIContent buttonContent;
            bool isObjectSelected = false;
            if(container.hasSelection && container.selectedObject >= 0) isObjectSelected = true;
            int groupIndex = container.selectedObject;

            GUI.enabled = guiEnabled && container.itemCount > 0;
            buttonContent = new GUIContent("Remove All", "Remove all from export list");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                exporter.RemoveAllSpritesFromExportList();
                container.Clear();
                container.changed = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            GUILayout.Space(50.0f);

            GUI.enabled = guiEnabled && isObjectSelected;
            buttonContent = new GUIContent("Remove", "Remove selected from export list");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                exporter.RemoveSpriteFromExportList(container.selectedIndex);
                container.DeleteSelected();
                container.changed = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            Utils.GUITools.EditorLayout.EndHorizontal();
        }

        private void DrawExportOptions() {
            Utils.GUITools.Engine.SwitchToFixedWidth(240.0f);
            export_exportPrefabs.Draw(ref exporter.exportPrefabs);
            Utils.GUITools.Engine.SwitchToAutoWidth(); // revert
        }

        private void DrawExportWindowButtons() {
            Utils.GUITools.EditorLayout.BeginHorizontal();
            bool guiEnabled = GUI.enabled;

            if(Utils.GUITools.Layout.Button("Cancel")) {
                CloseInnerWindows();
            }

            GUILayout.Space(25.0f);

            GUI.enabled = guiEnabled && (export_ungroupedSpritesListBoxContainer_ToExport.itemCount > 0 || export_groupsListBoxContainer_ToExport.itemCount > 0);
            if(Utils.GUITools.Layout.Button("Export")) {
                string savePath = EditorUtility.SaveFilePanel("Export Sprite Factory Package", "", "SpriteFactoryExport", exportTextExtensionNoDot);
                if(savePath != "") {
                    CloseInnerWindows();
                    exporter.savePath = savePath;
                    export = true;
                    busy = true;
                }
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            Utils.GUITools.EditorLayout.EndHorizontal();
        }

        private void DrawImportWarnings() {
            // Write out errors
            Utils.GUITools.Layout.Label("Import warnings / errors:", style_importerOutput);
            DrawSectionSpacer(8.0f);

            if(importer.status == -1) { // critical errors
                Utils.GUITools.Layout.Label("Import data has critical errors and cannot be imported. Fix the problems by either making changes in the source project and reexporting or making changes in this project and reimporting. Please see the documentation for help with the export/import process.", style_importerOutput);
                DrawSectionSpacer(8.0f);
            } else if(importer.status == 0) { // minor errors
                Utils.GUITools.Layout.Label("Import data has some issues that may affect sprite and group importing. You can still import the data, but you may encounter problems with imported sprites, groups, or prefabs. Please see the documentation for help with the export/import process.", style_importerOutput);
                DrawSectionSpacer(8.0f);
            }

            if(importer.errorCount > 0) {
                for(int i = 0; i < importer.errorCount; i++) {
                    string text = importer.errors[i];

                    int errorLevel = importer.errorLevels[i];
                    if(errorLevel > 0) {
                        Color oldColor = GUI.color; // store GUI color
                        if(errorLevel == 1) { // warning
                            GUI.color = Color.yellow;
                            Utils.GUITools.Layout.Label("WARNING:");
                        } else { // critical error
                            GUI.color = Color.red;
                            Utils.GUITools.Layout.Label("CRITICAL ERROR!");
                        }
                        GUI.color = oldColor; // restore GUI color
                    }
                    Utils.GUITools.Layout.Label(text, style_importerOutput);
                    GUILayout.Space(10.0f);
                }
            } else {
                Utils.GUITools.Layout.Label("There are no warnings or errors.", style_importerOutput);
            }

            // Write out files which will be imported
            DrawSectionSpacer(8.0f);
            Utils.GUITools.Layout.Label("Assets included in this package:", style_importerOutput);
            DrawSectionSpacer(8.0f);
            if(importer.uniqueAssetCount > 0) {
                for(int i = 0; i < importer.uniqueAssetCount; i++) {
                    Utils.GUITools.Layout.Label(importer.uniqueAssetPaths[i], style_importerOutput);
                }
            } else {
                Utils.GUITools.Layout.Label("There are no assets to import.", style_importerOutput);
            }
        }

        private void DrawImportWindowButtons() {
            Utils.GUITools.EditorLayout.BeginHorizontal();
            bool guiEnabled = GUI.enabled;

            if(Utils.GUITools.Layout.Button("Cancel")) {
                CloseInnerWindows();
            }

            GUILayout.Space(25.0f);

            GUI.enabled = guiEnabled && importer.status >= 0 && importer.fileCount > 0;
            if(Utils.GUITools.Layout.Button("Import")) {
                if(EditorUtility.DisplayDialog("Import", "WARNING: Make a backup of your entire project before proceeding!\nAfter the import, the data file, sprites, and sprite groups will be rebuilt. This may take a very long time. Are you sure?", "Import", "Cancel")) {
                    CloseInnerWindows();
                    ClearCurrentSpriteListSelection(); // drop the selections immediately
                    ClearCurrentGroupListSelection();
                    import = true;
                    busy = true;
                }
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore the GUI state

            Utils.GUITools.EditorLayout.EndHorizontal();
        }

        #region Drawing Helpers

        private void DrawListBox<T>(SimpleGUIListBoxContainer<T> container, int itemCount, T[] itemList, string[] nameList, string emptyMsg, bool displayIndex, float colWidth, float rowHeight, bool pushSelection = false, int pushedSelectionIndex = -1) {
            if(!loaded) {
                ColumnFiller(colWidth); // force column to not collapse
                return;
            }

            container.Draw(itemCount, itemList, nameList, emptyMsg, displayIndex, colWidth, rowHeight, pushSelection, pushedSelectionIndex);

        }

        private void DrawSectionSpacer(float size = 10.0f) {
            GUILayout.Space(size);
        }

        private void ColumnFiller(float width) { // a hack to make sure column width shows up even when no controls are drawn
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(width));
            Utils.GUITools.Layout.Label("");
            Utils.GUITools.EditorLayout.EndVertical();
        }

        #endregion

        #endregion

        #region Windows

        // Window Functions

        private void DrawInnerWindow() {
            if(openWindowId < 0) return;

            string windowTitle = string.Empty;
            bool scrollableWindow = false;
            float width = 200.0f;
            float height = 200.0f;

            // Set variables for specific open window
            if(openWindowId == 0) { // material set editor
                windowTitle = "Material Set Editor";
                width = 550.0f;
                RenderWindow = MaterialSetEditorWindow;
                scrollableWindow = false;
            } else if(openWindowId == 1) { // collider editor
                windowTitle = "Collider Editor";
                width = 615.0f;
                RenderWindow = ColliderEditorWindow;
                scrollableWindow = false;
            } else if(openWindowId == 2) { // editor properties
                windowTitle = "Editor Properties";
                width = 300.0f;
                RenderWindow = EditorPropertiesWindow;
                scrollableWindow = false;
            } else if(openWindowId == 3) { // sprite more settings
                windowTitle = "More Sprite Settings";
                width = 250.0f;
                RenderWindow = MoreSpriteSettingsWindow;
                scrollableWindow = false;
            } else if(openWindowId == 4) { // choose colliders to display window
                windowTitle = "Collider Preview";
                width = 250.0f;
                RenderWindow = ColliderDisplayFilterWindow;
                scrollableWindow = true;
                height = 300.0f;
            } else if(openWindowId == 5) { // locator set window
                windowTitle = "Locator Editor";
                width = 615.0f;
                RenderWindow = LocatorSetEditorWindow;
                scrollableWindow = false;
            } else if(openWindowId == 6) { // export window
                windowTitle = "Export";
                width = 580.0f;
                RenderWindow = ExportWindow;
                scrollableWindow = false;
            } else if(openWindowId == 7) { // import window
                windowTitle = "Import";
                width = 625.0f;
                RenderWindow = ImportWindow;
                scrollableWindow = false;
            } else if(openWindowId == 8) { // more utilities window
                windowTitle = "More Utilities";
                width = 250.0f;
                RenderWindow = MoreUtilitiesWindow;
                scrollableWindow = false;
            }

            DrawOverlay(); // grey out background elements
            mainPageEnabled = false; // disable all controls on the main page

            // Draw window
            // REMOVED TRY / CATCH WRAPPER BECAUSE IT CAUSES ERRORS TO BE THROWN BY OBJECTFIELD PICKERS -- CANNOT BE SILENCED ON MAC
            //try { // we have to catch an exception here that can occur when DisplayDialog is closed too quickly causing OnGUI to be interrupted.
                BeginWindows();
            //} catch {
            //    Debug.LogWarning("Exception encountered when drawing a window! This exception is the result of a bug in EditorUtility.DisplayDialog. This is a Unity bug and should not cause any problems with the functioning of Sprite Factory or the safety of your data.");
                //Debug.Log(e.StackTrace);
            //}

            GUI.enabled = !busy; // make sure GUI is enabled for this window
            if(scrollableWindow) // window scrolls, must set a height for it
                innerWindowRect = GUILayout.Window(openWindowId, innerWindowRect, ShowWindow, windowTitle, GUILayout.Width(width), GUILayout.Height(height));
            else // not scrollable, use automatic height
                innerWindowRect = GUILayout.Window(openWindowId, innerWindowRect, ShowWindow, windowTitle, GUILayout.Width(width));
            GUI.enabled = mainPageEnabled; // disable GUI again
            EndWindows();

            GUI.FocusWindow(openWindowId); // focus this window
            GUI.BringWindowToFront(openWindowId); // bring to front just in case
        }

        private void DrawOverlay() {
            // Find inner rect of scroll view so it fills the whole scrollable area and not just the window
            Utils.GUITools.EditorLayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            Utils.GUITools.EditorLayout.EndHorizontal();
            if(Event.current.type == EventType.repaint) {
                pageRect = GUILayoutUtility.GetLastRect();
            }

            float width = pageRect.width;
            float height = pageRect.yMin;

            // If scroll rect doesn't fill the current window, use the window dimensions instead
            if(width < Screen.width) width = Screen.width;
            if(height < Screen.height) height = Screen.height;

            SpriteFactory.Utils.GUITools.Solid.Draw(new Rect(0, 0, width, height), overlayColor); // draw overlay color all over screen
        }

        private void OpenInnerWindow(int id) {
            CloseInnerWindows();
            openWindowId = id;
            refreshInnerWindow = true;
            windowJustOpened = true;
        }

        private void CloseInnerWindows() {
            RenderWindow = null;
            openWindowId = -1;
            windowJustOpened = false;
            mainPageEnabled = true;
            innerWindowRect.width = 0.0f; // this will be set by the specific window
            innerWindowRect.height = 0.0f; // this will be automatically set
            innerWindowScrollers = new Vector2[10]; // clear the scroll pos array
        }

        private void OverrideCursorForInnerWindows() {
            if(openWindowId < 0) return;
            EditorGUIUtility.AddCursorRect(new Rect(0.0f, 0.0f, Screen.width, Screen.height), MouseCursor.Arrow); // set default arrow cursor
        }

        private void RecordOpenWindowPosition(int windowId) {
            if(windowId != openWindowId) return;
            if(Event.current.type != EventType.repaint) return; // must set the position only in the repaint event or else the window will look like its in the right place, but it will really be at 0,0
            // record the GUILayout position rect so we can draw the window here later
            Rect layoutRect = GUILayoutUtility.GetLastRect();
            innerWindowRect.x = layoutRect.x;
            innerWindowRect.y = layoutRect.y;
        }

        private void DrawCloseWindow() {
            DrawSectionSpacer(20.0f);
            if(Utils.GUITools.Layout.Button("Close Window")) {
                CloseInnerWindows();
            }
            GUILayout.Space(8.0f);
        }

        private float GetLayoutWidth() {
            Utils.GUITools.EditorLayout.BeginVertical();
            GUILayout.FlexibleSpace();
            Utils.GUITools.EditorLayout.EndVertical();
            Rect windowSize = GUILayoutUtility.GetLastRect();
            return windowSize.width;
        }

        private void ShowWindow(int windowId) {
            if(RenderWindow == null) return; // no window function has been set

            Utils.GUITools.EditorLayout.BeginWindow();
            RenderWindow(windowId);
            Utils.GUITools.EditorLayout.EndWindow();
        }

        // Window Contents

        private void EditorPropertiesWindow(int windowId) {
            if(openWindowId != 2) return; // prevent Unity bug where it runs the last opened window for 1 frame before showing the new open window
            if(windowJustOpened) windowJustOpened = false;
            if(refreshInnerWindow) {
                refreshInnerWindow = false;
                refreshEditorPropertiesControls = true;
            }
            bool origGUIEnabled = GUI.enabled;

            float windowWidth = GetLayoutWidth();
            float labelWidth = 150.0f;
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, windowWidth - labelWidth); // set width of labels/controls
            bool guiEnabled = GUI.enabled && !busy; // disable GUI if busy
            GUI.enabled = guiEnabled; // set current gui state

            bool changed = false;

            if(refreshEditorPropertiesControls) {
                editorProperties_pixelsPerUnit.refresh = true;
                editorProperties_trimSprites.refresh = true;
                editorProperties_framePadding.refresh = true;
                editorProperties_maxAtlasSize.refresh = true;
                editorProperties_forceSquareAtlases.refresh = true;
                editorProperties_defaultUseMipMaps.refresh = true;
                editorProperties_defaultUseTextureCompression.refresh = true;
                //editorProperties_atlasPackingMethod.refresh = true;
                editorProperties_resolutionTarget.refresh = true;
                editorProperties_resolutionTargetResamplingMode.refresh = true;
                editorProperties_defaultMaterial.refresh = true;
                editorProperties_defaultFilterMode.refresh = true;
                editorProperties_defaultAnisoLevel.refresh = true;
                editorProperties_defaultUseTwoSidedMesh.refresh = true;
                editorProperties_defaultUse2DColliders.refresh = true;
                editorProperties_defaultMeshType.refresh = true;
                //editorProperties_defaultAutoMeshTransparencyChannel.refresh = true;
                editorProperties_defaultAutoMeshEdgeExtrude.refresh = true;
                editorProperties_defaultAutoMeshVertexReductionDistance.refresh = true;
                editorProperties_rebuildSpriteOnSave.refresh = true;
                editorProperties_rebuildSpriteGroupOnSave.refresh = true;
                refreshEditorPropertiesControls = false;
            }

            Utils.GUITools.Layout.Label("Global Settings");
            GUILayout.Space(2.0f);

            // Pixels Per Unit
            int pixelsPerUnit = editorProperties.pixelsPerUnit;
            if(editorProperties_pixelsPerUnit.Draw(ref pixelsPerUnit)) {
                editorProperties.pixelsPerUnit = pixelsPerUnit; // update the data
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            GUILayout.Space(10.0f);
            Utils.GUITools.Layout.Label("Atlas Generation Settings");
            GUILayout.Space(2.0f);

            // Max Atlas Size
            int maxAtlasSize = editorProperties.maxAtlasSize;
            int entryNum;
            if(maxAtlasSize == 128) entryNum = 0;
            else if(maxAtlasSize == 256) entryNum = 1;
            else if(maxAtlasSize == 512) entryNum = 2;
            else if(maxAtlasSize == 1024) entryNum = 3;
            else if(maxAtlasSize == 2048) entryNum = 4;
            else entryNum = 5; // 4096
            if(editorProperties_maxAtlasSize.Draw(entryNum)) {
                int selection = editorProperties_maxAtlasSize.selectionIndex;
                int newSize;
                if(selection == 0) newSize = 128;
                else if(selection == 1) newSize = 256;
                else if(selection == 2) newSize = 512;
                else if(selection == 3) newSize = 1024;
                else if(selection == 4) newSize = 2048;
                else newSize = 4096; // 5
                editorProperties.maxAtlasSize = newSize; // update the data
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // Force Square Atlases
            bool forceSquareAtlases = editorProperties.forceSquareAtlases;
            if(editorProperties_forceSquareAtlases.Draw(ref forceSquareAtlases)) {
                editorProperties.forceSquareAtlases = forceSquareAtlases; // update the data
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // Trim Sprites
            bool trimSprites = editorProperties.trimSprites;
            if(editorProperties_trimSprites.Draw(ref trimSprites)) {
                editorProperties.trimSprites = trimSprites; // update the data
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // Frame Padding
            int framePadding = editorProperties.framePadding;
            if(editorProperties_framePadding.Draw(ref framePadding)) {
                editorProperties.framePadding = framePadding; // update the data
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // Create Mip Maps
            bool useMipMaps = editorProperties.useMipMaps;
            if(editorProperties_defaultUseMipMaps.Draw(ref useMipMaps)) {
                editorProperties.useMipMaps = useMipMaps; // update the data
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // Compress Textures
            bool useTextureCompression = editorProperties.useTextureCompression;
            if(editorProperties_defaultUseTextureCompression.Draw(ref useTextureCompression)) {
                editorProperties.useTextureCompression = useTextureCompression; // update the data
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // Atlas Packing Method
            //int selectionValue = (int)editorProperties.atlasPackingMethod;
            //if(editorProperties_atlasPackingMethod.DrawByValue(selectionValue)) {
            //    editorProperties.atlasPackingMethod = (SpriteFactory.AtlasPackingMethod)editorProperties_atlasPackingMethod.selectionValue;
            //    changed = true;
            //    changeType |= EditorPropertyChangeType.Atlases;
            //}

            // Default Filter Mode
            int filterMode = (int)editorProperties.defaultFilterMode;
            if(editorProperties_defaultFilterMode.DrawByValue(filterMode)) {
                editorProperties.defaultFilterMode = (FilterMode)editorProperties_defaultFilterMode.selectionValue; // update data
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // Default Aniso Level -- allow enabled even if not in the right mode so they can set aniso default
            int anisoLevel = editorProperties.defaultAnisoLevel;
            if(editorProperties_defaultAnisoLevel.Draw(ref anisoLevel)) {
                editorProperties.defaultAnisoLevel = anisoLevel; // update the data
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // Resolution Target
            int resolutionTarget = (int)editorProperties.resolutionTarget;
            if(editorProperties_resolutionTarget.DrawByValue(resolutionTarget)) {
                editorProperties.resolutionTarget = (Enums.ResolutionTarget)editorProperties_resolutionTarget.selectionValue;
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // Resolution Target Resampling Mode
            int resolutionTargetResamplingMode = (int)editorProperties.resolutionTargetResamplingMode;
            if(editorProperties_resolutionTargetResamplingMode.DrawByValue(resolutionTargetResamplingMode)) {
                editorProperties.resolutionTargetResamplingMode = (Enums.ImageResamplingMode)editorProperties_resolutionTargetResamplingMode.selectionValue;
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // New default style DOES require rebuilding, sometimes just materials, sometimes atlases too

            GUILayout.Space(10.0f);
            Utils.GUITools.Layout.Label("Default Settings");
            GUILayout.Space(2.0f);

            // Default Material
            Object defaultMaterial = editorProperties.defaultMaterial;
            if(editorProperties_defaultMaterial.Draw(ref defaultMaterial)) {
                editorProperties.defaultMaterial = (Material)editorProperties_defaultMaterial.value;
                if(editorProperties.defaultMaterial == null) { // material was set none
                    editorProperties.defaultMaterial = db.defaultSpriteMaterial; // use true default material
                    editorProperties_defaultMaterial.refresh = true;
                    Debug.LogWarning("Default Sprite Material cannot be set to none! Substituting the original default material.");
                } else {
                    if(!db.CheckMaterialForCompatibility(editorProperties.defaultMaterial)) {
                        Debug.LogWarning("Substituting the original default material.");
                        editorProperties.defaultMaterial = db.defaultSpriteMaterial; // use true default material
                        editorProperties_defaultMaterial.refresh = true;
                    }
                }
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Materials;
            }

            // Default Two-sided Mesh
            if(editorProperties_defaultUseTwoSidedMesh.Draw(ref editorProperties.defaultUseTwoSidedMesh)) {
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases; // Could change this to meshes only at some point
            }

            // Default Mesh Type
            if(editorProperties_defaultMeshType.DrawByValue((int)editorProperties.defaultMeshType)) {
                editorProperties.defaultMeshType = (SpriteFactory.Enums.SpriteMeshType)editorProperties_defaultMeshType.selectionValue;
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases; // Could change this to meshes only at some point
            }

            /*// Default Mesh Generation Transparency Channel
            if(editorProperties_defaultAutoMeshTransparencyChannel.DrawByValue((int)editorProperties.defaultAutoMeshTransparencyChannel)) {
                editorProperties.defaultAutoMeshTransparencyChannel = (SpriteFactory.Enums.ColorChannel)editorProperties_defaultAutoMeshTransparencyChannel.selectionValue;
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases; // Could change this to meshes only at some point
            }*/

            // Default auto mesh edge extrusion
            int extrude = editorProperties.defaultAutoMeshEdgeExtrude;
            if(editorProperties_defaultAutoMeshEdgeExtrude.Draw(ref extrude)) {
                editorProperties.defaultAutoMeshEdgeExtrude = extrude; // update the data
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // Default auto mesh edge extrusion
            int reductionDistance = editorProperties.defaultAutoMeshVertexReductionDistance;
            if(editorProperties_defaultAutoMeshVertexReductionDistance.Draw(ref reductionDistance)) {
                editorProperties.defaultAutoMeshVertexReductionDistance = reductionDistance; // update the data
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.Atlases;
            }

            // SPECIAL - these properties are defaults and do not cause atlas rebuilding

            // Default 2D Colliders
            if(!SpriteFactory.Utils.UnityTools.supports2DColliders) GUI.enabled = false; // only allow 2D collider settings in Unity 4.3+
            if(editorProperties_defaultUse2DColliders.Draw(ref editorProperties.defaultUse2DColliders)) {
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.None;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state

            GUILayout.Space(10.0f);
            Utils.GUITools.Layout.Label("Preferences");
            GUILayout.Space(2.0f);

            // Rebuild Sprite Atlases on save
            int selectionValue = (int)editorProperties.rebuildSpriteOnSave;
            if(editorProperties_rebuildSpriteOnSave.DrawByValue(selectionValue)) {
                editorProperties.rebuildSpriteOnSave = (SpriteFactory.AutomaticActionPolicy)editorProperties_rebuildSpriteOnSave.selectionValue;
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.None;
            }

            // Rebuild Sprite Group Atlases on save
            selectionValue = (int)editorProperties.rebuildSpriteGroupOnSave;
            if(editorProperties_rebuildSpriteGroupOnSave.DrawByValue(selectionValue)) {
                editorProperties.rebuildSpriteGroupOnSave = (SpriteFactory.AutomaticActionPolicy)editorProperties_rebuildSpriteGroupOnSave.selectionValue;
                changed = true;
                editorPropertyChangeType |= EditorPropertyChangeType.None;
            }

            Utils.GUITools.Engine.SwitchToAutoWidth(); // revert

            // Version label
            GUI.enabled = false;
            DrawSectionSpacer();
            Utils.GUITools.EditorLayout.Label("Sprite Factory Version: " + programVersion);
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state

            // Handle changes
            if(changed) unappliedEditorPropertiesChanges = true;

            // Detect if we have a hard change
            bool hardChange = false;
            if(unappliedEditorPropertiesChanges) {
                if((editorPropertyChangeType & EditorPropertyChangeType.Atlases) == EditorPropertyChangeType.Atlases ||
                    (editorPropertyChangeType & EditorPropertyChangeType.Materials) == EditorPropertyChangeType.Materials)
                    hardChange = true;
            }

            // Draw apply button
            GUILayout.Space(15.0f);

            Utils.GUITools.EditorLayout.BeginHorizontal(style_buttonRow, GUILayout.Height(buttonRowHeight));

            GUI.enabled = guiEnabled && unappliedEditorPropertiesChanges;
            if(hardChange) {
                if(Utils.GUITools.Layout.Button("Apply")) {
                    if(ConfirmEditorPropertyChangeDialog()) {
                        CloseInnerWindows(); // close the window
                        changeEditorProperties = true; // flag deferred action on
                        busy = true; // pause user input until deferred action is complete
                    } else {
                        LoadEditorProperties(); // revert
                    }
                }
                GUI.enabled = guiEnabled;  // force enabled now that this is used to close the window
                if(Utils.GUITools.Layout.Button("Cancel")) {
                    LoadEditorProperties(); // revert
                    CloseInnerWindows(); // close the window
                }
                GUI.enabled = guiEnabled && unappliedEditorPropertiesChanges;
            } else { // don't update atlases, etc
                if(Utils.GUITools.Layout.Button("Apply")) {
                    CloseInnerWindows(); // close the window
                    changeEditorProperties = true; // flag deferred action on
                    busy = true; // pause user input until deferred action is complete
                }
                GUI.enabled = guiEnabled; // force enabled now that this is used to close the window
                if(Utils.GUITools.Layout.Button("Cancel")) {
                    LoadEditorProperties(); // revert
                    CloseInnerWindows(); // close the window
                }
                GUI.enabled = guiEnabled && unappliedEditorPropertiesChanges;
            }

            Utils.GUITools.EditorLayout.EndHorizontal();

            if(GUI.enabled != origGUIEnabled) GUI.enabled = origGUIEnabled; // restore the gui to the state before drawing the window
        }

        private void MoreSpriteSettingsWindow(int windowId) {
            if(openWindowId != 3) return; // prevent Unity bug where it runs the last opened window for 1 frame before showing the new open window
            if(windowJustOpened) {
                windowJustOpened = false;
                // Calculate auto tiling mode each time we open the window
                if(masterSpriteData.tilingMode == EditorMasterSprite.TilingMode.Auto) {
                    determineEdgeTiling = true; // defer the check so we can verify texture settings are corred
                    busy = true;
                }
            }
            if(refreshInnerWindow) {
                refreshInnerWindow = false;
                spriteProperties_useTwoSidedMesh.refresh = true;
                spriteProperties_filterMode.refresh = true;
                spriteProperties_anisoLevel.refresh = true;
                spriteProperties_tilingMode.refresh = true;
                spriteProperties_tileTop.refresh = true;
                spriteProperties_tileBottom.refresh = true;
                spriteProperties_tileLeft.refresh = true;
                spriteProperties_tileRight.refresh = true;
                spriteProperties_meshType.refresh = true;
                //spriteProperties_meshGenerationTransparencyChannel.refresh = true;
                spriteProperties_useDefaultAutoMeshEdgeExtrude.refresh = true;
                spriteProperties_autoMeshEdgeExtrude.refresh = true;
                spriteProperties_useDefaultAutoMeshVertexReductionDistance.refresh = true;
                spriteProperties_autoMeshVertexReductionDistance.refresh = true;
            }
            bool origGUIEnabled = GUI.enabled;

            float windowWidth = GetLayoutWidth();
            float labelWidth = windowWidth * 0.6f;
            Utils.GUITools.Engine.SwitchToFixedWidth(labelWidth, windowWidth - labelWidth); // set width of labels/controls
            bool guiEnabled = GUI.enabled && !busy; // disable GUI if busy
            GUI.enabled = guiEnabled; // set current gui state

            EditorMasterSprite.Data spriteData = masterSpriteData;

            Utils.GUITools.EditorLayout.Label("Misc Settings");

            // Tileable
            EditorMasterSprite.TilingMode tilingMode = spriteData.tilingMode;
            if(spriteProperties_tilingMode.DrawByValue((int)tilingMode)) {
                tilingMode = (EditorMasterSprite.TilingMode)spriteProperties_tilingMode.selectionValue;
                spriteData.tilingMode = tilingMode; // update the tiling mode in the master sprite data
                unsavedChanges = true;
                remakeAtlases = true;
                determineEdgeTiling = true; // update the auto edge tiling detection now (also needed for none and manual)
                busy = true; // this is a deferred action
            }

            // Show individual edge tiling check boxes
            GUI.enabled = guiEnabled && tilingMode == EditorMasterSprite.TilingMode.Manual; // disable controls unless set to manual mode
            if(spriteProperties_tileTop.Draw(ref spriteData.tileTop)) {
                unsavedChanges = true;
                remakeAtlases = true;
            }

            if(spriteProperties_tileBottom.Draw(ref spriteData.tileBottom)) {
                unsavedChanges = true;
                remakeAtlases = true;
            }

            if(spriteProperties_tileLeft.Draw(ref spriteData.tileLeft)) {
                unsavedChanges = true;
                remakeAtlases = true;
            }

            if(spriteProperties_tileRight.Draw(ref spriteData.tileRight)) {
                unsavedChanges = true;
                remakeAtlases = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state

            GUILayout.Space(15.0f);

            // Use 2-sided mesh
            int intValue = (int)spriteData.editorUseTwoSidedMesh;
            if(spriteProperties_useTwoSidedMesh.DrawByValue(intValue)) {
                spriteData.editorUseTwoSidedMesh = (BoolDefaultOption)spriteProperties_useTwoSidedMesh.selectionValue;
                unsavedChanges = true;
                remakeMeshes = true;
            }

            if(masterSpriteData.spriteGroupId == -1) { // sprite is not in a group, render the buttons. If in a group, these are handled in group properties

                GUILayout.Space(15.0f);
                Utils.GUITools.EditorLayout.Label("Atlas Settings");

                // Texture Filter Mode
                int filterMode;
                if(spriteData.useDefaultAtlasTextureFilterMode) filterMode = -1;
                else filterMode = (int)spriteData.atlasTextureFilterMode;
                if(spriteProperties_filterMode.DrawByValue(filterMode)) {
                    if(spriteProperties_filterMode.selectionValue < 0) {
                        spriteData.useDefaultAtlasTextureFilterMode = true;
                    } else {
                        spriteData.useDefaultAtlasTextureFilterMode = false;
                        spriteData.atlasTextureFilterMode = (FilterMode)spriteProperties_filterMode.selectionValue; // update data
                    }

                    unsavedChanges = true;
                    remakeAtlases = true;
                }

                // Aniso Level
                if(filterMode == -1) { // set to default mode
                    if(db.defaultFilterMode != FilterMode.Bilinear && db.defaultFilterMode != FilterMode.Trilinear) // default mode is one that has aniso
                        GUI.enabled = false;
                } else { // not default mode
                    if(filterMode != (int)FilterMode.Bilinear && filterMode != (int)FilterMode.Trilinear)
                        GUI.enabled = false;
                }
                int anisoLevel = spriteData.atlasTextureAnisoLevel;
                if(spriteProperties_anisoLevel.DrawByValue(anisoLevel)) {
                    spriteData.atlasTextureAnisoLevel = spriteProperties_anisoLevel.selectionValue; // update the data
                    unsavedChanges = true;
                    remakeAtlases = true;
                }
                if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state
            }

            GUILayout.Space(15.0f);
            Utils.GUITools.EditorLayout.Label("Mesh Settings");

            // Mesh Type
            int meshType;
            if(spriteData.useDefaultMeshType) meshType = -1;
            else meshType = (int)spriteData.meshType;
            if(spriteProperties_meshType.DrawByValue(meshType)) {
                if(spriteProperties_meshType.selectionValue < 0) {
                    spriteData.useDefaultMeshType = true;
                } else {
                    spriteData.useDefaultMeshType = false;
                    spriteData.meshType = (SpriteFactory.Enums.SpriteMeshType)spriteProperties_meshType.selectionValue; // update data
                }
                unsavedChanges = true;
                remakeAtlases = true;
            }

            /*// Mesh Generation Transparency Channel
            if((spriteData.useDefaultMeshType && db.defaultMeshType != Enums.SpriteMeshType.AutoMesh) ||
                (!spriteData.useDefaultMeshType && spriteData.meshType != Enums.SpriteMeshType.AutoMesh)) GUI.enabled = false;
            int meshGenerationTransparencyChannel;
            if(spriteData.useDefaultAutoMeshTransparencyChannel) meshGenerationTransparencyChannel = -1;
            else meshGenerationTransparencyChannel = (int)spriteData.meshGenerationTransparencyChannel;
            if(spriteProperties_meshGenerationTransparencyChannel.DrawByValue(meshGenerationTransparencyChannel)) {
                if(spriteProperties_meshGenerationTransparencyChannel.selectionValue < 0) {
                    spriteData.useDefaultAutoMeshTransparencyChannel = true;
                } else {
                    spriteData.useDefaultAutoMeshTransparencyChannel = false;
                    spriteData.meshGenerationTransparencyChannel = (SpriteFactory.Enums.ColorChannel)spriteProperties_meshGenerationTransparencyChannel.selectionValue; // update data
                }
                unsavedChanges = true;
                remakeAtlases = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state
            */

            // Auto mesh edge extrude
            if((spriteData.useDefaultMeshType && db.defaultMeshType != Enums.SpriteMeshType.AutoMesh) ||
                (!spriteData.useDefaultMeshType && spriteData.meshType != Enums.SpriteMeshType.AutoMesh)) GUI.enabled = false;
            bool useDefaultExtrude = spriteData.useDefaultAutoMeshEdgeExtrude;
            if(spriteProperties_useDefaultAutoMeshEdgeExtrude.Draw(ref useDefaultExtrude)) {
                spriteData.useDefaultAutoMeshEdgeExtrude = useDefaultExtrude;
                // Populate the value or it will not fill if user doesn't change it manually after disabling default 
                spriteData.autoMeshEdgeExtrudeOverride = editorProperties.defaultAutoMeshEdgeExtrude; // set to the default value if set to default
                spriteProperties_autoMeshEdgeExtrude.refresh = true;
                unsavedChanges = true;
                remakeAtlases = true;
            }
            if(spriteData.useDefaultAutoMeshEdgeExtrude) GUI.enabled = false; // disable GUI if using default
            int extrude = spriteData.useDefaultAutoMeshEdgeExtrude ? editorProperties.defaultAutoMeshEdgeExtrude : spriteData.autoMeshEdgeExtrudeOverride; // show default value if using default
            if(spriteProperties_autoMeshEdgeExtrude.Draw(ref extrude)) {
                spriteData.autoMeshEdgeExtrudeOverride = extrude;
                unsavedChanges = true;
                remakeAtlases = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state

            // Auto mesh vert reduction distance
            if((spriteData.useDefaultMeshType && db.defaultMeshType != Enums.SpriteMeshType.AutoMesh) ||
                (!spriteData.useDefaultMeshType && spriteData.meshType != Enums.SpriteMeshType.AutoMesh)) GUI.enabled = false;
            bool useDefaultDistance = spriteData.useDefaultAutoMeshVertexReductionDistance;
            if(spriteProperties_useDefaultAutoMeshVertexReductionDistance.Draw(ref useDefaultDistance)) {
                spriteData.useDefaultAutoMeshVertexReductionDistance = useDefaultDistance;
                // Populate the value or it will not fill if user doesn't change it manually after disabling default 
                spriteData.autoMeshVertexReductionDistanceOverride = editorProperties.defaultAutoMeshVertexReductionDistance; // set to the default value if set to default
                spriteProperties_autoMeshVertexReductionDistance.refresh = true;
                unsavedChanges = true;
                remakeAtlases = true;
            }
            if(spriteData.useDefaultAutoMeshVertexReductionDistance) GUI.enabled = false; // disable GUI if using default
            int vertDistance = spriteData.useDefaultAutoMeshVertexReductionDistance ? editorProperties.defaultAutoMeshVertexReductionDistance : spriteData.autoMeshVertexReductionDistanceOverride; // show default value if using default
            if(spriteProperties_autoMeshVertexReductionDistance.Draw(ref vertDistance)) {
                spriteData.autoMeshVertexReductionDistanceOverride = vertDistance;
                unsavedChanges = true;
                remakeAtlases = true;
            }
            if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state

            Utils.GUITools.Engine.SwitchToAutoWidth(); // revert

            DrawCloseWindow();
            if(GUI.enabled != origGUIEnabled) GUI.enabled = origGUIEnabled; // restore the gui to the state before drawing the window
        }

        private void MaterialSetEditorWindow(int windowId) {
            if(openWindowId != 0) return; // prevent Unity bug where it runs the last opened window for 1 frame before showing the new open window
            if(windowJustOpened) windowJustOpened = false;
            if(refreshInnerWindow) {
                refreshInnerWindow = false;
                materialSetListBoxContainer.refresh = true;
            }
            bool origGUIEnabled = GUI.enabled;
            GUI.enabled = GUI.enabled && !busy; // disable GUI if busy

            Utils.GUITools.EditorLayout.BeginHorizontal();

            float colWidth = 250.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(colWidth));
            DrawMaterialSetListBox(colWidth, 200);
            Utils.GUITools.EditorLayout.EndVertical();

            colWidth = 320.0f;
            Utils.GUITools.Engine.SwitchToFixedWidth(140, 160); // set width of labels/controls
            Utils.GUITools.EditorLayout.BeginVertical(style_cellPad, GUILayout.Width(colWidth));
            DrawMaterialSetProperties(colWidth);
            Utils.GUITools.EditorLayout.EndVertical();
            Utils.GUITools.Engine.SwitchToAutoWidth(); // revert

            Utils.GUITools.EditorLayout.EndHorizontal();

            DrawCloseWindow();

            if(GUI.enabled != origGUIEnabled) GUI.enabled = origGUIEnabled; // restore the gui to the state before drawing the window
        }

        private void ColliderEditorWindow(int windowID) {
            if(openWindowId != 1) return; // prevent Unity bug where it runs the last opened window for 1 frame before showing the new open window
            if(windowJustOpened) windowJustOpened = false;
            if(refreshInnerWindow) {
                refreshInnerWindow = false;
                colliderSetListBoxContainer.refresh = true;
                colliderGroupListBoxContainer.refresh = true;
            }
            bool origGUIEnabled = GUI.enabled;
            GUI.enabled = GUI.enabled && !busy; // disable GUI if busy

            Utils.GUITools.EditorLayout.BeginHorizontal();

            float colWidth = 250.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(colWidth));
            DrawColliderSetListBox(colWidth, 200.0f);
            DrawSectionSpacer();
            DrawColliderGroupListBox(colWidth, 200.0f);
            Utils.GUITools.EditorLayout.EndVertical();

            colWidth = 325.0f;
            Utils.GUITools.EditorLayout.BeginVertical(style_cellPad, GUILayout.Width(colWidth));
            DrawColliderSetProperties(colWidth, 160.0f, 165.0f);
            DrawColliderGroupProperties(colWidth, 160.0f, 165.0f);
            Utils.GUITools.EditorLayout.EndVertical();

            Utils.GUITools.EditorLayout.EndHorizontal();

            DrawCloseWindow();

            if(GUI.enabled != origGUIEnabled) GUI.enabled = origGUIEnabled; // restore the gui to the state before drawing the window

            refreshColliderFrameProperties = true; // force collider frames to refresh every cycle the window is open
            refreshColliderGroupList = true; // force group names to refresh every cycle window is open
        }

        private void ColliderDisplayFilterWindow(int windowID) {
            if(openWindowId != 4) return; // prevent Unity bug where it runs the last opened window for 1 frame before showing the new open window
            if(windowJustOpened) windowJustOpened = false;
            if(refreshInnerWindow) {
                refreshInnerWindow = false;
            }
            bool origGUIEnabled = GUI.enabled;
            GUI.enabled = GUI.enabled && !busy; // disable GUI if busy

            innerWindowScrollers[0] = EditorGUILayout.BeginScrollView(innerWindowScrollers[0]); // start a scroll view


            DrawCloseWindow();
            EditorGUILayout.EndScrollView();
            if(GUI.enabled != origGUIEnabled) GUI.enabled = origGUIEnabled; // restore the gui to the state before drawing the window
        }

        private void LocatorSetEditorWindow(int windowID) {
            if(openWindowId != 5) return; // prevent Unity bug where it runs the last opened window for 1 frame before showing the new open window
            if(windowJustOpened) windowJustOpened = false;
            if(refreshInnerWindow) {
                refreshInnerWindow = false;
                locatorSetListBoxContainer.refresh = true;
            }
            bool origGUIEnabled = GUI.enabled;
            GUI.enabled = GUI.enabled && !busy; // disable GUI if busy

            Utils.GUITools.EditorLayout.BeginHorizontal();

            float colWidth = 250.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(colWidth));
            DrawLocatorSetListBox(colWidth, 200.0f);
            Utils.GUITools.EditorLayout.EndVertical();

            colWidth = 325.0f;
            Utils.GUITools.EditorLayout.BeginVertical(style_cellPad, GUILayout.Width(colWidth));
            DrawLocatorSetProperties(colWidth, 160.0f, 165.0f);
            Utils.GUITools.EditorLayout.EndVertical();

            Utils.GUITools.EditorLayout.EndHorizontal();

            DrawCloseWindow();

            if(GUI.enabled != origGUIEnabled) GUI.enabled = origGUIEnabled; // restore the gui to the state before drawing the window
        }

        private void ExportWindow(int windowID) {
            if(openWindowId != 6) return; // prevent Unity bug where it runs the last opened window for 1 frame before showing the new open window
            if(windowJustOpened) windowJustOpened = false;
            if(refreshInnerWindow) {
                refreshInnerWindow = false;

                // Load the groups and sprites only when window is opened or refreshed
                exporter.Clear();
                exporter.groupIndices = db.GetSavedSpriteGroupIndices();
                exporter.groupNames = db.GetSavedSpriteGroupNames(true);
                db.GetSavedSpriteListsInGroup(-1, out exporter.spriteIndices, out exporter.spriteNames);

                // Clear all controls in this window
                export_groupsListBoxContainer.Clear();
                export_groupsListBoxContainer_ToExport.Clear();
                export_ungroupedSpritesListBoxContainer.Clear();
                export_ungroupedSpritesListBoxContainer_ToExport.Clear();
                export_exportPrefabs.Clear();
            }
            bool origGUIEnabled = GUI.enabled;
            GUI.enabled = GUI.enabled && !busy; // disable GUI if busy

            Utils.GUITools.EditorLayout.BeginHorizontal();

            float colWidth = 275.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(colWidth));
            DrawExportGroupsListBox(colWidth, 200.0f);
            DrawSectionSpacer(10.0f);
            DrawExportSpritesListBox(colWidth, 200.0f);
            Utils.GUITools.EditorLayout.EndVertical();

            DrawSectionSpacer(30.0f);

            colWidth = 275.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(colWidth));
            DrawExportGroupsToExportListBox(colWidth, 200.0f);
            DrawSectionSpacer(10.0f);
            DrawExportSpritesToExportListBox(colWidth, 200.0f);
            Utils.GUITools.EditorLayout.EndVertical();

            Utils.GUITools.EditorLayout.EndHorizontal();

            DrawSectionSpacer(10.0f);
            DrawExportOptions(); // export options

            DrawSectionSpacer(20.0f);
            DrawExportWindowButtons(); // window buttons

            GUILayout.Space(8.0f);

            if(GUI.enabled != origGUIEnabled) GUI.enabled = origGUIEnabled; // restore the gui to the state before drawing the window
        }

        private void ImportWindow(int windowID) {
            if(openWindowId != 7) return; // prevent Unity bug where it runs the last opened window for 1 frame before showing the new open window
            if(windowJustOpened) windowJustOpened = false;
            if(refreshInnerWindow) {
                refreshInnerWindow = false;

                // Load the import data
                importer.ImportFile();

                // Refresh all controls in this window
                importMessagesListBoxContainer.refresh = true;
            }
            bool origGUIEnabled = GUI.enabled;
            GUI.enabled = GUI.enabled && !busy; // disable GUI if busy

            float colWidth = 610.0f;
            Utils.GUITools.EditorLayout.BeginVertical(GUILayout.Width(colWidth));

            DrawSectionSpacer(15.0f);

            // Make scroll view
            float height;
            if(importer.errorCount >= 7 || importer.fileCount >= 30) height = 550.0f;
            else height = 300.0f;
            innerWindowScrollers[0] = EditorGUILayout.BeginScrollView(innerWindowScrollers[0], GUILayout.Height(height)); // scroll view
            DrawImportWarnings();
            EditorGUILayout.EndScrollView();

            Utils.GUITools.EditorLayout.EndVertical();

            // Window buttons
            DrawSectionSpacer(20.0f);
            DrawImportWindowButtons();

            GUILayout.Space(8.0f);

            if(GUI.enabled != origGUIEnabled) GUI.enabled = origGUIEnabled; // restore the gui to the state before drawing the window
        }

        private void MoreUtilitiesWindow(int windowId) {
            if(openWindowId != 8) return; // prevent Unity bug where it runs the last opened window for 1 frame before showing the new open window
            if(windowJustOpened) windowJustOpened = false;
            if(refreshInnerWindow) {
                refreshInnerWindow = false;
            }
            bool origGUIEnabled = GUI.enabled;
            bool guiEnabled = GUI.enabled && !busy; // disable GUI if busy
            GUI.enabled = guiEnabled; // set current gui state

            GUIContent buttonContent;
            bool isDataSaved = db.IsDataSaved();

            Utils.GUITools.Layout.Label("Asset Rebuilding:");
            DrawSectionSpacer(6.0f);

            GUI.enabled = guiEnabled && isDataSaved;
            buttonContent = new GUIContent("Rebuild All Atlases", "Rebuild all atlases for all sprites and sprite groups. This can take a very long time depending on how many sprites/groups you have.");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog();
                if(EditorUtility.DisplayDialog("Rebuild All Atlases", "All atlases will be rebuilt. This may take a very long time. Are you sure?", "Rebuild", "Cancel")) {
                    rebuildAllAtlases = true;
                    busy = true;
                    CloseInnerWindows();
                }
            }

            GUI.enabled = guiEnabled && isDataSaved;
            buttonContent = new GUIContent("Rebuild All Materials", "Rebuild all materials for all sprites and sprite groups. You may need to do this if you have source materials used by many sprites and have made changes to those source materials. This can take some time if you have a lot of sprites/groups, but not nearly as long as rebuilding all atlases.");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog();
                if(EditorUtility.DisplayDialog("Rebuild All Materials", "All materials will be rebuilt. This may take some time. Are you sure?", "Rebuild", "Cancel")) {
                    rebuildAllMaterials = true;
                    busy = true;
                    CloseInnerWindows();
                }
            }

            DrawSectionSpacer(15.0f);
            Utils.GUITools.Layout.Label("Advanced:");
            DrawSectionSpacer(6.0f);

            GUI.enabled = guiEnabled;
            buttonContent = new GUIContent("Rebuild Data File", "Rebuild the main data file by scanning the save folder for existing assets. You should only need to do this if your data file becomes corrupt.");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                if(EditorUtility.DisplayDialog("Rebuild Data File", "The data file will be completely rebuilt. This may take a some time. Are you sure?", "Rebuild", "Cancel")) {
                    if(EditorUtility.DisplayDialog("Rebuild All Sprites", "Do you want to also rebuild all sprites and sprite groups? This may take a very long time. Are you sure? In nearly all cases, you should select Yes.", "Yes", "No")) {
                        rebuildDataFile_rebuildAll = true;
                    }
                    ClearCurrentSpriteListSelection(); // drop the selections immediately
                    ClearCurrentGroupListSelection();
                    rebuildDataFile = true;
                    busy = true;
                    CloseInnerWindows();
                }
            }
            if(GUI.enabled != origGUIEnabled) GUI.enabled = origGUIEnabled; // restore the gui to the state before drawing the window

            DrawSectionSpacer(15.0f);
            Utils.GUITools.Layout.Label("Import / Export:");
            DrawSectionSpacer(6.0f);

            buttonContent = new GUIContent("Import", "Import Master Sprites, Sprite Groups, prefabs, and dependencies from a Sprite Factory export set. See the documentation for help before proceeding!");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog();
                string filePath = EditorUtility.OpenFilePanel("Import Sprite Factory Data", "", exportTextExtensionNoDot);
                if(filePath != "") {
                    importer.Clear();
                    importer.SetImportPath(filePath);
                    OpenInnerWindow(7);
                }
            }

            GUI.enabled = guiEnabled && isDataSaved;
            buttonContent = new GUIContent("Export", "Export Master Sprites, Sprite Groups, prefabs, and dependencies to a Sprite Factory export set. See the documentation for help before proceeding!");
            if(Utils.GUITools.Layout.Button(buttonContent)) {
                ShowSaveChangesDialog();
                OpenInnerWindow(6);
            }
            if(GUI.enabled != origGUIEnabled) GUI.enabled = origGUIEnabled; // restore the gui to the state before drawing the window

            DrawCloseWindow();
        }

        #endregion

        #region Save / Load / Revert

        private void ShowSaveChangesDialog() {
            if(!unsavedChanges) return;

            string type = "";
            if(editMode == EditMode.Sprite) {
                type = "Sprite";
            } else if(editMode == EditMode.SpriteGroup) {
                type = "Sprite Group";
            }

            if(EditorUtility.DisplayDialog("Save Changes", "The current " + type + " has unsaved changes. Save changes to this " + type + "?", "Save", "Do Not Save"))
                SaveChangesDeferred();
            else
                Revert();
        }

        private void SaveChangesDeferred(bool isRebuild = false) {
            saveChanges = true; // flag to save changes later
            saveChanges_editMode = editMode; // store the current edit mode
            busy = true; // disable user input until finished
            // GUIUtility.keyboardControl = 0; // defocus keyboard control -- CAUSES A CRASH - fix in future version

            // Optional atlas rebuilding
            // This only applies to saving a Master Sprite
            if(editMode == EditMode.Sprite) { // editing sprite
                masterSpriteData.PrepareForEditorSave();
                if(!isRebuild) { // this is not an explicit rebuild, so check if user wants to rebuild or not

                    // Check if any source images in the sprite or group changed and trigger an atlas rebuild
                    if(!remakeAtlases) { // nothing flagged an atlas rebuild
                        // Not rebuilding atlases because it didn't think we need to, but need to check if any frames have been updated
                        if(db.CheckIfSourceImagesChanged(masterSpriteData, selectedMasterSpriteIndex, selectedGroupId)) { // something changed, we have to rebuild the atlases
                            remakeAtlases = true;
                        }
                    }

                    // Ask user if they want to rebuild if required
                    ShowRebuildDialog();
                }
            }

            // Points of rebuilding:
            // Move sprite in/out of group
            // Change name of group
            // Duplicate sprite in group
            // Duplicate group
            // *DONE* Delete sprite in group 
            // *DONE* Save master sprite in group

        }

        private void SaveChanges(EditMode editMode) {

            // Save changes to sprite or group
            if(editMode == EditMode.Sprite) { // editing sprite
                bool preventBuildingAssets;
                if(masterSpriteData.spriteGroupId < 0) { // not in a group
                    preventBuildingAssets = preventRebuildSpriteAssets;
                } else { // in a group
                    preventBuildingAssets = preventRebuildSpriteGroupAssets;
                    refreshGroupListOnSave = true; // update the names
                }

                //Utils.AssetTools.FixTextureImporterSettings(masterSpriteData.GetFrameTextureGUIDs()); // We now fix the texture settings every time we update atlases, so no need to do this here
                materialSetContainer.ExportData(masterSpriteData); // save the material set data to the sprite before we save it to disk

                db.SaveSprite(masterSpriteData, selectedMasterSpriteIndex, selectedGroupId, remakeAtlases, remakeMaterials, remakeMeshes, true, preventBuildingAssets, false, false); // create or load sprite, create atlases, save changes to master sprite and sprite on disk, push updates to prefabs based on source sprite
                
                if(refreshGroupListOnSave) groupListBoxContainer.softRefresh = true; // force refresh so name changes update
                if(refreshSpriteListOnSave) spriteListBoxContainer.refresh = true; // force refresh so name changes update

                if(masterSpriteData.spriteGroupId != selectedGroupId) { // sprite has been moved out of the current group
                    ClearCurrentSpriteListSelection();
                } else { // sprite is still in this group, we can reload it
                    ReloadSelected(saveButtonPressed); // reload or old data may stick around (especially if sprite is in a group and we do some group processing), resume editing from current selections when save is done if user directly saved it
                }

            } else if(editMode == EditMode.SpriteGroup) { // editing sprite group

                materialSetContainer.ExportData(selectedGroup); // save the material set data to the group before we save it to disk
                db.SaveSpriteGroup(selectedGroup, remakeAtlases, remakeMaterials); // save group to disk
                if(refreshGroupListOnSave) groupListBoxContainer.softRefresh = true; // force name changes to update, but don't cause lose sprite selection
                ReloadSelected(false); // reload or old data may stick around
            }

            if(saveButtonPressed) saveButtonPressed = false; // save was directly clicked by user, clear the flag now
        }

        private void ReloadSelected(bool resumeEditing) {
            if(resumeEditing) { // resume editing sprite at last animation/frame selected
                reloadLastSelection = true;
                lastSelectedAnimationIndex = animationListBoxContainer.selectedIndex;
                lastSelectedFrameIndex = frameListBoxContainer.selectedIndex;
            }

            Revert();
        }

        private void Revert() {
            if(editMode == EditMode.Sprite) { // revert sprite changes
                RevertMasterSprite();
            } else if(editMode == EditMode.SpriteGroup) { // revert group changes
                RevertSpriteGroup();
            }
        }

        private void RevertMasterSprite() {
            LoadListSelectedSprite();  // load the master sprite
            spriteListBoxContainer.refresh = true; // force refresh
            ClearSpriteChangeVars(); // clear vars
            //GUIUtility.keyboardControl = 0; // defocus keyboard control
        }

        private void RevertSpriteGroup() {
            LoadListSelectedGroup();  // load the group
            groupListBoxContainer.refreshDontClearChildren = true; // force refresh, but don't clear children so we don't lose selections
            ClearGroupChangeVars(); // clear vars
            //GUIUtility.keyboardControl = 0; // defocus keyboard control
        }

        private void LoadListSelectedSprite() {
            masterSpriteSelectionChanged = true;
            if(selectedMasterSpriteIndex == -1) return; // throw new System.Exception("Error!");
            masterSpriteData = db.GetEditorSpriteDataCopy(selectedMasterSpriteIndex);
            if(masterSpriteData != null) {
                materialSetContainer = new MaterialSetContainer(db, masterSpriteData); // get material set data from sprite
                SetStaticSpriteMode(masterSpriteData.isStaticSprite); // update the static sprite mode
            } else { // master sprite could not be loaded
                Debug.LogError("Master sprite could not be loaded!");
                materialSetContainer = null;
            }
        }

        private void LoadListSelectedGroup() {
            if(selectedGroupIndex == -1) {
                selectedGroup = null;
                materialSetContainer = null;
                return; // throw new System.Exception("Error!");
            }
            selectedGroup = db.GetSpriteGroupByIndex(selectedGroupIndex);
            materialSetContainer = new MaterialSetContainer(db, selectedGroup); // get material set data from group
        }

        private void ShowRebuildDialog() {
            if(editMode == EditMode.Sprite) {
                if(masterSpriteData.spriteGroupId < 0) ShowRebuildSpriteAtlasesDialog(); // sprite is not in a group
                else ShowRebuildGroupAtlasesDialog(); // sprite is in a group
            }
        }

        private void ShowRebuildSpriteAtlasesDialog() {
            if(!remakeAtlases) return; // it wasn't going to make atlases, so don't ask
            if(masterSpriteData == null) return;
            if(masterSpriteData.spriteGroupId >= 0) return; // sprite is in a group!
            if(masterSpriteData.spriteGroupId != selectedGroupId) return; // sprite is changing groups

            if(db.rebuildSpriteOnSave == AutomaticActionPolicy.Prompt) {
                if(!EditorUtility.DisplayDialog("Rebuild Atlases", "The Sprite's atlases need to be rebuilt because of changes you have made. This could take a long time. Would you like to rebuild them now? If not, you must manually rebuild the Sprite when you are ready before the Sprite will function correctly in the scene. You can turn off this notice in the Editor Properties.", "Rebuild Now", "I'll do it Later")) {
                    Debug.LogWarning("Skipped rebuilding the Sprite's atlases. Remember: You must rebuild the Sprite's atlases before you can use it. To rebuild the atlases, select the Sprite from the list and press the Rebuild Master Sprite button.");
                    preventRebuildSpriteAssets = true;
                }
            } else if(db.rebuildSpriteOnSave == AutomaticActionPolicy.Never) {
                Debug.LogWarning("Skipped rebuilding the Sprite's atlases. Remember: You must rebuild the Sprite's atlases before you can use it. To rebuild the atlases, select the Sprite from the list and press the Rebuild Master Sprite button.");
                Debug.LogWarning("Rebuild Sprite Group Atlases on Save = " + db.rebuildSpriteGroupOnSave + ". You may change this setting in the Editor Properties.");
                preventRebuildSpriteAssets = true;
            }
        }

        private void ShowRebuildGroupAtlasesDialog() {
            if(!remakeAtlases) return; // it wasn't going to make atlases, so don't ask
            if(masterSpriteData == null) return;
            if(masterSpriteData.spriteGroupId < 0) return; // sprite is not in a group
            if(masterSpriteData.spriteGroupId != selectedGroupId) return; // sprite is changing groups

            if(db.rebuildSpriteGroupOnSave == AutomaticActionPolicy.Prompt) {
                if(!EditorUtility.DisplayDialog("Rebuild Atlases", "The Sprite Group's atlases need to be rebuilt because of changes you have made. This could take a long time. Would you like to rebuild them now? If not, you must manually rebuild the group when you are ready before the Sprites will function correctly in the scene. You can turn off this notice in the Editor Properties.", "Rebuild Now", "I'll do it Later")) {
                    Debug.LogWarning("Skipped rebuilding the Sprite Group's atlases. Remember: You must rebuild the group's atlases before you can use these Sprites. To rebuild the atlases, select the Sprite Group from the list and press the Rebuild Sprite Group button.");
                    remakeAtlases = false; // override and do not remake atlases
                    remakeMaterials = false;
                    preventRebuildSpriteGroupAssets = true;
                }
            } else if(db.rebuildSpriteGroupOnSave == AutomaticActionPolicy.Never) {
                Debug.LogWarning("Skipped rebuilding the Sprite Group's atlases. Remember: You must rebuild the group's atlases before you can use these Sprites. To rebuild the atlases, select the Sprite Group from the list and press the Rebuild Sprite Group button.");
                Debug.LogWarning("Rebuild Sprite Group Atlases on Save = " + db.rebuildSpriteGroupOnSave + ". You may change this setting in the Editor Properties.");
                remakeAtlases = false; // override and do not remake atlases
                remakeMaterials = false;
                preventRebuildSpriteGroupAssets = true;
            }
        }

        #endregion

        #region Listbox Selections

        private void UpdateSpriteListSelection() {
            if(busy) return; // currently waiting for selection to be changed

            // Update the selection from list box
            if(spriteListBoxContainer.hasSelection) {
                int spriteIndex = spriteListBoxContainer.selectedObject;
                if(selectedMasterSpriteIndex != spriteIndex) { // selection has changed
                    ShowSaveChangesDialog();
                    pendingSpriteListboxAction.action = ListboxAction.Action.ChangeSelection; // selection will be changed in Update
                    pendingSpriteListboxAction.objectIndex = spriteIndex; // save the index we're switching to
                    busy = true; // prevent user input while we wait for selection to change
                }
            } else { // no selection
                if(masterSpriteData != null || selectedMasterSpriteIndex != -1) { // deselected
                    ClearCurrentSpriteListSelection(); // clear the selection
                }
            }
        }

        private void UpdateGroupListSelection() {
            if(busy) return; // currently waiting for selection to be changed

            // Update the selection from list box
            if(groupListBoxContainer.hasSelection) {
                int groupIndex = groupListBoxContainer.selectedObject;
                if(selectedGroupIndex != groupIndex) { // selection has changed
                    ShowSaveChangesDialog();
                    pendingGroupListboxAction.action = ListboxAction.Action.ChangeSelection; // selection will be changed in Update
                    pendingGroupListboxAction.objectIndex = groupIndex; // save the index we're switching to
                    busy = true; // prevent user input while we wait for selection to change
                }
            } else { // no selection
                if(selectedGroup != null || selectedGroupIndex != -1) { // deselected
                    ClearCurrentGroupListSelection(); // clear the selection
                }
            }
        }

        private void ForceListSelectSpriteAtIndex(int listIndex, int spriteIndex) {
            spriteListBoxContainer.selectedObject = spriteIndex;
            spriteListBoxContainer.selectedIndex = listIndex;
            selectedMasterSpriteIndex = spriteIndex;
            LoadListSelectedSprite(); // load the master sprite
            ClearSpriteChangeVars(); // reset change detection vars
        }

        private void ForceListSelectGroupAtIndex(int listIndex, int groupIndex) {
            groupListBoxContainer.selectedObject = groupIndex;
            groupListBoxContainer.selectedIndex = listIndex;
            selectedGroupIndex = groupIndex;
            LoadListSelectedGroup(); // load the group
            ClearGroupChangeVars(); // reset change vars
        }

        private void ClearCurrentSpriteListSelection() {
            if(spriteListBoxContainer != null) spriteListBoxContainer.ClearSelection();
            masterSpriteData = null;
            selectedMasterSpriteIndex = -1;
            ClearSpriteChangeVars(); // no longer selecting anything, change detection is reset
            if(selectedGroup != null) { // a group is selected
                RevertSpriteGroup(); // must reload the sprite group in case changes have been made to it
            }
        }

        private void ClearCurrentGroupListSelection() {
            if(groupListBoxContainer != null) groupListBoxContainer.ClearSelection();
            selectedGroup = null;
            selectedGroupIndex = -1;
            ClearGroupChangeVars(); // no longer selecting anything, change detection is reset
        }

        #endregion

        #region Editor Properties

        private void LoadEditorProperties() {
            // Load saved editor properties
            editorProperties = new EditorProperties();
            editorProperties.pixelsPerUnit = db.pixelsPerUnit;
            editorProperties.trimSprites = db.trimSprites;
            editorProperties.framePadding = db.framePadding;
            editorProperties.maxAtlasSize = db.maxAtlasSize;
            editorProperties.forceSquareAtlases = db.forceSquareAtlases;
            editorProperties.useMipMaps = db.useMipMaps;
            editorProperties.useTextureCompression = db.useTextureCompression;
            //editorProperties.atlasPackingMethod = db.atlasPackingMethod;
            editorProperties.resolutionTarget = db.resolutionTarget;
            editorProperties.resolutionTargetResamplingMode = db.resolutionTargetResamplingMode;
            editorProperties.defaultMaterial = db.userDefaultMaterial;
            editorProperties.defaultFilterMode = db.defaultFilterMode;
            editorProperties.defaultAnisoLevel = db.defaultAnisoLevel;
            editorProperties.defaultUseTwoSidedMesh = db.defaultUseTwoSidedMesh;
            editorProperties.defaultMeshType = db.defaultMeshType;
            editorProperties.defaultAutoMeshTransparencyChannel = db.defaultAutoMeshTransparencyChannel;
            editorProperties.defaultAutoMeshEdgeExtrude = db.defaultAutoMeshEdgeExtrude;
            editorProperties.defaultAutoMeshVertexReductionDistance = db.defaultAutoMeshVertexReductionDistance;
            editorProperties.defaultUse2DColliders = db.defaultUse2DColliders;
            editorProperties.rebuildSpriteOnSave = db.rebuildSpriteOnSave;
            editorProperties.rebuildSpriteGroupOnSave = db.rebuildSpriteGroupOnSave;

            // refresh the controls
            refreshEditorPropertiesControls = true;

            ClearEditorPropertiesChangeVars();
            UpdateCacheVars(); // make sure caches have the latest data
        }

        private void ClearEditorPropertiesChangeVars() {
            unappliedEditorPropertiesChanges = false;
            editorPropertyChangeType = EditorPropertyChangeType.None;
        }

        private void ApplyEditorProperties(EditorPropertyChangeType changeType) {
            // Save editor properties
            db.ChangeEditorProperties(editorProperties, changeType);
            ClearEditorPropertiesChangeVars();
            UpdateCacheVars(); // make sure caches have the latest data
        }

        private bool ConfirmEditorPropertyChangeDialog() {
            if((editorPropertyChangeType & EditorPropertyChangeType.Atlases) == EditorPropertyChangeType.Atlases)
                return ConfirmAtlasPropertyChangeDialog();
            else if((editorPropertyChangeType & EditorPropertyChangeType.Materials) == EditorPropertyChangeType.Materials)
                return ConfirmMaterialPropertyChangeDialog();
            return true;
        }

        private bool ConfirmAtlasPropertyChangeDialog() {
            return EditorUtility.DisplayDialog("Global Atlas Property Change", "All atlases must be rebuilt and all sprite prefabs must be updated. This may take a very long time depending on how many sprites you have. Are you sure?", "Apply", "Cancel");
        }

        private bool ConfirmMaterialPropertyChangeDialog() {
            return EditorUtility.DisplayDialog("Global Material Property Change", "All materials must be rebuilt. This may take some time, though not nearly as much as rebuilding atlases. Are you sure?", "Apply", "Cancel");
        }

        #endregion

        #region Clear Vars

        private void ClearMomentaryVars() {
            if(masterSpriteSelectionChanged) masterSpriteSelectionChanged = false;
            if(sceneSelectionChanged) sceneSelectionChanged = false;
            if(reloadLastSelection) ClearReloadSelectionVars();
        }

        private void ClearSpriteChangeVars() {
            unsavedChanges = false;
            remakeAtlases = false;
            remakeMaterials = false;
            remakeMeshes = false;
            refreshSpriteListOnSave = false;
        }

        private void ClearGroupChangeVars() {
            ClearSpriteChangeVars();
            refreshGroupListOnSave = false;
        }

        private void ClearReloadSelectionVars() {
            reloadLastSelection = false;
            lastSelectedAnimationIndex = -1;
            lastSelectedFrameIndex = -1;
        }

        private void ClearPersistentVars() {
            importInProcess = false;
        }

        #endregion

        #region Create / Assign Sprite in Scene

        private void CreateListSelectedSpriteInScene() {
            GameObject spriteObject = new GameObject(masterSpriteData.name);
            Utils.UnityTools.Undo.RegisterCreatedObjectUndo(spriteObject, masterSpriteData.name); // register with undo system

            // select the new game object
            Selection.objects = new Object[1] { spriteObject };
            selectedGameObject = spriteObject;

            AssignSpriteToSelection(true);
            //Debug.Log("Created new sprite \"" + sprite.name + "\"! This sprite was created in-scene. You should make a prefab out of this sprite as soon as possible for best results.");
        }

        private void TryAssignSpriteToSelection() {
            // Determine if we are assigning over an existing sprite or a new game object

            // warn if overwriting sprite
            // repair mesh filter, renderer, material setup
            // warn if overwriting other mesh/material

            Sprite spriteOnObject = (Sprite)selectedGameObject.GetComponent(typeof(Sprite)); // try to get existing sprite on object
            if(spriteOnObject != null) { // found a sprite on object already

                if(EditorUtility.DisplayDialog("Replace Sprite", "The object already has a sprite assigned. Would you like to replace the sprite on the object?", "Replace", "Cancel")) {
                    AssignSpriteToSelection(false);
                }

            } else { // there is no sprite on this object

                bool conflict = CheckForComponentConflicts(selectedGameObject);
                if(conflict) {
                    if(EditorUtility.DisplayDialog("Component Conflicts Found", "The object already has one or more necessary components (ex: MeshFilter, MeshRenderer). These components will be replaced. Any data in them will be lost.", "Replace", "Cancel")) {
                        AssignSpriteToSelection(true);
                    }
                } else
                    AssignSpriteToSelection(true);
            }
        }

        private void AssignSpriteToSelection(bool noSpriteComponent) { // assign a sprite to a scene game object or prefab
            Sprite sprite;

            // Register with Undo system first
            // Utils.UnityTools.Undo.RegisterCompleteObjectUndo(selectedGameObject, selectedGameObject.name); // seems buggy

            if(noSpriteComponent) { // this an object with no Sprite component
                RemoveConflictingComponents(); // remove any conflicting components first
                RepairSpriteComponents(selectedGameObject); // add components and set to defaults
            } else { // a sprite already exists on this object
                RepairSpriteComponents(selectedGameObject); // repair components and reset to defaults
            }
            sprite = (Sprite)selectedGameObject.GetComponent(typeof(Sprite));

            Utils.UnityTools.Undo.CollapseCurrentGroupUndoOperations(); // collapse all undos into one

            // Save data to sprite
            db.AssignSprite(sprite, selectedMasterSpriteIndex, masterSpriteData.editorMasterSprite);
        }

        private void RepairSpriteComponents(GameObject go) {
            // check for the components required by Sprite

            // Remove all sprites first
            Component[] sprites = go.GetComponents(typeof(Sprite));
            if(sprites != null && sprites.Length > 0) { // found sprites
                for(int i = 0; i < sprites.Length; i++) {
                    Utils.UnityTools.Undo.DestroyObjectImmediate(sprites[i]); // remove sprite component
                }
                EditorUtility.SetDirty(go); // flag this object needs saving
            }
            go.AddComponent(typeof(Sprite)); // add back one sprite component

            // Check for Mesh Filter
            MeshFilter meshFilter = (MeshFilter)go.GetComponent(typeof(MeshFilter));
            if(meshFilter == null) { // no mesh filter, add it
                meshFilter = (MeshFilter)Utils.UnityTools.Undo.AddComponent(go, typeof(MeshFilter));
                EditorUtility.SetDirty(go);
            }

            // Check for MeshRenderer
            MeshRenderer meshRenderer = (MeshRenderer)go.GetComponent(typeof(MeshRenderer));
            if(meshRenderer == null) { // no mesh filter, add it
                meshRenderer = (MeshRenderer)Utils.UnityTools.Undo.AddComponent(go, typeof(MeshRenderer));
                EditorUtility.SetDirty(go);
            } //else if(meshRenderer.sharedMaterial == null) { // material is missing / deleted

            // set mesh renderer settings to defaults
            SerializedObject so = new SerializedObject(meshRenderer);
            so.Update();

            // Cast Shadows
            SerializedProperty sp = so.FindProperty("m_CastShadows");
            if(sp == null) Debug.LogError("m_CastShadows not found!");
            sp.boolValue = false;

            // Receive Shadows
            sp = so.FindProperty("m_ReceiveShadows");
            if(sp == null) Debug.LogError("m_ReceiveShadows not found!");
            sp.boolValue = false;

            // Materials array
            sp = so.FindProperty("m_Materials.Array.size"); // get array size
            if(sp == null) Debug.LogError("m_Materials.Array.size not found!");
            if(sp.intValue != 1) sp.intValue = 1; // set array size to 1
            sp = so.FindProperty("m_Materials.Array.data[0]"); // get 1st entry in array
            if(sp == null) Debug.LogError("m_Materials.Array.data[0] not found!");
            Material editorMaterial = masterSpriteData.GetEditorMaterial();
            if(sp.objectReferenceValue != editorMaterial) sp.objectReferenceValue = editorMaterial; // set to sprite's default material

            so.ApplyModifiedProperties();

            EditorUtility.SetDirty(meshRenderer); // flag this object needs saving
        }

        private bool CheckForComponentConflicts(GameObject go) {
            MeshFilter meshFilter = (MeshFilter)go.GetComponent(typeof(MeshFilter));
            MeshRenderer meshRenderer = (MeshRenderer)go.GetComponent(typeof(MeshRenderer));
            if(meshFilter != null || meshRenderer != null) return true; // conflicts found
            return false;
        }

        private void RemoveConflictingComponents() {
            MeshFilter meshFilter = (MeshFilter)selectedGameObject.GetComponent(typeof(MeshFilter));
            if(meshFilter != null) {
                Utils.UnityTools.Undo.DestroyObjectImmediate(meshFilter);
                EditorUtility.SetDirty(selectedGameObject);
            }

            MeshRenderer meshRenderer = (MeshRenderer)selectedGameObject.GetComponent(typeof(MeshRenderer));
            if(meshRenderer != null) {
                Utils.UnityTools.Undo.DestroyObjectImmediate(meshRenderer);
                EditorUtility.SetDirty(selectedGameObject);
            }
        }

        #endregion

        #region Frame Offset Functions

        private void OffsetAllColliderFramesInAnimation(EditorMasterSprite.Animation animation, int offsetX, int offsetY, bool offsetStaticColliders) {
            int colliderCount = masterSpriteData.liveColliderSetCount;
            if(colliderCount <= 0) return;

            // offset all collider frames in animation
            Sprite.ColliderSet[] colliderSets = masterSpriteData.colliderSets;
            for(int i = 0; i < colliderCount; i++) {
                Sprite.ColliderSet colliderSet = colliderSets[i];
                if(colliderSet == null) continue;
                int colliderSetIndex = i;

                if(!colliderSet.isAnimated) { // static collider
                    if(!offsetStaticColliders) continue;
                    OffsetColliderFrame(colliderSetIndex, null, offsetX, offsetY, true); // offset the static collider

                } else { // animated collider

                    EditorMasterSprite.Frame[] frames = animation.editorFrames;
                    if(frames == null || frames.Length == 0) continue;
                    for(int j = 0; j < frames.Length; j++) {
                        OffsetColliderFrame(colliderSetIndex, frames[j], offsetX, offsetY, false);
                    }
                }
            }

            // Refresh the controls (may not be visible but still refresh them)
            RefreshColliderFrameOffsetControls();
        }

        private void OffsetAllColliderFramesInFrame(EditorMasterSprite.Frame editorFrame, int offsetX, int offsetY, bool offsetStaticColliders) {
            int colliderCount = masterSpriteData.liveColliderSetCount;
            if(colliderCount <= 0) return;

            // Offset all collider frames in frame, including static colliders
            Sprite.ColliderSet[] colliderSets = masterSpriteData.colliderSets;
            for(int i = 0; i < colliderCount; i++) {
                Sprite.ColliderSet colliderSet = colliderSets[i];
                if(colliderSet == null) continue;
                int colliderSetIndex = i;
                OffsetColliderFrame(colliderSetIndex, editorFrame, offsetX, offsetY, offsetStaticColliders);
            }

            // Refresh the controls (may not be visible but still refresh them)
            RefreshColliderFrameOffsetControls();
        }

        private void RefreshColliderFrameOffsetControls() {
            colliderFrameProperties_sizeX.refresh = true;
            colliderFrameProperties_sizeY.refresh = true;
            colliderFrameProperties_centerX.refresh = true;
            colliderFrameProperties_centerY.refresh = true;
        }

        private void OffsetColliderFrame(int colliderSetIndex, EditorMasterSprite.Frame editorFrame, int offsetX, int offsetY, bool offsetStaticCollider) {
            if(masterSpriteData.colliderSets == null || masterSpriteData.colliderSets.Length == 0) return;
            if(colliderSetIndex < 0 || colliderSetIndex >= masterSpriteData.colliderSets.Length) return;

            Sprite.ColliderFrame colliderFrame;
            bool isStaticCollider = !masterSpriteData.colliderSets[colliderSetIndex].isAnimated;

            if(isStaticCollider) {
                if(!offsetStaticCollider) return;
                colliderFrame = masterSpriteData.colliderSets[colliderSetIndex].staticColliderFrame; // get collider frame from collider set
            } else {
                if(editorFrame == null) return;
                colliderFrame = editorFrame.colliderFrames[colliderSetIndex];
            }

            OffsetColliderFrame(colliderFrame, offsetX, offsetY); // offset the collider
        }

        private void OffsetColliderFrame(Sprite.ColliderFrame colliderFrame, int offsetX, int offsetY) {
            if(colliderFrame == null) return;
            colliderFrame.center2D.x += offsetX;
            colliderFrame.center2D.y += offsetY;
        }

        private void OffsetAllLocatorFramesInAnimation(EditorMasterSprite.Animation animation, int offsetX, int offsetY) {
            int locatorCount = masterSpriteData.liveLocatorSetCount;
            if(locatorCount <= 0) return;

            // offset all locator frames in animation
            Sprite.LocatorSet[] locatorSets = masterSpriteData.locatorSets;
            for(int i = 0; i < locatorCount; i++) {
                Sprite.LocatorSet locatorSet = locatorSets[i];
                if(locatorSet == null) continue;
                int locatorSetIndex = i;

                EditorMasterSprite.Frame[] frames = animation.editorFrames;
                if(frames == null || frames.Length == 0) continue;
                for(int j = 0; j < frames.Length; j++) {
                    OffsetLocatorFrame(locatorSetIndex, frames[j], offsetX, offsetY);
                }
            }

            // Refresh the controls (may not be visible but still refresh them)
            RefreshLocatorFrameOffsetControls();
        }

        private void OffsetAllLocatorFramesInFrame(EditorMasterSprite.Frame editorFrame, int offsetX, int offsetY) {
            int locatorCount = masterSpriteData.liveLocatorSetCount;
            if(locatorCount <= 0) return;

            // Offset all locator frames in frame, including static locators
            Sprite.LocatorSet[] locatorSets = masterSpriteData.locatorSets;
            for(int i = 0; i < locatorCount; i++) {
                Sprite.LocatorSet locatorSet = locatorSets[i];
                if(locatorSet == null) continue;
                int locatorSetIndex = i;
                OffsetLocatorFrame(locatorSetIndex, editorFrame, offsetX, offsetY);
            }

            // Refresh the controls (may not be visible but still refresh them)
            RefreshLocatorFrameOffsetControls();
        }

        private void RefreshLocatorFrameOffsetControls() {
            locatorFrameProperties_positionX.refresh = true;
            locatorFrameProperties_positionY.refresh = true;
        }

        private void OffsetLocatorFrame(int locatorSetIndex, EditorMasterSprite.Frame editorFrame, int offsetX, int offsetY) {
            if(masterSpriteData.locatorSets == null || masterSpriteData.locatorSets.Length == 0) return;
            if(locatorSetIndex < 0 || locatorSetIndex >= masterSpriteData.locatorSets.Length) return;

            Sprite.LocatorFrame locatorFrame;
            if(editorFrame == null) return;

            locatorFrame = editorFrame.locatorFrames[locatorSetIndex];
            OffsetLocatorFrame(locatorFrame, offsetX, offsetY); // offset the locator
        }

        private void OffsetLocatorFrame(Sprite.LocatorFrame locatorFrame, int offsetX, int offsetY) {
            if(locatorFrame == null) return;
            locatorFrame.pixelPosition.x += offsetX;
            locatorFrame.pixelPosition.y += offsetY;
        }

        private void OffsetAllFrames(int offsetX, int offsetY) {
            EditorMasterSprite.Frame[] frames = animationListBoxContainer.selectedObject.editorFrames;
            for(int i = 0; i < frames.Length; i++) {
                frames[i].framePixelOffset.x += offsetX;
                frames[i].framePixelOffset.y += offsetY;
            }
        }

        #endregion

        #region Frame Editor Functions

        private bool FitColliderToSprite(EditorMasterSprite.Frame frame, Sprite.ColliderFrame colliderFrame) {
            if(frame == null || colliderFrame == null) return false;
            Texture2D tex = frame.GetTexture();
            if(tex == null) return false;

            colliderFrame.rotation = 0.0f; // make sure collider isn't rotated

            Color[] pixels = tex.GetPixels();
            int rows = tex.height;
            int cols = tex.width;
            int lastRow = rows - 1;
            int lastCol = cols - 1;

            int lowestLeft = -1;
            bool foundLeft = false;
            int highestRight = -1;
            int highestTop = -1;
            int lowestBot = -1;
            bool foundPixel = false;

            // Remember: 0,0 is lower left! We run through each row going UP
            for(int curRow = 0; curRow < rows; curRow++) {
                for(int curCol = 0; curCol < cols; curCol++) {
                    int index = curRow * cols + curCol;

                    if(pixels[index].a > 0.0f) { // found a pixel that isn't totally transparent
                        if(!foundPixel) foundPixel = true;

                        // save data about where we found the pixels
                        if(lowestBot == -1) lowestBot = curRow; // save first pixel we hit
                        if(curRow > highestTop) highestTop = curRow; // save every time we hit a pixel going down

                        if(!foundLeft || curCol < lowestLeft) { // save every time we find a left value closer to 0, always on the first find
                            lowestLeft = curCol;
                            if(!foundLeft) foundLeft = true;
                        }
                        if(curCol > highestRight) highestRight = curCol;
                    }
                }
            }
            if(!foundPixel) return false; // there were no pixels not at 0 alpha in this atlas!

            // Save trim values
            int trimTop = lastRow - highestTop;
            int trimBot = lowestBot;
            int trimLeft = lowestLeft;
            int trimRight = lastCol - highestRight;

            SpriteFactory.Utils.DataClasses.IntVector2 offset = frame.framePixelOffset;

            // First find start/end for entire texture map
            int halfWidth = tex.width / 2;
            int halfHeight = tex.height / 2;
            SpriteFactory.Utils.DataClasses.IntVector2 startPos = new SpriteFactory.Utils.DataClasses.IntVector2(-1 * (tex.width - halfWidth), (tex.height - halfHeight));
            SpriteFactory.Utils.DataClasses.IntVector2 endPos = new SpriteFactory.Utils.DataClasses.IntVector2(halfWidth, -halfHeight);

            // Adjust for trim
            if(trimTop != 0 || trimBot != 0 || trimLeft != 0 || trimRight != 0) {
                startPos.x += trimLeft;
                startPos.y -= trimTop;
                endPos.x -= trimRight;
                endPos.y += trimBot;
            }

            // Adjust for offset
            startPos.x += offset.x;
            startPos.y += offset.y;
            endPos.x += offset.x;
            endPos.y += offset.y;

            // Convert to center, size format and store in collider frame
            colliderFrame.size2D.x = endPos.x - startPos.x;
            colliderFrame.size2D.y = startPos.y - endPos.y; // reverse
            colliderFrame.center2D.x = (startPos.x + endPos.x) * 0.5f;
            colliderFrame.center2D.y = (startPos.y + endPos.y) * 0.5f;

            return true;
        }

        #endregion

        #region Misc

        private void SetStyles() {
            // set up styles
            errorGUIStyle = new GUIStyle();
            errorGUIStyle.normal.textColor = Color.red;

            style_mainPageContainer = new GUIStyle();
            style_mainPageContainer.padding = new RectOffset(0, 0, 5, 5);

            style_mainColumns = new GUIStyle();
            style_mainColumns.padding = new RectOffset(10, 10, 0, 0);

            style_cellPad = new GUIStyle();
            style_cellPad.padding = new RectOffset(10, 10, 5, 5);

            style_leftMargin = new GUIStyle();
            style_leftMargin.margin = new RectOffset(10, 0, 0, 0);

            style_labelNoLRPad = new GUIStyle(GUI.skin.label);
            style_labelNoLRPad.padding = new RectOffset(0, 0, style_labelNoLRPad.padding.top, style_labelNoLRPad.padding.bottom);
            style_labelNoLRPad.margin = new RectOffset(0, 0, style_labelNoLRPad.margin.top, style_labelNoLRPad.margin.top);

            style_importerOutput = new GUIStyle(GUI.skin.label);
            style_importerOutput.wordWrap = true;
            style_importerOutput.normal.textColor = GUI.skin.label.normal.textColor;

            style_buttonRow = new GUIStyle();
            style_buttonRow.padding = new RectOffset(0, 0, 5, 5);

            // Left Pad Fix:
            // Issue with 8px padding showing up on EditorGUILayout controls in same cell as fixed controls:
            // GetRect() MEANS ADDED MARGIN TO OTHER AUTO LAYOUT CONTROLS IN THE SAME CELL
            // Auto control label has some built-in padding that DOES NOT obey style
            // also, if it's alone in a cell with no padding, it will have no padding
            // but the instant you add a GetRect() call to the same cell its in, it starts rendering with padding
            // You end up with double left padding on auto layout controls, but single padding on fixed layout controls
            // WORKAROUND: Always left-pad any cell that contains auto layout + fixed layout controls
            // left-pad must be >= label left pad, or 4px to hide the padding discrepancy.
            style_leftPadFix = new GUIStyle();
            style_leftPadFix.padding = new RectOffset(4, 0, 0, 0);

            style_blank = new GUIStyle();

            stylesSet = true; // flag it
        }

        private void UpdateEditMode() {
            if(busy) return; // currently waiting for selection to be changed

            if(groupListBoxContainer.hasSelection && groupListBoxContainer.selectedIndex > 0) { // we have a group selected
                if(spriteListBoxContainer.hasSelection) editMode = EditMode.Sprite;
                else editMode = EditMode.SpriteGroup;
            } else { // no group selected
                if(spriteListBoxContainer.hasSelection) editMode = EditMode.Sprite;
                else editMode = EditMode.None;
            }
        }

        private void SetStaticSpriteMode(bool isStatic) {
            // Change labels on some controls depending on mode
            if(isStatic) {
                frameProperties_offsetColliders.label.text = "Colliders:";
                frameProperties_offsetLocators.label.text = "Locators:";
                frameProperties_offsetStaticColliders.label.text = "Static Colliders:";
            } else {
                frameProperties_offsetColliders.label.text = "C:";
                frameProperties_offsetLocators.label.text = "L:";
                frameProperties_offsetStaticColliders.label.text = "S:";
            }
        }

        private string[] GetColliderLayerOptions() {
            string[] options = new string[32];
            for(int i = 0; i < 32; i++) { // get layer names
                options[i] = i + " : " + LayerMask.LayerToName(i);
            }
            SpriteFactory.Utils.ArrayTools.Insert<string>(ref options, 0, "Inherit from Sprite");
            return options;
        }

        private void Export() {
            db.ExportPackage(exporter);
        }

        private bool UpgradeCheck() {
            if(!upgradeRequired) {
                if(programVersionUpdateRequired) UpdateProgramVersion(); // check if the program version needs to be updated even data version doesn't
                return true;
            }

            if(EditorUtility.DisplayDialog("Upgrade Rebuild Required", "Sprite Factory " + programVersion + " requires all data to be rebuilt before you can proceed. This may take a very long time depending on how many Sprites and Sprite Groups you have. MAKE SURE YOU BACKUP YOUR ENTIRE PROJECT FIRST!", "Rebuild Now", "Close")) {
                db.UpgradeRebuild();
                upgradeRequired = false;
                return true;
            } else { // user does not want to upgrade, force quit
                this.Close();
                return false;
            }
        }

        private void UpdateProgramVersion() {
            if(!programVersionUpdateRequired) return;

            db.UpdateProgramVersion();
            programVersionUpdateRequired = false;
        }

        private void NotInitialized() {
            initialized = false;
            initializationFailed = false;
        }

        private bool HandleEditorPlayModeChanges() {
            if(EditorApplication.isPlaying) {
                EditorPlayStarted();
                return false; // close the editor window if editor is in play mode
            } else if(editorIsPlaying) { // just stopped playing
                EditorPlayStopped();
                return false;
            }
            return true;
        }

        private void EditorPlayStarted() {
            editorIsPlaying = true;
        }

        private void EditorPlayStopped() {
            editorIsPlaying = false;
            NotInitialized();
            Initialize();
        }

        private void UpdateCacheVars() {
            db.UpdateCacheVars();
        }

        #endregion

        #region Unity Selection

        private void GetUnitySelection() {
            unitySelection = Selection.gameObjects;
            sceneSelectionChanged = true;
        }

        private void UpdateUnitySelection() {
            if(sceneSelectionChanged) {
                // Clear selection
                selectedGameObject = null;

                // Check for new selected game object
                if(unitySelection != null && unitySelection.Length > 0) {
                    for(int i = 0; i < unitySelection.Length; i++) {
                        PrefabType type = PrefabUtility.GetPrefabType(unitySelection[i]);
                        if(type == PrefabType.Prefab) continue; // do not allow selecting prefabs
                        selectedGameObject = unitySelection[i];
                        break;
                    }
                }
            }
        }

        #endregion

        #region Delegates

        private void AnimationSelectionChangeDelegate(bool selected, EditorMasterSprite.Animation selection) {
            if(selection == null) return;

            if(selected) { // this was a selection
                selection.BeginEditing();
            } else { // this was a deselection
                selection.EndEditing();
            }
        }

        #endregion

        #region Error Handling

        private void HandleExceptionError(System.Exception e) {
            if(e.GetType() == typeof(System.InvalidOperationException)) {
                // silence the exception
                // This is a workaround to prevent Mac version from throwing exceptions when chooser window is opened for any object control
                // This is not a good way to do it, but I cannot pinpoint where the exception is thrown because Unity is throwing it
                return;
            }

            Debug.LogError("SpriteFactory failed due to an exception:");
            Debug.LogError(e.Message);
            Debug.LogError("Stack Trace: " + e.StackTrace);
            initialized = false; // prevent it from continuing to try to run
            ClearPersistentVars(); // make sure no persistent vars are left over
        }

        #endregion

        #endregion
    }
}