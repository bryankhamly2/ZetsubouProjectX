﻿using UnityEditor;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using SpriteFactory;
using SpriteFactory.Editor.DataClasses;
using Sprite = SpriteFactory.Sprite;
using Settings = SpriteFactory.Settings;

namespace SpriteFactory.Editor {

    public class EditorMasterSprite : ScriptableObject {
        new public string name; // store just the name here so we can build lists quickly without loading any of the dependencies

        public string editorPreviewMeshFileName;
        public string editorPreviewMaterialFileName;
        public string[] atlasFiles;
        public SpriteFactoryData.MaterialSetFiles_Save[] materialSetFiles;
        public string coreFileName;

        // Core access
        [System.NonSerialized] private EditorMasterSpriteCore _coreFile;
        private EditorMasterSpriteCore core {
            get {
                //if(_coreFile == null) { // core file hasn't been loaded yet -- probably shouldn't cache this because it can change
                    _coreFile = SpriteEditor.LoadAssetAtPathRel<EditorMasterSpriteCore>(SpriteEditor.AddEditorMasterSpriteCoreFilePath(coreFileName));
                    if(_coreFile == null) { // unable to load the core file
                        Debug.LogError("EditorMasterSprite core file is missing!");
                        return null;
                    }
                //}
                return _coreFile;
            }
        }

        // Core pass-through properties
        public EditorMasterSprite.Data data {
            get {
                EditorMasterSpriteCore coreObj = core;
                if(coreObj == null) return null;
                return coreObj.data;
            }
            set {
                EditorMasterSpriteCore coreObj = core;
                if(coreObj == null) return;
                coreObj.data = value;
            }
        }

        #region // METHODS
        
        public string GetEditorPreviewMeshFilePath() {
            return SpriteEditor.AddEditorMeshFilePath(editorPreviewMeshFileName);
        }

        public string GetEditorPreviewMaterialFilePath() {
            return SpriteEditor.AddMaterialFilePath(editorPreviewMaterialFileName);
        }

        public string GetAtlasFilePath(int index) {
            if(atlasFiles == null || index < 0 || index >= atlasFiles.Length) throw new System.Exception("Invalid index!");
            return SpriteEditor.AddAtlasFilePath(atlasFiles[index]);
        }

        public string[] GetAtlasFilePaths() {
            if(atlasFiles == null) return null;
            string[] paths = new string[atlasFiles.Length];
            for(int i = 0; i < atlasFiles.Length; i++) {
                paths[i] = SpriteEditor.AddAtlasFilePath(atlasFiles[i]);
            }
            return paths;
        }

        public void SetAtlasFiles(string[] atlasFilePaths) {
            if(atlasFilePaths == null) {
                atlasFiles = null;
                return;
            }

            // Get file names from full paths and store
            string[] fileNames = new string[atlasFilePaths.Length];
            for(int i = 0; i < atlasFilePaths.Length; i++) {
                fileNames[i] = System.IO.Path.GetFileName(atlasFilePaths[i]);
            }
            atlasFiles = fileNames;
        }

        public SpriteFactoryData.MaterialSetFiles[] GetWorkingMaterialSetFiles() {
            if(materialSetFiles == null) return null;
            
            int count = materialSetFiles.Length;
            SpriteFactoryData.MaterialSetFiles[] workingFiles = new SpriteFactoryData.MaterialSetFiles[count];
            for(int i = 0; i < count; i++) {
                workingFiles[i] = new SpriteFactoryData.MaterialSetFiles(materialSetFiles[i]); // convert
            }
            return workingFiles;
        }

        public void SetDirtyForSave(bool setDirtyCore = true) {
            EditorUtility.SetDirty(this);
            if(setDirtyCore) EditorUtility.SetDirty(core);
        }

        public void SetCoreDirtyForSave() {
            EditorUtility.SetDirty(core);
        }

        #endregion

        #region // ENUMS

        public enum TilingMode { Auto = 0, None = 1, Manual = 2 };

        #endregion

        #region // CLASSES

        // COMPONENT CLASSES /////////////

        #region // Data

        [System.Serializable]
        public class Data : Sprite.Data_Base {
            #region // Static vars

            private static Color[] colliderSetColors = new Color[] {
                Color.green,
                Color.blue,
                Color.red,
                Color.yellow,
                Color.cyan,
                Color.magenta,
                new Color(1.0f, 0.56f, 0.0f), // orange
                new Color(0.8f, 1.0f, 0.776f), // light green
                new Color(1.0f, 0.84f, 0.84f), // pink
                new Color(0.84f, 0.95f, 1.0f), // baby blue
                new Color(0.5f, 0.0f, 0.0f), // dark red
                new Color(0.0f, 0.5f, 0.0f), // dark green
                new Color(0.0f, 0.0f, 0.5f), // dark blue
                new Color(0.27f, 0.0f, 0.5f), // dark purple
                Color.white,
                Color.black
            };

            #endregion

            // Identity
            public EditorMasterSprite editorMasterSprite; // a link to the editor master sprite object, not the core, but the main one
            public int spriteGroupId;

            // Data
            public EditorMasterSprite.Animation[] editorAnimations; // holds frame texture data used in the sprite editor
            public EditorMasterSprite.Atlas[] editorAtlases;
            public EditorMasterSprite.MeshFrame[] editorMeshFrames;
            public AutoMeshSettings autoMeshSettings;
            public int defaultFrameRate = 15;
            public Sprite.WrapMode defaultWrapMode = Sprite.WrapMode.Once;
            public BoolDefaultOption editorUseTwoSidedMesh;
            public bool useDefaultAtlasTextureFilterMode;
            public FilterMode atlasTextureFilterMode;
            public int atlasTextureAnisoLevel = -1; // set to default
            public EditorMasterSprite.MaterialSet[] editorMaterialSets;
            public int[] atlasToGroupAtlasIndices; // relates local atlas index to group atlas index for sprites in groups
            public TilingMode tilingMode;
            public bool tile;
            public bool tileTop;
            public bool tileBottom;
            public bool tileRight;
            public bool tileLeft;
            public bool useDefaultMeshType = true;
            public SpriteFactory.Enums.SpriteMeshType meshType;
            public bool useDefaultAutoMeshTransparencyChannel = true;
            public SpriteFactory.Enums.TransparencyChannel autoMeshTransparencyChannelOverride = Enums.TransparencyChannel.Alpha;
            public bool useDefaultAutoMeshEdgeExtrude = true;
            public int autoMeshEdgeExtrudeOverride;
            public bool useDefaultAutoMeshVertexReductionDistance = true;
            public int autoMeshVertexReductionDistanceOverride;
            public SpriteFactory.Utils.DataClasses.IntPadding bleedPaddingPixels;
            [SerializeField]private int colliderGroupUniqueIdCounter;
            [SerializeField]private int meshFrameUidCounter;

            // For new sprite creation
            public string editorMaterialGUID;
            public bool hasEditorMaterial {
                get {
                    if(Utils.AssetTools.GetAssetPathFromGUID(editorMaterialGUID) != null) return true;
                    return false;
                }
            }

            // Properties
            public int liveColliderSetCount {
                get {
                    if(colliderSets == null) return 0;
                    return colliderSets.Length;
                }
            }
            public int liveColliderGroupCount {
                get {
                    if(colliderGroups == null) return 0;
                    return colliderGroups.Length;
                }
            }
            public int liveLocatorSetCount {
                get {
                    if(locatorSets == null) return 0;
                    return locatorSets.Length;
                }
            }
            public bool finalUseCustomMesh {
                get {
                    if(useDefaultMeshType) { // using the default type
                        if(gameSettings != null && gameSettings.settings != null) {
                            if(gameSettings.settings.defaultMeshType == Enums.SpriteMeshType.AutoMesh)
                                return true;
                            else
                                return false;
                        }
                    }
                    // Using an override
                    if(meshType == Enums.SpriteMeshType.AutoMesh) return true;
                    return false;
                }
            }
            public Enums.TransparencyChannel finalAutoMeshTransparencyChannel {
                get {
                    if(!useDefaultAutoMeshTransparencyChannel) return autoMeshTransparencyChannelOverride; // use the override
                    if(gameSettings != null && gameSettings.settings != null) {
                        return gameSettings.settings.defaultAutoMeshTransparencyChannel;
                    }
                    return Enums.TransparencyChannel.Alpha; // failed to find settings, just set to alpha
                }
            }
            public int finalAutoMeshExtrude {
                get {
                    if(useDefaultAutoMeshEdgeExtrude) { // using the default
                        if(gameSettings != null && gameSettings.settings != null) {
                            return gameSettings.settings.scaledDefaultAutoMeshEdgeExtrude; // return the scaled extrude for current resolution target
                        }
                        // if fail, just return below
                    }
                    // Using an override
                    if(gameSettings != null && gameSettings.settings != null) {
                        return gameSettings.settings.ScaleAutoMeshEdgeExtrude(autoMeshEdgeExtrudeOverride); // return the scaled value for current resolution target
                    }
                    return autoMeshEdgeExtrudeOverride;
                }
            }
            public int finalAutoMeshVertexReductionDistance {
                get {
                    if(useDefaultAutoMeshVertexReductionDistance) { // using the default
                        if(gameSettings != null && gameSettings.settings != null) {
                            return gameSettings.settings.scaledDefaultAutoMeshVertexReductionDistance;
                        }
                        // if fail, just return below
                    }
                    // Using an override
                    if(gameSettings != null && gameSettings.settings != null) {
                        return gameSettings.settings.ScaleAutoMeshEdgeVertexReductionDistance(autoMeshVertexReductionDistanceOverride); // return the scaled value for current resolution target
                    }
                    return autoMeshVertexReductionDistanceOverride;
                }
            }

            public Data(EditorMasterSprite editorMasterSprite) {
                this.editorMasterSprite = editorMasterSprite;
            }

            public Data(EditorMasterSprite editorMasterSprite, string name)
                : this(editorMasterSprite) { // used for creation of new master sprites
                    this.name = name;
            }


            #region Animation Editing Functions

            public int GetAnimationIndex(EditorMasterSprite.Animation inAnimation) {
                for(int i = 0; i < editorAnimations.Length; i++) {
                    if(editorAnimations[i] == inAnimation) return i;
                }
                return -1;
            }

            public void SetToDefaultAnimation(EditorMasterSprite.Animation inAnim) {
                int index = GetAnimationIndex(inAnim);
                if(index == -1) throw new System.Exception("Animation not found!");
                defaultAnimationIndex = index;
            }

            private EditorMasterSprite.Animation CreateNewAnimation() {
                EditorMasterSprite.Animation newAnim = new EditorMasterSprite.Animation(defaultFrameRate, defaultWrapMode);
                VerifyName(newAnim, -1);

                return newAnim;
            }

            public void AddNewAnimation() {
                SpriteFactory.Utils.ArrayTools.Add<EditorMasterSprite.Animation>(ref editorAnimations, CreateNewAnimation());
            }

            public void AddAnimation(EditorMasterSprite.Animation inAnimation) {
                VerifyName(inAnimation, -1);
                SpriteFactory.Utils.ArrayTools.Add(ref editorAnimations, inAnimation);
            }

            public int InsertNewAnimationBeforeSelected(EditorMasterSprite.Animation inAnimation) {
                int index = GetAnimationIndex(inAnimation); // find position of selected animation
                EditorMasterSprite.Animation newAnimation = CreateNewAnimation();
                SpriteFactory.Utils.ArrayTools.Insert(ref editorAnimations, index, newAnimation); // insert into animation list
                AdjustAnimationIndices(index, 1, false); // make sure indices stay aligned
                return index;
            }

            public void DuplicateAnimation(EditorMasterSprite.Animation inAnimation) {
                int index = GetAnimationIndex(inAnimation); // find position of selected animation

                inAnimation.EndEditing(); // make sure animation is not in edit mode before copying to commit the texture
                EditorMasterSprite.Animation newAnimation = inAnimation.DeepCopy(); // create the new animation
                inAnimation.BeginEditing(); // resume editing after copy

                // Insert one space after current entry
                if(index < editorAnimations.Length - 1) { // space left to insert
                    index++; // insert in next space
                    SpriteFactory.Utils.ArrayTools.Insert(ref editorAnimations, index, newAnimation); // insert into animations list
                    VerifyName(newAnimation, index);
                    AdjustAnimationIndices(index, 1, false); // make sure indices stay aligned
                } else {// already at last space, add it instead
                    AddAnimation(newAnimation); // add to end
                }
            }

            public void RemoveAnimation(EditorMasterSprite.Animation inAnimation) {
                int index = System.Array.IndexOf(editorAnimations, inAnimation);
                if(index >= 0 && index < editorAnimations.Length) {
                    SpriteFactory.Utils.ArrayTools.RemoveAt(ref editorAnimations, index); // remove animation
                    if(index == defaultAnimationIndex) defaultAnimationIndex = 0; // removed the default, set to 0
                    else AdjustAnimationIndices(index, -1, false); // make sure indices stay aligned
                    return;
                }
                Debug.Log("Error removing animation");
            }

            public void RemoveAnimation(int index) {
                if(index >= 0 && index < editorAnimations.Length) {
                    SpriteFactory.Utils.ArrayTools.RemoveAt(ref editorAnimations, index);
                    if(index == defaultAnimationIndex) defaultAnimationIndex = 0; // removed the default, set to 0
                    else AdjustAnimationIndices(index, -1, false); // make sure indices stay aligned
                    return;
                }
                Debug.Log("Error removing animation");
            }

            public bool ReorderAnimation(EditorMasterSprite.Animation inAnimation, int offset, bool reorderNow = true) {
                bool offsetDown = false;
                int index = GetAnimationIndex(inAnimation);
                int newIndex = index + offset;

                if(Mathf.Sign(offset) > 0) // reorder down
                    offsetDown = true;

                if(offsetDown) { // moving down
                    int lastIndex = editorAnimations.Length - 1;
                    if(index == lastIndex) return false; // already at the end
                    if(!reorderNow) return true; // just testing to see if we can reorder, passed

                    if(newIndex >= lastIndex) { // would be at last, must insert at end
                        offset = lastIndex - index;
                        SpriteFactory.Utils.ArrayTools.Add(ref editorAnimations, inAnimation);
                    } else { // insert into array list
                        SpriteFactory.Utils.ArrayTools.Insert(ref editorAnimations, newIndex + 1, inAnimation); // adjust for insert pushing things down so we insert after the target
                    }
                    SpriteFactory.Utils.ArrayTools.RemoveAt(ref editorAnimations, index); // remove the old one
                    AdjustAnimationIndices(index, offset, true); // make sure indices stay aligned

                } else { // moving up
                    if(index == 0) return false; // already at beginning
                    if(!reorderNow) return true; // just testing to see if we can reorder, passed

                    // Adjust offset if we can't move the full offset
                    if(newIndex <= 0) { // trying to move up but can't do full offset
                        if(Mathf.Abs(offset) > index) { // reduce offset to push entry to 0
                            offset = index;
                            newIndex = index + offset; // recalulate new index
                        }
                    }
                    SpriteFactory.Utils.ArrayTools.Insert(ref editorAnimations, newIndex, inAnimation); // insert the script in its new place
                    SpriteFactory.Utils.ArrayTools.RemoveAt(ref editorAnimations, Mathf.Abs(offset) + index); // remove the script from the array list
                    AdjustAnimationIndices(index, offset, true); // make sure indices stay aligned
                }
                return true;
            }

            private void AdjustAnimationIndices(int index, int offset, bool moveUpDown) {
                if(!moveUpDown) { // must be an insert/delete
                    if(defaultAnimationIndex >= index) { // index was affected
                        defaultAnimationIndex += offset;
                    }
                } else { // must be a up/down move swap
                    int newIndex = index + offset;
                    if(defaultAnimationIndex == index)
                        defaultAnimationIndex = newIndex;
                    else if(defaultAnimationIndex == newIndex)
                        defaultAnimationIndex = index;
                }
                if(defaultAnimationIndex < 0) defaultAnimationIndex = 0;
            }

            public void ChangeAnimationName(EditorMasterSprite.Animation inAnimation, string newName) {
                int animIndex = GetAnimationIndex(inAnimation);
                editorAnimations[animIndex].name = newName;
                VerifyName(inAnimation, animIndex);
            }

            private void VerifyName(EditorMasterSprite.Animation inAnim, int thisIndex) {
                string newName = SpriteFactory.Utils.StringTools.VerifyName(inAnim.name, thisIndex, GetEditorAnimationNames());
                if(inAnim.name != newName) inAnim.name = newName; // update name if cleaned up
            }

            #endregion

            #region Frame Editing Functions

            public void AddNewFrame(int animationIndex, Texture2D texture, ulong timestamp) { // add new frame from drag-and-drop
                if(!VerifyAnimationIndex(animationIndex)) return;
                Frame newFrame = editorAnimations[animationIndex].AddNewFrame(texture, timestamp, colliderSets, locatorSets);
            }

            public void AddNewFrame(int animationIndex) { // add new blank frame
                if(!VerifyAnimationIndex(animationIndex)) return;
                Frame newFrame = editorAnimations[animationIndex].AddNewFrame(colliderSets, locatorSets);
            }

            public void InsertNewFrameBeforeSelected(int animationIndex, int frameIndex) {
                if(!VerifyAnimationIndex(animationIndex)) return;
                editorAnimations[animationIndex].InsertNewFrame(frameIndex, colliderSets, locatorSets);
            }

            public void DuplicateFrame(int animationIndex, int frameIndex) {
                if(!VerifyAnimationIndex(animationIndex)) return;
                editorAnimations[animationIndex].DuplicateFrame(frameIndex);
            }

            public void RemoveFrame(int animationIndex, EditorMasterSprite.Frame frame) {
                if(!VerifyAnimationIndex(animationIndex)) return;
                editorAnimations[animationIndex].RemoveFrame(frame);
            }

            public void RemoveFrame(int animationIndex, int frameIndex) {
                if(!VerifyAnimationIndex(animationIndex)) return;
                editorAnimations[animationIndex].RemoveFrame(frameIndex);
            }

            public bool ReorderFrame(int animationIndex, int frameIndex, int offset, bool reorderNow = true) {
                if(!VerifyAnimationIndex(animationIndex)) return false;
                return editorAnimations[animationIndex].ReorderFrame(frameIndex, offset, reorderNow);
            }

            public bool ReverseFrames(int animationIndex) {
                if(!VerifyAnimationIndex(animationIndex)) return false;
                return editorAnimations[animationIndex].ReverseFrames();
            }

            #endregion

            #region Collider Set Functions

            #region Editor Controls

            public void AddNewColliderSet(bool is2D) {
                Sprite.ColliderSet newSet = CreateColliderSet(is2D);
                SpriteFactory.Utils.ArrayTools.Add<Sprite.ColliderSet>(ref colliderSets, newSet);

                // When you add a new collider, you have to add it to the sprite
                // Frames must be updated
                // each frame gets 1 collider frame per collider
                AddNewColliderFrames(); // add collider frame to every frame
            }

            public void InsertNewColliderSet(bool is2D, int index) {
                Sprite.ColliderSet newSet = CreateColliderSet(is2D);
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.ColliderSet>(ref colliderSets, index, newSet);
                InsertNewColliderFrames(index);  // insert collider frames in every frame
            }

            public void DeleteColliderSet(int index) {
                SpriteFactory.Utils.ArrayTools.RemoveAt<Sprite.ColliderSet>(ref colliderSets, index);
                DeleteColliderFrames(index); // delete collider frame from every frame
            }

            public void DuplicateColliderSet(int index) {
                Sprite.ColliderSet newSet = colliderSets[index].DeepCopy();
                if(newSet.isParent) newSet.isParent = false; // prevent having multiple parents
                //if(!newSet.name.EndsWith("_copy")) newSet.name += "_copy"; // append copy
                InitializeColliderSet(ref newSet, false);
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.ColliderSet>(ref colliderSets, index + 1, newSet);
                DuplicateColliderFrames(index); // duplicate collider frame in every frame
            }

            public bool ReorderColliderSet(int index, int offset, bool reorderNow = true) {
                if(offset == 0) return false;
                if(index == colliderSets.Length - 1 && offset > 0) return false; // at end of list trying to move down
                if(index == 0 && offset < 0) return false; // at beginning of list trying to move up
                if(!reorderNow) return true; // just testing to see if we can reorder, passed

                RecorderColliderFrames(index, offset); // reorder collider frames in every frame

                // Does not handle offsets other than +/- 1
                if(offset > 1) offset = 1;
                if(offset < -1) offset = -1;

                Sprite.ColliderSet entry = colliderSets[index]; // get the entry
                SpriteFactory.Utils.ArrayTools.RemoveAt<Sprite.ColliderSet>(ref colliderSets, index); // remove entry first

                if(offset > 0) {
                    if(index + offset >= colliderSets.Length) { // would be at the end of the list
                        SpriteFactory.Utils.ArrayTools.Add<Sprite.ColliderSet>(ref colliderSets, entry); // add to end of the list

                        return true;
                    }
                }
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.ColliderSet>(ref colliderSets, index + offset, entry); // insert the entry back
                return true;
            }

            public void SetColliderSetParent(int index) {
                if(index < 0 || index >= liveColliderSetCount) return;
                ClearColliderSetParent();
                colliderSets[index].isParent = true;
                
                // Clear rotation on all frames of parent
                ClearParentColliderFrameRotations();
            }

            public void ClearColliderSetParent() {
                if(liveColliderSetCount == 0) return;
                for(int i = 0; i < colliderSets.Length; i++) {
                    if(colliderSets[i].isParent) colliderSets[i].isParent = false;
                }
            }

            public void ChangeColliderSet_IsAnimated(int index, bool isAnimatedCollider) {
                if(index < 0 || index >= liveColliderSetCount) return;
                Sprite.ColliderSet colliderSet = colliderSets[index];
                colliderSet.isAnimated = isAnimatedCollider;

                if(isAnimatedCollider) {
                    Sprite.ColliderFrame staticColliderFrame = colliderSet.staticColliderFrame;
                    if(staticColliderFrame.enabled) // set enable in new frames to true if the collider was enabled when converted
                        colliderSet.enableInNewFrames = true;

                    // copy static collider info to all frames
                    if(editorAnimations != null && editorAnimations.Length > 0) {
                        for(int i = 0; i < editorAnimations.Length; i++) {
                            if(editorAnimations[i] == null) continue;
                            EditorMasterSprite.Frame[] animFrames = editorAnimations[i].editorFrames;
                            if(animFrames == null || animFrames.Length == 0) continue;
                            for(int j = 0; j < animFrames.Length; j++) {
                                if(animFrames[j] == null) continue;
                                Sprite.ColliderFrame[] colliderFrames = animFrames[j].colliderFrames;
                                if(colliderFrames == null || colliderFrames.Length == 0) continue;
                                colliderFrames[index] = staticColliderFrame.DeepCopy();
                            }
                        }
                    }
                    colliderSets[index].staticColliderFrame = null; // null out the static collider data
                    return; // changed to an animated collider
                } else { // changed to static collider
                    // clear collider frames so no old data is left over
                    ClearColliderFrames(index); // clear the data in collider frames for this collider set
                    CreateStaticColliderFrame(colliderSet); // create a new static collider frame to store the frame data
                }
            }

            public void ChangeColliderSet_Is2D(int index, bool is2D) {
                if(index < 0 || index >= liveColliderSetCount) return;
                Sprite.ColliderSet colliderSet = colliderSets[index];
                colliderSet.ChangeColliderMode(is2D);
            }

            public Sprite.ColliderSet[] GetColliderSetsInGroup(int groupIndex) {
                if(colliderSets == null || colliderSets.Length == 0) return null;
                if(colliderGroups == null || colliderGroups.Length == 0) return null;
                if(groupIndex < 0 || groupIndex >= colliderGroups.Length) return null; // out of range
                if(colliderSets[groupIndex] == null) return null;

                int groupId = colliderGroups[groupIndex].id;

                List<Sprite.ColliderSet> sets = new List<Sprite.ColliderSet>();
                for(int i = 0; i < colliderSets.Length; i++) {
                    if(colliderSets[i] == null) continue;
                    if(colliderSets[i].groupId == groupId) sets.Add(colliderSets[i]);
                }
                if(sets.Count == 0) return null;

                return sets.ToArray();
            }

            #endregion

            #region Collider Frame Functions

            private void AddNewColliderFrames() {
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].AddNewColliderFrames();
                }
            }

            private void InsertNewColliderFrames(int index) {
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].InsertNewColliderFrames(index);
                }
            }

            private void DeleteColliderFrames(int index) {
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].DeleteColliderFrames(index);
                }
            }

            private void DuplicateColliderFrames(int index) {
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].DuplicateColliderFrames(index);
                }
            }

            private void RecorderColliderFrames(int index, int offset) {
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].ReorderColliderFrames(index, offset);
                }
            }

            private void ClearColliderFrames(int colliderSetIndex) {
                if(colliderSetIndex < 0 || colliderSetIndex >= liveColliderSetCount) return;
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].ClearColliderFrames(colliderSetIndex);
                }
            }

            public Sprite.ColliderFrame GetColliderFrame(int animIndex, int frameIndex, int colliderSetIndex) {
                if(liveColliderSetCount == 0) return null; // no collider sets
                if(colliderSetIndex < 0 || colliderSetIndex >= colliderSets.Length) return null; // invalide collider set index
                if(colliderSets[colliderSetIndex] == null) return null; // collider set is missing!

                if(!colliderSets[colliderSetIndex].isAnimated) { // static collider
                    return colliderSets[colliderSetIndex].staticColliderFrame; // get static collider frame from collider set

                } else { // animated collider
                    if(editorAnimations == null || editorAnimations.Length == 0) return null; // no animations
                    if(animIndex < 0 || animIndex >= editorAnimations.Length) return null; // invalid anim index

                    EditorMasterSprite.Frame[] frames = editorAnimations[animIndex].editorFrames;
                    if(frames == null || frames.Length == 0) return null; // no frames
                    if(frameIndex < 0 || frameIndex >= frames.Length) return null; // invalid frame index

                    EditorMasterSprite.Frame frame = frames[frameIndex];
                    if(frame.colliderFrames == null || colliderSetIndex >= frame.colliderFrames.Length) return null; // no collider frames

                    return frame.colliderFrames[colliderSetIndex]; // get the current editing collider frame from the sprite frame
                }
            }

            public Sprite.ColliderFrame[] GetAllMixedColliderFrames(int animIndex, int frameIndex) { // includes static and animated together
                if(liveColliderSetCount == 0) return null; // no collider sets
                Sprite.ColliderFrame[] colliderFrames = new Sprite.ColliderFrame[colliderSets.Length];
                for(int i = 0; i < colliderSets.Length; i++) {
                    Sprite.ColliderFrame colliderFrame = GetColliderFrame(animIndex, frameIndex, i);
                    colliderFrames[i] = colliderFrame;
                }
                return colliderFrames;
            }

            public bool SetColliderFrame(int animIndex, int frameIndex, int colliderSetIndex, Sprite.ColliderFrame colliderFrame) {
                if(liveColliderSetCount == 0) return false; // no collider sets
                if(colliderSetIndex < 0 || colliderSetIndex >= colliderSets.Length) return false; // invalide collider set index
                if(colliderSets[colliderSetIndex] == null) return false; // collider set is missing!

                if(!colliderSets[colliderSetIndex].isAnimated) { // static collider
                    colliderSets[colliderSetIndex].staticColliderFrame = colliderFrame; // set static collider frame in collider set
                    return true;

                } else { // animated collider
                    if(editorAnimations == null || editorAnimations.Length == 0) return false; // no animations
                    if(animIndex < 0 || animIndex >= editorAnimations.Length) return false; // invalid anim index

                    EditorMasterSprite.Frame[] frames = editorAnimations[animIndex].editorFrames;
                    if(frames == null || frames.Length == 0) return false; // no frames
                    if(frameIndex < 0 || frameIndex >= frames.Length) return false; // invalid frame index

                    EditorMasterSprite.Frame frame = frames[frameIndex];
                    if(frame.colliderFrames == null || colliderSetIndex >= frame.colliderFrames.Length) return false; // no collider frames

                    frame.colliderFrames[colliderSetIndex] = colliderFrame; // set the current editing collider frame in the sprite frame
                    return true;
                }
            }

            public bool IsColliderAnimated(int colliderSetIndex) {
                if(liveColliderSetCount == 0) return false; // no collider sets
                if(colliderSetIndex < 0 || colliderSetIndex >= colliderSets.Length) return false; // invalide collider set index
                if(colliderSets[colliderSetIndex] == null) return false; // collider set is missing!
                return colliderSets[colliderSetIndex].isAnimated;
            }

            private void CreateStaticColliderFrame(Sprite.ColliderSet set) {
                set.staticColliderFrame = new Sprite.ColliderFrame(); // create a new static collider frame to store the frame data
                set.staticColliderFrame.enabled = true; // start static colliders enabled
            }

            private void ClearParentColliderFrameRotations() {
                if(colliderSets == null || colliderSets.Length == 0) return;

                // Find index of parent collider set
                int parentColliderSetIndex = GetParentColliderSetIndex();
                if(parentColliderSetIndex == -1) return; // no parent collider sets

                // Get parent collider set
                Sprite.ColliderSet parentSet = colliderSets[parentColliderSetIndex];
                if(parentSet == null) return;

                // Clear static collider frame
                if(!parentSet.isAnimated) {
                    if(parentSet.staticColliderFrame != null) {
                        parentSet.staticColliderFrame.rotation = 0.0f; // clear
                    }
                    return; // done
                }
                
                // Clear animated collider frames
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    EditorMasterSprite.Frame[] frames = editorAnimations[i].editorFrames;
                    if(frames == null || frames.Length == 0) continue;
                    for(int j = 0; j < frames.Length; j++) {
                        if(frames[j] == null) continue;
                        Sprite.ColliderFrame[] colliderFrames = frames[j].colliderFrames;
                        if(colliderFrames == null || colliderFrames.Length == 0) continue;
                        if(colliderFrames[parentColliderSetIndex] == null) continue;
                        colliderFrames[parentColliderSetIndex].rotation = 0.0f; // clear
                    }
                }
            }

            private int GetParentColliderSetIndex() {
                if(colliderSets == null || colliderSets.Length == 0) return -1;
                for(int i = 0; i < colliderSets.Length; i++) {
                    if(colliderSets[i] == null) continue;
                    if(colliderSets[i].isParent) return i;
                }
                return -1;
            }

            #endregion

            private Sprite.ColliderSet CreateColliderSet(bool is2D) {
                Sprite.ColliderSet newSet = new Sprite.ColliderSet(is2D, "Collider0");
                InitializeColliderSet(ref newSet);
                return newSet;
            }

            private void InitializeColliderSet(ref Sprite.ColliderSet set, bool assignNewColor = true) {
                set.name = VerifyColliderSetName(set.name, -1); // make sure name isn't used
                if(assignNewColor) set.previewColor = FindUnusedColliderSetColor(); // set color for collider
                if(isStaticSprite) {
                    set.isAnimated = false; // make sure collider set is static for static sprites
                    CreateStaticColliderFrame(set); // make sure static sprite has a static collider and that the static frame has been created
                }
            }

            private Color FindUnusedColliderSetColor() {
                if(colliderSets == null || colliderSets.Length == 0) return colliderSetColors[0];

                int colorCount = colliderSetColors.Length;
                int colliderSetCount = colliderSets.Length;
                for(int i = 0; i < colorCount; i++) {
                    bool used = false;

                    for(int j = 0; j < colliderSetCount; j++) {
                        if(colliderSetColors[i] == colliderSets[j].previewColor) {
                            used = true;
                            break;
                        }
                    }
                    if(used) continue; // color was already used
                    return colliderSetColors[i]; // color wasn't used
                }

                // no color was chosen, pick one at random
                int rand = Random.Range(0, colorCount);
                return colliderSetColors[rand];
            }

            #region // Name Verification

            public string VerifyColliderSetName(string name, int thisIndex) {
                return SpriteFactory.Utils.StringTools.VerifyName(name, thisIndex, GetColliderSetNames());
            }

            #endregion

            public bool ColliderSetHasRotatedFrames(Sprite.ColliderSet colliderSet) {
                if(colliderSet == null) return false;
                if(colliderSets == null || colliderSets.Length == 0) return false;

                int index = GetColliderSetIndex(colliderSet);
                if(index < 0) return false;

                // Check static collider frames
                if(!colliderSet.isAnimated) {
                    if(colliderSet.staticColliderFrame != null) {
                        if(colliderSet.staticColliderFrame.rotation != 0.0f) return true;
                    }
                    return false;
                }

                // Check animated collider frames
                if(editorAnimations == null || editorAnimations.Length == 0) return false;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    EditorMasterSprite.Frame[] frames = editorAnimations[i].editorFrames;
                    if(frames == null || frames.Length == 0) continue;
                    for(int j = 0; j < frames.Length; j++) {
                        if(frames[j] == null) continue;
                        Sprite.ColliderFrame[] colliderFrames = frames[j].colliderFrames;
                        if(colliderFrames == null || colliderFrames.Length == 0) continue;
                        if(colliderFrames[index] == null) continue;
                        if(colliderFrames[index].rotation != 0.0f) return true;
                    }
                }
                return false;
            }

            public int GetColliderSetIndex(Sprite.ColliderSet colliderSet) {
                if(colliderSet == null) return -1;
                if(colliderSets == null || colliderSets.Length == 0) return -1;

                // Find this collider set
                for(int i = 0; i < colliderSets.Length; i++) {
                    if(colliderSets[i] == colliderSet)  return i;
                }
                return -1;
            }

            #endregion

            #region Collider Group Functions

            #region Editor Controls

            public void AddNewColliderGroup() {
                Sprite.ColliderGroup newSet = CreateColliderGroup();
                SpriteFactory.Utils.ArrayTools.Add<Sprite.ColliderGroup>(ref colliderGroups, newSet);
            }

            public void InsertNewColliderGroup(int index) {
                Sprite.ColliderGroup newSet = CreateColliderGroup();
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.ColliderGroup>(ref colliderGroups, index, newSet);
            }

            public void DeleteColliderGroup(int index) {
                SpriteFactory.Utils.ArrayTools.RemoveAt<Sprite.ColliderGroup>(ref colliderGroups, index);
            }

            public void DuplicateColliderGroup(int index) {
                Sprite.ColliderGroup newSet = colliderGroups[index].DeepCopy(GetUniqueColliderGroupId());
                //if(!newSet.name.EndsWith("_copy")) newSet.name += "_copy"; // append copy
                InitializeColliderGroup(ref newSet);
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.ColliderGroup>(ref colliderGroups, index + 1, newSet);
            }

            public bool ReorderColliderGroup(int index, int offset, bool reorderNow = true) {
                if(offset == 0) return false;
                if(index == colliderGroups.Length - 1 && offset > 0) return false; // at end of list trying to move down
                if(index == 0 && offset < 0) return false; // at beginning of list trying to move up
                if(!reorderNow) return true; // just testing to see if we can reorder, passed

                // Does not handle offsets other than +/- 1
                if(offset > 1) offset = 1;
                if(offset < -1) offset = -1;

                Sprite.ColliderGroup entry = colliderGroups[index]; // get the entry
                SpriteFactory.Utils.ArrayTools.RemoveAt<Sprite.ColliderGroup>(ref colliderGroups, index); // remove entry first

                if(offset > 0) {
                    if(index + offset >= colliderGroups.Length) { // would be at the end of the list
                        SpriteFactory.Utils.ArrayTools.Add<Sprite.ColliderGroup>(ref colliderGroups, entry); // add to end of the list

                        return true;
                    }
                }
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.ColliderGroup>(ref colliderGroups, index + offset, entry); // insert the entry back
                return true;
            }

            #endregion

            private Sprite.ColliderGroup CreateColliderGroup() {
                Sprite.ColliderGroup newGroup = new Sprite.ColliderGroup("Group0", GetUniqueColliderGroupId());
                InitializeColliderGroup(ref newGroup);
                return newGroup;
            }

            private void InitializeColliderGroup(ref Sprite.ColliderGroup group) {
                group.name = VerifyColliderGroupName(group.name, -1); // make sure name isn't used
            }

            #region // Name Verification

            public string VerifyColliderGroupName(string name, int thisIndex) {
                return SpriteFactory.Utils.StringTools.VerifyName(name, thisIndex, GetColliderGroupNames());
            }

            #endregion

            private int GetUniqueColliderGroupId() {
                return colliderGroupUniqueIdCounter++;
            }

            private bool IsValidColliderGroupId(int id) {
                if(colliderGroups == null || colliderGroups.Length == 0) return false;
                for(int i = 0; i < colliderGroups.Length; i++) {
                    if(colliderGroups[i] == null) continue;
                    if(colliderGroups[i].id == id) return true;
                }
                return false;
            }

            private int FindColliderGroupIndex(int groupId) {
                if(colliderGroups == null || colliderGroups.Length == 0) return -1;
                for(int i = 0; i < colliderGroups.Length; i++) {
                    if(colliderGroups[i] == null) continue;
                    if(colliderGroups[i].id == groupId) return i;
                }
                return -1;
            }

            #endregion

            #region Locator Set Functions

            #region Editor Controls

            public void AddNewLocatorSet() {
                Sprite.LocatorSet newSet = CreateLocatorSet();
                SpriteFactory.Utils.ArrayTools.Add<Sprite.LocatorSet>(ref locatorSets, newSet);

                // When you add a new locator, you have to add it to the sprite
                // Frames must be updated
                // each frame gets 1 locator frame per locator
                AddNewLocatorFrames(); // add locator frame to every frame
            }

            public void InsertNewLocatorSet(int index) {
                Sprite.LocatorSet newSet = CreateLocatorSet();
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.LocatorSet>(ref locatorSets, index, newSet);
                InsertNewLocatorFrames(index);  // insert locator frames in every frame
            }

            public void DeleteLocatorSet(int index) {
                SpriteFactory.Utils.ArrayTools.RemoveAt<Sprite.LocatorSet>(ref locatorSets, index);
                DeleteLocatorFrames(index); // delete locator frame from every frame
            }

            public void DuplicateLocatorSet(int index) {
                Sprite.LocatorSet newSet = locatorSets[index].DeepCopy();
                if(!newSet.name.EndsWith("_copy")) newSet.name += "_copy"; // append copy
                InitializeLocatorSet(ref newSet);
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.LocatorSet>(ref locatorSets, index + 1, newSet);
                DuplicateLocatorFrames(index); // duplicate locator frame in every frame
            }

            public bool ReorderLocatorSet(int index, int offset, bool reorderNow = true) {
                if(offset == 0) return false;
                if(index == locatorSets.Length - 1 && offset > 0) return false; // at end of list trying to move down
                if(index == 0 && offset < 0) return false; // at beginning of list trying to move up
                if(!reorderNow) return true; // just testing to see if we can reorder, passed

                RecorderLocatorFrames(index, offset); // reorder locator frames in every frame

                // Does not handle offsets other than +/- 1
                if(offset > 1) offset = 1;
                if(offset < -1) offset = -1;

                Sprite.LocatorSet entry = locatorSets[index]; // get the entry
                SpriteFactory.Utils.ArrayTools.RemoveAt<Sprite.LocatorSet>(ref locatorSets, index); // remove entry first

                if(offset > 0) {
                    if(index + offset >= locatorSets.Length) { // would be at the end of the list
                        SpriteFactory.Utils.ArrayTools.Add<Sprite.LocatorSet>(ref locatorSets, entry); // add to end of the list

                        return true;
                    }
                }
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.LocatorSet>(ref locatorSets, index + offset, entry); // insert the entry back
                return true;
            }

            #endregion

            #region Locator Frame Functions

            private void AddNewLocatorFrames() {
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].AddNewLocatorFrames();
                }
            }

            private void InsertNewLocatorFrames(int index) {
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].InsertNewLocatorFrames(index);
                }
            }

            private void DeleteLocatorFrames(int index) {
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].DeleteLocatorFrames(index);
                }
            }

            private void DuplicateLocatorFrames(int index) {
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].DuplicateLocatorFrames(index);
                }
            }

            private void RecorderLocatorFrames(int index, int offset) {
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].ReorderLocatorFrames(index, offset);
                }
            }

            private void ClearLocatorFrames(int locatorSetIndex) {
                if(locatorSetIndex < 0 || locatorSetIndex >= liveLocatorSetCount) return;
                if(editorAnimations == null || editorAnimations.Length == 0) return;
                int editorAnimCount = editorAnimations.Length;
                for(int i = 0; i < editorAnimCount; i++) {
                    editorAnimations[i].ClearLocatorFrames(locatorSetIndex);
                }
            }

            public Sprite.LocatorFrame GetLocatorFrame(int animIndex, int frameIndex, int locatorSetIndex) {
                if(liveLocatorSetCount == 0) return null; // no locator sets
                if(locatorSetIndex < 0 || locatorSetIndex >= locatorSets.Length) return null; // invalide locator set index
                if(locatorSets[locatorSetIndex] == null) return null; // locator set is missing!

                if(editorAnimations == null || editorAnimations.Length == 0) return null; // no animations
                if(animIndex < 0 || animIndex >= editorAnimations.Length) return null; // invalid anim index

                EditorMasterSprite.Frame[] frames = editorAnimations[animIndex].editorFrames;
                if(frames == null || frames.Length == 0) return null; // no frames
                if(frameIndex < 0 || frameIndex >= frames.Length) return null; // invalid frame index

                EditorMasterSprite.Frame frame = frames[frameIndex];
                if(frame.locatorFrames == null || locatorSetIndex >= frame.locatorFrames.Length) return null; // no locator frames

                return frame.locatorFrames[locatorSetIndex]; // get the current editing locator frame from the sprite frame
            }

            public bool SetLocatorFrame(int animIndex, int frameIndex, int locatorSetIndex, Sprite.LocatorFrame locatorFrame) {
                if(liveLocatorSetCount == 0) return false; // no locator sets
                if(locatorSetIndex < 0 || locatorSetIndex >= locatorSets.Length) return false; // invalide locator set index
                if(locatorSets[locatorSetIndex] == null) return false; // locator set is missing!

                if(editorAnimations == null || editorAnimations.Length == 0) return false; // no animations
                if(animIndex < 0 || animIndex >= editorAnimations.Length) return false; // invalid anim index

                EditorMasterSprite.Frame[] frames = editorAnimations[animIndex].editorFrames;
                if(frames == null || frames.Length == 0) return false; // no frames
                if(frameIndex < 0 || frameIndex >= frames.Length) return false; // invalid frame index

                EditorMasterSprite.Frame frame = frames[frameIndex];
                if(frame.locatorFrames == null || locatorSetIndex >= frame.locatorFrames.Length) return false; // no locator frames

                frame.locatorFrames[locatorSetIndex] = locatorFrame; // set the current editing locator frame in the sprite frame
                return true;
            }

            #endregion

            private Sprite.LocatorSet CreateLocatorSet() {
                Sprite.LocatorSet newSet = new Sprite.LocatorSet("Locator0");
                InitializeLocatorSet(ref newSet);
                return newSet;
            }

            private void InitializeLocatorSet(ref Sprite.LocatorSet set) {
                set.name = VerifyLocatorSetName(set.name, -1); // make sure name isn't used
                set.previewColor = FindUnusedLocatorSetColor(); // set color for locator
            }

            private Color FindUnusedLocatorSetColor() {
                if(locatorSets == null || locatorSets.Length == 0) return colliderSetColors[0];

                int colorCount = colliderSetColors.Length;
                int locatorSetCount = locatorSets.Length;
                for(int i = 0; i < colorCount; i++) {
                    bool used = false;

                    for(int j = 0; j < locatorSetCount; j++) {
                        if(colliderSetColors[i] == locatorSets[j].previewColor) {
                            used = true;
                            break;
                        }
                    }
                    if(used) continue; // color was already used
                    return colliderSetColors[i]; // color wasn't used
                }

                // no color was chosen, pick one at random
                int rand = Random.Range(0, colorCount);
                return colliderSetColors[rand];
            }

            #region // Name Verification

            public string VerifyLocatorSetName(string name, int thisIndex) {
                return SpriteFactory.Utils.StringTools.VerifyName(name, thisIndex, GetLocatorSetNames());
            }

            #endregion

            #endregion

            #region Get Information

            public string[] GetAtlasTextureGUIDs() {
                if(editorAtlases == null || editorAtlases.Length == 0) return null;

                // Get atlas textures
                string[] allAtlasTextureGUIDs = new string[0];
                for(int i = 0; i < editorAtlases.Length; i++) {
                    string guid = editorAtlases[i].textureMapGUID;
                    SpriteFactory.Utils.ArrayTools.Add<string>(ref allAtlasTextureGUIDs, guid);
                }
                return allAtlasTextureGUIDs;
            }

            public string[] GetFrameTextureGUIDs() {
                if(editorAnimations == null || editorAnimations.Length == 0) return null;

                string[] guids = new string[0];
                for(int i = 0; i < editorAnimations.Length; i++) {
                    string[] frameGUIDs = editorAnimations[i].GetFrameTextureGUIDs();
                    if(frameGUIDs == null || frameGUIDs.Length == 0) continue;
                    SpriteFactory.Utils.ArrayTools.Combine<string>(ref guids, frameGUIDs);
                }
                return guids;
            }

            public ulong[] GetFrameTextureTimestamps() {
                if(editorAnimations == null || editorAnimations.Length == 0) return null;

                ulong[] timestamps = new ulong[0];
                for(int i = 0; i < editorAnimations.Length; i++) {
                    ulong[] animTimestamps = editorAnimations[i].GetFrameTextureTimestamps();
                    if(animTimestamps == null || animTimestamps.Length == 0) continue;
                    SpriteFactory.Utils.ArrayTools.Combine<ulong>(ref timestamps, animTimestamps);
                }
                return timestamps;
            }

            public Rect GetTotalBounds() {
                Rect rect = new Rect();

                float minX = 0;
                float maxX = 0;
                float minY = 0;
                float maxY = 0;
                bool firstRun = true;

                EditorMasterSprite.Animation[] anims = editorAnimations;
                if(anims == null || anims.Length == 0) return rect;
                for(int i = 0; i < anims.Length; i++) {
                    EditorMasterSprite.Frame[] frames = anims[i].editorFrames;
                    if(frames == null || frames.Length == 0) continue;
                    for(int j = 0; j < frames.Length; j++) {
                        EditorMasterSprite.Frame frame = frames[j];
                        if(!frame.hasTexture) continue; // texture missing
                        float halfX = frame.width * 0.5f;
                        float halfY = frame.height * 0.5f;
                        float curMinX = -halfX + frame.framePixelOffset.x;
                        float curMaxX = halfX + frame.framePixelOffset.x;
                        float curMinY = -halfY - frame.framePixelOffset.y; // reverse y because we want +y to be up
                        float curMaxY = halfY - frame.framePixelOffset.y; // reverse y because we want +y to be up

                        if(firstRun || curMinX < minX) minX = curMinX;
                        if(firstRun || curMinY < minY) minY = curMinY;
                        if(firstRun || curMaxX > maxX) maxX = curMaxX;
                        if(firstRun || curMaxY > maxY) maxY = curMaxY;

                        firstRun = false;
                    }
                }
                rect.x = minX;
                rect.y = minY;
                rect.width = maxX - minX;
                rect.height = maxY - minY;
                return rect;
            }

            public EditorMasterSprite.Frame GetEditorPreviewFrame() {
                if(editorAnimations == null || editorAnimations.Length <= 0) return null;
                if(defaultAnimationIndex < 0 || defaultAnimationIndex >= editorAnimations.Length) return null;
                EditorMasterSprite.Animation anim = editorAnimations[defaultAnimationIndex];
                if(anim == null) return null;
                EditorMasterSprite.Frame[] frames = anim.editorFrames;
                if(frames == null || frames.Length == 0) return null;
                if(frames[0] == null) return null;
                return frames[0];
            }

            public Texture2D GetEditorPreviewAtlasTexture() {
                if(editorAtlases == null || editorAtlases.Length == 0) return null;
                EditorMasterSprite.Frame editorPreviewFrame = GetEditorPreviewFrame();
                if(editorPreviewFrame == null) return null;
                int atlasIndex = editorPreviewFrame.atlasIndex;
                if(atlasIndex < 0) return null;
                return editorAtlases[atlasIndex].GetTextureMap();
            }

            private string[] GetEditorAnimationNames() {
                // Get list of animation names
                string[] animNames = null;
                if(editorAnimations != null && editorAnimations.Length > 0) {
                    animNames = new string[editorAnimations.Length];
                    for(int i = 0; i < editorAnimations.Length; i++)
                        animNames[i] = editorAnimations[i].name;
                }
                return animNames;
            }

            public string[] GetColliderSetNames() {
                int count = liveColliderSetCount;
                if(count <= 0) return null;
                string[] names = new string[count];
                for(int i = 0; i < count; i++) {
                    names[i] = colliderSets[i].name;
                }
                return names;
            }

            public string[] GetColliderGroupNames() {
                int count = liveColliderGroupCount;
                if(count <= 0) return null;
                string[] names = new string[count];
                for(int i = 0; i < count; i++) {
                    names[i] = colliderGroups[i].name;
                }
                return names;
            }

            public string[] GetLocatorSetNames() {
                int count = liveLocatorSetCount;
                if(count <= 0) return null;
                string[] names = new string[count];
                for(int i = 0; i < count; i++) {
                    names[i] = locatorSets[i].name;
                }
                return names;
            }

            #endregion

            private bool VerifyAnimationIndex(int animationIndex) {
                if(editorAnimations == null || editorAnimations.Length == 0 || animationIndex < 0 || animationIndex >= editorAnimations.Length || editorAnimations[animationIndex] == null) {
                    Debug.LogError("Animation not found!");
                    return false;
                }
                return true;
            }

            #region Edge Tiling

            public void UpdateEdgeTiling(int padding) {
                if(tilingMode == TilingMode.None || finalUseCustomMesh) { // no tiling or using custom mesh which does not support tiling
                    tile = false;
                    tileTop = false;
                    tileBottom = false;
                    tileLeft = false;
                    tileRight = false;
                } else if(tilingMode == TilingMode.Manual) { // manual tiling
                    if(tileTop || tileBottom || tileLeft || tileRight) tile = true; // flag tiling true if any edge is tiled
                    else tile = false; // otherwise set to false
                } else if(tilingMode == TilingMode.Auto) { // automatic tiling

                    // Go through frames in sprite and determine which edges, if any, need to be tiled
                    // For speed, just use the default animation
                    if(editorAnimations == null || editorAnimations.Length <= 0) return; // no animations, done
                    if(defaultAnimationIndex < 0 || defaultAnimationIndex >= editorAnimations.Length) return; // no default animation, done

                    EditorMasterSprite.Animation anim = editorAnimations[defaultAnimationIndex]; // get default animation
                    if(anim == null) return; // anim is missing, done

                    EditorMasterSprite.Frame[] frames = anim.editorFrames; // get frames from default animation
                    if(frames == null || frames.Length == 0) return; // no frames, done

                    bool found = false;
                    for(int i = 0; i < frames.Length; i++) {
                        EditorMasterSprite.Frame frame = frames[i];
                        if(frame == null) continue; // frame is missing, skip
                        Texture2D texture = frame.GetTexture();
                        if(texture == null) continue; // source image is missing
                        UpdateEdgeTiling(texture.GetPixels(), texture.width, texture.height); // determine tiling for this image
                        found = true;
                        break; // just check the first frame
                    }
                    if(!found) { // no valid frames found, just disable tiling
                        tile = false;
                        tileTop = false;
                        tileBottom = false;
                        tileLeft = false;
                        tileRight = false;
                    }

                } else { // unknown
                    Debug.LogError("Unknown tiling mode!");
                }

                // Calculate bleed padding amount for preventing bilinear/trilinear cutoff artifacts at edges of mesh
                bleedPaddingPixels = new SpriteFactory.Utils.DataClasses.IntPadding();
                int bleedPaddingThickness = padding >> 1; // bleed padding is 1/2 thickness of padding
                // only add bleed padding if not tiled on that edge because tiled edges should be exact
                if(tile) {
                    if(!tileTop) bleedPaddingPixels.top = bleedPaddingThickness;
                    if(!tileBottom) bleedPaddingPixels.bottom = bleedPaddingThickness;
                    if(!tileLeft) bleedPaddingPixels.left = bleedPaddingThickness;
                    if(!tileRight) bleedPaddingPixels.right = bleedPaddingThickness;
                } else {
                    bleedPaddingPixels.top = bleedPaddingThickness;
                    bleedPaddingPixels.left = bleedPaddingThickness;
                    bleedPaddingPixels.right = bleedPaddingThickness;
                    bleedPaddingPixels.bottom = bleedPaddingThickness;
                }
            }

            private void UpdateEdgeTiling(Color[] pixels, int width, int height) {
                // Check each edge and determine if the edge is tiled
                tileTop = CheckRowAutoTile(pixels, width, height, height - 1);
                tileBottom = CheckRowAutoTile(pixels, width, height, 0);
                tileLeft = CheckColumnAutoTile(pixels, width, height, 0);
                tileRight = CheckColumnAutoTile(pixels, width, height, width - 1);

                if(tileTop || tileBottom || tileLeft || tileRight) tile = true; // flag tiling true if any edge is tiled
                else tile = false; // otherwise set to false
            }

            private bool CheckRowAutoTile(Color[] pixels, int width, int height, int row) {
                int cols = width;
                float totalAlpha = 0.0f;
                for(int col = 0; col < cols; col++) {
                    int index = row * cols + col;
                    float alpha = pixels[index].a;
                    if(alpha > 0.0f) totalAlpha += alpha;
                }
                // consider it tiling if we found enough opaque or semi-transparent pixels and the total value adds up to at least x% solid
                if(totalAlpha >= cols * 0.35f) return true; // must be 35% solid total to tile
                return false;
            }

            private bool CheckColumnAutoTile(Color[] pixels, int width, int height, int col) {
                int rows = height;
                int cols = width;
                float totalAlpha = 0.0f;
                for(int row = 0; row < rows; row++) {
                    int index = row * cols + col;
                    float alpha = pixels[index].a;
                    if(alpha > 0.0f) totalAlpha += alpha;
                }
                // consider it tiling if we found enough opaque or semi-transparent pixels and the total value adds up to at least x% solid
                if(totalAlpha >= rows * 0.35f) return true; // must be 35% solid total to tile
                return false;
            }

            #endregion

            #region Update data on save

            public void PrepareForEditorSave() {
                if(editorAnimations != null && editorAnimations.Length > 0) {
                    for(int i = 0; i < editorAnimations.Length; i++) {
                        if(editorAnimations[i] == null) continue;
                        editorAnimations[i].PrepareForEditorSave();
                    }
                }
            }

            public void FinalizeChanges() {
                // Finalize animations
                if(editorAnimations != null && editorAnimations.Length != 0) {
                    for(int i = 0; i < editorAnimations.Length; i++) {
                        editorAnimations[i].FinalizeChanges(this);
                    }
                }

                // Calculate final size and center for static collider frames, animated ones are done in editorFrame
                if(colliderSets != null) {
                    for(int i = 0; i < colliderSets.Length; i++) {
                        if(colliderSets[i].isAnimated) continue; // skip animated colliders
                        colliderSets[i].staticColliderFrame.CalculateFinalVars(gameSettings.pixelsPerUnit, colliderSets[i]);
                    }
                }
            }

            public bool UpgradeCheck(Settings settings) {
                bool changed = false;
                // Check for data changes when upgrading

                // Verify data that can be lost or cause upgrade issues
                // THIS SHOULD BE REPLACED WITH A GENERAL VALIDATION OF ALL DATA AT SOME POINT

                // Colliders
                if(liveColliderSetCount > 0) {

                    // Collider Set data
                    for(int i = 0; i < colliderSets.Length; i++) {
                        Sprite.ColliderSet colliderSet = colliderSets[i];
                        if(colliderSet == null) continue;
                        if(colliderSet.VerifyData(IsValidColliderGroupId)) changed = true;
                    }

                    // Collider animation data format change
                        
                    // Static colliders
                    for(int i = 0; i < colliderSets.Length; i++) {
                        if(colliderSets[i] == null) continue;
                        if(colliderSets[i].UpgradeCheck()) changed = true;
                    }
                }

                // Animations (also handles animated colliders)
                if(editorAnimations != null && editorAnimations.Length != 0) {
                    for(int i = 0; i < editorAnimations.Length; i++) {
                        if(editorAnimations[i] == null) continue;
                        if(editorAnimations[i].UpgradeCheck()) changed = true;
                    }
                }

                // Material sets
                if(editorMaterialSets != null) {
                    for(int i = 0; i < editorMaterialSets.Length; i++) {
                        if(editorMaterialSets[i] == null) continue;
                        if(editorMaterialSets[i].useDefaultMaterial) continue;
                        if(editorMaterialSets[i].sourceMaterial != null && Utils.AssetTools.GetGUID(editorMaterialSets[i].sourceMaterial) == settings.defaultMaterialGUID) { // this material is the default, change settings
                            editorMaterialSets[i].useDefaultMaterial = true;
                            editorMaterialSets[i].sourceMaterial = null; // clear the material
                            changed = true;
                        }
                    }
                }

                // Check texture filter mode
                if(!useDefaultAtlasTextureFilterMode && atlasTextureFilterMode == settings.defaultFilterMode) {
                    useDefaultAtlasTextureFilterMode = true;
                    changed = true;
                }
                
                // Check texture aniso level
                if(atlasTextureAnisoLevel != -1 && atlasTextureAnisoLevel == settings.defaultAnisoLevel) {
                    atlasTextureAnisoLevel = -1; // set to default
                    changed = true;
                }

                // Check two-sided mesh
                if(editorUseTwoSidedMesh == BoolDefaultOption.Default) {
                    if(twoSidedMesh) { // should never be positive after upgrade, so its outdated data

                        if(twoSidedMesh != settings.defaultUseTwoSidedMesh) editorUseTwoSidedMesh = BoolDefaultOption.True;
                        changed = true;
                        twoSidedMesh = false;

                    } else { // its negative, so its either outdated data or was already cleared in another upgrade

                        if(twoSidedMesh != settings.defaultUseTwoSidedMesh) {
                            editorUseTwoSidedMesh = BoolDefaultOption.False;
                            changed = true;
                        }
                    }
                }

                // Check mesh type
                if(!useDefaultMeshType && meshType == settings.defaultMeshType) {
                    useDefaultMeshType = true;
                    changed = true;
                }

                // Check auto mesh transparency channel
                if(!useDefaultAutoMeshTransparencyChannel && autoMeshTransparencyChannelOverride == settings.defaultAutoMeshTransparencyChannel) {
                    useDefaultAutoMeshTransparencyChannel = true;
                    changed = true;
                }

                // Check auto mesh edge extrude
                // Also check for 0 because it will always default the field to 0 on an upgrade, but its an illegal value
                if(!useDefaultAutoMeshEdgeExtrude && (autoMeshEdgeExtrudeOverride == 0 || autoMeshEdgeExtrudeOverride == settings.defaultAutoMeshEdgeExtrude)) {
                    autoMeshEdgeExtrudeOverride = settings.defaultAutoMeshEdgeExtrude;
                    useDefaultAutoMeshEdgeExtrude = true;
                    changed = true;
                }

                // Check auto mesh edge reduction distance
                // Also check for 0 because it will always default the field to 0 on an upgrade, but its an illegal value
                if(!useDefaultAutoMeshVertexReductionDistance && (autoMeshVertexReductionDistanceOverride == 0 || autoMeshVertexReductionDistanceOverride == settings.defaultAutoMeshVertexReductionDistance)) {
                    autoMeshVertexReductionDistanceOverride = settings.defaultAutoMeshVertexReductionDistance;
                    useDefaultAutoMeshVertexReductionDistance = true;
                    changed = true;
                }

                return changed;
            }

            public void FinalizeChangesOnAtlasUpdate() {
                // convert some pixels to units when atlases are updated

                // Recalulate frame offsets since changes to bleed padding may have affected it
                if(editorAnimations != null && editorAnimations.Length > 0) {
                    for(int i = 0; i < editorAnimations.Length; i++) {
                        editorAnimations[i].ConvertFrameOffsets(this);
                    }
                }
            }

            #endregion

            #region Utilities

            public Sprite.Data ConvertToSpriteData(Settings settings, out Sprite.SharedData sharedData) {
                Sprite.Data spriteData = new Sprite.Data(); // make new sprite data
                base.CopyDataVars((Sprite.Data_Base)this, (Sprite.Data_Base)spriteData); // copy the shared vars from the base
                sharedData = new Sprite.SharedData(); // create the shared data

                // Convert editor use two sided mesh
                if(editorUseTwoSidedMesh == BoolDefaultOption.Default) {
                    spriteData.twoSidedMesh = settings.defaultUseTwoSidedMesh;
                } else if(editorUseTwoSidedMesh == BoolDefaultOption.True) {
                    spriteData.twoSidedMesh = true;
                } else { // false
                    spriteData.twoSidedMesh = false;
                }

                // Convert useCustomMesh
                bool useCustomMesh;
                Enums.SpriteMeshType meshType;
                if(useDefaultMeshType) {
                    meshType = settings.defaultMeshType;
                } else {
                    meshType = this.meshType;
                }
                if(meshType == SpriteFactory.Enums.SpriteMeshType.AutoMesh) useCustomMesh = true;
                else useCustomMesh = false;
                spriteData.useCustomMesh = useCustomMesh;

                // Convert MasterSprite.Animations to Sprite.SpriteAnimations
                if(editorAnimations != null) {
                    int count = editorAnimations.Length;
                    Sprite.Animation[] newAnimations = new Sprite.Animation[count];
                    for(int i = 0; i < count; i++) {
                        newAnimations[i] = editorAnimations[i].ConvertToSpriteAnimation(settings.pixelsPerUnit, useCustomMesh, this);
                    }
                    spriteData.animations = newAnimations;
                } else
                    spriteData.animations = null;

                // Atlases are copied in new SpriteData(this)
                
                // Convert MasterSprite.MaterialSet[] to Sprite.MaterialSet[]
                if(editorMaterialSets != null) {
                    int count = editorMaterialSets.Length;
                    Sprite.MaterialSet[] newMaterialSets = new Sprite.MaterialSet[count];
                    for(int i = 0; i < count; i++) {
                        newMaterialSets[i] = editorMaterialSets[i].ConvertToSpriteMaterialSet();
                    }
                    spriteData.materialSets = newMaterialSets;
                } else
                    spriteData.materialSets = null;

                // Convert MasterSprite.Atlas[] to Sprite.Atlas[]
                if(editorAtlases != null) {
                    int count = editorAtlases.Length;
                    Sprite.Atlas[] newAtlases = new Sprite.Atlas[count];
                    for(int i = 0; i < count; i++) {
                        newAtlases[i] = editorAtlases[i].ConvertToSpriteAtlas();
                    }
                    spriteData.atlases = newAtlases;
                } else
                    spriteData.atlases = null;

                // Mesh Frames - store in shared data
                int maxVertCount = 0;
                if(editorMeshFrames != null) {
                    int count = editorMeshFrames.Length;
                    Sprite.MeshFrame[] newMeshFrames = new Sprite.MeshFrame[count];
                    for(int i = 0; i < count; i++) {
                        if(editorMeshFrames[i] == null) continue;
                        Sprite.MeshFrame spriteMeshFrame = editorMeshFrames[i].ConvertToSpriteMeshFrame(settings.pixelsPerUnit, settings.resolutionTargetScaleInverseMultiplier, this, spriteData.twoSidedMesh);
                        if(spriteMeshFrame.vertices == null || spriteMeshFrame.vertices.Length == 0) continue; // skip corrupt mesh frames
                        int vertCount = spriteMeshFrame.vertexCount;
                        if(vertCount > maxVertCount) maxVertCount = vertCount; // store the highest vert count of all meshes
                        newMeshFrames[i] = spriteMeshFrame;
                    }
                    sharedData.meshFrames = newMeshFrames;
                } else
                    sharedData.meshFrames = null;

                // Save max mesh component counts
                sharedData.meshFramesMaxVertexCount = maxVertCount;

                // Bake final vars after export. These are just to save time doing it beforehand instead of on awake.
                spriteData.CalculateCountsAndFlags();

                return spriteData;
            }

            private void CopyDataVars(Data source, Data destination) {
                base.CopyDataVars((Sprite.Data_Base)source, (Sprite.Data_Base)destination); // copy the data vars in the base class

                // Objects
                destination.editorMaterialGUID = source.editorMaterialGUID;
                destination.atlasToGroupAtlasIndices = SpriteFactory.Utils.ArrayTools.Clone<int>(source.atlasToGroupAtlasIndices);
                if(source.bleedPaddingPixels == null) destination.bleedPaddingPixels = null;
                else destination.bleedPaddingPixels = source.bleedPaddingPixels.Clone();
                
                // Editor Animations
                EditorMasterSprite.Animation[] sourceAnims = source.editorAnimations;
                if(sourceAnims != null) {
                    int count = sourceAnims.Length;
                    EditorMasterSprite.Animation[] newAnims = new EditorMasterSprite.Animation[count];
                    for(int i = 0; i < count; i++) {
                        newAnims[i] = sourceAnims[i].DeepCopy();
                    }
                    destination.editorAnimations = newAnims;
                } else
                    destination.editorAnimations = null;

                // Editor Material Sets
                EditorMasterSprite.MaterialSet[] sourceMaterialSets = source.editorMaterialSets;
                if(sourceMaterialSets != null) {
                    int count = sourceMaterialSets.Length;
                    EditorMasterSprite.MaterialSet[] newMaterialSets = new EditorMasterSprite.MaterialSet[count];
                    for(int i = 0; i < count; i++) {
                        newMaterialSets[i] = sourceMaterialSets[i].DeepCopy();
                    }
                    destination.editorMaterialSets = newMaterialSets;
                } else
                    destination.editorMaterialSets = null;

                // Editor Atlases
                EditorMasterSprite.Atlas[] sourceAtlases = source.editorAtlases;
                if(sourceAtlases != null) {
                    int count = sourceAtlases.Length;
                    destination.editorAtlases = new EditorMasterSprite.Atlas[count];
                    for(int i = 0; i < count; i++) {
                        destination.editorAtlases[i] = sourceAtlases[i].DeepCopy();
                    }
                } else
                    destination.editorAtlases = null;

                // Mesh Frames
                EditorMasterSprite.MeshFrame[] sourceMeshFrames = source.editorMeshFrames;
                if(sourceMeshFrames != null) {
                    int count = sourceMeshFrames.Length;
                    MeshFrame[] newMeshFrames = new MeshFrame[count];
                    for(int i = 0; i < count; i++) {
                        newMeshFrames[i] = MeshFrame.Clone(sourceMeshFrames[i]);
                    }
                    destination.editorMeshFrames = newMeshFrames;
                } else
                    destination.editorMeshFrames = null;

                // Automesh settings
                destination.autoMeshSettings = AutoMeshSettings.Clone(source.autoMeshSettings);

                // Values
                //destination.editorMasterSprite = source.editorMasterSprite; // DO NOT copy editorMasterSprite
                destination.spriteGroupId = source.spriteGroupId;
                destination.defaultFrameRate = source.defaultFrameRate;
                destination.defaultWrapMode = source.defaultWrapMode;
                destination.editorUseTwoSidedMesh = source.editorUseTwoSidedMesh;
                destination.useDefaultAtlasTextureFilterMode = source.useDefaultAtlasTextureFilterMode;
                destination.atlasTextureFilterMode = source.atlasTextureFilterMode;
                destination.atlasTextureAnisoLevel = source.atlasTextureAnisoLevel;
                destination.tilingMode = source.tilingMode;
                destination.tile = source.tile;
                destination.tileTop = source.tileTop;
                destination.tileBottom = source.tileBottom;
                destination.tileLeft = source.tileLeft;
                destination.tileRight = source.tileRight;
                destination.useDefaultMeshType = source.useDefaultMeshType;
                destination.meshType = source.meshType;
                destination.useDefaultAutoMeshTransparencyChannel = source.useDefaultAutoMeshTransparencyChannel;
                destination.autoMeshTransparencyChannelOverride = source.autoMeshTransparencyChannelOverride;
                destination.colliderGroupUniqueIdCounter = source.colliderGroupUniqueIdCounter;
                destination.meshFrameUidCounter = source.meshFrameUidCounter;
                destination.useDefaultAutoMeshEdgeExtrude = source.useDefaultAutoMeshEdgeExtrude;
                destination.autoMeshEdgeExtrudeOverride = source.autoMeshEdgeExtrudeOverride;
                destination.useDefaultAutoMeshVertexReductionDistance = source.useDefaultAutoMeshVertexReductionDistance;
                destination.autoMeshVertexReductionDistanceOverride = source.autoMeshVertexReductionDistanceOverride;
            }

            public Data DeepCopy(EditorMasterSprite editorMasterSprite) {
                Data newData = new Data(editorMasterSprite);
                CopyDataVars(this, newData);
                return newData;
            }

            public void ConvertToStaticSprite() {
                if(isStaticSprite) return;
                isStaticSprite = true;

                // If we have animations, delete all but first
                if(editorAnimations != null && editorAnimations.Length > 0) { // we have at least one animation
                    if(editorAnimations.Length > 1) { // more than one animation, delete all but first
                        EditorMasterSprite.Animation[] newAnims = new EditorMasterSprite.Animation[1];
                        newAnims[0] = editorAnimations[0]; // copy first cell into new animations
                        editorAnimations = newAnims; // replace animations
                    }
                } else { // no animations exist, create one
                    editorAnimations = new EditorMasterSprite.Animation[1];
                    editorAnimations[0] = new EditorMasterSprite.Animation(defaultFrameRate, defaultWrapMode);
                }
                defaultAnimationIndex = 0; // set default animation index to 0

                // If frames exist, delete all but first
                EditorMasterSprite.Frame[] frames = editorAnimations[0].editorFrames;
                if(frames != null && frames.Length > 1) { // we have more than one frame, delete the rest
                    EditorMasterSprite.Frame[] newFrames = new EditorMasterSprite.Frame[1];
                    newFrames[0] = frames[0];
                    editorAnimations[0].editorFrames = newFrames;
                    editorAnimations[0].RecalculateFrameCount(); // store new frame count
                }

                // If colliders exist, make sure they're all static
                if(colliderSets != null && colliderSets.Length > 0) {
                    for(int i = 0; i < colliderSets.Length; i++) {
                        ChangeColliderSet_IsAnimated(i, false);
                    }
                }
            }

            public void ConvertToAnimatedSprite() {
                if(!isStaticSprite) return;
                isStaticSprite = false;

                // nothing special is required

            }

            #endregion

            public Material GetEditorMaterial() {
                return Utils.AssetTools.LoadAssetFromGUID<Material>(editorMaterialGUID);
            }

            public void SetEditorMaterial(Material material) {
                editorMaterialGUID = Utils.AssetTools.GetGUID(material);
            }

            public bool CheckIfAnySourceImagesHaveChanged() {
                // Checks for changed source images by comparing timestamp to stored value
                if(editorAnimations == null || editorAnimations.Length == 0) return false;

                for(int i = 0; i < editorAnimations.Length; i++) {
                    EditorMasterSprite.Frame[] thisFrames = editorAnimations[i].editorFrames;
                    if(thisFrames == null || thisFrames.Length == 0) continue;

                    for(int j = 0; j < thisFrames.Length; j++) {
                        if(thisFrames[j].textureGUID == null || thisFrames[j].textureGUID == string.Empty) continue; // it was blank

                        string path = Utils.AssetTools.GetAssetPathFromGUID(thisFrames[j].textureGUID); // get path of asset
                        if(path == null || path == string.Empty) continue; // no file

                        TextureImporter importer = (TextureImporter)TextureImporter.GetAtPath(path); // load the texture importer
                        if(importer == null) continue; // no importer found

                        if(thisFrames[j].textureTimestamp != importer.assetTimeStamp) { // timestamp does not match
                            return true; // just one means we must rebuild, so done
                        }
                    }
                }
                return false;
            }

            #region Custom Meshes

            public void GenerateAutoSpriteMeshes(Settings settings, bool forceRebuild, CacheDataObject cache) {
                if(!finalUseCustomMesh) {
                    if(editorMeshFrames != null && editorMeshFrames.Length > 0) {
                        editorMeshFrames = null; // clear editor mesh frames
                    }
                    if(autoMeshSettings != null) autoMeshSettings = null; // clear automesh settings
                    return;
                }

                // Update automesh settings
                // If any important settings are changed, we must clear all meshes and rebuild
                if(autoMeshSettings == null) autoMeshSettings = new AutoMeshSettings();
                
                // Some settings are not settable in the editor yet. If these settings are added, do the change checks.
                bool clearAllMeshFrames = false;

                if(forceRebuild) clearAllMeshFrames = true;

                int autoMeshExtrude = finalAutoMeshExtrude;
                if(autoMeshSettings.extrudeAmount != autoMeshExtrude) {
                    autoMeshSettings.extrudeAmount = autoMeshExtrude;
                    clearAllMeshFrames = true;
                }

                /*Enums.ColorChannel newTransChannel = finalMeshGenerationTransparencyChannel;
                if(autoMeshSettings.transparencyChannel != newTransChannel) {
                    clearAllMeshFrames = true;
                    autoMeshSettings.transparencyChannel = newTransChannel;
                }*/
                //autoMeshSettings.transparencyCutoff = transparencyCutoff;
                //autoMeshSettings.shellFindBleedCorners = shellFindBleedCorners;
                //autoMeshSettings.outlineDrawEdgeCorners = outlineDrawEdgeCorners;

                int autoMeshEdgeReductionDistance = finalAutoMeshVertexReductionDistance;
                if(autoMeshSettings.edgeVertexReductionDistance != autoMeshEdgeReductionDistance) {
                    autoMeshSettings.edgeVertexReductionDistance = (double)autoMeshEdgeReductionDistance;
                    clearAllMeshFrames = true;
                }

                if(autoMeshSettings.transparencyChannel != settings.defaultAutoMeshTransparencyChannel) { // Just use default for now instead over override stuff
                    autoMeshSettings.transparencyChannel = settings.defaultAutoMeshTransparencyChannel;
                    clearAllMeshFrames = true;
                }

                if(autoMeshSettings.resolutionTarget != settings.resolutionTarget) {
                    autoMeshSettings.resolutionTarget = settings.resolutionTarget;
                    clearAllMeshFrames = true;
                }

                if(autoMeshSettings.resolutionTargetResamplingMode != settings.resolutionTargetResamplingMode) {
                    autoMeshSettings.resolutionTargetResamplingMode = settings.resolutionTargetResamplingMode;
                    clearAllMeshFrames = true; // must rebuild the frames when we change resampling mode because blur may make it bigger/smaller
                }

                if(autoMeshSettings.trim != settings.trimSprites) {
                    autoMeshSettings.trim = settings.trimSprites;
                    clearAllMeshFrames = true;
                }

                // Clear mesh frames if necessary
                if(clearAllMeshFrames) { // an important setting changed, clear all meshes so they'll be rebuilt
                    editorMeshFrames = null;
                }

                DeleteUnusedFrameMeshes(); // clean up any old unused frames orphaned by user changing frame source images or deleting them
                
                if(editorAtlases == null || editorAtlases.Length == 0) return; // no atlases
                if(editorAnimations == null || editorAnimations.Length == 0) return; // no animations
                
                for(int i = 0; i < editorAnimations.Length; i++) {
                    if(editorAnimations[i] == null) continue; // skip nulls
                    editorAnimations[i].GenerateAutoSpriteMeshes(this, cache);
                }
            }

            public int UpdateFrameMeshIfNecessary(int uid, string sourceImageGUID, ulong sourceImageTimestamp, SpriteFactory.Utils.DataClasses.IntRect pixelUVRect, int atlasIndex, CacheDataObject cache) {
                
                // Find out if this frame already has a mesh
                MeshFrame meshFrame;
                bool found = false;
                int index = -1;

                // Try finding by uid verified by guid
                if(uid >= 0) { // we have a uid
                    index = FindMeshFrameIndex(uid);
                    if(index >= 0) { // uid was found in the list
                        if(sourceImageGUID == editorMeshFrames[index].sourceImageGUID) {
                            found = true;
                        }
                    }
                }

                // Find by guid
                if(!found) { // we didn't find it by uid, try guid
                    index = FindMeshFrameIndex(sourceImageGUID);
                    if(index >= 0) { // guid was found in the list
                        found = true;
                    }
                }

                // Create a new one
                bool newMeshFrame = false;
                if(!found) { // not found in list, create a new entry
                    meshFrame = AddNewFrameMesh(sourceImageGUID);
                    newMeshFrame = true;
                } else {
                    meshFrame = editorMeshFrames[index];
                }
                
                // Determine if we need to update the mesh frame

                // Check image timestamp
                if(newMeshFrame || meshFrame.textureTimestamp != sourceImageTimestamp) { // timestamp doesn't match, we need to update
                    MeshFrameGenerator.MeshData meshData = MeshFrameGenerator.GenerateMesh(sourceImageGUID, autoMeshSettings, cache);
                    if(meshData != null) meshFrame.ImportMeshData(meshData); // copy mesh data into mesh frame
                    // store other data
                    meshFrame.sourceImageGUID = sourceImageGUID;
                    meshFrame.textureTimestamp = sourceImageTimestamp;
                    meshFrame.pixelUVRect = SpriteFactory.Utils.DataClasses.IntRect.Clone(pixelUVRect);
                    meshFrame.atlasIndex = atlasIndex;
                    //Debug.Log("Updating mesh frame");
                }

                return meshFrame.uid;
            }

            private void DeleteUnusedFrameMeshes() {
                // Delete any orphaned frame meshes

                if(!finalUseCustomMesh) return;
                if(editorAnimations == null || editorAnimations.Length == 0 || editorMeshFrames == null || editorMeshFrames.Length == 0) {
                    editorMeshFrames = null; // clear all
                    return;
                }

                bool[] toDelete = null;
                int deleteCount = 0;

                for(int x = 0; x < editorMeshFrames.Length; x++) {
                    if(editorMeshFrames[x] == null) continue;
                    string guid = editorMeshFrames[x].sourceImageGUID;
                    bool found = false;

                    // Search all frame meshes and make sure they are still in use by a frame
                    for(int i = 0; i < editorAnimations.Length; i++) {
                        if(editorAnimations[i] == null) continue;
                        EditorMasterSprite.Frame[] frames = editorAnimations[i].editorFrames;
                        if(frames == null || frames.Length == 0) continue;
                        for(int j = 0; j < frames.Length; j++) {
                            if(frames[j] == null) continue;
                            if(frames[j].textureGUID == guid) { // match
                                found = true;
                                break;
                            }
                        }
                        if(found) break;
                    }
                    if(!found) { // no frame was using the mesh frame
                        if(toDelete == null) toDelete = new bool[editorMeshFrames.Length];
                        toDelete[x] = true; // mark this mesh frame for deletion
                        deleteCount++;
                    }
                }

                // Delete orphaned mesh frames
                if(deleteCount > 0) { // we found something to delete
                    MeshFrame[] newMeshFrames = new MeshFrame[editorMeshFrames.Length - deleteCount];
                    int count = 0;
                    for(int i = 0; i < toDelete.Length; i++) {
                        if(toDelete[i]) continue;
                        newMeshFrames[count] = editorMeshFrames[i];
                        count++;
                    }
                    editorMeshFrames = newMeshFrames;
                }
            }

            public void UpdateMeshFramesOnAtlasUpadate(int uid, int atlasIndex, SpriteFactory.Utils.DataClasses.IntRect pixelUVRect) {
                if(uid < 0) return;
                if(!finalUseCustomMesh) return;

                MeshFrame meshFrame = FindMeshFrame(uid);
                if(meshFrame == null) return;

                meshFrame.atlasIndex = atlasIndex;
                meshFrame.pixelUVRect = SpriteFactory.Utils.DataClasses.IntRect.Clone(pixelUVRect);
            }

            private MeshFrame FindMeshFrame(string sourceImageGUID) {
                if(editorMeshFrames == null || editorMeshFrames.Length == 0) return null;
                int index = FindMeshFrameIndex(sourceImageGUID);
                if(index < 0) return null;
                return editorMeshFrames[index];
            }

            private MeshFrame FindMeshFrame(int uid) {
                if(editorMeshFrames == null || editorMeshFrames.Length == 0) return null;
                int index = FindMeshFrameIndex(uid);
                if(index < 0) return null;
                return editorMeshFrames[index];
            }

            private int FindMeshFrameIndex(string sourceImageGUID) {
                if(editorMeshFrames == null || editorMeshFrames.Length == 0) return -1;
                for(int i = 0; i < editorMeshFrames.Length; i++) {
                    if(editorMeshFrames[i].sourceImageGUID == sourceImageGUID) return i;
                }
                return -1;
            }

            public int FindMeshFrameIndex(int uid) {
                if(editorMeshFrames == null || editorMeshFrames.Length == 0) return -1;
                for(int i = 0; i < editorMeshFrames.Length; i++) {
                    if(editorMeshFrames[i].uid == uid) return i;
                }
                return -1;
            }

            private MeshFrame AddNewFrameMesh(string sourceImageGUID) {
                int uid = GetNewMeshFrameUid();
                MeshFrame meshFrame = new MeshFrame();
                meshFrame.sourceImageGUID = sourceImageGUID;
                meshFrame.uid = uid;
                SpriteFactory.Utils.ArrayTools.Add<MeshFrame>(ref editorMeshFrames, meshFrame);
                return meshFrame;
            }

            private int GetNewMeshFrameUid() {
                return meshFrameUidCounter++;
            }

            public MeshFrame GetEditorPreviewMeshFrame() {
                if(!finalUseCustomMesh) return null;
                
                Frame frame = GetEditorPreviewFrame();
                if(frame == null) return null;

                return FindMeshFrame(frame.meshFrameUid);
            }

            #endregion
        }

        #endregion

        #region // Animation

        [System.Serializable]
        public class Animation : Sprite.Animation_Base {
            public EditorMasterSprite.Frame[] editorFrames;
            public int editorFrameCount; // editor frame count

            // Property overrides / replacements
            public int frameRate {
                get { return _frameRate; }
                set {// update frameRate in all frames when changed
                    _frameRate = value;
                    if(_frameRate < 1) _frameRate = 1;
                    if(editorFrames == null) return;
                    for(int i = 0; i < editorFrames.Length; i++) // update frameRate in each frame
                        editorFrames[i].frameRate = _frameRate;
                }
            }

            public Animation() { }

            public Animation(int frameRate, Sprite.WrapMode wrapMode)
                : base(frameRate, wrapMode) {
            }

            #region Update data on save

            public void FinalizeChanges(EditorMasterSprite.Data masterSpriteData) {
                if(editorFrames == null || editorFrames.Length == 0) return;

                for(int i = 0; i < editorFrames.Length; i++) {
                    editorFrames[i].FinalizeChanges(masterSpriteData);
                }
            }

            // Atlas Creation

            public void ConvertFrameOffsets(EditorMasterSprite.Data masterSpriteData) {
                if(editorFrames == null || editorFrames.Length == 0) return;

                for(int i = 0; i < editorFrames.Length; i++) {
                    editorFrames[i].FinalizeFrameOffset(masterSpriteData);
                }
            }

            // Upgrading

            public bool UpgradeCheck() {
                bool changed = false;

                if(editorFrames != null && editorFrames.Length > 0) {
                    for(int i = 0; i < editorFrames.Length; i++) {
                        if(editorFrames[i] == null) continue;
                        if(editorFrames[i].UpgradeCheck()) changed = true;
                    }
                }

                return changed;
            }

            #endregion

            #region EditorFrame Functions

            #region Create

            private EditorMasterSprite.Frame CreateNewFrame(Sprite.ColliderSet[] colliderSets, Sprite.LocatorSet[] locatorSets) {
                return new EditorMasterSprite.Frame(null, 0, frameRate, colliderSets, locatorSets);
            }

            private EditorMasterSprite.Frame CreateNewFrame(Texture2D texture, ulong timestamp, Sprite.ColliderSet[] colliderSets, Sprite.LocatorSet[] locatorSets) {
                EditorMasterSprite.Frame newFrame = new EditorMasterSprite.Frame(texture, timestamp, frameRate, colliderSets, locatorSets);
                return newFrame;
            }

            #endregion

            #region Add, Delete, Reorder

            public void AddFrame(EditorMasterSprite.Frame inFrame) { // used by duplication and add blank frame
                SpriteFactory.Utils.ArrayTools.Add(ref editorFrames, inFrame);
                editorFrameCount = editorFrames.Length;
            }

            public EditorMasterSprite.Frame AddNewFrame(Sprite.ColliderSet[] colliderSets, Sprite.LocatorSet[] locatorSets) {
                EditorMasterSprite.Frame newFrame = CreateNewFrame(colliderSets, locatorSets);
                AddFrame(newFrame);
                return newFrame;
            }

            public EditorMasterSprite.Frame AddNewFrame(Texture2D texture, ulong timestamp, Sprite.ColliderSet[] colliderSets, Sprite.LocatorSet[] locatorSets) {
                EditorMasterSprite.Frame newFrame = CreateNewFrame(texture, timestamp, colliderSets, locatorSets);
                AddFrame(newFrame);
                return newFrame;
            }

            public void InsertNewFrame(int frameIndex, Sprite.ColliderSet[] colliderSets, Sprite.LocatorSet[] locatorSets) {
                if(!VerifyFrameIndex(frameIndex)) return; // make sure frame exists
                SpriteFactory.Utils.ArrayTools.Insert<EditorMasterSprite.Frame>(ref editorFrames, frameIndex, CreateNewFrame(colliderSets, locatorSets)); // insert into animation list
                editorFrameCount = editorFrames.Length;
            }

            public void DuplicateFrame(int frameIndex) {
                if(!VerifyFrameIndex(frameIndex)) return; // make sure frame exists

                EditorMasterSprite.Frame newFrame = editorFrames[frameIndex].DeepCopy(); // create the new animation

                // Insert one space after current entry
                if(frameIndex < editorFrames.Length - 1) { // space left to insert
                    frameIndex++; // insert in next space
                    SpriteFactory.Utils.ArrayTools.Insert(ref editorFrames, frameIndex, newFrame); // insert into editorFrames list
                } else {// already at last space, add it instead
                    AddFrame(newFrame); // add to end
                }

                editorFrameCount = editorFrames.Length;
            }

            public void RemoveFrame(EditorMasterSprite.Frame inFrame) {
                int frameIndex = FindFrameIndex(inFrame);
                if(!VerifyFrameIndex(frameIndex)) return; // make sure frame exists
                SpriteFactory.Utils.ArrayTools.RemoveAt(ref editorFrames, frameIndex); // remove animation
                editorFrameCount = editorFrames.Length;
            }

            public void RemoveFrame(int frameIndex) {
                if(!VerifyFrameIndex(frameIndex)) return; // make sure frame exists
                SpriteFactory.Utils.ArrayTools.RemoveAt(ref editorFrames, frameIndex);
                editorFrameCount = editorFrames.Length;
            }

            public bool ReorderFrame(int frameIndex, int offset, bool reorderNow = true) {
                if(!VerifyFrameIndex(frameIndex)) return false; // make sure frame exists

                EditorMasterSprite.Frame frame = editorFrames[frameIndex];
                bool offsetDown = false;
                int newIndex = frameIndex + offset;

                if(Mathf.Sign(offset) > 0) // reorder down
                    offsetDown = true;

                if(offsetDown) { // moving down
                    int lastIndex = editorFrames.Length - 1;
                    if(frameIndex == lastIndex) return false; // already at the end
                    if(!reorderNow) return true; // not reordering, just making sure we can move it

                    if(newIndex >= lastIndex) { // would be at last, must insert at end
                        offset = lastIndex - frameIndex;
                        SpriteFactory.Utils.ArrayTools.Add(ref editorFrames, frame);
                    } else { // insert into array list
                        SpriteFactory.Utils.ArrayTools.Insert(ref editorFrames, newIndex + 1, frame); // adjust for insert pushing things down so we insert after the target
                    }
                    SpriteFactory.Utils.ArrayTools.RemoveAt(ref editorFrames, frameIndex); // remove the old one

                } else { // moving up
                    if(frameIndex == 0) return false; // already at beginning
                    if(!reorderNow) return true; // not reordering, just making sure we can move it

                    // Adjust offset if we can't move the full offset
                    if(newIndex <= 0) { // trying to move up but can't do full offset
                        if(Mathf.Abs(offset) > frameIndex) { // reduce offset to push entry to 0
                            offset = frameIndex;
                            newIndex = frameIndex + offset; // recalulate new index
                        }
                    }
                    SpriteFactory.Utils.ArrayTools.Insert(ref editorFrames, newIndex, frame); // insert the script in its new place
                    SpriteFactory.Utils.ArrayTools.RemoveAt(ref editorFrames, Mathf.Abs(offset) + frameIndex); // remove the script from the array list
                }
                return true;
            }

            public bool ReverseFrames() {
                if(editorFrames == null) return false;
                if(editorFrames.Length < 2) return false;
                System.Array.Reverse(editorFrames);
                return true;
            }

            public void RecalculateFrameCount() {
                if(editorFrames == null) {
                    editorFrameCount = 0;
                    return;
                }
                editorFrameCount = editorFrames.Length;
            }

            #endregion

            #region Get / Find

            public int FindFrameIndex(EditorMasterSprite.Frame inFrame) {
                for(int i = 0; i < editorFrames.Length; i++) {
                    if(editorFrames[i] == inFrame) return i;
                }
                return -1;
            }

            public Texture2D[] GetFrameTextures() {
                if(editorFrames == null || editorFrames.Length == 0) return null;
                int count = editorFrames.Length;
                Texture2D[] textures = new Texture2D[count];
                for(int i = 0; i < count; i++) {
                    textures[i] = editorFrames[i].GetTexture(); // add to list EVEN if null
                }
                return textures;
            }

            public string[] GetFrameTextureGUIDs() {
                if(editorFrames == null || editorFrames.Length == 0) return null;
                int count = editorFrames.Length;
                string[] guids = new string[count];
                for(int i = 0; i < count; i++) {
                    guids[i] = editorFrames[i].textureGUID; // add to list EVEN if null
                }
                return guids;
            }

            public Texture2D[] GetUniqueFrameTextures() {
                if(editorFrames == null) return null;
                Texture2D[] textures = new Texture2D[0];
                for(int i = 0; i < editorFrames.Length; i++) {
                    Texture2D tex = editorFrames[i].GetTexture();
                    if(System.Array.IndexOf(textures, tex) > -1) continue; // already in list
                    SpriteFactory.Utils.ArrayTools.Add<Texture2D>(ref textures, tex); // add to list
                }
                return textures;
            }

            public string[] GetFrameTextureNames() {
                string[] names = new string[editorFrames.Length];
                for(int i = 0; i < editorFrames.Length; i++) {
                    names[i] = editorFrames[i].GetTexture().name;
                }
                return names;
            }

            public ulong[] GetFrameTextureTimestamps() {
                if(editorFrames == null) return null;
                int count = editorFrames.Length;
                ulong[] timestamps = new ulong[count];
                for(int i = 0; i < count; i++) {
                    timestamps[i] = editorFrames[i].textureTimestamp; // add to list
                }
                return timestamps;
            }

            #endregion

            private bool VerifyFrameIndex(int frameIndex) {
                if(editorFrames == null || editorFrames.Length == 0 || frameIndex < 0 || frameIndex >= editorFrames.Length || editorFrames[frameIndex] == null) {
                    Debug.LogError("Frame not found! " + frameIndex);
                    return false;
                }
                return true;
            }

            #endregion

            #region Collider Frame Functions

            public void AddNewColliderFrames() {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].AddNewColliderFrame();
                }
            }

            public void InsertNewColliderFrames(int index) {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].InsertNewColliderFrame(index);
                }
            }

            public void DeleteColliderFrames(int index) {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].DeleteColliderFrame(index);
                }
            }

            public void DuplicateColliderFrames(int index) {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].DuplicateColliderFrame(index);
                }
            }

            public void ReorderColliderFrames(int index, int offset) {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].RecorderColliderFrame(index, offset);
                }
            }

            public void ClearColliderFrames(int colliderSetIndex) {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].ClearColliderFrame(colliderSetIndex);
                }
            }

            #endregion

            #region Locator Frame Functions

            public void AddNewLocatorFrames() {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].AddNewLocatorFrame();
                }
            }

            public void InsertNewLocatorFrames(int index) {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].InsertNewLocatorFrame(index);
                }
            }

            public void DeleteLocatorFrames(int index) {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].DeleteLocatorFrame(index);
                }
            }

            public void DuplicateLocatorFrames(int index) {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].DuplicateLocatorFrame(index);
                }
            }

            public void ReorderLocatorFrames(int index, int offset) {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].RecorderLocatorFrame(index, offset);
                }
            }

            public void ClearLocatorFrames(int locatorSetIndex) {
                if(editorFrames == null || editorFrames.Length == 0) return;
                int editorFramesCount = editorFrames.Length;
                for(int i = 0; i < editorFramesCount; i++) {
                    editorFrames[i].ClearLocatorFrame(locatorSetIndex);
                }
            }

            #endregion

            #region Utilities

            public Sprite.Animation ConvertToSpriteAnimation(int pixelsPerUnit, bool useCustomMesh, EditorMasterSprite.Data parentData) {
                Sprite.Animation spriteAnimation = new Sprite.Animation(); // make new sprite animation
                base.CopyDataVars((Sprite.Animation_Base)this, (Sprite.Animation_Base)spriteAnimation); // copy shared vars from base to spriteAnimation

                // Convert MasterSpriteFrames to SpriteFrames
                if(editorFrames != null) {
                    Sprite.Frame[] newFrames = new Sprite.Frame[0];
                    for(int i = 0; i < editorFrames.Length; i++) {
                        if(editorFrames[i].atlasIndex < 0) continue; // skip corrupt frames so they don't even show up in sprite
                        SpriteFactory.Utils.ArrayTools.Add<Sprite.Frame>(ref newFrames, editorFrames[i].ConvertToSpriteFrame(pixelsPerUnit, useCustomMesh, parentData));
                    }
                    spriteAnimation.SetFrames(newFrames);
                } else {
                    spriteAnimation.SetFrames(null);
                }

                return spriteAnimation;
            }

            private void CopyDataVars(EditorMasterSprite.Animation source, EditorMasterSprite.Animation destination) {
                base.CopyDataVars((Sprite.Animation_Base)source, (Sprite.Animation_Base)destination); // copy vars from base

                // Copy editor frames
                EditorMasterSprite.Frame[] sourceEditorFrames = source.editorFrames;
                if(sourceEditorFrames != null) {
                    int count = sourceEditorFrames.Length;
                    EditorMasterSprite.Frame[] newEditorFrames = new EditorMasterSprite.Frame[count];
                    for(int i = 0; i < count; i++) {
                        newEditorFrames[i] = sourceEditorFrames[i].DeepCopy();
                    }
                    destination.editorFrames = newEditorFrames;
                } else
                    destination.editorFrames = null;

                // copy local vars
                destination.editorFrameCount = source.editorFrameCount;
            }

            public EditorMasterSprite.Animation DeepCopy() { // deep copy
                EditorMasterSprite.Animation editorAnimCopy = new EditorMasterSprite.Animation(); // create new object
                CopyDataVars(this, editorAnimCopy); // copy data to the new object
                return editorAnimCopy;
            }

            #endregion

            public void PrepareForEditorSave() {
                if(editorFrames == null || editorFrames.Length == 0) return;
                for(int i = 0; i < editorFrames.Length; i++) {
                    if(editorFrames[i] == null) continue;
                    editorFrames[i].PrepareForEditorSave();
                }
            }

            /*
            public void PrepareForAtlasCreation() {
                if(editorFrames == null || editorFrames.Length == 0) return;
                for(int i = 0; i < editorFrames.Length; i++) {
                    if(editorFrames[i] == null) continue;
                    editorFrames[i].PrepareForAtlasCreation();
                }
            }

            public void AtlasCreationFinished() {
                if(editorFrames == null || editorFrames.Length == 0) return;
                for(int i = 0; i < editorFrames.Length; i++) {
                    if(editorFrames[i] == null) continue;
                    editorFrames[i].AtlasCreationFinished();
                }
            }*/

            public void BeginEditing() {
                if(editorFrames == null || editorFrames.Length == 0) return;
                //Debug.Log("Beginning editing mode on " + name);
                for(int i = 0; i < editorFrames.Length; i++) {
                    if(editorFrames[i] == null) continue;
                    editorFrames[i].BeginEditing();
                }
            }

            public void EndEditing() {
                if(editorFrames == null || editorFrames.Length == 0) return;
                //Debug.Log("Ending editing mode on " + name);
                for(int i = 0; i < editorFrames.Length; i++) {
                    if(editorFrames[i] == null) continue;
                    editorFrames[i].EndEditing();
                }
            }

            #region Custom Meshes

            public void GenerateAutoSpriteMeshes(EditorMasterSprite.Data parent, CacheDataObject cache) {
                if(editorFrames == null || editorFrames.Length == 0) return; // no frames

                for(int i = 0; i < editorFrames.Length; i++) {
                    if(editorFrames[i] == null) continue; // skip nulls
                    editorFrames[i].GenerateAutoSpriteMesh(parent, cache);
                }
            }

            #endregion
        }

        #endregion

        #region // Frame

        [System.Serializable]
        public class Frame : Sprite.Frame_Base {
            [SerializeField]
            private string _textureGUID;
            [SerializeField]
            private SpriteFactory.Utils.DataClasses.SerializableULong textureTimestampSUL;
            public SpriteFactory.Utils.DataClasses.IntVector2 framePixelOffset; // frame offset (in pixels)
            [SerializeField]
            private Vector2 trimPixelOffset; // must serialize this so we have trim data even when we aren't recacluating atlases
            [SerializeField]
            private SpriteFactory.Utils.DataClasses.IntRect _pixelUVRect;
            [SerializeField]
            private int _meshFrameUid = -1;
            
            // These are not NECESSARILY always accurate, they will be updated as often as possible, but they're really just cache data
            [SerializeField]
            private int _width;
            [SerializeField]
            private int _height;
            [SerializeField]
            private string _textureName;

            // Working
            private Texture2D tempTexture;
            private bool isEditingMode;
            
            // OLD DATA - kept for backward compatibiliy
            [SerializeField] private Texture2D texture;

            // Properties
            public ulong textureTimestamp { get { return textureTimestampSUL.value; } set { textureTimestampSUL.value = value; } }
            public string textureGUID { get { return _textureGUID; } }
            public int width { get { return _width; } }
            public int height { get { return _height; } }
            public string texturePath {
                get {
                    if(isEditingMode) {
                        if(tempTexture == null) return string.Empty;
                        return AssetDatabase.GetAssetPath(tempTexture);
                    }

                    return AssetDatabase.GUIDToAssetPath(_textureGUID);
                }
            }
            public bool hasTexture {
                get {
                    if(isEditingMode) {
                        return tempTexture != null ? true : false;
                    }
                    string path = AssetDatabase.GUIDToAssetPath(_textureGUID);
                    if(path == null || path == string.Empty) return false;
                    return true;
                }
            }
            public string textureName { get { return _textureName; } }
            public int meshFrameUid { get { return _meshFrameUid; } }
            public SpriteFactory.Utils.DataClasses.IntRect pixelUVRect { get { return _pixelUVRect;  } }

            public Frame(Texture2D texture, ulong timestamp, int frameRate, Sprite.ColliderSet[] colliderSets, Sprite.LocatorSet[] locatorSets) {
                // Frames are always created in the editor so new frames should always start in editing mode
                isEditingMode = true; // this must come first
                
                textureTimestampSUL = new SpriteFactory.Utils.DataClasses.SerializableULong();
                framePixelOffset = new SpriteFactory.Utils.DataClasses.IntVector2();
                _pixelUVRect = new SpriteFactory.Utils.DataClasses.IntRect();

                //this.texture = texture; // no longer storing texture directly
                SetTexture(texture);
                textureTimestamp = timestamp;
                this.frameRate = frameRate;
                CreateColliderFrames(colliderSets); // create collider frames if we have any sets
                CreateLocatorFrames(locatorSets); // create locator frames if we have existing sets
                
                // Cache data
                if(texture != null) {
                    _width = texture.width;
                    _height = texture.height;
                }
            }

            public Frame(EditorMasterSprite.Frame editorFrame) { // clone
                CopyDataVars(editorFrame, this); // copy data to self
            }

            #region Collider Frame Functions

            private void CreateColliderFrames(Sprite.ColliderSet[] colliderSets) { // create collider frames from collider sets on instantiation
                if(colliderSets == null || colliderSets.Length == 0) return; // no sets, no need to make collider frames

                // we have collider sets and must make collider frames for each
                int colliderSetCount = colliderSets.Length;
                colliderFrames = new Sprite.ColliderFrame[colliderSetCount];
                for(int i = 0; i < colliderSetCount; i++) {
                    Sprite.ColliderSet colliderSet = colliderSets[i];
                    Sprite.ColliderFrame newFrame = new Sprite.ColliderFrame(); // create new collider frame (even if static collider)
                    colliderFrames[i] = newFrame; // store it

                    // Set options for new frames
                    if(colliderSet.enableInNewFrames) newFrame.enabled = true; // enable collider in frame by default
                }
            }

            public void AddNewColliderFrame() {
                Sprite.ColliderFrame newFrame = new Sprite.ColliderFrame();
                SpriteFactory.Utils.ArrayTools.Add<Sprite.ColliderFrame>(ref colliderFrames, newFrame);
            }

            public void InsertNewColliderFrame(int index) {
                Sprite.ColliderFrame newFrame = new Sprite.ColliderFrame();
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.ColliderFrame>(ref colliderFrames, index, newFrame);
            }

            public void DeleteColliderFrame(int index) {
                SpriteFactory.Utils.ArrayTools.RemoveAt<Sprite.ColliderFrame>(ref colliderFrames, index);
            }

            public void DuplicateColliderFrame(int index) {
                Sprite.ColliderFrame newFrame = colliderFrames[index].DeepCopy();
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.ColliderFrame>(ref colliderFrames, index + 1, newFrame);
            }

            public bool RecorderColliderFrame(int index, int offset) {
                if(offset == 0) return false;
                if(index == colliderFrames.Length - 1 && offset > 0) return false; // at end of list trying to move down
                if(index == 0 && offset < 0) return false; // at beginning of list trying to move up

                // Does not handle offsets other than +/- 1
                if(offset > 1) offset = 1;
                if(offset < -1) offset = -1;

                Sprite.ColliderFrame entry = colliderFrames[index]; // get the entry
                SpriteFactory.Utils.ArrayTools.RemoveAt<Sprite.ColliderFrame>(ref colliderFrames, index); // remove entry first

                if(offset > 0) {
                    if(index + offset >= colliderFrames.Length) { // would be at the end of the list
                        SpriteFactory.Utils.ArrayTools.Add<Sprite.ColliderFrame>(ref colliderFrames, entry); // add to end of the list
                        return true;
                    }
                }
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.ColliderFrame>(ref colliderFrames, index + offset, entry); // insert the entry back
                return true;
            }

            public void ClearColliderFrame(int index) {
                colliderFrames[index] = new Sprite.ColliderFrame();
            }

            #endregion

            #region Locator Frame Functions

            private void CreateLocatorFrames(Sprite.LocatorSet[] locatorSets) { // create locator frames from locator sets on instantiation
                if(locatorSets == null || locatorSets.Length == 0) return; // no sets, no need to make locator frames

                // we have locator sets and must make locator frames for each
                int locatorSetCount = locatorSets.Length;
                locatorFrames = new Sprite.LocatorFrame[locatorSetCount];
                for(int i = 0; i < locatorSetCount; i++) {
                    Sprite.LocatorSet locatorSet = locatorSets[i];
                    Sprite.LocatorFrame newFrame = new Sprite.LocatorFrame(); // create new locator frame (even if static locator)
                    locatorFrames[i] = newFrame; // store it

                    // Set options for new frames
                    if(!locatorSet.defaultToPosXIsForward) newFrame.flipForwardVector = true; // flip vector if default is to the left
                    newFrame.offsetZ = locatorSet.defaultOffsetZ; // set offset Z to locator default
                }
            }

            public void AddNewLocatorFrame() {
                Sprite.LocatorFrame newFrame = new Sprite.LocatorFrame();
                SpriteFactory.Utils.ArrayTools.Add<Sprite.LocatorFrame>(ref locatorFrames, newFrame);
            }

            public void InsertNewLocatorFrame(int index) {
                Sprite.LocatorFrame newFrame = new Sprite.LocatorFrame();
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.LocatorFrame>(ref locatorFrames, index, newFrame);
            }

            public void DeleteLocatorFrame(int index) {
                SpriteFactory.Utils.ArrayTools.RemoveAt<Sprite.LocatorFrame>(ref locatorFrames, index);
            }

            public void DuplicateLocatorFrame(int index) {
                Sprite.LocatorFrame newFrame = locatorFrames[index].DeepCopy();
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.LocatorFrame>(ref locatorFrames, index + 1, newFrame);
            }

            public bool RecorderLocatorFrame(int index, int offset) {
                if(offset == 0) return false;
                if(index == locatorFrames.Length - 1 && offset > 0) return false; // at end of list trying to move down
                if(index == 0 && offset < 0) return false; // at beginning of list trying to move up

                // Does not handle offsets other than +/- 1
                if(offset > 1) offset = 1;
                if(offset < -1) offset = -1;

                Sprite.LocatorFrame entry = locatorFrames[index]; // get the entry
                SpriteFactory.Utils.ArrayTools.RemoveAt<Sprite.LocatorFrame>(ref locatorFrames, index); // remove entry first

                if(offset > 0) {
                    if(index + offset >= locatorFrames.Length) { // would be at the end of the list
                        SpriteFactory.Utils.ArrayTools.Add<Sprite.LocatorFrame>(ref locatorFrames, entry); // add to end of the list
                        return true;
                    }
                }
                SpriteFactory.Utils.ArrayTools.Insert<Sprite.LocatorFrame>(ref locatorFrames, index + offset, entry); // insert the entry back
                return true;
            }

            public void ClearLocatorFrame(int index) {
                locatorFrames[index] = new Sprite.LocatorFrame();
            }

            #endregion

            #region Update data on save

            public void FinalizeChanges(EditorMasterSprite.Data masterSpriteData) {
                // Convert pixel data stored in MasterSprite.Frame to units and store in inherited variables from Sprite.Frame
                FinalizeFrameOffset(masterSpriteData); // this bakes frame offsets to units

                // Determine if we have an event on this frame
                if(eventString != null && eventString.Trim() != "") hasEvent = true;
                else hasEvent = false;

                // Calculate final size and center for collider frames
                Sprite.ColliderSet[] colliderSets = masterSpriteData.colliderSets;
                if(colliderFrames != null && colliderFrames.Length > 0) {
                    for(int i = 0; i < colliderFrames.Length; i++) {
                        if(!colliderSets[i].isAnimated) continue; // skip static sprites
                        colliderFrames[i].CalculateFinalVars(masterSpriteData.gameSettings.pixelsPerUnit, masterSpriteData.colliderSets[i]);
                    }
                }

                // Calculate final size and center for locator frames
                if(locatorFrames != null && locatorFrames.Length > 0) {
                    for(int i = 0; i < locatorFrames.Length; i++) {
                        locatorFrames[i].CalculateFinalVars(masterSpriteData.gameSettings.pixelsPerUnit);
                    }
                }
            }

            public void FinalizeFrameOffset(EditorMasterSprite.Data masterSpriteData) {
                // This is called from two places, possibly twice in one save:
                // - On create atlas from FinalizeChangesOnAtlasUpdate (if creating atlases) - this was done for groups because rebuilding atlases may cause trim/bleed padding to change if images changed and sprite won't be saved again after
                // - On save sprite from FinalizeChanges

                float fPixelsPerUnit = (float)masterSpriteData.gameSettings.pixelsPerUnit;
                float resolutionTargetScaleInverse = masterSpriteData.gameSettings.settings.resolutionTargetScaleInverseMultiplier;

                // bleed padding offset
                SpriteFactory.Utils.DataClasses.IntPadding bleedPaddingPixels = masterSpriteData.bleedPaddingPixels;
                float bleedPaddingPixelOffsetX = (bleedPaddingPixels.left - bleedPaddingPixels.right) * -0.5f * resolutionTargetScaleInverse; // half the difference = amount to offset to make it centered
                float bleedPaddingPixelOffsetY = (bleedPaddingPixels.top - bleedPaddingPixels.bottom) * 0.5f * resolutionTargetScaleInverse;

                // frame offset -- include bleed padding and trim offset directly in the frame offset
                if(!masterSpriteData.finalUseCustomMesh) {
                    frameOffset.x = framePixelOffset.x + bleedPaddingPixelOffsetX + trimPixelOffset.x;
                    frameOffset.y = framePixelOffset.y + bleedPaddingPixelOffsetY + trimPixelOffset.y;

                    // Scale pixel dimensions to match if scaled because pixel width stored is actual pixel width of the uv area
                    float pixelWidth = this.pixelWidth * resolutionTargetScaleInverse;
                    float pixelHeight = this.pixelHeight * resolutionTargetScaleInverse;

                    // Find pixel center of image
                    float pixelCenterX = pixelWidth * 0.5f + frameOffset.x;
                    float pixelCenterY = pixelHeight * 0.5f + frameOffset.y;

                    // Adjust offset to prevent 1/2 pixel misalignment
                    if(SpriteFactory.Utils.MathTools.IsNearOrWholeNumber(resolutionTargetScaleInverse)) { // only do pixel snap on resolution targets that have even scaling
                        SpriteFactory.Utils.MiscTools.SnapToPixel(ref frameOffset.x, ref frameOffset.y, pixelCenterX, pixelCenterY);
                    }
                    
                } else {

                    // Only send frame offset for custom meshes -- ignore bleed padding and trim
                    frameOffset.x = framePixelOffset.x;
                    frameOffset.y = framePixelOffset.y;
                }

                // Convert to scale
                frameOffset /= fPixelsPerUnit;
            }

            // ATLAS CREATION / UPDATE

            public void SetAtlas(int inAtlasIndex) { // set the atlas link in this frame
                atlasIndex = inAtlasIndex;
            }

            internal void ImportAtlasCellData(AtlasCellData atlasCellData) {
                ConvertAtlasCellPixelDataToUnitsAndStore(atlasCellData); // convert the pixel-based frame data to unit/uv-based data and store
            }

            private void ConvertAtlasCellPixelDataToUnitsAndStore(AtlasCellData atlasCellData) {
                // FINALIZE FRAME DATA -- Convert any pixel-based information to units/uvs

                float resolutionTargetScaleInverse = SpriteFactory.Utils.MiscTools.ResolutionTargetInverseScale(atlasCellData.resolutionTarget);
                float fPixelsPerUnit = (float)atlasCellData.pixelsPerUnit;
                pixelWidth = atlasCellData.pixelUVRect.width;
                pixelHeight = atlasCellData.pixelUVRect.height;

                // Store the UV rect in pixel coords for use when converting to GMS
                _pixelUVRect = SpriteFactory.Utils.DataClasses.IntRect.Clone(atlasCellData.pixelUVRect);

                // Calculate trim offset
                if(atlasCellData.trim) { // texture is trimmed so we must adjust and offset to display it correctly
                    // Calculate trim offsets in pixels (but use floats so we can retain half pixels)
                    trimPixelOffset.x = atlasCellData.pixelTrimDiff.x * resolutionTargetScaleInverse * 0.5f * -1.0f; // half the difference of trims = amount to offset to make it centered
                    trimPixelOffset.y = atlasCellData.pixelTrimDiff.y * resolutionTargetScaleInverse * 0.5f * -1.0f;
                } else { // not trimmed
                    // clear the offset if not trimming to make sure nothing is left over
                    trimPixelOffset.x = 0.0f;
                    trimPixelOffset.y = 0.0f;
                }

                float fAtlasWidth = (float)atlasCellData.atlasWidth; // get width of atlas as float
                float fAtlasHeight = (float)atlasCellData.atlasHeight; // get height of atlas as float

                // Convert pixel rect into relative (uv) rect
                // Final UV coords for the frame, cutting within the padding
                // We don't need this for custom meshes, but the inspector uses the uvCoords for drawing the preview
                uvCoords = new Rect(
                    _pixelUVRect.x / fAtlasWidth,
                    _pixelUVRect.y / fAtlasHeight,
                    _pixelUVRect.width / fAtlasWidth,
                    _pixelUVRect.height / fAtlasHeight
                );

                // Calculate vars depending on the mesh type
                if(!atlasCellData.useCustomMesh) { // using default plane mesh

                    // Precalc extents of plane mesh
                    meshExtents.x = pixelWidth * resolutionTargetScaleInverse / fPixelsPerUnit * 0.5f; // size of the plane. Based on a plane of 1x1, extents of +/- 0.5.
                    meshExtents.y = pixelHeight * resolutionTargetScaleInverse / fPixelsPerUnit * 0.5f;
                    
                } // custom meshes are generated elsewhere
            }

            #endregion

            #region Utilities

            public Sprite.Frame ConvertToSpriteFrame(int pixelsPerUnit, bool useCustomMesh, EditorMasterSprite.Data parentData) {
                Sprite.Frame spriteFrame = new Sprite.Frame(); // create new sprite frame
                base.CopyDataVars((Sprite.Frame_Base)this, (Sprite.Frame_Base)spriteFrame); // copy vars from base to new sprite frame

                // Convert custom MeshFrame data
                if(useCustomMesh) {
                    int index = parentData.FindMeshFrameIndex(_meshFrameUid); // find the mesh frame index
                    if(index >= 0) {
                        spriteFrame.meshFrameIndex = index; // store the mesh frame index in the sprite frame instead of UID    
                    }
                }

                // Set custom mesh setting in sprite frame
                spriteFrame.useCustomMesh = useCustomMesh;
                               
                return spriteFrame;
            }

            private void CopyDataVars(EditorMasterSprite.Frame source, EditorMasterSprite.Frame destination) {
                base.CopyDataVars((Sprite.Frame_Base)source, (Sprite.Frame_Base)destination); // copy vars from base class

                // Copy vars from this class
                destination.texture = source.texture;
                destination._textureGUID = source._textureGUID;
                destination.textureTimestampSUL = source.textureTimestampSUL.Clone();
                destination.framePixelOffset = SpriteFactory.Utils.DataClasses.IntVector2.Clone(source.framePixelOffset);
                destination.trimPixelOffset = source.trimPixelOffset; // struct copy
                destination._width = source._width;
                destination._height = source._height;
                destination._textureName = source._textureName;
                destination._pixelUVRect = SpriteFactory.Utils.DataClasses.IntRect.Clone(source._pixelUVRect);
                destination._meshFrameUid = source._meshFrameUid;
                if(source.isEditingMode) {
                    destination.isEditingMode = true;
                    destination.tempTexture = source.tempTexture;
                }
            }

            public EditorMasterSprite.Frame DeepCopy() {
                return new EditorMasterSprite.Frame(this);
            }

            #endregion

            public void PrepareForEditorSave() {
                if(isEditingMode) EndEditing(); // end editing and commit textures to GUID
            }

            public void BeginEditing() {
                if(isEditingMode) {
                    Debug.LogError("Editing was already begun!");
                    return;
                }
                
                tempTexture = GetTexture(); // load the texture from GUID
                UpdateTextureName(tempTexture); // ensure the texture name is current

                isEditingMode = true; // set mode last so we can load the texture properly first
            }

            public void EndEditing() {
                if(!isEditingMode) {
                    // Debug.LogError("Editing was already ended!"); // silence this error because it would get thrown after a save/reload
                    return;
                }

                isEditingMode = false; // set mode first so we can store the texture properly after
                
                SetTexture(tempTexture); // store the texture GUID
                tempTexture = null; // clear the texture
            }

            public Texture2D GetTexture() {
                if(isEditingMode) { // we are currently editing this animation, use the cached texture
                    UpdateSize(tempTexture); // update the size in case the source image file is modified while using the editor
                    // don't bother doing this with the name, it doesn't matter if it goes out of sync really
                    return tempTexture;
                }

                string path = AssetDatabase.GUIDToAssetPath(_textureGUID);
                if(path == null || path == string.Empty) return null;
                Texture2D tex = (Texture2D)AssetDatabase.LoadAssetAtPath(path, typeof(Texture2D));
                return tex;
            }

            public void SetTexture(Texture2D texture) {
                UpdateSize(texture);
                UpdateTextureName(texture);

                if(isEditingMode) { // we are currently editing this animation, cache the texture directly
                    tempTexture = texture;
                    return;
                }

                if(texture != null) {
                    string path = AssetDatabase.GetAssetPath(texture);
                    if(path == null || path == string.Empty) _textureGUID = string.Empty;
                    else _textureGUID = AssetDatabase.AssetPathToGUID(path);
                } else _textureGUID = string.Empty;
            }

            public void UpdateCachedTextureInfo() {
                // Check if the source image has changed before we bother loading it and updating
                if(!isEditingMode) {
                    string path = AssetDatabase.GUIDToAssetPath(_textureGUID);
                    if(path == null || path == string.Empty) return;
                    TextureImporter importer = (TextureImporter)TextureImporter.GetAtPath(path);
                    if(importer == null) return;
                    ulong currentTimestamp = importer.assetTimeStamp;
                    if(textureTimestampSUL.value == currentTimestamp) {
                        return; // time stamp matches, don't bother updating info, it should be current (if name has been changed, it doesn't matter)
                    }
                }

                Texture2D texture = GetTexture();
                UpdateSize(texture);
                UpdateTextureName(texture);
            }

            private void UpdateSize(Texture2D texture) {
                if(texture != null) {
                    if(_width != texture.width) _width = texture.width;
                    if(_height != texture.height)_height = texture.height;
                } else {
                    if(_width != 0) _width = 0;
                    if(_height != 0) _height = 0;
                }
            }

            private void UpdateTextureName(Texture2D texture) {
                if(texture == null) _textureName = string.Empty;
                else _textureName = texture.name;
            }

            #region // Upgrade Data

            public bool UpgradeCheck() {
                bool changed = false;

                // Collider frame data format
                if(colliderFrames != null && colliderFrames.Length > 0) {
                    for(int i = 0; i < colliderFrames.Length; i++) {
                        if(colliderFrames[i] == null) continue;
                        if(colliderFrames[i].UpgradeCheck()) changed = true;
                    }
                }

                // Convert texture object reference to GUID
                if(texture != null) {
                    string path = AssetDatabase.GetAssetPath(texture);
                    if(path != null && path != string.Empty) {
                        _textureGUID = AssetDatabase.AssetPathToGUID(path);
                        if(_textureGUID == null || _textureGUID == string.Empty) {
                            Debug.LogWarning("Source image was not found in AssetDatabase! The source image will left be blank.");
                        }
                    } else { // texture was not found
                        Debug.LogWarning("Source image was not found in AssetDatabase! The source image will left be blank.");
                    }
                    texture = null;
                    changed = true;
                }

                return changed;
            }

            #endregion

            #region // Custom Meshes

            public void GenerateAutoSpriteMesh(EditorMasterSprite.Data parent, CacheDataObject cache) {
                if(!hasTexture) {
                    //Debug.LogWarning("Source image missing! Cannot generate mesh!");
                    return; // no texture
                }

                // Create or update the mesh frame and store the unique id
                _meshFrameUid = parent.UpdateFrameMeshIfNecessary(_meshFrameUid, _textureGUID, textureTimestamp, _pixelUVRect, atlasIndex, cache);
            }

            #endregion
        }

        #endregion

        #region // Atlas

        [System.Serializable]
        public class Atlas : Sprite.Atlas_Base{
            public string textureMapGUID;
            public string[] materialGUIDs;

            public bool hasTexture {
                get {
                    return textureMapPath != null ? true : false;
                }
            }
            public string textureMapPath {
                get {
                    return Utils.AssetTools.GetAssetPathFromGUID(textureMapGUID);
                }
            }

            public Atlas() { }

            public Atlas(Atlas atlas) {
                CopyDataVars(atlas, this);
            }

            public Texture2D GetTextureMap() {
                return Utils.AssetTools.LoadAssetFromGUID<Texture2D>(textureMapGUID);
            }

            #region Utilities

            public Sprite.Atlas ConvertToSpriteAtlas() {
                Sprite.Atlas spriteAtlas = new Sprite.Atlas(); // make new sprite atlas
                base.CopyDataVars((Sprite.Atlas_Base)this, (Sprite.Atlas_Base)spriteAtlas); // copy shared vars from base to spriteAtlas

                // Convert texture GUID to texture
                spriteAtlas.textureMap = Utils.AssetTools.LoadAssetFromGUID<Texture2D>(textureMapGUID);

                // Convert MaterialGUIDs to materials
                if(materialGUIDs != null) {
                    Material[] newMaterials = new Material[0];
                    for(int i = 0; i < materialGUIDs.Length; i++) {
                        Material mat = Utils.AssetTools.LoadAssetFromGUID<Material>(materialGUIDs[i]);
                        SpriteFactory.Utils.ArrayTools.Add<Material>(ref newMaterials, mat);
                    }
                    spriteAtlas.materials = newMaterials;
                } else {
                    spriteAtlas.materials = null;
                }

                return spriteAtlas;
            }

            public Atlas DeepCopy() {
                return new Atlas(this);
            }

            protected void CopyDataVars(Atlas source, Atlas destination) {
                base.CopyDataVars(source, destination);

                destination.textureMapGUID = source.textureMapGUID;
                if(source.materialGUIDs != null) destination.materialGUIDs = (string[])source.materialGUIDs.Clone();
                else destination.materialGUIDs = null;
            }

            #endregion
        }

        #endregion

        #region // Material Set

        [System.Serializable]
        public class MaterialSet : Sprite.MaterialSet {

            public bool useDefaultMaterial;
            public Material sourceMaterial;

            public MaterialSet(string name, bool useDefaultMaterial, Material sourceMaterial)
                : base(name) {
                this.useDefaultMaterial = useDefaultMaterial;
                this.sourceMaterial = sourceMaterial;
            }

            public MaterialSet(EditorMasterSprite.MaterialSet materialSet) { // clone
                CopyDataVars(materialSet, this); // copy data from this to the new object
            }

            #region // Utilities

            private void CopyDataVars(EditorMasterSprite.MaterialSet source, EditorMasterSprite.MaterialSet destination) {
                base.CopyDataVars(source, destination); // copy vars from base class

                // Copy vars from this class
                destination.useDefaultMaterial = source.useDefaultMaterial;
                destination.sourceMaterial = source.sourceMaterial;
            }

            new public EditorMasterSprite.MaterialSet DeepCopy() {
                return new EditorMasterSprite.MaterialSet(this);
            }

            public Sprite.MaterialSet ConvertToSpriteMaterialSet() {
                Sprite.MaterialSet spriteMaterialSet = new Sprite.MaterialSet(name);
                return spriteMaterialSet;
            }

            #endregion
        }

        #endregion

        // SPRITE GROUPS //////////////////

        #region // SpriteGroup

        public class SpriteGroup {
            // Identity
            public int groupId = -1;

            // Data
            public string name = "";
            public int[] spriteIds;
            public EditorMasterSprite.MaterialSet[] editorMaterialSets;

            // Group Settings (overrides sprite settings)
            public int atlasTextureFilterMode;
            public int atlasTextureAnisoLevel = -1;

            public SpriteGroup(int groupId, string name, int[] masterSpriteIds, EditorMasterSprite.MaterialSet[] materialSets, bool useDefaultAtlasTextureFilterMode, FilterMode atlasTextureFilterMode, int atlasTextureAnisoLevel) {
                this.groupId = groupId;
                this.name = name;
                this.spriteIds = masterSpriteIds;
                this.editorMaterialSets = materialSets;

                // settings
                if(useDefaultAtlasTextureFilterMode) this.atlasTextureFilterMode = -1;
                else this.atlasTextureFilterMode = (int)atlasTextureFilterMode;
                this.atlasTextureAnisoLevel = atlasTextureAnisoLevel;
            }

            public void ClearSpriteData() {
                spriteIds = null;
                editorMaterialSets = null;
            }

            public void ImportSettings(SpriteGroup source) {
                // import only the settings, not identity or the sprite ids
                name = source.name;
                atlasTextureFilterMode = source.atlasTextureFilterMode;
                atlasTextureAnisoLevel = source.atlasTextureAnisoLevel;

                // Import material sets
                EditorMasterSprite.MaterialSet[] sourceSets = source.editorMaterialSets;
                if(sourceSets == null) editorMaterialSets = null;
                else {
                    editorMaterialSets = new EditorMasterSprite.MaterialSet[sourceSets.Length];
                    for(int i = 0; i < sourceSets.Length; i++) {
                        editorMaterialSets[i] = sourceSets[i].DeepCopy();
                    }
                }
            }
        }

        #endregion

        // MISC /////////

        [System.Serializable]
        public class MeshFrame : Sprite.MeshFrame_Base {

            public Vector2[] vertices;
            public float pixelCenterOffsetX;
            public float pixelCenterOffsetY;
            public SpriteFactory.Utils.DataClasses.IntRect pixelUVRect;
            public int atlasIndex;
            public int uid;

            public string sourceImageGUID;
            public SpriteFactory.Utils.DataClasses.SerializableULong textureTimestampSUL;
            public Enums.TransparencyChannel transparencyChannel;

            // Properties
            public ulong textureTimestamp { get { return textureTimestampSUL.value; } set { textureTimestampSUL.value = value; } }


            public MeshFrame() {
                textureTimestampSUL = new SpriteFactory.Utils.DataClasses.SerializableULong();
                pixelUVRect = new SpriteFactory.Utils.DataClasses.IntRect();
            }

            public MeshFrame(MeshFrame meshFrame) {
                CopyDataVars(meshFrame, this);
            }

            protected void CopyDataVars(MeshFrame source, MeshFrame destination) {
                base.CopyDataVars(source, destination); // copy vars in the base

                // Copy variables from this class
                destination.vertices = SpriteFactory.Utils.ArrayTools.Clone<Vector2>(source.vertices);
                destination.pixelCenterOffsetX = source.pixelCenterOffsetX;
                destination.pixelCenterOffsetY = source.pixelCenterOffsetY;
                if(source.pixelUVRect != null) destination.pixelUVRect = source.pixelUVRect.Clone();
                else destination.pixelUVRect = null;
                destination.atlasIndex = source.atlasIndex;
                destination.sourceImageGUID = source.sourceImageGUID;
                if(source.textureTimestampSUL != null) destination.textureTimestampSUL = source.textureTimestampSUL.Clone();
                else destination.textureTimestampSUL = null;
                destination.uid = source.uid;
            }

            public static MeshFrame Clone(MeshFrame meshFrame) {
                if(meshFrame == null) return null;
                return new MeshFrame(meshFrame);
            }

            internal void ImportMeshData(MeshFrameGenerator.MeshData meshData) {
                if(meshData == null) return;

                // Convert MeshData to MeshFrame
                vertices = meshData.vertices;
                triangles = meshData.triangles;
                uvs = meshData.uvs;
                pixelCenterOffsetX = meshData.pixelCenterOffsetX;
                pixelCenterOffsetY = meshData.pixelCenterOffsetY;
                transparencyChannel = meshData.transparencyChannel;
            }

            public Sprite.MeshFrame ConvertToSpriteMeshFrame(int pixelsPerUnit, float resolutionTargetScaleInverseMultiplier, EditorMasterSprite.Data parentData, bool twoSidedMesh) {              
                Sprite.MeshFrame spriteMeshFrame = new Sprite.MeshFrame();
                //base.CopyDataVars(this, spriteMeshFrame); // DO NOT COPY ANYTHING HERE

                // Do data conversion
                ScaleAndOffsetMeshFrame(spriteMeshFrame, pixelsPerUnit, resolutionTargetScaleInverseMultiplier, parentData, twoSidedMesh); // convert mesh to world scale format and bake in offsets

                return spriteMeshFrame;
            }

            protected void ScaleAndOffsetMeshFrame(Sprite.MeshFrame spriteMeshFrame, int pixelsPerUnit, float resolutionTargetScaleInverseMultiplier, EditorMasterSprite.Data parentData, bool twoSidedMesh) {
                Vector2[] sourceVertices = this.vertices; // get the mesh vertices from the editor mesh frame
                if(sourceVertices == null || sourceVertices.Length == 0) return; // no verts, nothing to do
                Vector2[] sourceUVs = this.uvs;
                int[] sourceTriangles = this.triangles;
                int vertexCount = sourceVertices.Length;
                int finalVertCount = twoSidedMesh ? vertexCount * 2 : vertexCount;

                // Get information from atlas
                Atlas[] atlases = parentData.editorAtlases;
                if(atlasIndex < 0 || atlases == null || atlases.Length == 0 || atlasIndex >= atlases.Length) return;
                Atlas atlas = atlases[atlasIndex];
                if(atlas == null) return;

                // Bleed padding is incompatible with custom meshes

                // Offset -- Cannot bake offset in here or we cannot reuse mesh frames
                //int pixelOffsetX = framePixelOffset.x;
                //int pixelOffsetY = framePixelOffset.y;

                // UVs - must go first because we will be modifying the vertices in the meshFrame

                // Scale UVs to fit into atlas
                // UVs must be laid out on original untrimmed texture size
                // UVs may extend beyond 0-1 if we have extrude distance and the graphics go up to the edge

                // Incoming UVs are already offset for trim and extrude

                float uvScaleX = 1.0f / atlas.width; // the scale to fit this texture into the UV sheet
                float uvScaleY = 1.0f / atlas.height;
                // Copy the UVs and offset and scale
                Vector2[] targetUVs = new Vector2[finalVertCount];
                for(int i = 0; i < vertexCount; i++) {
                    targetUVs[i].x = (sourceUVs[i].x + pixelUVRect.x) * uvScaleX;
                    targetUVs[i].y = (sourceUVs[i].y + pixelUVRect.y) * uvScaleY;
                }

                // Vertices
                float centerOffsetX = this.pixelCenterOffsetX;
                float centerOffsetY = this.pixelCenterOffsetY;

                // Apply frame offset
                //if(framePixelOffset != null) {
                //    centerOffsetX += framePixelOffset.x;
                //    centerOffsetY += framePixelOffset.y;
                //}
                // Frame offset cannot be baked in otherwise we cannot share mesh frames

                // Adjust to prevent 1/2 pixel misalignment to be consistent with the way we handle rect meshes
                if(SpriteFactory.Utils.MathTools.IsNearOrWholeNumber(resolutionTargetScaleInverseMultiplier)) { // only do pixel snap on resolution targets that have even scaling
                    SpriteFactory.Utils.MiscTools.SnapToPixel(ref centerOffsetX, ref centerOffsetY);
                }

                // Scale verts so mesh is the proper size and apply offset so its centered
                float vertScale = 1.0f / (float)pixelsPerUnit; // the scale to make the mesh the proper size in the world
                Vector3[] targetVertices = new Vector3[finalVertCount];
                for(int i = 0; i < vertexCount; i++) {
                    targetVertices[i].x = (sourceVertices[i].x + centerOffsetX) * vertScale;
                    targetVertices[i].y = (sourceVertices[i].y + centerOffsetY) * vertScale;
                }

                int[] targetTriangles;

                // Bake two-sided meshes
                if(twoSidedMesh) {

                    // Duplicate verts and uvs for backside
                    for(int i = vertexCount; i < finalVertCount; i++) {
                        targetVertices[i] = targetVertices[i - vertexCount];
                        targetUVs[i] = targetUVs[i - vertexCount];
                    }

                    // Triangles
                    int triangleCount = sourceTriangles.Length;
                    targetTriangles = new int[triangleCount * 2];

                    // Copy front side triangles
                    for(int i = 0; i < triangleCount; i++) {
                        targetTriangles[i] = sourceTriangles[i];
                    }

                    // Copy reversing winding order of back side triangles to flip normal
                    for(int i = triangleCount; i < targetTriangles.Length; i += 3) {
                        int sourceIndex = i - triangleCount;
                        targetTriangles[i] = sourceTriangles[sourceIndex + 2];
                        targetTriangles[i + 1] = sourceTriangles[sourceIndex + 1];
                        targetTriangles[i + 2] = sourceTriangles[sourceIndex];
                    }

                } else
                    targetTriangles = SpriteFactory.Utils.ArrayTools.Clone<int>(sourceTriangles); // triangles are the same

                // Copy data to target
                spriteMeshFrame.vertices = targetVertices;
                spriteMeshFrame.uvs = targetUVs;
                spriteMeshFrame.triangles = targetTriangles;
            }
        }

        #endregion
    }

    public class EditorMasterSpriteCore : ScriptableObject {
        [SerializeField] private EditorMasterSprite.Data _data; // the master sprite data object containing the editor data

        public EditorMasterSprite.Data data {
            get {
                return _data;
            }
            set {
                _data = value;
                EditorUtility.SetDirty(this);
            }
        }
    }
}