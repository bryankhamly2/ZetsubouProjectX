﻿using System;
using System.Collections.Generic;

namespace SpriteFactory.Editor {

    public interface IExternalEditorTools {
        void FixTextureImporterSettings(string pathToTexture, ref bool deselected, ref List<string> texturesToImportPaths);
    }
}
