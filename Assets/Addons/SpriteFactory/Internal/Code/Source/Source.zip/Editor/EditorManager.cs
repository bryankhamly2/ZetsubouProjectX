﻿using System;
using System.Collections.Generic;

namespace SpriteFactory.Editor {

    public static class EditorManager {

        public static IExternalEditorTools externalEditorTools;
    }
}
