using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using SpriteFactory.Editor.DataClasses;
using Sprite = SpriteFactory.Sprite;
using Settings = SpriteFactory.Settings;

namespace SpriteFactory.Editor {

    public class SpriteFactoryData : ScriptableObject {

        public Settings settings;

        // Save data
        [SerializeField] private List<SpriteSaveData> spriteSaveData = new List<SpriteSaveData>(); // a list of sprites and frame data saved on disk
        [SerializeField] private int _spriteIdCounter = 0; // unique number for each sprite

        [SerializeField] private List<SpriteGroupSaveData> spriteGroupSaveData = new List<SpriteGroupSaveData>(); // a list of sprites and frame data saved on disk
        [SerializeField] private int _groupIdCounter = 0; // unique number for each sprite group

        [SerializeField] private List<int> ungroupedSpriteIds = new List<int>();

        [SerializeField] public string programVersion;
        [SerializeField] public int dataVersion;
        [SerializeField] public bool isTrial;


        #region Rebuilding

        public void FlagSpriteOrSpriteGroupForRebuilding(int spriteIndex, int groupId, bool rebuildRequired) {
            CheckSpriteIndex(spriteIndex);
            int groupIndex = FindSpriteGroupIndexBySpriteGroupId(groupId);
            if(groupIndex >= 0) { // sprite is in a group
                CheckSpriteGroupIndex(groupIndex);
                // flag the group, not the sprite
                if(spriteGroupSaveData[groupIndex].rebuildRequired != rebuildRequired)
                    spriteGroupSaveData[groupIndex].rebuildRequired = rebuildRequired;
            } else {
                if(spriteSaveData[spriteIndex].rebuildRequired != rebuildRequired)
                    spriteSaveData[spriteIndex].rebuildRequired = rebuildRequired;
            }
        }

        public void FlagSpriteForRebuilding(int spriteIndex, bool rebuildRequired) {
            CheckSpriteIndex(spriteIndex);
            if(spriteSaveData[spriteIndex].rebuildRequired != rebuildRequired) spriteSaveData[spriteIndex].rebuildRequired = rebuildRequired;
        }

        public void FlagSpriteGroupForRebuilding(int groupIndex, bool rebuildRequired) {
            CheckSpriteGroupIndex(groupIndex);
            SpriteGroupSaveData group = spriteGroupSaveData[groupIndex];
            if(group.rebuildRequired != rebuildRequired) group.rebuildRequired = rebuildRequired;

            /* // Not necessary because when you move him out he will be rebuilt anyway
            // Make sure no child sprites are flagged -- this is to prevent flags from sticking around when moving a sprite into a group
            if(group.spriteIds != null && group.spriteIds.Length > 0) {
                int spriteCount = spriteSaveData.Count;
                for(int i = 0; i < group.spriteIds.Length; i++) {
                    int spriteIndex = FindSpriteIndexBySpriteId(group.spriteIds[i]);
                    if(spriteIndex < 0 || spriteIndex >= spriteCount) continue;
                    if(spriteSaveData[spriteIndex].rebuildRequired) spriteSaveData[spriteIndex].rebuildRequired = false;
                }
            }*/
        }

        public int[] GetSpriteIndicesFlaggedForRebuilding() {
            if(spriteSaveData == null || spriteSaveData.Count == 0) return null;

            int[] indices = null;
            for(int i = 0; i < spriteSaveData.Count; i++) {
                if(spriteSaveData[i].groupId >= 0) continue; // this sprite is in a group, skip
                if(!spriteSaveData[i].rebuildRequired) continue; // no rebuild required
                SpriteFactory.Utils.ArrayTools.Add<int>(ref indices, i);
            }
            return indices;
        }

        public int[] GetSpriteGroupIndicesFlaggedForRebuilding() {
            if(spriteGroupSaveData == null || spriteGroupSaveData.Count == 0) return null;

            int[] indices = null;
            for(int i = 0; i < spriteGroupSaveData.Count; i++) {
                if(!spriteGroupSaveData[i].rebuildRequired) continue; // no rebuild required
                SpriteFactory.Utils.ArrayTools.Add<int>(ref indices, i);
            }
            return indices;
        }

        public bool IsSpriteFlaggedForRebuilding(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return spriteSaveData[spriteIndex].rebuildRequired;
        }

        public bool IsSpriteGroupFlaggedForRebuilding(int groupIndex) {
            CheckSpriteGroupIndex(groupIndex);
            return spriteGroupSaveData[groupIndex].rebuildRequired;
        }

        #endregion

        #region Sprite Functions

        internal int[] GetSpriteIndices() {
            if(spriteSaveData == null) return null;

            int[] indices = new int[spriteSaveData.Count];
            for(int i = 0; i < spriteSaveData.Count; i++) {
                indices[i] = i;
            }
            return indices;
        }

        internal string GetSpriteName(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return spriteSaveData[spriteIndex].name;
        }

        internal string[] GetSpriteNames() {
            if(spriteSaveData == null) return null;

            string[] names = new string[spriteSaveData.Count];
            for(int i = 0; i < spriteSaveData.Count; i++) {
                names[i] = spriteSaveData[i].name;
            }
            return names;
        }

        internal string[] GetUngroupedSpriteFileNames() {
            if(spriteSaveData == null || spriteSaveData.Count == 0) return null;
            if(ungroupedSpriteIds == null || ungroupedSpriteIds.Count == 0) return null;

            string[] names = new string[0];
            for(int i = 0; i < ungroupedSpriteIds.Count; i++) {
                int spriteId = ungroupedSpriteIds[i];
                if(spriteId < 0) continue;
                int spriteIndex = FindSpriteIndexBySpriteId(spriteId);
                if(spriteIndex < 0 || spriteIndex >= spriteSaveData.Count) continue;
                string fileName = spriteSaveData[spriteIndex].editorMasterSpriteFileName;
                SpriteFactory.Utils.ArrayTools.Add<string>(ref names, fileName);
            }
            return names;
        }

        internal bool GetSpriteNamesAndIndicesInGroup(int groupId, out int[] indices, out string[] names, bool prependRebuildRequired = false) {
            indices = null;
            names = null;

            if(groupId < 0) { // get sprites not in any group
                if(spriteSaveData == null || spriteSaveData.Count == 0 || ungroupedSpriteIds == null || ungroupedSpriteIds.Count == 0) return false; // no sprites
                bool found = false;
                for(int i = 0; i < ungroupedSpriteIds.Count; i++) {
                    int spriteIndex = FindSpriteIndexBySpriteId(ungroupedSpriteIds[i]);
                    CheckSpriteIndex(spriteIndex);
                    SpriteFactory.Utils.ArrayTools.Add<int>(ref indices, spriteIndex);
                    string name = spriteSaveData[spriteIndex].name;
                    if(prependRebuildRequired && spriteSaveData[spriteIndex].rebuildRequired) name = "* " + name;
                    SpriteFactory.Utils.ArrayTools.Add<string>(ref names, name);
                    found = true;
                }
                return found;

            } else { // get sprites in group
                int groupIndex = FindSpriteGroupIndexBySpriteGroupId(groupId);
                CheckSpriteGroupIndex(groupIndex);
                SpriteGroupSaveData group = spriteGroupSaveData[groupIndex];
                if(group.spriteIds == null || group.spriteIds.Length == 0) return false; // no sprites in group
                bool found = false;
                for(int i = 0; i < group.spriteIds.Length; i++) {
                    int spriteIndex = FindSpriteIndexBySpriteId(group.spriteIds[i]);
                    if(spriteIndex < 0) continue; // error
                    SpriteFactory.Utils.ArrayTools.Add<int>(ref indices, spriteIndex);
                    SpriteFactory.Utils.ArrayTools.Add<string>(ref names, spriteSaveData[spriteIndex].name);
                    found = true;
                }
                return found;
            }
        }

        internal string[] GetSpriteAtlasFilePaths(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            EditorMasterSprite sprite = LoadEditorMasterSprite(spriteIndex);
            return sprite.GetAtlasFilePaths();
        }

        internal string[] GetSpriteMaterialFilePaths(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            MaterialSetFiles[] materialSets = LoadEditorMasterSprite(spriteIndex).GetWorkingMaterialSetFiles();
            if(materialSets == null) return null;

            string[] fileNames = new string[0];
            for(int i = 0; i < materialSets.Length; i++) {
                string[] materialFiles = materialSets[i].materialFilePaths;
                if(materialFiles == null) continue;
                for(int j = 0; j < materialFiles.Length; j++) {
                    SpriteFactory.Utils.ArrayTools.Add<string>(ref fileNames, materialFiles[j]);
                }
            }
            return fileNames;
        }

        internal SpriteFactoryData.MaterialSetFiles[] GetSpriteMaterialSetFiles(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return LoadEditorMasterSprite(spriteIndex).GetWorkingMaterialSetFiles(); // returns a copy
        }

        internal int GetSpriteGroupIdOfSpriteById(int spriteId) {
            return GetSpriteGroupIdOfSpriteByIndex(FindSpriteIndexBySpriteId(spriteId));
        }

        internal int GetSpriteGroupIdOfSpriteByIndex(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return spriteSaveData[spriteIndex].groupId;
        }

        internal string GetEditorSpriteFileName(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return spriteSaveData[spriteIndex].editorMasterSpriteFileName;
        }

        internal string GetEditorSpriteFilePath(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return spriteSaveData[spriteIndex].GetEditorMasterSpriteFilePath(); // get the relative path
        }

        internal string GetEditorSpriteCoreFilePath(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return spriteSaveData[spriteIndex].GetEditorMasterSpriteCoreFilePath(); // get the relative path
        }

        internal string GetGameSpriteFilePath(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return spriteSaveData[spriteIndex].GetGameMasterSpriteFilePath(); // get the relative path
        }

        internal string GetSpriteEditorPreviewMeshFile(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return LoadEditorMasterSprite(spriteIndex).GetEditorPreviewMeshFilePath(); // get the relative path
        }

        internal string GetSpriteEditorPreviewMaterialFile(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return LoadEditorMasterSprite(spriteIndex).GetEditorPreviewMaterialFilePath(); // get the relative path
        }

        internal int GetSpriteId(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return spriteSaveData[spriteIndex].spriteId;
        }

        internal int FindSpriteIndexBySpriteId(int id) {
            for(int i = 0; i < spriteSaveData.Count; i++) {
                if(spriteSaveData[i].spriteId == id) return i;
            }
            return -1;
        }

        internal int CreateNewSpriteInGroup(string editorMasterSpriteFileName, string name, int groupId, int newIndex = -1, bool updateInDataFileOnly = false) {
            int spriteIndex;

            // create new sprite in list
            spriteSaveData.Add(new SpriteSaveData());
            spriteIndex = spriteSaveData.Count - 1;
            int spriteId = GetNewSpriteId();
            int groupIndex = FindSpriteGroupIndexBySpriteGroupId(groupId);
            SpriteGroup spriteGroup = updateInDataFileOnly ? null : LoadSpriteGroup(groupIndex);

            if(newIndex == -1) { // add to end of list
                if(groupIndex == -1) { // ungrouped list
                    ungroupedSpriteIds.Add(spriteId);
                } else { // a group
                    spriteGroupSaveData[groupIndex].AddSprite(spriteId);
                    if(!updateInDataFileOnly) {
                        spriteGroup.AddSprite(editorMasterSpriteFileName);
                        spriteGroup.SetDirtyForSave();
                    }
                }

            } else { // insert new sprite at specific index in list
                if(groupIndex == -1) { // ungrouped list
                    if(newIndex == ungroupedSpriteIds.Count) ungroupedSpriteIds.Add(spriteId); // add entry to end of ungrouped list
                    else ungroupedSpriteIds.Insert(newIndex, spriteId); // insert entry in ungrouped list
                } else { // a group
                    if(newIndex == spriteGroupSaveData[groupIndex].spriteCount) {
                        spriteGroupSaveData[groupIndex].AddSprite(spriteId); // add entry to end of group list
                        if(!updateInDataFileOnly) {
                            spriteGroup.AddSprite(editorMasterSpriteFileName);
                            spriteGroup.SetDirtyForSave();
                        }
                    } else {
                        spriteGroupSaveData[groupIndex].InsertSprite(newIndex, spriteId); // insert entry in group list
                        if(!updateInDataFileOnly) {
                            spriteGroup.InsertSprite(newIndex, editorMasterSpriteFileName);
                            spriteGroup.SetDirtyForSave();
                        }
                    }
                    
                }
            }
            spriteSaveData[spriteIndex].spriteId = spriteId; // save the sprite id in the entry
            spriteSaveData[spriteIndex].name = name;
            return spriteIndex;
        }

        private int GetNewSpriteId() {
            int num = _spriteIdCounter;
            _spriteIdCounter++; // increment for next time
            return num;
        }

        internal void ClearSpriteAtlasAndMaterialFiles(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            EditorMasterSprite sprite = LoadEditorMasterSprite(spriteIndex);
            sprite.atlasFiles = null;
            sprite.materialSetFiles = null;
            sprite.SetDirtyForSave();
        }

        internal void SaveSpriteData(int spriteIndex, string spriteName, string[] atlasFiles, SpriteFactoryData.MaterialSetFiles[] materialSetFiles) {
            CheckSpriteIndex(spriteIndex);
            EditorMasterSprite sprite = LoadEditorMasterSprite(spriteIndex);
            SpriteSaveData data = spriteSaveData[spriteIndex];
            data.name = spriteName;
            sprite.name = spriteName; // save the name in the master sprite also
            sprite.data.name = spriteName; // save the name in the core also
            sprite.SetAtlasFiles(atlasFiles);
            if(materialSetFiles == null) sprite.materialSetFiles = null;
            else {
                // copy the material set files and store
                SpriteFactoryData.MaterialSetFiles_Save[] newSetFiles = new SpriteFactoryData.MaterialSetFiles_Save[materialSetFiles.Length];
                for(int i = 0; i < materialSetFiles.Length; i++) {
                    newSetFiles[i] = new MaterialSetFiles_Save(materialSetFiles[i]);
                }
                sprite.materialSetFiles = newSetFiles;
            }
            sprite.SetDirtyForSave(true); // flag for saving, save the core
        }

        internal void SaveSpriteFileData(int spriteIndex, int groupId, string editorMasterSpriteFileName, string gameMasterSpriteFileName, string editorPreviewMeshFileName, string editorPreviewMaterialFileName) {
            CheckSpriteIndex(spriteIndex);
            SpriteSaveData data = spriteSaveData[spriteIndex];
            string groupName = GetSpriteGroupNameById(groupId); // null if ungrouped
            data.groupId = groupId;
            data.editorMasterSpriteFileName = editorMasterSpriteFileName;
            data.editorMasterSpriteCoreFileName = SpriteEditor.GetEditorMasterSpriteCoreFileNameOnly(data.name, groupName);
            data.gameMasterSpriteFileName = gameMasterSpriteFileName;

            EditorMasterSprite sprite = LoadEditorMasterSprite(spriteIndex);
            sprite.editorPreviewMeshFileName = editorPreviewMeshFileName;
            sprite.editorPreviewMaterialFileName = editorPreviewMaterialFileName;
            sprite.SetDirtyForSave(false); // flag for saving, no need to save core
        }

        internal void DeleteSprite(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);

            // Remove sprite from the group list
            int spriteId = spriteSaveData[spriteIndex].spriteId;
            int groupId = spriteSaveData[spriteIndex].groupId;
            if(groupId >= 0) { // sprite is in a group
                DeleteSpriteFromSpriteGroup(groupId, spriteId); // Remove the sprite from the group
            } else { // sprite is ungrouped
                RemoveSpriteIdFromUngroupedList(spriteId); // Remove the sprite from the ungrouped list 
            }

            // Remove sprite from sprite list
            spriteSaveData.RemoveAt(spriteIndex);
        }

        internal bool ReorderSprite(int spriteIndex, int offset, bool reorderNow) {
            CheckSpriteIndex(spriteIndex);
            if(offset == 0) return false;
            if(spriteIndex == spriteSaveData.Count - 1 && offset > 0) return false; // at end of list trying to move down
            if(spriteIndex == 0 && offset < 0) return false; // at beginning of list trying to move up
            if(!reorderNow) return true; // just testing to see if we can reorder, passed

            // Does not handle offsets other than +/- 1
            if(offset > 1) offset = 1;
            if(offset < -1) offset = -1;

            SpriteSaveData entry = spriteSaveData[spriteIndex]; // get the entry
            spriteSaveData.RemoveAt(spriteIndex); // remove entry first

            if(offset > 0) {
                //offset += 1; // account for insert pushing the entry down
                if(spriteIndex + offset >= spriteSaveData.Count) { // would be at the end of the list
                    spriteSaveData.Add(entry); // add to end of the list
                    return true;
                }
            }
            spriteSaveData.Insert(spriteIndex + offset, entry); // insert the entry back
            return true;
        }

        internal bool ReorderSpriteInGroup(int groupId, int listIndex, int offset, bool reorderNow) {
            int groupIndex = FindSpriteGroupIndexBySpriteGroupId(groupId);

            // Get item count of group
            int listItemCount;
            if(groupIndex == -1) listItemCount = ungroupedSpriteIds.Count; // ungrouped list
            else listItemCount = spriteGroupSaveData[groupIndex].spriteCount; // a group list 

            // Check if we have space to move item up/down
            if(offset == 0) return false;
            if(listIndex == listItemCount - 1 && offset > 0) return false; // at end of list trying to move down
            if(listIndex == 0 && offset < 0) return false; // at beginning of list trying to move up
            if(!reorderNow) return true; // just testing to see if we can reorder, passed

            // Does not handle offsets other than +/- 1
            if(offset > 1) offset = 1;
            if(offset < -1) offset = -1;


            if(groupIndex == -1) { // ungrouped list

                int entry = ungroupedSpriteIds[listIndex]; // get the entry
                ungroupedSpriteIds.RemoveAt(listIndex); // remove entry first

                if(offset > 0) {
                    listItemCount = ungroupedSpriteIds.Count;
                    if(listIndex + offset >= listItemCount) { // would be at the end of the list
                        ungroupedSpriteIds.Add(entry); // add to end of the list
                        return true;
                    }
                }
                ungroupedSpriteIds.Insert(listIndex + offset, entry); // insert the entry back

            } else { // group list

                SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
                SpriteGroupSaveData groupData = spriteGroupSaveData[groupIndex];
                int entry = groupData.spriteIds[listIndex]; // get the entry
                string masterSpriteFileName = spriteGroup.GetSprite(listIndex);
                groupData.RemoveSpriteAt(listIndex); // remove entry first
                spriteGroup.RemoveSpriteAt(listIndex);

                if(offset > 0) {
                    listItemCount = groupData.spriteCount;
                    if(listIndex + offset >= listItemCount) { // would be at the end of the list
                        groupData.AddSprite(entry); // add to end of the list
                        spriteGroup.AddSprite(masterSpriteFileName);
                        spriteGroup.SetDirtyForSave();
                        return true;
                    }
                }
                groupData.InsertSprite(listIndex + offset, entry); // insert the entry back
                spriteGroup.InsertSprite(listIndex + offset, masterSpriteFileName);
                spriteGroup.SetDirtyForSave();
            }

            return true;
        }

        private void CheckSpriteIndex(int spriteIndex) {
            if(spriteIndex < 0 || spriteIndex >= spriteSaveData.Count) throw new System.Exception("Invalid sprite index!");
        }

        internal bool IsSpriteDataSaved() {
            if(spriteSaveData.Count > 0) return true;
            return false;
        }

        internal AssetData[] GetSpriteExportAssets(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            return GetSpriteExportAssets(GetEditorSpriteFileName(spriteIndex));
        }

        private AssetData[] GetSpriteExportAssets(string masterSpriteFileName, string groupName = null) {
            if(masterSpriteFileName == null || masterSpriteFileName == "") return null;
            string masterSpritePath = SpriteEditor.AddEditorMasterSpriteFilePath(masterSpriteFileName);
            if(!SpriteEditor.FileExistsRel(masterSpritePath)) return null; // master sprite file does not exist
            
            // Load master sprite
            EditorMasterSprite masterSprite = LoadEditorMasterSprite(masterSpritePath, false);
            if(masterSprite == null) return null; // master sprite couldn't be loaded

            // Load core
            string masterSpriteCorePath = SpriteEditor.AddEditorMasterSpriteCoreFilePath(masterSprite.coreFileName);
            EditorMasterSpriteCore masterSpriteCore = LoadEditorMasterSpriteCore(masterSpriteCorePath);
            if(masterSpriteCore == null) return null; // core is missing

            // Make sure game master sprite exists
            string gameMasterSpritePath = SpriteEditor.GetGameMasterSpriteFilePath(masterSprite.name, groupName);
            if(!SpriteEditor.FileExistsRel(gameMasterSpritePath)) return null; // game master sprite is missing

            AssetData[] assetData = null;

            SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData, new AssetData(SpriteEditor.RelToAbsPath(masterSpritePath), AssetData.AssetType.EditorMasterSprite)); // add master sprite path
            SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData, new AssetData(SpriteEditor.RelToAbsPath(masterSpriteCorePath), AssetData.AssetType.EditorMasterSpriteCore)); // add master sprite core path
            SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData, new AssetData(SpriteEditor.RelToAbsPath(gameMasterSpritePath), AssetData.AssetType.GameMasterSprite)); // add game master sprite path

            // From MasterSprite
            // Editor preview mesh
            if(masterSprite.editorPreviewMeshFileName != null && masterSprite.editorPreviewMeshFileName != "") {
                string path = SpriteEditor.AddEditorMeshFilePath(masterSprite.editorPreviewMeshFileName);
                if(SpriteEditor.FileExistsRel(path)) {
                    SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData, new AssetData(SpriteEditor.RelToAbsPath(path), AssetData.AssetType.SpriteMesh)); // add path
                }
            }

            // Editor preview material
            if(masterSprite.editorPreviewMaterialFileName != null && masterSprite.editorPreviewMaterialFileName != "") {
                string path = SpriteEditor.AddMaterialFilePath(masterSprite.editorPreviewMaterialFileName);
                if(SpriteEditor.FileExistsRel(path)) {
                    SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData, new AssetData(SpriteEditor.RelToAbsPath(path), AssetData.AssetType.EditorPreviewMaterial)); // add path
                }
            }

            /* Skip material sets
             * 
            // Material set files
            if(masterSprite.materialSetFiles != null) {
                SpriteFactoryData.MaterialSetFiles_Save[] matFiles = masterSprite.materialSetFiles;
                for(int i = 0; i < matFiles.Length; i++) {
                    string[] filePaths = matFiles[i].GetMaterialFilePaths();
                    if(filePaths == null) continue;
                    for(int k = 0; k < filePaths.Length; k++) {
                        if(!SpriteEditor.FileExistsRel(filePaths[k])) continue;
                        SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref absAssetPaths, new AssetData(SpriteEditor.RelToAbsPath(filePaths[k]), AssetData.AssetType.MaterialSetMaterial)); // add path
                    }
                }
            }
            */

            // From Core
            EditorMasterSprite.Data masterSpriteData = masterSpriteCore.data;

            /* Skip atlases
             * 
            // Atlases
            if(masterSpriteData.atlases != null) {
                Sprite.Atlas[] atlases = masterSpriteCore.data.atlases;
                for(int i = 0; i < atlases.Length; i++) {
                    if(atlases[i] == null) continue;
                    if(atlases[i].textureMap == null) continue;
                    SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref absAssetPaths, new AssetData(AssetDatabase.GetAssetPath(atlases[i].textureMap),AssetData.AssetType.Atlas)); // add path
                }
            }
            */

            // Material Set source materials
            if(masterSpriteData.editorMaterialSets != null) {
                EditorMasterSprite.MaterialSet[] materialSets = masterSpriteData.editorMaterialSets;
                for(int i = 0; i < materialSets.Length; i++) {
                    if(materialSets[i] == null) continue;
                    if(materialSets[i].sourceMaterial == null) continue;
                    SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData,  new AssetData(AssetDatabase.GetAssetPath(materialSets[i].sourceMaterial), AssetData.AssetType.SourceMaterial)); // add path
                }
            }
                    
            // Source frame images
            string[] frameImageGUIDs = masterSpriteData.GetFrameTextureGUIDs();
            if(frameImageGUIDs != null) {
                for(int j = 0; j < frameImageGUIDs.Length; j++) {
                    if(frameImageGUIDs[j] == null) continue;
                    SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData,  new AssetData(AssetDatabase.GUIDToAssetPath(frameImageGUIDs[j]), AssetData.AssetType.SourceImage)); // add path
                }
            }

            return assetData;
        }

        // Sprite object methods

        internal void RenameMasterSpriteAndChildFiles(string oldName, ref string newName, int spriteIndex, int oldGroupId, int newGroupId, bool skipNameCheck = false) {
            // Rename the master sprite and all generated files
            
            string oldGroupName = GetSpriteGroupNameById(oldGroupId);
            string oldPrefix = SpriteEditor.GetSpriteChildFilePrefix(oldName, oldGroupName);
            string oldPrefixL = oldPrefix.ToLower();
            string newGroupName = GetSpriteGroupNameById(newGroupId);

            EditorMasterSprite sprite = LoadEditorMasterSprite(spriteIndex);
            SpriteSaveData spriteData = spriteSaveData[spriteIndex];
            SpriteGroup newSpriteGroup = null;
            if(newGroupId >= 0) newSpriteGroup = LoadSpriteGroup(FindSpriteGroupIndexBySpriteGroupId(newGroupId));

            if(sprite == null || spriteData == null) throw new System.Exception("Error! MasterSprite data could not be found!");

            // Make sure newName is safe
            if(!skipNameCheck) newName = FindNewSpriteName(newName, newGroupId, spriteIndex);
            if(newName == oldName && oldGroupId == newGroupId) return; // the sprite is just going to be renamed what it already is, don't rename all the files

            // Rename the Sprite
            spriteData.name = newName; // rename in data
            sprite.data.name = newName; // rename in the MasterSprite

            if(newGroupId == -1) { // not in a group, these files are stored per-sprite

                // Rename sprite atlas files
                string[] atlasFiles = sprite.atlasFiles;
                if(atlasFiles != null) {
                    for(int i = 0; i < atlasFiles.Length; i++) {
                        string newFileName = System.IO.Path.GetFileNameWithoutExtension(atlasFiles[i]); // get the atlas file name without the path or extension
                        if(newFileName.ToLower().StartsWith(oldPrefixL)) // strip off the group name so we have only the atlas name
                            newFileName = newFileName.Remove(0, oldPrefix.Length);
                        newFileName = SpriteEditor.GetAtlasFileNameOnly(newFileName, newName);
                        SpriteEditor.RenameFileRel(sprite.GetAtlasFilePath(i), Path.GetFileNameWithoutExtension(newFileName), true); // rename the atlas file
                        atlasFiles[i] = newFileName; // save the new file name in the master sprite
                    }
                }

                // Rename sprite material files
                MaterialSetFiles_Save[] materialSetFiles = sprite.materialSetFiles;
                if(materialSetFiles != null) {
                    for(int i = 0; i < materialSetFiles.Length; i++) {
                        string[] materialFiles = materialSetFiles[i].materialFileNames;
                        if(materialFiles != null) {
                            for(int j = 0; j < materialFiles.Length; j++) {
                                string newMaterialFileName = SpriteEditor.GetMaterialFileNameOnly(materialSetFiles[i].materialRootNames[j], newName, null);
                                SpriteEditor.RenameFileRel(materialSetFiles[i].GetMaterialFilePath(j), Path.GetFileNameWithoutExtension(newMaterialFileName), true); // rename the material file
                                materialFiles[j] = newMaterialFileName; // save the new file name in data
                            }
                        }
                    }
                }
            }
                    
            // Rename the child files
            RenameSpriteChildFiles(sprite, spriteData, newName, newGroupName, true, newSpriteGroup); // set dirty is inside function
            
            EditorUtility.SetDirty(this); // flag data for saving
        }

        private void RenameSpriteChildFiles(EditorMasterSprite sprite, SpriteSaveData spriteData, string newName, string newGroupName, bool dirtyCore, SpriteGroup spriteGroup = null) {
            // Outer function must set dirty

            // Rename master sprite files
            // editor master sprite
            string newEMSFileName = SpriteEditor.GetEditorMasterSpriteFileNameOnly(newName, newGroupName);
            SpriteEditor.RenameFileRel(spriteData.GetEditorMasterSpriteFilePath(), Path.GetFileNameWithoutExtension(newEMSFileName), true); // rename the ems file
            string newSpritePath = SpriteEditor.GetEditorMasterSpriteFilePath(newName, newGroupName);
            if(spriteGroup != null) {
                spriteGroup.ReplaceSprite(spriteData.editorMasterSpriteFileName, newEMSFileName); // replace the name in the sprite group object
                spriteGroup.SetDirtyForSave();
            }
            spriteData.editorMasterSpriteFileName = newEMSFileName; // save the file name in data

            // editor master sprite core
            string newSpriteCoreFileName = SpriteEditor.GetEditorMasterSpriteCoreFileNameOnly(newName, newGroupName);
            SpriteEditor.RenameFileRel(spriteData.GetEditorMasterSpriteCoreFilePath(), Path.GetFileNameWithoutExtension(newSpriteCoreFileName), true); // rename the ems core file
            sprite.coreFileName = newSpriteCoreFileName; // store link to core
            spriteData.editorMasterSpriteCoreFileName = newSpriteCoreFileName; // update core link in data

            // game master sprite
            string newGameSpriteFileName = SpriteEditor.GetGameMasterSpriteFileNameOnly(newName, newGroupName);
            SpriteEditor.RenameFileRel(spriteData.GetGameMasterSpriteFilePath(), Path.GetFileNameWithoutExtension(newGameSpriteFileName), true); // rename the gms file
            spriteData.gameMasterSpriteFileName = newGameSpriteFileName; // save the file name in data

            // Rename sprite editor mesh file
            string newMeshFileName = SpriteEditor.GetEditorMeshFileNameOnly(newName, newGroupName);
            SpriteEditor.RenameFileRel(sprite.GetEditorPreviewMeshFilePath(), Path.GetFileNameWithoutExtension(newMeshFileName), true);
            sprite.editorPreviewMeshFileName = newMeshFileName; // save in data

            // Rename sprite editor material
            string newMaterialName = SpriteEditor.GetEditorMaterialFileNameOnly(newName, newGroupName);
            SpriteEditor.RenameFileRel(sprite.GetEditorPreviewMaterialFilePath(), Path.GetFileNameWithoutExtension(newMaterialName), true);
            sprite.editorPreviewMaterialFileName = newMaterialName; // save in data

            sprite.SetDirtyForSave(dirtyCore); // flag for saving
        }

        private EditorMasterSprite LoadEditorMasterSprite(int spriteIndex, bool throwException = true) {
            return LoadEditorMasterSprite(spriteSaveData[spriteIndex].GetEditorMasterSpriteFilePath(), throwException);
        }

        private EditorMasterSprite LoadEditorMasterSprite(string path, bool throwException = true) {
            if(name == "" || name == null || name == string.Empty) return null;
            EditorMasterSprite masterSprite = SpriteEditor.LoadAssetAtPathRel<EditorMasterSprite>(path);
            if(masterSprite == null && throwException) throw new System.Exception("MasterSprite file is missing!");
            return masterSprite;
        }

        private EditorMasterSpriteCore LoadEditorMasterSpriteCore(int spriteIndex, bool throwException = true) {
            return LoadEditorMasterSpriteCore(spriteSaveData[spriteIndex].GetEditorMasterSpriteCoreFilePath(), throwException);
        }

        private EditorMasterSpriteCore LoadEditorMasterSpriteCore(string path, bool throwException = true) {
            if(name == "" || name == null || name == string.Empty) return null;
            EditorMasterSpriteCore masterSpriteCore = SpriteEditor.LoadAssetAtPathRel<EditorMasterSpriteCore>(path);
            if(masterSpriteCore == null && throwException) throw new System.Exception("MasterSpriteCore file is missing!");
            return masterSpriteCore;
        }

        internal string FindNewSpriteName(string spriteName, int groupId, int spriteIndex = -1) {
            if(!SpriteEditor.DirectoryExistsRel(SpriteEditor.editorMasterSpriteSavePath)) return spriteName; // save folder does not exist
            
            List<string> orphanedGroups = null;
            string groupName = GetSpriteGroupNameById(groupId); // returns null of ungrouped
            string fileNameNoExt = SpriteEditor.GetEditorMasterSpriteFilePrefix(groupName) + spriteName;
                
            // Check all sprites in data in this group
            string[] dbSpriteNames = GetSpriteNamesInGroup(groupId);
            
            // If this is a rename, this file should also exist in the directory and in the database
            // We don't want to disallow it to rename it to itself...
            string existingSpriteName = null;
            if(spriteIndex > -1) { // this sprite is already saved
                existingSpriteName = GetSpriteName(spriteIndex);
            }
            int existsAtDirIndex = -1;

            // Check all sprites in folder
            string fileNameRoot = SpriteFactory.Utils.StringTools.StripTrailingNumbers(fileNameNoExt); // get the sprite name without any extra numbers at the end
            string[] dirSpriteFiles = SpriteEditor.DirectoryGetFilesRel(SpriteEditor.editorMasterSpriteSavePath, string.Format("{0}*{1}", fileNameRoot, SpriteEditor.assetExtension), SearchOption.TopDirectoryOnly);
            // we are not going to worry about orphaned dependencies... if there are leftover core, atlases, materials, etc. after user manually deleted
            // a group asset, just overwrite them when needed.
            // Strip out paths, prefix, and extension and just get the sprite name
            for(int i = 0; i < dirSpriteFiles.Length; i++) {
                string dirSpriteName;
                bool found = FindEditorMasterSpriteNameInFilePath(dirSpriteFiles[i], out dirSpriteName, groupName);
                dirSpriteFiles[i] = dirSpriteName; // if the path doesn't contain a sprite object, the string will be null
                if(dirSpriteName == null) continue;
                if(existingSpriteName != null && dirSpriteName.ToLower() == existingSpriteName.ToLower()) existsAtDirIndex = i;
            }

            // Iterate until we get a name that is safe in both data file and folder
            string desiredName = spriteName;
            while(true) {
                desiredName = SpriteFactory.Utils.StringTools.VerifyName(desiredName, existsAtDirIndex, dirSpriteFiles); // get a safe name based on the files in the directory
                int index = SpriteFactory.Utils.ArrayTools.IndexOf<string>(dbSpriteNames, desiredName); // check if this filename is safe with the sprites in data
                if(index == -1 || index == spriteIndex) { // it was not in the data list, its safe to use, or it was the current sprite which we can save over safely
                    spriteName = desiredName; // this is our final filename
                    break;
                } else { // name is in use in the db list but the file is missing, this means the user deleted, renamed, or moved a sprite group file!
                    if(orphanedGroups == null) orphanedGroups = new List<string>();
                    orphanedGroups.Add(dbSpriteNames[index]);
                    desiredName = SpriteFactory.Utils.StringTools.IterateName(desiredName); // just add 1 to the name that failed and recheck
                }
            }

            // Report orphaned groups in the data file
            if(orphanedGroups != null) {
                for(int i = 0; i < orphanedGroups.Count; i++) {
                    Debug.LogWarning("Orphaned Sprite Group \"" + orphanedGroups[i] + "\" was found in the data file! A Sprite Group asset may have been deleted, moved, or renamed on disk. The editor data should be rebuilt.");
                }
            }

            return spriteName;
        }

        private bool FindEditorMasterSpriteNameInFilePath(string editorMasterSpriteFilePath, out string spriteName, string groupName = null) {
            spriteName = null;
            string name = Path.GetFileNameWithoutExtension(editorMasterSpriteFilePath); // get the file name without path or extension
            string prefix = SpriteEditor.GetEditorMasterSpriteFilePrefix(groupName);
            string suffix = SpriteEditor.editorMasterSpriteFileNameSuffix;

            // strip out the group and sprite prefix
            if(name.ToLower().StartsWith(prefix.ToLower())) name = name.Substring(prefix.Length);
            else return false; // invalid path

            // strip out the sprite suffix
            if(name.ToLower().EndsWith(suffix.ToLower())) name = name.Substring(0, name.Length - suffix.Length);
            else return false; // invalid path

            spriteName = name;
            return true;
        }

        #endregion

        #region Sprite Group Functions

        internal int GetSpriteCountInGroup(int groupId) {
            if(spriteSaveData == null || spriteSaveData.Count == 0) return 0; // no sprites

            int index = FindSpriteGroupIndexBySpriteGroupId(groupId);
            if(index >= 0 && index < spriteGroupSaveData.Count) // count in a group
                return spriteGroupSaveData[index].spriteCount;
            else { // ungrouped sprites
                if(ungroupedSpriteIds == null) return 0;
                return ungroupedSpriteIds.Count;
            }
        }

        internal string[] GetSpriteNamesInGroup(int groupId) {
            if(spriteSaveData == null || spriteSaveData.Count == 0) return null;

            int groupIndex = FindSpriteGroupIndexBySpriteGroupId(groupId);
            if(groupIndex >= 0 && groupIndex < spriteGroupSaveData.Count) { // get names in group
                if(spriteGroupSaveData == null || spriteGroupSaveData.Count == 0) return null;
                int[] spriteIds = spriteGroupSaveData[groupIndex].spriteIds;
                if(spriteIds == null || spriteIds.Length == 0) return null;
                
                string[] names = new string[spriteIds.Length];
                for(int i = 0; i < spriteIds.Length; i++) {
                    int spriteIndex = FindSpriteIndexBySpriteId(spriteIds[i]);
                    CheckSpriteIndex(spriteIndex);
                    names[i] = spriteSaveData[spriteIndex].name;
                }
                return names;
            } else { // ungrouped sprites
                if(ungroupedSpriteIds == null || ungroupedSpriteIds.Count == 0) return null;
                string[] names = new string[ungroupedSpriteIds.Count];
                for(int i = 0; i < ungroupedSpriteIds.Count; i++) {
                    int spriteIndex = FindSpriteIndexBySpriteId(ungroupedSpriteIds[i]);
                    CheckSpriteIndex(spriteIndex);
                    names[i] = spriteSaveData[spriteIndex].name;
                }
                return names;
            }
        }

        internal EditorMasterSprite.SpriteGroup GetWorkingSpriteGroupById(int groupId) {
            int index = FindSpriteGroupIndexBySpriteGroupId(groupId);
            return GetWorkingSpriteGroupByIndex(index);
        }

        internal EditorMasterSprite.SpriteGroup GetWorkingSpriteGroupByIndex(int groupIndex) {
            CheckSpriteGroupIndex(groupIndex);

            SpriteGroupSaveData data = spriteGroupSaveData[groupIndex];
            int[] spriteIds = null;
            if(data.spriteIds != null) spriteIds = (int[])data.spriteIds.Clone();
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            return new EditorMasterSprite.SpriteGroup(data.groupId, data.name, spriteIds, ConvertDataMaterialSetsToMasterSpriteMaterialSets(spriteGroup.materialSets), spriteGroup.useDefaultAtlasTextureFilterMode, spriteGroup.atlasTextureFilterMode, spriteGroup.atlasTextureAnisoLevel);
        }

        internal void SaveWorkingSpriteGroup(EditorMasterSprite.SpriteGroup spriteGroup) {
            SaveSpriteGroupData(spriteGroup.groupId, spriteGroup.name, spriteGroup.spriteIds, spriteGroup.editorMaterialSets, spriteGroup.atlasTextureFilterMode, spriteGroup.atlasTextureAnisoLevel);
        }

        internal int[] GetSpriteGroupIndices() {
            if(spriteGroupSaveData == null) return null;

            int[] indices = new int[spriteGroupSaveData.Count];
            for(int i = 0; i < spriteGroupSaveData.Count; i++) {
                indices[i] = i;
            }
            return indices;
        }

        internal string GetSpriteGroupName(int groupIndex) {
            if(groupIndex == -1) return null; // ungrouped
            CheckSpriteGroupIndex(groupIndex);
            return spriteGroupSaveData[groupIndex].name;
        }

        internal string GetSpriteGroupNameById(int groupId) {
            if(groupId == -1) return null; // ungrouped
            int groupIndex = FindSpriteGroupIndexBySpriteGroupId(groupId);
            return GetSpriteGroupName(groupIndex);
        }

        internal string[] GetSpriteGroupNames(bool appendSpriteCount = false, bool prependRebuildRequired = false) {
            if(spriteGroupSaveData == null) return null;

            string[] names = new string[spriteGroupSaveData.Count];
            for(int i = 0; i < spriteGroupSaveData.Count; i++) {
                names[i] = spriteGroupSaveData[i].name;
                if(prependRebuildRequired && spriteGroupSaveData[i].rebuildRequired) names[i] = "* " + names[i];
                if(appendSpriteCount) { // append sprite count to end of name
                    int spriteCount = 0;
                    if(spriteGroupSaveData[i].spriteIds != null) {
                        spriteCount = spriteGroupSaveData[i].spriteIds.Length;
                    }
                    names[i] += " (" + spriteCount + ")";
                }
            }
            return names;
        }

        internal string[] GetSpriteGroupAtlasFilePaths(int groupIndex) {
            CheckSpriteGroupIndex(groupIndex);
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            return spriteGroup.GetAtlasFilePaths();
        }

        internal string[] GetSpriteGroupMaterialFilePaths(int groupIndex) {
            CheckSpriteGroupIndex(groupIndex);

            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);

            // Get material files from sets
            MaterialSetFiles[] materialSetFiles = spriteGroup.GetWorkingMaterialSetFiles();
            if(materialSetFiles == null) return null;

            string[] fileNames = new string[0];
            for(int i = 0; i < materialSetFiles.Length; i++) {
                string[] groupMaterialFiles = materialSetFiles[i].materialFilePaths;
                if(groupMaterialFiles == null) continue;
                for(int j = 0; j < groupMaterialFiles.Length; j++) {
                    SpriteFactory.Utils.ArrayTools.Add<string>(ref fileNames, groupMaterialFiles[j]);
                }
            }
            return fileNames;
        }

        internal void GetSpriteGroupAtlasAndMaterialFilePaths(int groupIndex, out string[] atlasFiles, out string[] materialFiles) {
            CheckSpriteGroupIndex(groupIndex);
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);

            // Get atlas files
            atlasFiles = spriteGroup.GetAtlasFilePaths();

            // Get material files
            materialFiles = GetSpriteGroupMaterialFilePaths(groupIndex);
        }

        internal SpriteFactoryData.MaterialSetFiles[] GetSpriteGroupMaterialSetFiles(int groupIndex) {
            CheckSpriteGroupIndex(groupIndex);
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            return spriteGroup.GetWorkingMaterialSetFiles(); // returns copy
        }

        internal void ClearSpriteGroupAtlases(int groupIndex) {
            CheckSpriteGroupIndex(groupIndex);
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            spriteGroup.atlasFiles = null;
            spriteGroup.SetDirtyForSave(); // flag for saving
        }

        internal void ClearSpriteGroupMaterialFiles(int groupIndex) {
            CheckSpriteGroupIndex(groupIndex);
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            spriteGroup.ClearMaterialFiles();
            spriteGroup.SetDirtyForSave(); // flag for saving
        }

        internal int[] GetSpriteGroupSpriteIds(int groupIndex) {
            CheckSpriteGroupIndex(groupIndex);
            if(spriteGroupSaveData[groupIndex].spriteIds == null) return null;
            return (int[])spriteGroupSaveData[groupIndex].spriteIds.Clone();
        }

        internal int[] GetSpriteGroupSpriteIdsBySpriteGroupId(int groupId) {
            if(groupId == -1) {// ungrouped
                return GetUngroupedSpriteIds();
            } else {
                int index = FindSpriteGroupIndexBySpriteGroupId(groupId);
                return GetSpriteGroupSpriteIds(index);
            }
        }

        internal int GetSpriteGroupId(int groupIndex) {
            CheckSpriteGroupIndex(groupIndex);
            return spriteGroupSaveData[groupIndex].groupId;
        }

        internal int FindSpriteGroupIndexBySpriteGroupId(int id) {
            if(id < 0) return -1;
            for(int i = 0; i < spriteGroupSaveData.Count; i++) {
                if(spriteGroupSaveData[i].groupId == id) return i;
            }
            return -1;
        }

        internal int FindSpriteGroupIndexBySpriteIndex(int spriteIndex) {
            CheckSpriteIndex(spriteIndex);
            int groupId = spriteSaveData[spriteIndex].groupId;
            return FindSpriteGroupIndexBySpriteGroupId(groupId);
        }

        internal int CreateNewSpriteGroup(string name, Material defaultSpriteMaterial, FilterMode filterMode, int anisoLevel, int newIndex = -1, bool updateInDataFileOnly = false) {
            int groupIndex;
            if(newIndex <= -1) { // create new spriteGroup at end of list
                spriteGroupSaveData.Add(new SpriteGroupSaveData());
                groupIndex = spriteGroupSaveData.Count - 1;
            } else { // create new spriteGroup at specific index
                groupIndex = newIndex;
                spriteGroupSaveData.Insert(newIndex, new SpriteGroupSaveData());
            }
            int groupId = GetNewSpriteGroupId();
            spriteGroupSaveData[groupIndex].groupId = groupId; // save the spriteGroup id in the entry
            spriteGroupSaveData[groupIndex].name = name;

            if(updateInDataFileOnly) return groupIndex;

            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            spriteGroup.name = name;
            spriteGroup.materialSets = new MaterialSetSaveData[1] { new MaterialSetSaveData("Default", true, defaultSpriteMaterial) }; // create default material set
            spriteGroup.useDefaultAtlasTextureFilterMode = true;
            spriteGroup.atlasTextureFilterMode = filterMode; // save filter mode
            spriteGroup.atlasTextureAnisoLevel = anisoLevel;
            spriteGroup.SetDirtyForSave(); // flag for saving
            return groupIndex;
        }

        private int GetNewSpriteGroupId() {
            int num = _groupIdCounter;
            _groupIdCounter++; // increment for next time
            return num;
        }

        internal void SaveSpriteGroupData(int groupId, string name, int[] masterSpriteIds, EditorMasterSprite.MaterialSet[] materialSets, int atlasTextureFilterMode, int atlasTextureAnisoLevel) {
            int groupIndex = FindSpriteGroupIndexBySpriteGroupId(groupId);
            CheckSpriteGroupIndex(groupIndex);
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);

            // Save material sets
            if(materialSets == null) spriteGroup.materialSets = null;
            else {
                // Convert MasterSprite.MaterialSets to MaterialSetSaveDatas
                MaterialSetSaveData[] materialSetData = new MaterialSetSaveData[materialSets.Length];
                for(int i = 0; i < materialSets.Length; i++) {
                    materialSetData[i] = new MaterialSetSaveData(materialSets[i]);
                }
                spriteGroup.materialSets = materialSetData; // store
            }

            // Save the rest of the data
            SpriteGroupSaveData data = spriteGroupSaveData[groupIndex];

            // Check for group name change
            if(name != data.name) RenameSpriteGroupAndChildFiles(groupIndex, ref name); // file name changed, rename all assets

            // Copy the new data
            data.groupId = groupId;
            data.name = name; // save name in data
            if(masterSpriteIds == null) data.spriteIds = null;
            else data.spriteIds = (int[])masterSpriteIds.Clone();

            spriteGroup.name = name; // save name in group object also
            spriteGroup.useDefaultAtlasTextureFilterMode = atlasTextureFilterMode == -1 ? true : false; // set to default = -1, otherwise not default
            spriteGroup.atlasTextureFilterMode = spriteGroup.useDefaultAtlasTextureFilterMode ? FilterMode.Bilinear : (FilterMode)atlasTextureFilterMode; // if filter mode is set out of range, use bilinear, otherwise convert texture filter mode
            spriteGroup.atlasTextureAnisoLevel = atlasTextureAnisoLevel;
            spriteGroup.SetDirtyForSave(); // flag dirty

            // Does not save over atlases or material sets
        }

        internal void SaveSpriteGroupData_AtlasFiles(int groupIndex, string[] atlasFiles) {
            CheckSpriteGroupIndex(groupIndex);
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            spriteGroup.SetAtlasFiles(atlasFiles);
            spriteGroup.SetDirtyForSave(); // flag for saving
        }

        internal void SaveSpriteGroupData_MaterialSetFiles(int groupIndex, MaterialSetFiles[] materialSetFiles) {
            CheckSpriteGroupIndex(groupIndex);
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            if(materialSetFiles == null) spriteGroup.materialSetFiles = null;
            else {
                // copy the material set files and store
                SpriteFactoryData.MaterialSetFiles_Save[] newSetFiles = new SpriteFactoryData.MaterialSetFiles_Save[materialSetFiles.Length];
                for(int i = 0; i < materialSetFiles.Length; i++) {
                    newSetFiles[i] = new MaterialSetFiles_Save(materialSetFiles[i]);
                }
                spriteGroup.materialSetFiles = newSetFiles;
            }
            spriteGroup.SetDirtyForSave(); // flag for saving
        }

        internal void DeleteSpriteGroup(int groupIndex) {
            CheckSpriteGroupIndex(groupIndex);
            spriteGroupSaveData.RemoveAt(groupIndex);
        }

        internal bool ReorderSpriteGroup(int groupIndex, int offset, bool reorderNow) {
            CheckSpriteGroupIndex(groupIndex);
            if(offset == 0) return false;
            if(groupIndex == spriteGroupSaveData.Count - 1 && offset > 0) return false; // at end of list trying to move down
            if(groupIndex == 0 && offset < 0) return false; // at beginning of list trying to move up
            if(!reorderNow) return true; // just testing to see if we can reorder, passed

            // Does not handle offsets other than +/- 1
            if(offset > 1) offset = 1;
            if(offset < -1) offset = -1;

            SpriteGroupSaveData entry = spriteGroupSaveData[groupIndex]; // get the entry
            spriteGroupSaveData.RemoveAt(groupIndex); // remove entry first

            if(offset > 0) {
                //offset += 1; // account for insert pushing the entry down
                if(groupIndex + offset >= spriteGroupSaveData.Count) { // would be at the end of the list
                    spriteGroupSaveData.Add(entry); // add to end of the list
                    return true;
                }
            }
            spriteGroupSaveData.Insert(groupIndex + offset, entry); // insert the entry back
            return true;
        }

        private void CheckSpriteGroupIndex(int groupIndex) {
            if(groupIndex < 0 || groupIndex >= spriteGroupSaveData.Count) throw new System.Exception("Invalid spriteGroup index!");
        }

        internal bool IsSpriteGroupDataSaved() {
            if(spriteGroupSaveData.Count > 0) return true;
            return false;
        }

        internal int ChangeSpriteGroup(EditorMasterSprite.Data masterSpriteDataWorking, int oldGroupId, int newGroupId, int spriteId) {
            if(oldGroupId < 0 || newGroupId < 0) return -1;

            int oldGroupIndex = FindSpriteGroupIndexBySpriteGroupId(oldGroupId);
            int newGroupIndex = FindSpriteGroupIndexBySpriteGroupId(newGroupId);
            CheckSpriteGroupIndex(oldGroupIndex);
            CheckSpriteGroupIndex(newGroupIndex);
            
            int spriteIndex = FindSpriteIndexBySpriteId(spriteId);
            CheckSpriteIndex(spriteIndex);

            SpriteGroup oldSpriteGroup = LoadSpriteGroup(oldGroupIndex); // load old group object
            int spriteFileIndexInOldGroup = oldSpriteGroup.IndexOfSprite(GetEditorSpriteFileName(spriteIndex)); // get the index of the sprite file before we do any renaming

            // Rename the sprite and its assets before actually moving into the new group
            string oldSpriteName = GetSpriteName(spriteIndex); // the actual old saved name, not the incoming possibly different name
            string newSpriteName = FindNewSpriteName(masterSpriteDataWorking.name, newGroupId, -1); // Get a new safe name before moving this into the group
            masterSpriteDataWorking.name = newSpriteName; // rename in working data so when we save it doesn't get the old version
            RenameMasterSpriteAndChildFiles(oldSpriteName, ref newSpriteName, spriteIndex, oldGroupId, newGroupId, true); // rename sprite and all assets on disk

            // Remove from old group
            spriteGroupSaveData[oldGroupIndex].RemoveSprite(spriteId); // remove from data
            oldSpriteGroup.RemoveSpriteAt(spriteFileIndexInOldGroup); // remove from old group object
            oldSpriteGroup.SetDirtyForSave();
            
            // Add to new group
            spriteSaveData[spriteIndex].groupId = newGroupId; // save sprite group id in sprite entry in data
            spriteGroupSaveData[newGroupIndex].AddSprite(spriteId); // add to new group in data
            SpriteGroup newSpriteGroup = LoadSpriteGroup(newGroupIndex); // load new group object
            int index = newSpriteGroup.AddSprite(GetEditorSpriteFileName(spriteIndex)); // add to new group object
            newSpriteGroup.SetDirtyForSave();
            return index;
        }

        internal int AddSpriteToSpriteGroup(EditorMasterSprite.Data masterSpriteDataWorking, int newGroupId, int spriteId) {
            int groupIndex = FindSpriteGroupIndexBySpriteGroupId(newGroupId);
            CheckSpriteGroupIndex(groupIndex);
            int spriteIndex = FindSpriteIndexBySpriteId(spriteId);
            CheckSpriteIndex(spriteIndex);

            // Rename the sprite and its assets before actually moving into the new group
            string oldSpriteName = GetSpriteName(spriteIndex); // the actual old saved name, not the incoming possibly different name
            string newSpriteName = FindNewSpriteName(masterSpriteDataWorking.name, newGroupId, -1); // Get a new safe name before moving this into the group
            masterSpriteDataWorking.name = newSpriteName; // rename in working data so when we save it doesn't get the old version
            RenameMasterSpriteAndChildFiles(oldSpriteName, ref newSpriteName, spriteIndex, -1, newGroupId, true); // rename sprite and all assets on disk

            spriteSaveData[spriteIndex].groupId = newGroupId; // save sprite group id in sprite entry
            RemoveSpriteIdFromUngroupedList(spriteId);
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            spriteGroup.AddSprite(GetEditorSpriteFileName(spriteIndex));
            spriteGroup.SetDirtyForSave();
            int index = spriteGroupSaveData[groupIndex].AddSprite(spriteId);
            return index;
        }

        internal void RemoveSpriteFromSpriteGroup(EditorMasterSprite.Data masterSpriteDataWorking, int oldGroupId, int spriteId, bool addToUngroupedList = true) {
            int groupIndex = FindSpriteGroupIndexBySpriteGroupId(oldGroupId);
            CheckSpriteGroupIndex(groupIndex);
            int spriteIndex = FindSpriteIndexBySpriteId(spriteId);
            CheckSpriteIndex(spriteIndex);

            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            int spriteFileIndexInGroup = spriteGroup.IndexOfSprite(GetEditorSpriteFileName(spriteIndex)); // get the index of the sprite file before we do any renaming

            // Rename the sprite and its assets before actually moving into the new group
            string oldSpriteName = GetSpriteName(spriteIndex); // the actual old saved name, not the incoming possibly different name
            string newSpriteName = FindNewSpriteName(masterSpriteDataWorking.name, -1, -1); // Get a new safe name before moving this into the ungrouped set
            masterSpriteDataWorking.name = newSpriteName; // rename in working data so when we save it doesn't get the old version
            RenameMasterSpriteAndChildFiles(oldSpriteName, ref newSpriteName, spriteIndex, oldGroupId, -1, true); // rename sprite and all assets on disk
            
            spriteSaveData[spriteIndex].groupId = -1; // save sprite group id in sprite entry, no longer in a group
            if(addToUngroupedList) ungroupedSpriteIds.Add(spriteId); // add sprite to ungrouped list
            spriteGroupSaveData[groupIndex].RemoveSprite(spriteId); // remove from group in db
            if(spriteFileIndexInGroup >= 0) spriteGroup.RemoveSpriteAt(spriteFileIndexInGroup); // remove sprite from group object
            spriteGroup.SetDirtyForSave();
        }

        internal void DeleteSpriteFromSpriteGroup(int oldGroupId, int spriteId) {
            int groupIndex = FindSpriteGroupIndexBySpriteGroupId(oldGroupId);
            CheckSpriteGroupIndex(groupIndex);
            int spriteIndex = FindSpriteIndexBySpriteId(spriteId);
            CheckSpriteIndex(spriteIndex);
            
            spriteGroupSaveData[groupIndex].RemoveSprite(spriteId); // remove from group in db
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            spriteGroup.RemoveSprite(GetEditorSpriteFileName(spriteIndex)); // remove sprite from group object
            spriteGroup.SetDirtyForSave();
        }

        internal bool IsSpriteGroupNameInDataList(string name) {
            if(spriteGroupSaveData == null) return false;

            for(int i = 0; i < spriteGroupSaveData.Count; i++) {
                if(name == spriteGroupSaveData[i].name) return true;
            }
            return false;
        }

        internal AssetData[] GetSpriteGroupExportAssets(int groupIndex) {
            CheckSpriteGroupIndex(groupIndex);

            SpriteGroupSaveData data = spriteGroupSaveData[groupIndex];
            if(data.spriteIds == null || data.spriteIds.Length == 0) return null; // no sprites in this group

            // Load the sprite group object
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex, false);
            if(spriteGroup == null) return null;

            AssetData[] assetData = null;
            SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData, new AssetData(SpriteEditor.RelToAbsPath(SpriteEditor.GetSpriteGroupFilePath(GetSpriteGroupName(groupIndex))), AssetData.AssetType.SpriteGroup)); // add the sprite group object
            SpriteFactory.Utils.ArrayTools.Combine<AssetData>(ref assetData, spriteGroup.GetExportAssetData()); // get asset files from group

            // Master sprites
            string[] masterSpriteFiles = spriteGroup.masterSpriteFiles;
            if(masterSpriteFiles != null) {
                for(int i = 0; i < masterSpriteFiles.Length; i++) {
                    AssetData[] spriteAssets = GetSpriteExportAssets(masterSpriteFiles[i], spriteGroup.name); // get the assets from the sprite
                    if(spriteAssets == null || spriteAssets.Length == 0) continue; // sprite failed check, do not export
                    SpriteFactory.Utils.ArrayTools.Combine<AssetData>(ref assetData, spriteAssets); // add the sprite assets to the list
                }
            }

            return assetData;
        }

        // Sprite Group object methods

        private void RenameSpriteGroupAndChildFiles(int groupIndex, ref string newGroupName) {
            CheckSpriteGroupIndex(groupIndex);

            SpriteGroupSaveData groupData = spriteGroupSaveData[groupIndex];
            SpriteGroup spriteGroup = LoadSpriteGroup(groupIndex);
            if(groupData == null || spriteGroup == null) throw new System.Exception("Error! SpriteGroup data could not be found!");

            if(newGroupName == groupData.name && newGroupName == spriteGroup.name) return; // name is already the same, nothing to do

            // Make sure newName is safe
            newGroupName = FindNewGroupName(newGroupName, groupIndex);
            if(newGroupName == groupData.name) return; // the group is just going to be renamed what it already is, don't rename all the files

            string oldGroupName = groupData.name; // store old name
            string oldPrefix = SpriteEditor.GetSpriteGroupChildFilePrefix(oldGroupName);
            string oldPrefixL = oldPrefix.ToLower();

            // Rename the group
            groupData.name = newGroupName; // rename in data
            spriteGroup.name = newGroupName; // rename in the object

            // Rename the group object files
            SpriteEditor.RenameFileRel(SpriteEditor.GetSpriteGroupFilePath(oldGroupName), Path.GetFileNameWithoutExtension(SpriteEditor.GetSpriteGroupFileNameOnly(newGroupName)), true); // rename the group object

            // Rename group atlas files
            string[] atlasFiles = spriteGroup.atlasFiles;
            if(atlasFiles != null) {
                for(int i = 0; i < atlasFiles.Length; i++) {
                    string newFileName = System.IO.Path.GetFileNameWithoutExtension(atlasFiles[i]); // get the atlas file name without the path or extension
                    if(newFileName.ToLower().StartsWith(oldPrefixL)) // strip off the group name so we have only the atlas name
                        newFileName = newFileName.Remove(0, oldPrefix.Length);
                    string newAtlasFileName = SpriteEditor.GetAtlasFileNameOnly(newFileName, null, newGroupName);
                    SpriteEditor.RenameFileRel(spriteGroup.GetAtlasFilePath(i), Path.GetFileNameWithoutExtension(newAtlasFileName), true); // rename the atlas file
                    atlasFiles[i] = newAtlasFileName; // save the new file name in data
                }
            }

            // Rename group material files
            MaterialSetFiles_Save[] materialSetFiles = spriteGroup.materialSetFiles;
            if(materialSetFiles != null) {
                for(int i = 0; i < materialSetFiles.Length; i++) {
                    string[] materialFiles = materialSetFiles[i].materialFileNames;
                    if(materialFiles != null) {
                        for(int j = 0; j < materialFiles.Length; j++) {
                            string newMaterialSetFileName = SpriteEditor.GetMaterialFileNameOnly(materialSetFiles[i].materialRootNames[j], null, newGroupName);
                            SpriteEditor.RenameFileRel(materialSetFiles[i].GetMaterialFilePath(j), Path.GetFileNameWithoutExtension(newMaterialSetFileName), true); // rename the material file
                            materialFiles[j] = newMaterialSetFileName; // save the new file name in data
                        }
                    }
                }
            }

            // For each sprite in group
            if(groupData.spriteIds != null) {
                for(int i = 0; i < groupData.spriteIds.Length; i++) {
                    int spriteId = groupData.spriteIds[i];
                    int spriteIndex = FindSpriteIndexBySpriteId(spriteId);
                    if(spriteIndex < 0) continue; // not found
                    SpriteSaveData spriteData = spriteSaveData[spriteIndex];
                    EditorMasterSprite sprite = LoadEditorMasterSprite(spriteIndex);

                    if(spriteData == null || sprite == null) {
                        Debug.LogError("MasterSprite data is missing!");
                        continue;
                    }
                    
                    // Rename master sprite files
                    RenameSpriteChildFiles(sprite, spriteData, spriteData.name, newGroupName, false, spriteGroup); // flag for saving inside function, no dirty core since we didnt't set anything in it
                }
            }

            EditorUtility.SetDirty(this);
            spriteGroup.SetDirtyForSave(); // flag group for saving
        }

        private SpriteGroup LoadSpriteGroup(int groupIndex, bool throwException = true) {
            if(groupIndex == -1) return null; // ungrouped
            CheckSpriteGroupIndex(groupIndex);
            return LoadSpriteGroup(GetSpriteGroupName(groupIndex), throwException);
        }

        private SpriteGroup LoadSpriteGroup(string name, bool throwException = true) {
            if(name == "" || name == null || name == string.Empty) return null;
            SpriteGroup spriteGroup = SpriteEditor.LoadAssetAtPathRel<SpriteGroup>(SpriteEditor.GetSpriteGroupFilePath(name));
            if(spriteGroup == null && throwException) throw new System.Exception("SpriteGroup file is missing!");
            return spriteGroup;
        }

        internal string FindNewGroupName(string groupName, int groupIndex = -1) {
            if(!SpriteEditor.DirectoryExistsRel(SpriteEditor.spriteGroupSavePath)) return groupName; // save folder does not exist
            List<string> orphanedGroups = null;
                
            // Check all groups in data
            string[] dbGroupNames = GetSpriteGroupNames();

            // If this is a rename, this file should also exist in the directory and in the database
            // We don't want to disallow it to rename it to itself...
            string existingGroupName = null;
            if(groupIndex > -1) { // this sprite is already saved
                existingGroupName = GetSpriteGroupName(groupIndex);
            }
            int existsAtDirIndex = -1;
                
            // Check all groups in folder
            string[] dirGroupFiles = SpriteEditor.DirectoryGetFilesRel(SpriteEditor.spriteGroupSavePath, string.Format("*{0}{1}", SpriteEditor.spriteGroupFileNameSuffix, SpriteEditor.assetExtension), SearchOption.TopDirectoryOnly);
            // we are not going to worry about orphaned dependencies... if there are leftover core, atlases, materials, etc. after user manually deleted
            // a group asset, just overwrite them when needed.
            // Strip out paths, prefix, suffix, and extension and just get the group name
            for(int i = 0; i < dirGroupFiles.Length; i++) {
                string dirGroupName;
                bool found = FindSpriteGroupNameInFilePath(dirGroupFiles[i], out dirGroupName);
                dirGroupFiles[i] = dirGroupName; // if the path doesn't contain a group object, the string will be null
                if(existingGroupName != null && dirGroupName.ToLower() == existingGroupName.ToLower()) existsAtDirIndex = i;
            }

            // Iterate until we get a name that is safe in both data file and folder
            string desiredName = groupName;
            while(true) {
                desiredName = SpriteFactory.Utils.StringTools.VerifyName(desiredName, existsAtDirIndex, dirGroupFiles); // get a safe name based on the files in the directory
                // check if this filename is safe with the groups in the list to account for leftover groups in the list
                int index = SpriteFactory.Utils.ArrayTools.IndexOf<string>(dbGroupNames, desiredName);
                if(index == -1 || index == groupIndex) { // it was not in the data list, its safe to use, or it was the current group which we can save over safely
                    groupName = desiredName; // this is our final filename
                    break;
                } else { // name is in use in the db list but the file is missing, this means the user deleted, renamed, or moved a sprite group file!
                    if(orphanedGroups == null) orphanedGroups = new List<string>();
                    orphanedGroups.Add(dbGroupNames[index]);
                    desiredName = SpriteFactory.Utils.StringTools.IterateName(desiredName); // just add 1 to the name that failed and recheck
                }
            }

            // Report orphaned groups in the data file
            if(orphanedGroups != null) {
                for(int i = 0; i < orphanedGroups.Count; i++) {
                    Debug.LogWarning("Orphaned Sprite Group \"" + orphanedGroups[i] + "\" was found in the data file! A Sprite Group asset may have been deleted, moved, or renamed on disk. The editor data should be rebuilt.");
                }
            }

            return groupName;
        }

        private bool FindSpriteGroupNameInFilePath(string groupFilePath, out string groupName) {
            groupName = null;
            string name = Path.GetFileNameWithoutExtension(groupFilePath); // get the file name without path or extension
            string prefix = SpriteEditor.spriteGroupFileNamePrefix;
            string suffix = SpriteEditor.spriteGroupFileNameSuffix;

            // strip out the group prefix
            if(name.ToLower().StartsWith(prefix.ToLower())) name = name.Substring(prefix.Length);
            else return false; // invalid path

            // strip out the group suffix
            if(name.ToLower().EndsWith(suffix.ToLower())) name = name.Substring(0, name.Length - suffix.Length);
            else return false; // invalid path

            groupName = name;
            return true;
        }

        #endregion

        #region Misc

        internal int[] GetUngroupedSpriteIds() {
            if(ungroupedSpriteIds == null || ungroupedSpriteIds.Count == 0) return null;
            int[] ids = new int[ungroupedSpriteIds.Count];
            for(int i = 0; i < ungroupedSpriteIds.Count; i++)
                ids[i] = ungroupedSpriteIds[i];
            return ids;
        }

        private void RemoveSpriteIdFromUngroupedList(int spriteId) {
            if(ungroupedSpriteIds == null || ungroupedSpriteIds.Count == 0) return;
            ungroupedSpriteIds.Remove(spriteId); // remove sprite from ungrouped list
        }

        private EditorMasterSprite.MaterialSet[] ConvertDataMaterialSetsToMasterSpriteMaterialSets(MaterialSetSaveData[] inDataMaterialSets) {
            if(inDataMaterialSets == null) return null;
            EditorMasterSprite.MaterialSet[] newSets = new EditorMasterSprite.MaterialSet[inDataMaterialSets.Length];
            for(int i = 0; i < inDataMaterialSets.Length; i++) {
                newSets[i] = inDataMaterialSets[i].ConvertToMasterSpriteMaterialSet();
            }
            return newSets;
        }

        private SpriteFactoryData.MaterialSetSaveData[] ConvertMasterSpriteMaterialSetsToDataMaterialSets(EditorMasterSprite.MaterialSet[] inMaterialSets) {
            if(inMaterialSets == null) return null;
            SpriteFactoryData.MaterialSetSaveData[] newSets = new SpriteFactoryData.MaterialSetSaveData[inMaterialSets.Length];
            for(int i = 0; i < inMaterialSets.Length; i++) {
                newSets[i] = new SpriteFactoryData.MaterialSetSaveData(inMaterialSets[i]);
            }
            return newSets;
        }

        internal void ClearAll() {
            spriteSaveData = new List<SpriteSaveData>();
            _spriteIdCounter = 0;
            spriteGroupSaveData = new List<SpriteGroupSaveData>();
            _groupIdCounter = 0;
            ungroupedSpriteIds = new List<int>();
        }

        #endregion

        #region Upgrade

        public void UpgradeData(Material defaultSpriteMaterial) {
            if(settings != null && settings.defaultMaterialGUID == null || settings.defaultMaterialGUID == string.Empty) {
                settings.defaultMaterialGUID = Utils.AssetTools.GetGUID(defaultSpriteMaterial);
                EditorUtility.SetDirty(settings);
                AssetDatabase.SaveAssets();
            }

            UpgradeSprites();
            UpgradeSpriteGroups();
        }

        private void UpgradeSprites() {
            if(spriteSaveData == null || spriteSaveData.Count == 0) return;

            bool mustSave = false;

            for(int i = 0; i < spriteSaveData.Count; i++) {
                int spriteIndex = i;
                SpriteSaveData data = spriteSaveData[i];
                if(data == null) continue;
                EditorMasterSpriteCore emsCore = LoadEditorMasterSpriteCore(spriteIndex);
                if(emsCore == null) continue;
                bool changed = emsCore.data.UpgradeCheck(settings);
                if(changed) {
                    EditorUtility.SetDirty(emsCore);
                    mustSave = true;
                }
            }

            if(mustSave) AssetDatabase.SaveAssets();
        }

        private void UpgradeSpriteGroups() {
            if(spriteGroupSaveData == null || spriteGroupSaveData.Count == 0) return;

            bool mustSave = false;

            for(int i = 0; i < spriteGroupSaveData.Count; i++) {
                int groupIndex = i;
                SpriteGroupSaveData data = spriteGroupSaveData[i];
                if(data == null) continue;
                SpriteGroup group = LoadSpriteGroup(groupIndex);
                if(group == null) continue;
                bool changed = group.UpgradeCheck(settings);
                if(changed) {
                    EditorUtility.SetDirty(group);
                    mustSave = true;
                }
            }

            if(mustSave) AssetDatabase.SaveAssets();
        }

        #endregion

        #region // PRIVATE CLASSES //////////////////////////////

        [System.Serializable]
        private class SpriteSaveData {
            public string name; // used to find files
            public int spriteId;
            public int groupId = -1;
            public string editorMasterSpriteFileName; // the master sprite with editor data in a prefab on disk
            public string editorMasterSpriteCoreFileName; // ems core file
            public string gameMasterSpriteFileName; // the master sprite with game data in a prefab on disk
            public bool rebuildRequired;

            public string GetEditorMasterSpriteFilePath() {
                return SpriteEditor.AddEditorMasterSpriteFilePath(editorMasterSpriteFileName);
            }

            public string GetEditorMasterSpriteCoreFilePath() {
                return SpriteEditor.AddEditorMasterSpriteCoreFilePath(editorMasterSpriteCoreFileName);
            }

            public string GetGameMasterSpriteFilePath() {
                return SpriteEditor.AddGameMasterSpriteFilePath(gameMasterSpriteFileName);
            }
        }

        [System.Serializable]
        private class SpriteGroupSaveData {
            public string name; // used to find files
            public int groupId;
            public int[] spriteIds;
            public bool rebuildRequired;

            public int spriteCount {
                get {
                    if(spriteIds == null) return 0;
                    return spriteIds.Length;
                }
            }

            public int AddSprite(int spriteId) {
                int index = SpriteFactory.Utils.ArrayTools.IndexOf<int>(spriteIds, spriteId);
                if(index >= 0) return index; // sprite is already in the list
                return SpriteFactory.Utils.ArrayTools.Add<int>(ref spriteIds, spriteId); // add the entry
            }

            public void RemoveSprite(int spriteId) {
                if(spriteIds == null || spriteIds.Length == 0) return;
                int index = SpriteFactory.Utils.ArrayTools.IndexOf<int>(spriteIds, spriteId);
                if(index == -1) return; // sprite is not in the list
                SpriteFactory.Utils.ArrayTools.RemoveAt<int>(ref spriteIds, index); // remove the entry
            }

            public void RemoveSpriteAt(int index) {
                if(spriteIds == null || spriteIds.Length == 0) return;
                SpriteFactory.Utils.ArrayTools.RemoveAt<int>(ref spriteIds, index); // remove the entry
            }

            public void InsertSprite(int newIndex, int spriteId) {
                SpriteFactory.Utils.ArrayTools.Insert<int>(ref spriteIds, newIndex, spriteId);
            }
        }

        #endregion

        #region // PUBLIC CLASSES /////////////////////////////////////////////////////////////////

        [System.Serializable]
        public class MaterialSetSaveData {
            // used in the editor
            public string name;
            public bool useDefaultMaterial;
            public Material sourceMaterial;

            public MaterialSetSaveData(string name, bool useDefaultMaterial, Material sourceMaterial) {
                this.name = name;
                this.useDefaultMaterial = useDefaultMaterial;
                this.sourceMaterial = sourceMaterial;
            }

            public MaterialSetSaveData(MaterialSetSaveData materialSet) : this(materialSet.name, materialSet.useDefaultMaterial, materialSet.sourceMaterial) { }

            public MaterialSetSaveData(EditorMasterSprite.MaterialSet materialSet) : this(materialSet.name, materialSet.useDefaultMaterial, materialSet.sourceMaterial) { } // convert an editor material set to a save material set


            public EditorMasterSprite.MaterialSet ConvertToMasterSpriteMaterialSet() {
                EditorMasterSprite.MaterialSet newSet = new EditorMasterSprite.MaterialSet(name, useDefaultMaterial, sourceMaterial);
                return newSet;
            }

            public MaterialSetSaveData DeepCopy() {
                return new MaterialSetSaveData(this);
            }
        }

        [System.Serializable]
        public class MaterialSetFiles {
            public string[] materialFilePaths; // 1 file per atlas corresponding to atlas index of sprite/group
            public string[] materialRootNames; // the name of each material for use in creating the filename. includes Material_Atlas##, but no extension or sprite/group prefix

            public MaterialSetFiles(string[] materialFilePaths, string[] materialRootNames) {
                if(materialFilePaths == null) this.materialFilePaths = null;
                else this.materialFilePaths = (string[])materialFilePaths.Clone();

                if(materialRootNames == null) this.materialRootNames = null;
                else this.materialRootNames = (string[])materialRootNames.Clone();
            }

            public MaterialSetFiles(MaterialSetFiles materialSetFiles)
                : this(materialSetFiles.materialFilePaths, materialSetFiles.materialRootNames) { // clone
            }

            public MaterialSetFiles(MaterialSetFiles_Save materialSetFiles) { // convert save type to working type
                if(materialSetFiles.materialRootNames == null) this.materialRootNames = null;
                else this.materialRootNames = (string[])materialSetFiles.materialRootNames.Clone();
                
                if(materialSetFiles.materialFileNames == null) materialFilePaths = null;
                else {
                    string[] incomingMaterialFileNames = materialSetFiles.materialFileNames;
                    int count = incomingMaterialFileNames.Length;
                    materialFilePaths = new string[count];
                    for(int i = 0; i < count; i++) {
                        materialFilePaths[i] = SpriteEditor.AddMaterialFilePath(incomingMaterialFileNames[i]); // turn the filename into a path
                    }
                }
            }

            public MaterialSetFiles DeepCopy() {
                return new MaterialSetFiles(this);
            }

        }

        [System.Serializable]
        public class MaterialSetFiles_Save {
            public string[] materialFileNames; // 1 file per atlas corresponding to atlas index of sprite/group
            public string[] materialRootNames; // the name of each material for use in creating the filename. includes Material_Atlas##, but no extension or sprite/group prefix

            public MaterialSetFiles_Save(string[] materialFileNames, string[] materialRootNames) {
                if(materialFileNames == null) this.materialFileNames = null;
                else this.materialFileNames = (string[])materialFileNames.Clone();

                if(materialRootNames == null) this.materialRootNames = null;
                else this.materialRootNames = (string[])materialRootNames.Clone();
            }

            public MaterialSetFiles_Save(MaterialSetFiles materialSetFiles) { // convert working type to save type
                if(materialSetFiles.materialRootNames == null) this.materialRootNames = null;
                else this.materialRootNames = (string[])materialSetFiles.materialRootNames.Clone();
                
                if(materialSetFiles.materialFilePaths == null) materialFileNames = null;
                else {
                    string[] incomingMaterialFilePaths = materialSetFiles.materialFilePaths;
                    int count = incomingMaterialFilePaths.Length;
                    materialFileNames = new string[count];
                    for(int i = 0; i < count; i++) {
                        materialFileNames[i] = Path.GetFileName(incomingMaterialFilePaths[i]); // just get the file name of the material stripping path
                    }
                }
            }

            public string[] GetMaterialFilePaths() {
                if(materialFileNames == null) return null;
                string[] paths = new string[materialFileNames.Length];
                for(int i = 0; i < materialFileNames.Length; i++) {
                    paths[i] = SpriteEditor.AddMaterialFilePath(materialFileNames[i]);
                }
                return paths;
            }

            public string GetMaterialFilePath(int index) {
                if(materialFileNames == null || index < 0 || index >= materialFileNames.Length) throw new System.Exception("Invalid index!");
                return SpriteEditor.AddMaterialFilePath(materialFileNames[index]);
            }
        }

        #endregion
    }
}