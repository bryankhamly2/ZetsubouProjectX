﻿using UnityEditor;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using SpriteFactory;
using SpriteFactory.Editor.DataClasses;
using Sprite = SpriteFactory.Sprite;
using Settings = SpriteFactory.Settings;

namespace SpriteFactory.Editor {

    public class SpriteGroup : ScriptableObject {
        // Group Settings
        new public string name;
        public bool useDefaultAtlasTextureFilterMode;
        public FilterMode atlasTextureFilterMode;
        public int atlasTextureAnisoLevel = -1; // set to default
        
        public string[] masterSpriteFiles;
        public string[] atlasFiles;
        public SpriteFactoryData.MaterialSetFiles_Save[] materialSetFiles;
        
        public SpriteFactoryData.MaterialSetSaveData[] materialSets;
        
        public int spriteCount {
            get {
                if(masterSpriteFiles == null) return 0;
                return masterSpriteFiles.Length;
            }
        }

        // Public methods
        public string GetSprite(int index) {
            if(index < 0 || index >= masterSpriteFiles.Length) throw new System.Exception("Invalid index!");
            return masterSpriteFiles[index];
        }

        public int IndexOfSprite(string fileName) {
            if(masterSpriteFiles == null) return -1;
            for(int i = 0; i < masterSpriteFiles.Length; i++) {
                if(masterSpriteFiles[i] == fileName) return i;
            }
            return -1;
        }

        public bool ReplaceSprite(string oldFileName, string newFileName) {
            int index = IndexOfSprite(oldFileName);
            if(index == -1) return false;
            masterSpriteFiles[index] = newFileName;
            return true;
        }

        public int AddSprite(string fileName) {
            return SpriteFactory.Utils.ArrayTools.Add(ref masterSpriteFiles, fileName);
        }

        public bool RemoveSprite(string fileName) {
            if(masterSpriteFiles == null) return false;
            for(int i = 0; i < masterSpriteFiles.Length; i++) {
                if(masterSpriteFiles[i] == fileName) {
                    return SpriteFactory.Utils.ArrayTools.RemoveAt(ref masterSpriteFiles, i);
                }
            }
            return false;
        }

        public bool RemoveSpriteAt(int index) {
            return SpriteFactory.Utils.ArrayTools.RemoveAt(ref masterSpriteFiles, index);
        }

        public int InsertSprite(int newIndex, string fileName) {
            return SpriteFactory.Utils.ArrayTools.Insert(ref masterSpriteFiles, newIndex, fileName);
        }

        public string GetAtlasFilePath(int index) {
            if(atlasFiles == null || index < 0 || index >= atlasFiles.Length) throw new System.Exception("Invalid index!");
            return SpriteEditor.AddAtlasFilePath(atlasFiles[index]);
        }

        public string[] GetAtlasFilePaths() {
            if(atlasFiles == null) return null;
            string[] paths = new string[atlasFiles.Length];
            for(int i = 0; i < atlasFiles.Length; i++) {
                paths[i] = SpriteEditor.AddAtlasFilePath(atlasFiles[i]);
            }
            return paths;
        }

        public void SetAtlasFiles(string[] atlasFilePaths) {
            if(atlasFilePaths == null) {
                atlasFiles = null;
                return;
            }

            // Get file names from full paths and store
            string[] fileNames = new string[atlasFilePaths.Length];
            for(int i = 0; i < atlasFilePaths.Length; i++) {
                fileNames[i] = System.IO.Path.GetFileName(atlasFilePaths[i]);
            }
            atlasFiles = fileNames;
        }

        public SpriteFactoryData.MaterialSetFiles[] GetWorkingMaterialSetFiles() {
            if(materialSetFiles == null) return null;
            
            int count = materialSetFiles.Length;
            SpriteFactoryData.MaterialSetFiles[] workingFiles = new SpriteFactoryData.MaterialSetFiles[count];
            for(int i = 0; i < count; i++) {
                workingFiles[i] = new SpriteFactoryData.MaterialSetFiles(materialSetFiles[i]); // convert
            }
            return workingFiles;
        }

        public void SetDirtyForSave() {
            EditorUtility.SetDirty(this);
        }
        
        public void ClearMaterialFiles() {
            materialSetFiles = null;
        }

        internal AssetData[] GetExportAssetData() {
            AssetData[] assetData = null;
            
            /*
             * Do not export atlas or material set files and just let them be rebuilt
             * 
            // atlas files
            if(atlasFiles != null) {
                for(int i = 0; i < atlasFiles.Length; i++) {
                    if(atlasFiles[i] == null || atlasFiles[i] == "") continue;
                    string filePath = SpriteEditor.AddSpriteGroupFilePath(atlasFiles[i]);
                    if(!SpriteEditor.FileExistsRel(filePath)) continue; // atlas file is missing
                    SpriteFactory.Utils.ArrayTools.Add<string>(ref assetPaths, SpriteEditor.RelToAbsPath(filePath)); // add to list
                }
            }

            // material set files
            if(materialSetFiles != null) {
                for(int i = 0; i < materialSetFiles.Length; i++) {
                    if(materialSetFiles[i] == null) continue;
                    SpriteFactoryData.MaterialSetFiles_Save set = materialSetFiles[i];
                    for(int j = 0; j < set.materialFileNames.Length; j++) {
                        string filePath = SpriteEditor.AddMaterialFilePath(set.materialFileNames[i]);
                        if(!SpriteEditor.FileExistsRel(filePath)) continue; // material set file is missing
                        SpriteFactory.Utils.ArrayTools.Add<string>(ref assetPaths, SpriteEditor.RelToAbsPath(filePath)); // add to list
                    }
                }
            }
            */

            // material set source files
            if(materialSets != null) {
                for(int i = 0; i < materialSets.Length; i++) {
                    if(materialSets[i] == null) continue;
                    if(materialSets[i].sourceMaterial == null) continue;
                    SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData, new AssetData(AssetDatabase.GetAssetPath(materialSets[i].sourceMaterial), AssetData.AssetType.SourceMaterial)); // add to list
                }
            }

            return assetData;
        }

        public bool UpgradeCheck(Settings settings) {
            bool changed = false;
            
            // check material sets and convert defaults
            if(materialSets != null) {

                for(int i = 0; i < materialSets.Length; i++) {
                    if(materialSets[i] == null) continue;
                    if(materialSets[i].useDefaultMaterial) continue;
                    if(materialSets[i].sourceMaterial != null && Utils.AssetTools.GetGUID(materialSets[i].sourceMaterial) == settings.defaultMaterialGUID) { // this material is the default, change settings
                        materialSets[i].useDefaultMaterial = true;
                        materialSets[i].sourceMaterial = null; // clear the material
                        changed = true;
                    }
                }
            }

            // Check texture filter mode
            if(!useDefaultAtlasTextureFilterMode && atlasTextureFilterMode == settings.defaultFilterMode) {
                useDefaultAtlasTextureFilterMode = true;
                changed = true;
            }

            // Check texture aniso level
            if(atlasTextureAnisoLevel != -1 && atlasTextureAnisoLevel == settings.defaultAnisoLevel) {
                atlasTextureAnisoLevel = -1; // set to default
                changed = true;
            }

            return changed;
        }
    }
}