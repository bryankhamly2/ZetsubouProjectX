using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using SpriteFactory.Editor.Libraries.Ionic.Zlib;
using SpriteFactory.Editor.DataClasses;

namespace SpriteFactory.Editor.Utils {

    internal static class InspectorTools {

        private const float maxWidth = 400.0f;

        public static bool DrawToggle(SerializedProperty property, GUIContent label = null) {
            bool changed = false;
            GUIStyle style = GUI.skin.toggle;
            Rect position = GUILayoutUtility.GetRect(maxWidth, style.lineHeight + style.padding.vertical);
            GUIContent guiLabel = EditorGUI.BeginProperty(position, label, property);
            EditorGUI.BeginChangeCheck();
            bool newValue = EditorGUI.Toggle(position, guiLabel, property.boolValue);
            // Only assign the value back if it was actually changed by the user.
            // Otherwise a single value will be assigned to all objects when multi-object editing,
            // even when the user didn't touch the control.
            if(EditorGUI.EndChangeCheck()) {
                property.boolValue = newValue;
                changed = true;
            }
            EditorGUI.EndProperty();
            return changed;
        }

        public static bool DrawToggle(ref bool value, GUIContent label = null) {
            bool changed = false;
            GUIStyle style = GUI.skin.toggle;
            Rect position = GUILayoutUtility.GetRect(maxWidth, style.lineHeight + style.padding.vertical);
            bool newValue = EditorGUI.Toggle(position, label, value);
            if(newValue != value) {
                value = newValue;
                changed = true;
            }
            return changed;
        }

        public static void DrawFloat(SerializedProperty property, float min, float max, GUIContent label = null) {
            GUIStyle style = GUI.skin.textField;
            Rect position = GUILayoutUtility.GetRect(maxWidth, style.lineHeight + style.padding.vertical);
            GUIContent guiLabel = EditorGUI.BeginProperty(position, label, property);
            EditorGUI.BeginChangeCheck();
            float newValue = EditorGUI.FloatField(position, guiLabel, property.floatValue);
            if(newValue < min) newValue = min; // clamp to min
            else if(min < max && newValue > max) newValue = max; // clamp to max only if min is less, so if min = max, do not clamp upper value
            // Only assign the value back if it was actually changed by the user.
            // Otherwise a single value will be assigned to all objects when multi-object editing,
            // even when the user didn't touch the control.
            if(EditorGUI.EndChangeCheck()) property.floatValue = newValue;
            EditorGUI.EndProperty();
        }

        public static void DrawInt(SerializedProperty property, GUIContent label = null) {
            GUIStyle style = GUI.skin.textField;
            Rect position = GUILayoutUtility.GetRect(maxWidth, style.lineHeight + style.padding.vertical);
            GUIContent guiLabel = EditorGUI.BeginProperty(position, label, property);
            EditorGUI.BeginChangeCheck();
            int newValue = EditorGUI.IntField(position, guiLabel, property.intValue);
            // Only assign the value back if it was actually changed by the user.
            // Otherwise a single value will be assigned to all objects when multi-object editing,
            // even when the user didn't touch the control.
            if(EditorGUI.EndChangeCheck()) property.intValue = newValue;
            EditorGUI.EndProperty();
        }

        public static void DrawInt(SerializedProperty property, int min, int max, GUIContent label = null) {
            GUIStyle style = GUI.skin.textField;
            Rect position = GUILayoutUtility.GetRect(maxWidth, style.lineHeight + style.padding.vertical);
            GUIContent guiLabel = EditorGUI.BeginProperty(position, label, property);
            EditorGUI.BeginChangeCheck();
            int newValue = EditorGUI.IntField(position, guiLabel, property.intValue);
            if(newValue < min) newValue = min; // clamp to min
            else if(min < max && newValue > max) newValue = max; // clamp to max only if min is less, so if min = max, do not clamp upper value
            // Only assign the value back if it was actually changed by the user.
            // Otherwise a single value will be assigned to all objects when multi-object editing,
            // even when the user didn't touch the control.
            if(EditorGUI.EndChangeCheck()) property.intValue = newValue;
            EditorGUI.EndProperty();
        }

        public static void DrawObjectField(SerializedProperty property, System.Type type, bool allowSceneObjects, GUIContent label = null) {
            GUIStyle style = GUI.skin.textField;
            Rect position = GUILayoutUtility.GetRect(maxWidth, style.lineHeight + style.padding.vertical);
            GUIContent guiLabel = EditorGUI.BeginProperty(position, label, property);
            EditorGUI.BeginChangeCheck();
            Object newValue = EditorGUI.ObjectField(position, guiLabel, property.objectReferenceValue, type, allowSceneObjects);
            // Only assign the value back if it was actually changed by the user.
            // Otherwise a single value will be assigned to all objects when multi-object editing,
            // even when the user didn't touch the control.
            if(EditorGUI.EndChangeCheck()) property.objectReferenceValue = newValue;
            EditorGUI.EndProperty();
        }

        public static int DrawPopup(int selectedIndex, string[] options, GUIContent label = null) {
            GUIStyle style = GUI.skin.textField;
            Rect position = GUILayoutUtility.GetRect(maxWidth, style.lineHeight + style.padding.vertical);

            int count;
            if(options == null || options.Length == 0) count = 0;
            else count = options.Length;

            // Convert options to gui content array
            GUIContent[] guiOptions = new GUIContent[count];
            for(int i = 0; i < count; i++) {
                guiOptions[i] = new GUIContent(options[i]);
            }

            EditorGUI.BeginChangeCheck();
            int oldValue = selectedIndex;
            int newValue = EditorGUI.Popup(position, label, oldValue, guiOptions);
            // Only assign the value back if it was actually changed by the user.
            // Otherwise a single value will be assigned to all objects when multi-object editing,
            // even when the user didn't touch the control.
            if(EditorGUI.EndChangeCheck()) return newValue;
            return selectedIndex;
        }


        public static void DrawPopup(SerializedProperty property, string[] options, GUIContent label = null) {
            GUIStyle style = GUI.skin.textField;
            Rect position = GUILayoutUtility.GetRect(maxWidth, style.lineHeight + style.padding.vertical);

            GUIContent guiLabel;
            guiLabel = EditorGUI.BeginProperty(position, label, property);

            int count;
            if(options == null || options.Length == 0) count = 0;
            else count = options.Length;

            // Convert options to gui content array
            GUIContent[] guiOptions = new GUIContent[count];
            for(int i = 0; i < count; i++) {
                guiOptions[i] = new GUIContent(options[i]);
            }

            EditorGUI.BeginChangeCheck();
            int oldValue = property.intValue;
            int newValue = EditorGUI.Popup(position, guiLabel, oldValue, guiOptions);
            // Only assign the value back if it was actually changed by the user.
            // Otherwise a single value will be assigned to all objects when multi-object editing,
            // even when the user didn't touch the control.
            if(EditorGUI.EndChangeCheck()) property.intValue = newValue;
            EditorGUI.EndProperty();
        }

        public static void DrawPopup(SerializedProperty property, string[] options, int[] values, GUIContent label = null) {
            if(options.Length != values.Length) throw new System.ArgumentException("options.Length must = values.Length!");

            GUIStyle style = GUI.skin.textField;
            Rect position = GUILayoutUtility.GetRect(maxWidth, style.lineHeight + style.padding.vertical);

            GUIContent guiLabel;
            guiLabel = EditorGUI.BeginProperty(position, label, property);

            int count;
            if(options == null || options.Length == 0) count = 0;
            else count = options.Length;

            // Convert options to gui content array
            GUIContent[] guiOptions = new GUIContent[count];
            for(int i = 0; i < count; i++) {
                guiOptions[i] = new GUIContent(options[i]);
            }

            EditorGUI.BeginChangeCheck();
            int oldSelection = System.Array.IndexOf(values, property.intValue);
            int newSelection = EditorGUI.Popup(position, guiLabel, oldSelection, guiOptions);
            // Only assign the value back if it was actually changed by the user.
            // Otherwise a single value will be assigned to all objects when multi-object editing,
            // even when the user didn't touch the control.
            if(EditorGUI.EndChangeCheck()) {
                //if(newSelection < 0 || newSelection >= values.Length) property.intValue = 0; // filter out 
                //else
                property.intValue = values[newSelection];
            }
            EditorGUI.EndProperty();
        }

        public static void DrawPopupWithNone(SerializedProperty property, string[] options, GUIContent label = null) {
            GUIStyle style = GUI.skin.textField;
            Rect position = GUILayoutUtility.GetRect(maxWidth, style.lineHeight + style.padding.vertical);

            GUIContent guiLabel;
            guiLabel = EditorGUI.BeginProperty(position, label, property);

            int oldCount;
            if(options == null || options.Length == 0) oldCount = 0;
            else oldCount = options.Length;

            // Insert none at beginning of list
            int newCount = oldCount + 1;
            string[] newOptions = new string[newCount];
            newOptions[0] = "None";
            for(int i = 1; i < newCount; i++)
                newOptions[i] = options[i - 1];

            // Convert new options to gui content array
            GUIContent[] guiOptions = new GUIContent[newCount];
            for(int i = 0; i < newCount; i++) {
                guiOptions[i] = new GUIContent(newOptions[i]);
            }

            EditorGUI.BeginChangeCheck();
            int oldValue = property.intValue + 1; // offset for "none"
            int newValue = EditorGUI.Popup(position, guiLabel, oldValue, guiOptions);
            // Only assign the value back if it was actually changed by the user.
            // Otherwise a single value will be assigned to all objects when multi-object editing,
            // even when the user didn't touch the control.
            if(EditorGUI.EndChangeCheck()) property.intValue = newValue - 1; // offset for "none"
            EditorGUI.EndProperty();
        }

        public static void DrawVector3(SerializedProperty property, GUIContent label = null) {
            GUIStyle style = GUI.skin.textField;
            Rect position = GUILayoutUtility.GetRect(maxWidth, (style.lineHeight + style.padding.vertical) * 2.0f);
            GUIContent guiLabel = EditorGUI.BeginProperty(position, label, property);
            EditorGUI.BeginChangeCheck();
            Vector3 newValue = EditorGUI.Vector3Field(position, guiLabel.text, property.vector3Value);
            // Only assign the value back if it was actually changed by the user.
            // Otherwise a single value will be assigned to all objects when multi-object editing,
            // even when the user didn't touch the control.
            if(EditorGUI.EndChangeCheck()) property.vector3Value = newValue;
            EditorGUI.EndProperty();
        }
    }

    internal static class GUITools {

        public static object[] DropZone(string title, int height, int extraHeight = 0, GUISkin skin = null) {
            if(skin != null) {
                //GUISkin editorSkin = EditorGUIUtility.GetBuiltinSkin(EditorSkin.Inspector); // Cannot use this anymore... BUGGED in Unity 4.3
                GUISkin editorSkin = GUI.skin; // just get the current skin instead
                GUIStyle style = new GUIStyle(editorSkin.box);
                if(EditorGUIUtility.isProSkin)
                    style.normal.textColor = skin.FindStyle("DropZone").normal.textColor;
                else
                    style.normal.textColor = skin.FindStyle("DropZone").onNormal.textColor;
                GUILayout.Box(title, style, GUILayout.Height(height), GUILayout.ExpandWidth(true));
            } else {
                GUILayout.Box(title, GUILayout.Height(height), GUILayout.ExpandWidth(true));
            }

            Rect boxRect = GUILayoutUtility.GetLastRect();
            if(extraHeight > 0) boxRect.height += extraHeight;

            EventType eventType = Event.current.type;
            bool isAccepted = false;

            if(eventType == EventType.DragUpdated || eventType == EventType.DragPerform) {
                if(boxRect.Contains(Event.current.mousePosition)) {
                    DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
                    if(eventType == EventType.DragPerform) {
                        DragAndDrop.AcceptDrag();
                        isAccepted = true;
                    }
                    Event.current.Use();
                }
            }

            return isAccepted ? DragAndDrop.objectReferences : null;
        }

        public abstract class SimpleInspectorGUIControl {
            private bool _isReady; public bool isReady { get { return _isReady; } protected set { _isReady = value; } }
            private bool _refresh = true; public bool refresh { get { return _refresh; } set { _refresh = value; if(_refresh) ClearChildren(); } } // call refresh if just a selection changes
            public bool refreshDontClearChildren { set { _refresh = value; if(_refresh) UpdateChildren(); } } // refresh children, but don't clear child controls
            private bool _changed;
            public bool changed { // call change when any data changes that would affect a changePartner
                get { return _changed; }
                set {
                    if(value) {
                        refresh = true; // set refresh in self and clear children
                        UpdateChangePartners(); // refresh any connected controls that get refreshed on data changes only
                    }
                    _changed = value;
                }
            }

            protected SimpleInspectorGUIControl _parent = null; public SimpleInspectorGUIControl parent { get { return _parent; } set { _parent = value; if(_parent != null) _parent.AddChild(this); } } // sets parent and adds reciprocal link as child in parent
            protected List<SimpleInspectorGUIControl> _children = new List<SimpleInspectorGUIControl>();
            protected List<SimpleInspectorGUIControl> _changePartners = new List<SimpleInspectorGUIControl>();


            private void UpdateAll() {
                bool isTopParent = _parent == null ? true : false;
                if(!isTopParent) {
                    _parent.UpdateAll(); // send update up the ladder
                    return;
                }
                //This is the top parent
                Update(); // update self and the children recursively
            }

            private void Update() {
                UpdateSelf();
                UpdateChildren();
            }

            private void UpdateSelf() {
                _refresh = true;
            }

            protected void UpdateChildren() {
                if(_children.Count > 0) {
                    for(int i = 0; i < _children.Count; i++) {
                        _children[i].Update();
                    }
                }
            }

            private void UpdateChangePartners() {
                if(_changePartners.Count > 0) {
                    for(int i = 0; i < _changePartners.Count; i++) {
                        _changePartners[i].Update();
                    }
                }
            }

            public void ClearChildren() {
                // Clear any controls that depend on the selection of this control
                if(_children.Count > 0) {
                    for(int i = 0; i < _children.Count; i++) {
                        _children[i].Clear();
                        _children[i].ClearChildren(); // clear children recursively
                    }
                }
            }

            public void AddChild(SimpleInspectorGUIControl child) {
                _children.Add(child);
            }

            public void AddChangePartner(SimpleInspectorGUIControl partner) {
                _changePartners.Add(partner);
            }

            protected void BeginNewCycle() {
                ClearMomentaryVars();
            }

            private void ClearMomentaryVars() {
                // clear momentary vars
                if(_changed) _changed = false;
            }

            // Stubs
            public abstract void Clear();
        }

        public class SimpleInspectorGUIListBoxContainer<T> : SimpleInspectorGUIControl {
            private ListBox listBox;
            private GUISkin skin;
            private int _selectedIndex;
            public T selectedObject;
            private bool _selectionChanged;
            private bool _softRefresh;

            // Properties
            public bool hasSelection {
                get {
                    if(selectedIndex > -1) return true;
                    return false;
                }
            }
            public int selectedIndex {
                get {
                    return _selectedIndex;
                }
                set {
                    _selectedIndex = value;
                    if(_selectedIndex >= 0)
                        isReady = true;
                }
            }
            public bool selectionChanged {
                get {
                    return _selectionChanged;
                }
            }
            public bool softRefresh {
                set {
                    _softRefresh = value;
                }
            }
            public int entryCount {
                get {
                    return listBox.entryCount;
                }
            }


            public SimpleInspectorGUIListBoxContainer(GUISkin inSkin) {
                skin = inSkin;
                ClearAll();
            }

            public void Draw(int itemCount, T[] itemList, string[] nameList, string emptyMsg, bool displayIndex, float width, float height, bool autoSelectFirstEntry = false) {
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(_selectionChanged) _selectionChanged = false;

                // If no items, display an empty message
                if(itemCount == 0) {
                    listBox.DrawEmpty(GUILayoutUtility.GetRect(width, height), emptyMsg);
                    ClearSelection();
                    return;
                }

                // Rebuild list of item names, ids only if necessary
                if(refresh || _softRefresh) {
                    listBox.Clear(); // clear the list first

                    // Create id : description string for each item in list
                    for(int i = 0; i < itemCount; i++) {
                        string name = nameList[i];
                        if(displayIndex) name = i + " : " + name; // insert index before name
                        listBox.AddEntry(name); // add the name to the listBox
                    }
                    if(refresh) refresh = false; // just refreshed, flag off
                    if(_softRefresh) softRefresh = false;
                }

                // Check if there are any entries at all and make sure we don't still have a selection, also make sure if last cell is deleted, we clear the selection
                if(listBox.entryCount <= 0 || selectedIndex >= listBox.entryCount) {
                    ClearSelection();
                }

                if(parent != null && !parent.isReady) return; // parent doesn't have anything selected, don't draw

                // Automatically select the first entry
                if(autoSelectFirstEntry && selectedIndex == -1) { // we have no selection
                    selectedIndex = 0;
                }

                // Draw the list box control
                listBox.SetSelectedId(selectedIndex); // push possible changed selection into control
                Rect rect = GUILayoutUtility.GetRect(width, height);
                rect.width = width; // force rect to be correct width so padding doesn't make it wider than it should be
                rect.height = height;
                _selectionChanged = listBox.Draw(rect);
                int newVal = listBox.GetSelectedId(); // get changed selection id

                // Check for changes in value both with selection index and objects
                if(!_selectionChanged) {
                    if(newVal == -1 && object.Equals(selectedObject, default(T))) return; // nothing is selected
                    // account for updating after add/delete/move actions change the selection - allow selection to fall through and select whatever entry is next in line
                    if(newVal >= itemCount) newVal = -1; // selection no longer valid, set no selection
                    if(newVal >= 0 && object.Equals(selectedObject, itemList[newVal])) // objects match so they're the same
                        return; // no change, return
                    // objects that do not match will fall through and new selection will be made on element in same location
                }

                // Selection changed
                refresh = true; // refresh this and all child controls

                // Set final vars based on change
                selectedIndex = newVal;
                if(selectedIndex >= 0) // an object was selected
                    selectedObject = itemList[selectedIndex]; // find the object to return
            }

            public void DeleteSelected() { // call when deleting an item from the list
                // this doesn't actually delete anything, it just determines if we need to clear the selection or not

                if(selectedIndex == listBox.entryCount - 1) { // this is the last entry, deselect after delete
                    ClearSelection();
                }

            }

            public void ClearAll() {
                Clear();
            }

            public override void Clear() {
                // Selected choices
                ClearSelection();
                listBox = new ListBox(skin); // make a new listbox -- I SUSPECT THIS has something to do with a problem with refreshing the top-most parent of nested lists, but my change didn't work so we'll leave this to future sleuthing
                // DO NOT clear the list box here because when a child control drives a refresh, we can't have the list box cleared immediately or we'll get errors
                // listbox will be cleared when refresh rolls around
                refresh = true;
            }

            public void ClearSelection() {
                _selectedIndex = -1;
                selectedObject = default(T);
                isReady = false;
                refresh = true; // clear all children
            }

            public void ChangeSelection(int index) {
                if(index < 0) { // clear selection
                    ClearSelection();
                    return;
                }
                if(index >= listBox.entryCount) return;
                if(index == _selectedIndex) return; // same

                _selectedIndex = index;
                selectedObject = default(T);
                refresh = true;
            }

            private class ListBox {
                private List<ListBoxEntry> entryList = new List<ListBoxEntry>();
                private int selected = -1;
                private Vector2 scrollPos;
                private float maxItemWidth;
                private GUISkin skin;
                private GUIStyle origStyle;
                private GUIStyle style;
                private GUIStyle style_on;
                public int entryCount { get { return entryList.Count; } }
                private bool stylesCreated;

                // Consts
                private float itemHeight = 18.0f; // may change this to dynamic at some point but for now its fine static
                // calculated height doesn't seem to come out right. we get 13 when it should be 18...

                // Contstructors ////

                public ListBox(GUISkin inSkin) {
                    skin = inSkin;
                    // CreateStyles(); // can no longer create styles on instantiation because of bug requiring us to use GUI.skin instead of getting the editor skin
                }

                public ListBox(float inItemHeight, GUISkin inSkin) {
                    itemHeight = inItemHeight;
                    skin = inSkin;
                    // CreateStyles(); // can no longer create styles on instantiation because of bug requiring us to use GUI.skin instead of getting the editor skin
                }

                //Public functions ////

                public void AddEntry(string Name) {
                    entryList.Add(new ListBoxEntry(Name));
                    CalculateItemWidth(Name);
                }

                public int GetSelectedId() {
                    return selected;
                }

                public void SetSelectedId(int inSelected) {
                    if(inSelected >= entryList.Count || inSelected < -1) return;
                    selected = inSelected; // save selection id
                }

                public void ShowSelected() {
                    if(selected >= 0) { // we have a selection
                        scrollPos.y = selected * itemHeight;
                        scrollPos.x = 0.0f;
                    }
                }

                public void Clear() {
                    entryList.Clear();
                    maxItemWidth = 0.0f; // we will be recalculating contents width
                }

                public void DrawEmpty(Rect area, string emptyMsg) {
                    if(!stylesCreated) CreateStyles();

                    // Make the scroll view
                    GUI.Box(area, string.Empty); // draw box behind entire scroll view
                    Rect viewRect = new Rect(0.0f, 0.0f, area.width, itemHeight);
                    scrollPos = GUI.BeginScrollView(area, scrollPos, viewRect); // make a scroll view
                    GUI.Label(viewRect, emptyMsg); // show empty message
                    GUI.EndScrollView();
                }

                public bool Draw(Rect area) {
                    if(!stylesCreated) CreateStyles();

                    float y = 0.0f;
                    string entryText = "";
                    int tempSelected = selected; // working selected
                    Event ev = Event.current;
                    bool mouseEvent = false;
                    Vector2 mpos;
                    Rect localViewArea;
                    float totalContentsHeight = itemHeight * entryList.Count;
                    GUIStyle curStyle;
                    float modifiedMaxItemWidth = maxItemWidth;

                    // Detect event type
                    if(ev.type == EventType.MouseDown && Event.current.button == 0)
                        mouseEvent = true; // this is a mouse event cycle

                    // Use fixed width for now
                    int vScrollBarWidth = 15;
                    int hScrollBarHeight = 15;

                    float visibleWidth = area.width;
                    float visibleHeight = area.height;

                    // Determine if auto scroll bars would be generated
                    bool vScrollBarVisible = false;
                    bool hScrollBarVisible = false;

                    // Check against total area first
                    if(totalContentsHeight > visibleHeight) { // v scroll bar is visible
                        vScrollBarVisible = true;
                        visibleWidth -= vScrollBarWidth; // reduce visible width if v scroll bar is displayed. Prevents it from wanting to add horiz scroll bar even when entries are short (makes view area smaller to fit scroll bar).
                    }
                    if(modifiedMaxItemWidth > visibleWidth) { // h scroll bar is visible
                        hScrollBarVisible = true;
                        visibleHeight -= vScrollBarWidth; // reduce visible height for h scroll bar
                    }

                    // If either v or h scroll bar was activated, the other may have been also since the viewing area became smaller
                    // We have to re-evaluate both H and V
                    if(vScrollBarVisible) { // V is visible, see if H became visible too
                        if(!hScrollBarVisible && modifiedMaxItemWidth > visibleWidth) { // H became visible because it is wider than the new smaller width
                            hScrollBarVisible = true;
                            visibleHeight -= vScrollBarWidth; // reduce visible height for h scroll bar
                        }
                    }
                    if(hScrollBarVisible) { // H is visible, see if V becane visible too
                        if(!vScrollBarVisible && totalContentsHeight > visibleHeight) { // v scroll bar became visible because it was taller than the new smaller height
                            vScrollBarVisible = true;
                            visibleWidth -= vScrollBarWidth; // reduce visible width
                        }
                    }

                    // BUGS: Doesn't work well with forced scrollbars.

                    // Adjust width of elements to fill visible area accounting for scroll bar
                    if(modifiedMaxItemWidth < visibleWidth) {
                        modifiedMaxItemWidth = visibleWidth; // make items at least as wide as the scroll box (or we get weird error if horiz scrollbar is forced on)
                    }

                    // Make the scroll view
                    GUI.Box(area, string.Empty); // draw box behind entire scroll view
                    Rect viewRect = new Rect(0.0f, 0.0f, modifiedMaxItemWidth, totalContentsHeight);
                    scrollPos = GUI.BeginScrollView(area, scrollPos, viewRect); // make a scroll view with inner height of entries * height
                    // Offset view area by scroll pos to find relative view area in local coords
                    localViewArea = area; // start with the scroll box rect (world coords)
                    localViewArea.x = scrollPos.x;
                    localViewArea.y = scrollPos.y;

                    if(vScrollBarVisible) localViewArea.width -= vScrollBarWidth; // prevent clicks in the scroller from selecting other elements
                    if(hScrollBarVisible) localViewArea.height -= hScrollBarHeight; // prevent clicks in the scroller from selecting other elements

                    //Get mouse pos for hover and click detection
                    mpos = ev.mousePosition;

                    //Loop through to draw the entries and check for selection.
                    for(int i = 0; i < entryList.Count; i++) {
                        //bool hover = false;

                        // DRAW CULLING - important for speed of large lists
                        // Quickly determine if text would be visible in the scroll area
                        if(y > scrollPos.y + area.height || y + itemHeight < scrollPos.y) { // top pixel of this entry is scrolled off the bottom, or bottom pixel of this entry is scrolled off the top
                            y += itemHeight; // increment y for next round
                            continue; // skip this entry
                        }

                        entryText = entryList[i].name; // Get the list entry's name
                        Rect entryBox = new Rect(0.0f, y, modifiedMaxItemWidth, itemHeight); //Get the selection's area.

                        //Check for hover and selection
                        if(entryBox.Contains(mpos) && localViewArea.Contains(mpos)) { // mouse was in selection box region AND within visiable area when clicked
                            if(mouseEvent) {// this is a mouse click event cycle
                                tempSelected = i;
                            }
                        }

                        //Draw a box if it's selected
                        if(tempSelected == i) { // selected entry
                            //GUI.Box(entryBox, "", skin.box);
                            curStyle = style_on;
                            //} else if(hover){ // not selected but mouse hovering
                            //GUI.Box(entryBox, "", skin.box);
                        } else { // not selected entry
                            curStyle = style;
                        }

                        // Draw the text
                        if(GUI.Button(entryBox, entryText, curStyle)) { // use button because label doesn't support hover styles
                            GUIUtility.keyboardControl = 0; // clear keyboard focus when selection is made
                        }
                        y += itemHeight; // increment y position
                    }
                    GUI.EndScrollView();

                    // Detect change in selection
                    bool changed = false;

                    if(selected != tempSelected) {
                        SetSelectedId(tempSelected);
                        changed = true;
                    }

                    return changed;
                }

                // Private functions ////
                private void CalculateItemWidth(string s) {
                    if(!stylesCreated) CreateStyles();

                    Vector2 size = origStyle.CalcSize(new GUIContent(s));
                    if(size.x > maxItemWidth)
                        maxItemWidth = size.x; // save size of biggest entry
                }

                private void CreateStyles() {
                    stylesCreated = true;
                    //GUISkin editorSkin = EditorGUIUtility.GetBuiltinSkin(EditorSkin.Inspector); // Cannot use... Bugged in Unity 4.3
                    GUISkin editorSkin = GUI.skin; // just use current skin instead
                    origStyle = skin.FindStyle("listbox");
                    // Get listbox style from skin or substitute default label
                    if(origStyle == null) {
                        Debug.Log("No \"listbox\" style found in GUI skin! Substituting label style...");
                        style = new GUIStyle(editorSkin.label); // clone editor skin label style
                    } else
                        style = new GUIStyle(origStyle); // clone orig style so we don't change it

                    // Copy colors from current editor skin so users can change between light and dark skin in unity
                    style.normal.textColor = editorSkin.button.normal.textColor;
                    style.hover.textColor = editorSkin.button.hover.textColor;
                    style.active.textColor = editorSkin.button.active.textColor;
                    style.focused.textColor = editorSkin.button.focused.textColor;

                    // Copy style for manual ON style setting
                    // Since buttons and labels don't leave the ON state active like selection grid's, we have to use
                    // two separate styles breaking out the ON states to the normal state
                    style_on = new GUIStyle(style); // copy main style
                    // Set up normal style based on main style's onNormal state
                    style_on.normal.background = style.onNormal.background;
                    style_on.normal.textColor = style.onNormal.textColor;
                    // hover = onHover
                    style_on.hover.background = style.onHover.background;
                    style_on.hover.textColor = style.onHover.textColor;
                    // active = onActive
                    style_on.active.background = style.onActive.background;
                    style_on.active.textColor = style.onActive.textColor;
                    // focused = onFocused
                    style_on.focused.background = style.onFocused.background;
                    style_on.focused.textColor = style.onFocused.textColor;
                }

                private class ListBoxEntry {
                    public string name = "";

                    public ListBoxEntry(string inName) {
                        name = inName;
                    }
                }
            }
        }

        // GUI wrapper system

        public static class Engine {

            private static bool initialized;

            private static GUIContent fillerContent;

            // Label handling
            private static bool _hasLabel;
            private static GUIContent _labelContent;
            private static string _tooltip;
            private static GUIStyle _labelStyle;

            // Rendering Mode
            private static RenderingMode _renderingMode;
            private static float fixedLabelWidth;
            private static float fixedFieldWidth;

            // Begin/End checking
            private static int scrollViewCounter;
            private static int renderModeCounter;

            // Properties
            public static RenderingMode renderingMode {
                get {
                    return _renderingMode;
                }
            }
            // Labels
            public static bool hasLabel {
                get {
                    return _hasLabel;
                }
            }
            public static GUIContent labelContent {
                get {
                    return _labelContent;
                }
            }
            public static string tooltip {
                get {
                    return _tooltip;
                }
            }
            public static GUIStyle labelStyle {
                get {
                    return _labelStyle;
                }
            }

            #region Main

            public static void Initialize() {
                initialized = true;

                // Make objects
                fillerContent = new GUIContent("X");

                // Clear vars
                ClearCycleVars();

                // Initialize other classes
                Tooltip.Initialize();
                AutoLayout.Initialize();
                Layout.Initialize();
                EditorLayout.Initialize();
            }

            public static void Update() {
                if(!initialized) {
                    Debug.LogError("Engine has not been initialized and you are calling Update! Call Initialize() first in OnEnable().");
                    return;
                }

                // Verify all Begin/End tags match
                CheckCounters();

                // Clear vars
                ClearCycleVars();

                // Update other classes
                AutoLayout.Update();
                EditorLayout.Update();
            }

            private static void CheckCounters() {
#if DEBUG
                if(scrollViewCounter > 0) Debug.Log("ScrollView Begin/End imbalance! " + Mathf.Abs(scrollViewCounter) + " missing EndScrollView calls!");
                else if(scrollViewCounter < 0) Debug.Log("ScrollView Begin/End imbalance! " + scrollViewCounter + " extra BeginScrollView calls!");

                if(renderModeCounter > 0) Debug.Log("Render mode change imbalance! " + renderModeCounter + " missing SwitchToAutoWidth calls!");
                else if(renderModeCounter < 0) Debug.Log("Render mode change imbalance! " + Mathf.Abs(renderModeCounter) + " extra SwitchToFixedWidth calls!");
#endif
            }

            public static void ClearCycleVars() {
                scrollViewCounter = 0;
                renderModeCounter = 0;
                _renderingMode = RenderingMode.Auto;
                fixedLabelWidth = 0.0f;
                fixedFieldWidth = 0.0f;

                ClearLabelVars();
            }

            #endregion

            #region Layout

            public static Rect BeginHorizontal() {
                return AutoLayout.BeginHorizontal();
            }
            public static Rect BeginHorizontal(GUIStyle style) {
                return AutoLayout.BeginHorizontal(style);
            }
            public static Rect BeginHorizontal(GUIStyle style, params GUILayoutOption[] options) {
                return AutoLayout.BeginHorizontal(style, options);
            }
            public static Rect BeginHorizontal(params GUILayoutOption[] options) {
                return AutoLayout.BeginHorizontal(options);
            }
            public static void EndHorizontal() {
                AutoLayout.EndHorizontal();
            }

            public static Rect BeginVertical() {
                return AutoLayout.BeginVertical();
            }
            public static Rect BeginVertical(GUIStyle style) {
                return AutoLayout.BeginVertical(style);
            }
            public static Rect BeginVertical(GUIStyle style, params GUILayoutOption[] options) {
                return AutoLayout.BeginVertical(style, options);
            }
            public static Rect BeginVertical(params GUILayoutOption[] options) {
                return AutoLayout.BeginVertical(options);
            }
            public static void EndVertical() {
                AutoLayout.EndVertical();
            }

            public static void BeginRegion(GUIStyle style = null) {
                AutoLayout.BeginRegion(style);
            }
            public static void EndRegion() {
                AutoLayout.EndRegion();
            }

            public static void BeginScrollView(Vector2 scrollPos) {
                scrollViewCounter++;
                Tooltip.BeginScrollView(scrollPos);
            }
            public static void EndScrollView() {
                scrollViewCounter--;
                Tooltip.EndScrollView();
            }

            #endregion

            #region Rendering Mode

            public static void SwitchToFixedWidth(float labelWidth, float fieldWidth = 50.0f) { // MUST always revert to Auto width after done do NOT LEAVE open at fixed at end of OnGUI!
                if(_renderingMode == RenderingMode.Auto) renderModeCounter++; // allow chaining fixed without going back to auto until end
                _renderingMode = RenderingMode.Fixed;
                EditorGUIUtility.LookLikeControls(labelWidth, fieldWidth);
                fixedLabelWidth = labelWidth;
                fixedFieldWidth = fieldWidth;
            }

            public static void SwitchToAutoWidth() {
                renderModeCounter--;
                _renderingMode = RenderingMode.Auto;
                EditorGUIUtility.LookLikeControls();
            }

            #endregion

            #region Fixed Rendering

            public static Rect DrawFixedLabelAndGetControlRect(float colWidth, GUIStyle controlStyle) {
                // Draw label if necessary
                float marginTop;
                float labelWidth;
                Rect reserveRect = ReserveControlAndLabelRect(colWidth, controlStyle, out marginTop);
                Rect labelRect = DrawFixedLabel(reserveRect, marginTop, out labelWidth);
                return FindControlRect(labelRect, labelWidth);
            }

            public static Rect ReserveControlAndLabelRect(float colWidth, GUIStyle controlStyle, out float marginTop) {
                GUIStyle labelStyle = GUI.skin.label;
                float height = labelStyle.lineHeight;

                float marginBot; //, paddingTop, paddingBot;
                if(controlStyle == null) {
                    marginTop = labelStyle.margin.top;
                    marginBot = labelStyle.margin.bottom;
                    //paddingTop = labelStyle.padding.top;
                    //paddingBot = labelStyle.padding.bottom;
                } else {
                    marginTop = Mathf.Max(controlStyle.margin.top, labelStyle.margin.top);
                    marginBot = Mathf.Max(controlStyle.margin.bottom, labelStyle.margin.bottom);
                    //paddingTop = Mathf.Max(controlStyle.padding.top, labelStyle.padding.top);
                    //paddingBot = Mathf.Max(controlStyle.padding.bottom, labelStyle.padding.bottom);
                }
                Rect reserveRect = GUILayoutUtility.GetRect(colWidth, height + marginTop + marginBot, GUILayout.ExpandWidth(false));// + paddingBot + paddingTop);
                return reserveRect;
            }

            public static Rect ReserveLabelRect(out float marginTop) {
                GUIStyle labelStyle = GUI.skin.label;
                float height = labelStyle.lineHeight;
                float width = fixedLabelWidth;

                float marginBot; //, paddingTop, paddingBot;
                marginTop = labelStyle.margin.top;
                marginBot = labelStyle.margin.bottom;
                //paddingTop = labelStyle.padding.top;
                //paddingBot = labelStyle.padding.bottom;
                Rect reserveRect = GUILayoutUtility.GetRect(width, height + marginTop + marginBot, GUILayout.ExpandWidth(false));// + paddingBot + paddingTop);

                return reserveRect;
            }

            public static Rect ReserveControlRect(GUIStyle controlStyle) {
                GUIStyle labelStyle = GUI.skin.label;
                float height = labelStyle.lineHeight;
                float width = fixedFieldWidth;

                float marginTop, marginBot;//, paddingTop, paddingBot;
                marginTop = Mathf.Max(labelStyle.margin.top, controlStyle.margin.top);
                marginBot = Mathf.Max(labelStyle.margin.bottom, controlStyle.margin.bottom);
                //paddingTop = Mathf.Max(controlStyle.padding.top, controlStyle.padding.top);
                //paddingBot = Mathf.Max(controlStyle.padding.bottom, controlStyle.padding.bottom);

                Rect reserveRect = GUILayoutUtility.GetRect(width, height + marginTop + marginBot, GUILayout.ExpandWidth(false));// + paddingBot + paddingTop);
                return reserveRect;
            }

            public static Rect ReserveButtonRect(GUIStyle controlStyle, out float marginTop) {
                GUIStyle labelStyle = GUI.skin.label;
                float height = labelStyle.lineHeight;
                float width = fixedFieldWidth;

                float marginBot;
                marginTop = Mathf.Max(labelStyle.margin.top, controlStyle.margin.top);
                marginBot = Mathf.Max(labelStyle.margin.bottom, controlStyle.margin.bottom);
                Rect reserveRect = GUILayoutUtility.GetRect(width, height + marginTop + marginBot, GUILayout.ExpandWidth(false));
                return reserveRect;
            }

            public static Rect DrawFixedLabel(Rect reserveRect, float marginTop, out float labelWidth) {
                reserveRect.y += marginTop; // offset down for margin
                reserveRect.height -= marginTop; // counter the offset down

                if(!_hasLabel) {
                    labelWidth = 0.0f;
                    return reserveRect;
                }

                labelWidth = fixedLabelWidth;
                GUIStyle style = GUI.skin.label;

                float leftOffset = 0.0f;
                GUIStyle layoutStyle = AutoLayout.currentLayoutStyle; // get the style of the auto layout element this label is inside
                float layoutLeftPad = 0.0f;
                if(layoutStyle != null) {
                    layoutLeftPad = layoutStyle.padding.left;
                }
                //leftOffset = Mathf.Max(0.0f, style.margin.left - layoutLeftPad); // padding in cell absorbs margin

                reserveRect.x += leftOffset;
                reserveRect.width = labelWidth;

                GUI.Label(reserveRect, _labelContent, style);
                DrawTooltip(reserveRect);

                return reserveRect;
            }

            public static bool DrawFixedButton(Rect reserveRect, float marginTop) {
                bool result;

                reserveRect.y += marginTop;
                reserveRect.height -= 1.0f;
                //reserveRect.height -= marginTop;

                // Draw the button
                GUIContent content = _labelContent == null ? new GUIContent() : _labelContent;
                if(_labelStyle != null) result = GUI.Button(reserveRect, content, _labelStyle);
                else result = GUI.Button(reserveRect, content);

                // Draw tooltip
                DrawTooltip(reserveRect);

                return result;
            }

            public static Rect FindControlRect(Rect labelRect, float labelWidth) {
                // Adjust rect for control
                Rect controlRect = labelRect;
                controlRect.x += labelWidth;
                controlRect.width = fixedFieldWidth;
                return controlRect;
            }

            #endregion

            #region Tooltip Handling

            public static void DrawTooltip() {
                if(_tooltip == null || _tooltip == "") return;
                if(!GUI.enabled) return;
                Tooltip.LayoutShowTooltip(_tooltip); // draw tooltip
            }

            public static void DrawTooltip(Rect rect) {
                if(_tooltip == null || _tooltip == "") return;
                if(!GUI.enabled) return;
                Tooltip.FixedShowTooltip(rect, _tooltip); // draw tooltip
            }

            public static void InitializeLabel() {
                ClearLabelVars();
            }

            public static void SetLabel(GUIContent content) {
                if(content == null) return;

                _hasLabel = true;
                _labelContent = new GUIContent(content);
                _labelContent.tooltip = null; // clear tooltip
                _tooltip = content.tooltip;
            }

            public static void SetLabel(string label) {
                if(label == null) return;

                _hasLabel = true;
                Engine._labelContent = new GUIContent(label);
            }

            public static void SetStyle(GUIStyle style) {
                Engine._labelStyle = style;
            }

            public static void ClearLabelVars() {
                _tooltip = null;
                _labelContent = null;
                _hasLabel = false;
                _labelStyle = null;
            }

            #endregion

            // Private classes

            #region Auto Layout

            private static class AutoLayout {

                private static SpriteFactory.Utils.DataClasses.Pool<Layout> layouts;
                public static int currentLayoutId;
                private static bool layoutsBuilt;
                private static int idCounter;

                #region Properties

                public static GUIStyle currentLayoutStyle {
                    get {
                        Layout curLayout = currentLayout;
                        if(curLayout == null) return null;
                        return curLayout.style;
                    }
                }
                private static Layout currentLayout {
                    get {
                        if(currentLayoutId < 0 || currentLayoutId >= layouts.Length || !layoutsBuilt) return null;
                        return layouts[currentLayoutId];
                    }
                }
                private static Layout parentLayout {
                    get {
                        Layout layout = currentLayout;
                        if(layout == null) return null;
                        return layout.parent;
                    }
                }
                public static GUIStyle parentLayoutStyle {
                    get {
                        if(parentLayout == null) return null;
                        return parentLayout.style;
                    }
                }

                #endregion

                #region Main

                public static void Initialize() {
                    layouts = new SpriteFactory.Utils.DataClasses.Pool<Layout>(20, true, 20);
                }

                public static void Update() {
                    currentLayoutId = -1; // reset the count every event cycle
                    idCounter = -1;

                    Event e = Event.current;
                    if(e.type == EventType.Repaint) { // clear only on the repaint
                        layouts.Clear();
                        layoutsBuilt = false;
                    }
                }

                #endregion

                #region Layout Management

                private static void InitLayout(GUIStyle style = null) {
                    int newLayoutId = GetNextId(); // advance the counter
                    if(Event.current.type == EventType.Repaint) // assign this an id
                        AddLayout(newLayoutId, style); // create an object for this 
                    currentLayoutId = newLayoutId;
                }

                private static int AddLayout(int newLayoutId, GUIStyle style = null) {
                    int index = layouts.Add(new Layout(currentLayout, newLayoutId, style));
                    layoutsBuilt = true;
                    return index;
                }

                private static int GetNextId() {
                    return ++idCounter;
                }

                #endregion

                #region Layouts

                public static Rect BeginHorizontal() {
                    BeginRegion();
                    return EditorGUILayout.BeginHorizontal();
                }
                public static Rect BeginHorizontal(GUIStyle style) {
                    BeginRegion(style);
                    return EditorGUILayout.BeginHorizontal(style);
                }
                public static Rect BeginHorizontal(GUIStyle style, params GUILayoutOption[] options) {
                    BeginRegion(style);
                    return EditorGUILayout.BeginHorizontal(style, options);
                }
                public static Rect BeginHorizontal(params GUILayoutOption[] options) {
                    BeginRegion();
                    return EditorGUILayout.BeginHorizontal(options);
                }
                public static void EndHorizontal() {
                    EndRegion();
                    EditorGUILayout.EndHorizontal();
                }

                public static Rect BeginVertical() {
                    BeginRegion();
                    return EditorGUILayout.BeginVertical();
                }
                public static Rect BeginVertical(GUIStyle style) {
                    BeginRegion(style);
                    return EditorGUILayout.BeginVertical(style);
                }
                public static Rect BeginVertical(GUIStyle style, params GUILayoutOption[] options) {
                    BeginRegion(style);
                    return EditorGUILayout.BeginVertical(style, options);
                }
                public static Rect BeginVertical(params GUILayoutOption[] options) {
                    BeginRegion();
                    return EditorGUILayout.BeginVertical(options);
                }
                public static void EndVertical() {
                    EndRegion();
                    EditorGUILayout.EndVertical();
                }

                public static void BeginRegion(GUIStyle style = null) {
                    InitLayout(style);
                }
                public static void EndRegion() {
                    if(currentLayout == null) currentLayoutId = -1;
                    else currentLayoutId = currentLayout.parentId;
                }

                #endregion

                #region Private clases

                private class Layout {
                    public Layout parent;
                    public int layoutId;
                    public GUIStyle style;

                    public int parentId {
                        get {
                            if(parent == null) return -1;
                            return parent.layoutId;
                        }
                    }

                    public Layout(Layout parent, int layoutId, GUIStyle style) {
                        this.parent = parent;
                        this.layoutId = layoutId;
                        this.style = style;
                    }
                }

                #endregion
            }

            #endregion

            // Enums

            public enum RenderingMode { Auto = 0, Fixed = 1 }
        }

        public static class Tooltip {

            private static bool hover;
            private static bool hoverPrev;
            private static bool display;
            private static GUIContent tooltip;
            private static Rect hoverRect;
            private static GUIStyle style;
            private static bool fading;
            private static float startTime;
            private static float fadeStartTime;

            // Scroll view management
            private static VScrollView controlParentScrollView;
            private static VScrollView currentScrollView;
            private static VScrollView scrollViewContainer;

            private const float maxWidth = 300.0f;
            private const float hOffset = 25.0f;
            private const float vOffset = 5.0f;
            private const float startDelay = 0.5f;
            private const float fadeDelay = 0.25f;

            #region Main

            public static void Initialize() {
                // Get style
                GUISkin editorSkin = EditorGUIUtility.GetBuiltinSkin(EditorSkin.Inspector);
                style = new GUIStyle(editorSkin.textArea);
                style.wordWrap = true;
                style.padding = new RectOffset(5, 5, 5, 5);
                tooltip = new GUIContent();
                scrollViewContainer = new VScrollView(); // create the main parent "scroll view" which is really just the container

                hover = false;
                hoverPrev = false;
                display = false;
                hoverRect = new Rect();
                fading = false;
                startTime = 0.0f;
                fadeStartTime = 0.0f;

                controlParentScrollView = null;
                currentScrollView = null;
            }

            public static void Begin() {
                // Clear some working vars each cycle
                currentScrollView = scrollViewContainer; // reset back to the parent container
            }

            public static void End() {
                if(Event.current.type != EventType.repaint) return; // only draw in repaint event
                Draw();
            }

            #endregion

            private static void Draw() {
                bool guiEnabled = GUI.enabled; // save GUI state
                if(!guiEnabled) GUI.enabled = true; // make sure GUI is always enabled for tooltips

                if(hover) {
                    if(Time.realtimeSinceStartup >= startTime + startDelay) display = true; // start delay finished, show the tooltip
                } else if(hoverPrev) { // hover was just dropped
                    fading = true;
                    fadeStartTime = Time.realtimeSinceStartup;
                } else if(fading) {
                    if(Time.realtimeSinceStartup >= fadeStartTime + fadeDelay) Hide(); // fade delay finished, hide the tooltip
                }

                // Draw the tooltip
                if(display) Show();

                // update vars
                hoverPrev = hover;
                hover = false;

                if(GUI.enabled != guiEnabled) GUI.enabled = guiEnabled; // restore GUI state
            }

            private static void Show() {
                //Vector2 size = style.CalcSize(tooltip);
                float curMinWidth, curMaxWidth;
                style.CalcMinMaxWidth(tooltip, out curMinWidth, out curMaxWidth);
                float width = curMaxWidth > maxWidth ? maxWidth : curMaxWidth; // set width to 300 or less
                float height = style.CalcHeight(tooltip, width);

                Rect box = new Rect(hoverRect.x - hOffset, hoverRect.y + hoverRect.height + vOffset, width, height); // create rect for tooltip

                // Adjust box so it doesn't scroll off the sides LRB
                if(box.xMax > Screen.width) box.x -= box.xMax - Screen.width; // prevent it from extending off the right side
                if(box.x < 0) box.x += box.x * -1.0f; // prevent it from extending out the left side of the window
                if(box.xMin < 0) box.y += box.xMin * -1.0f; // prevent from extending off bottom of screen

                GUI.BeginGroup(box, style);
                GUI.Label(new Rect(0, 0, box.width, box.height), tooltip.text, style);
                GUI.EndGroup();
            }

            private static void Hide() {
                fading = false;
                display = false;
                controlParentScrollView = null;
            }

            public static void BeginScrollView(Vector2 offset) {
                VScrollView newScrollView = new VScrollView(offset);
                newScrollView.parent = currentScrollView; // set the previous current as the parent
                currentScrollView = newScrollView; // make this the new current
            }

            public static void EndScrollView() {
                currentScrollView = currentScrollView.parent; // set previous parent as current once we exit the scroll view
                if(currentScrollView == null) { // we must be back at the top
                    currentScrollView = scrollViewContainer; // set the container as the current
                }
            }

            public static void LayoutShowTooltip(string tooltip) {
                if(!DrawAllowed(tooltip)) return;
                Rect rect = GUILayoutUtility.GetLastRect(); // get rect of last drawn layout element
                CheckHover(rect, tooltip);
            }

            public static void FixedShowTooltip(Rect rect, string tooltip) {
                if(!DrawAllowed(tooltip)) return;
                CheckHover(rect, tooltip);
            }

            private static bool DrawAllowed(string tooltip) {
                // Prevent timer from starting if mouse moving
                if(!display && Event.current.type == EventType.MouseMove) { // if already hovering, don't cancel it
                    Vector2 delta = Event.current.delta;
                    if(delta.x != 0.0f || delta.y != 0.0f) {
                        Cancel();
                        return false;
                    }
                }

                Event e = Event.current;
                if(e.type != EventType.repaint) return false;
                if(tooltip == null || tooltip == "") return false;

                Vector2 mousePosition = e.mousePosition; // get the mouse position

                // Ignore mouse positions outside the window
                Vector2 mousePosWindow = ScrollViewToWindowPos(mousePosition); // get the mouse position relative to the window
                if(mousePosWindow.x < 0.0f || mousePosWindow.x > Screen.width ||
                    mousePosWindow.y < 0.0f || mousePosWindow.y > Screen.height) {
                    return false;
                }

                return true;
            }

            private static void CheckHover(Rect rect, string tooltip) {
                if(!rect.Contains(Event.current.mousePosition)) return; // mouse is not over the element, do nothing

                // The hoverRect from GetLastRect is relative to the CONTENTS of the main window
                // but when we draw the tooltip, the rects are relative to the visible portion of the main window
                Vector2 windowRelPos = ScrollViewToWindowPos(new Vector2(rect.x, rect.y)); // convert position to be window relative to account for scroll views
                hoverRect.x = windowRelPos.x;
                hoverRect.y = windowRelPos.y;
                hoverRect.width = rect.width;
                hoverRect.height = rect.height;

                Tooltip.tooltip.text = tooltip;

                if(!hover && !hoverPrev && !fading) {
                    startTime = Time.realtimeSinceStartup;
                    controlParentScrollView = currentScrollView; // record the scroll view holding this control
                }
                hover = true;
                if(fading) fading = false; // cancel the fade
            }

            private static Vector2 ScrollViewToWindowPos(Vector2 position) {
                if(currentScrollView == null) return new Vector2();
                Vector2 scrollViewOffset = currentScrollView.totalOffset; // get total offset of all scroll views control is inside
                return new Vector2(position.x - scrollViewOffset.x, position.y - scrollViewOffset.y);
            }

            private static void Cancel() {
                hover = false;
                hoverPrev = false;
                fading = false;
                display = false;
                controlParentScrollView = null;
                currentScrollView = scrollViewContainer;
            }

            // Private classes

            private class VScrollView {

                public VScrollView parent;
                public Vector2 offset;
                public Vector2 totalOffset {
                    get {
                        if(parent == null) return offset;
                        return parent.totalOffset + offset;
                    }
                }

                public VScrollView() { }

                public VScrollView(Vector2 offset) {
                    this.offset.x = offset.x;
                    this.offset.y = offset.y;
                }
            }
        }

        public static class Layout {

            public static void Initialize() {

            }

            #region Label

            public static void Label(GUIContent content) {
                Engine.InitializeLabel();
                Engine.SetLabel(content);
                Label();
            }
            public static void Label(GUIContent content, GUIStyle style) {
                Engine.InitializeLabel();
                Engine.SetLabel(content);
                Engine.SetStyle(style);
                Label();
            }
            public static void Label(GUIContent content, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(content);
                Label(options);
            }
            public static void Label(string label) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                Label();
            }
            public static void Label(string label, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                Label(options);
            }
            public static void Label(string label, GUIStyle style, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                Engine.SetStyle(style);
                Label(options);
            }

            // internal processing

            private static void Label(GUILayoutOption[] options = null) {
                // Draw the control
                if(Engine.labelStyle == null) GUILayout.Label(Engine.labelContent, options);
                else GUILayout.Label(Engine.labelContent, Engine.labelStyle, options);

                // Draw the tooltip
                Engine.DrawTooltip();
            }

            #endregion Label

            #region Button

            public static bool Button(GUIContent content) {
                Engine.InitializeLabel();
                Engine.SetLabel(content);
                return Button();
            }

            public static bool Button(string label) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return Button();
            }

            // internal processing

            private static bool Button() {
                bool result;

                if(Engine.renderingMode == Engine.RenderingMode.Fixed) { // do a manual GUI layout with fixed widths

                    GUIStyle controlStyle = GUI.skin.button;
                    float marginTop;
                    Rect reserveRect = Engine.ReserveButtonRect(controlStyle, out marginTop);
                    result = Engine.DrawFixedButton(reserveRect, marginTop);

                } else { // automatic layout

                    // Draw control
                    if(Engine.hasLabel) {
                        if(Engine.labelStyle == null) result = GUILayout.Button(Engine.labelContent);
                        else result = GUILayout.Button(Engine.labelContent, Engine.labelStyle);
                    } else {
                        if(Engine.labelStyle == null) result = GUILayout.Button("");
                        else result = GUILayout.Button("", Engine.labelStyle);
                    }

                    // Draw tooltip
                    Engine.DrawTooltip();
                }

                return result;
            }

            #endregion

        }

        public static class EditorLayout {

            #region Main

            public static void Initialize() {
                // Initialize static child classes
                LabeledControl.Initialize();
            }

            public static void Update() {
                // Update the child classes
                LabeledControl.Update();
            }

            #endregion

            #region Controls

            #region Label

            public static void Label(GUIContent content) {
                Engine.InitializeLabel();
                Engine.SetLabel(content);
                Label();
            }
            public static void Label(GUIContent content, GUIStyle style) {
                Engine.InitializeLabel();
                Engine.SetLabel(content);
                Engine.SetStyle(style);
                Label();
            }
            public static void Label(GUIContent content, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(content);
                Label(options);
            }
            public static void Label(GUIContent content, GUIStyle style, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(content);
                Engine.SetStyle(style);
                Label(options);
            }
            public static void Label(string label) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                Label();
            }
            public static void Label(string label, GUIStyle style) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                Engine.SetStyle(style);
                Label();
            }
            public static void Label(string label, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                Label(options);
            }
            public static void Label(string label, GUIStyle style, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                Engine.SetStyle(style);
                Label(options);
            }

            // internal processing

            private static void Label(GUILayoutOption[] options = null) {

                if(Engine.renderingMode == Engine.RenderingMode.Fixed) { // do a manual GUI layout with fixed widths

                    float marginTop, labelWidth;
                    Rect reserveRect = Engine.ReserveLabelRect(out marginTop);
                    Rect labelRect = Engine.DrawFixedLabel(reserveRect, marginTop, out labelWidth);

                } else { // automatic layout

                    // Draw the control
                    if(Engine.labelStyle == null) EditorGUILayout.LabelField(Engine.labelContent, options);
                    else EditorGUILayout.LabelField(Engine.labelContent, Engine.labelStyle, options);

                    // Draw the tooltip
                    Engine.DrawTooltip();

                }

            }

            #endregion Label

            #region Toggle

            public static bool Toggle(bool value) {
                Engine.InitializeLabel();
                return ProcessToggle(value);
            }

            public static bool Toggle(bool value, GUIStyle style) {
                Engine.InitializeLabel();
                Engine.SetStyle(style);
                return ProcessToggle(value);
            }

            public static bool Toggle(bool value, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                return ProcessToggle(value, options);
            }

            public static bool Toggle(bool value, GUIStyle style, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetStyle(style);
                return ProcessToggle(value, options);
            }

            public static bool Toggle(GUIContent label, bool value) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessToggle(value);
            }

            public static bool Toggle(GUIContent label, GUIStyle style, bool value) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                Engine.SetStyle(style);
                return ProcessToggle(value);
            }

            public static bool Toggle(GUIContent label, bool value, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessToggle(value, options);
            }

            public static bool Toggle(GUIContent label, bool value, GUIStyle style, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                Engine.SetStyle(style);
                return ProcessToggle(value, options);
            }

            // internal processing

            private static bool ProcessToggle(bool value, GUILayoutOption[] options = null) {
                Rect r = EditorGUILayout.BeginHorizontal(options);
                bool result;

                if(Engine.renderingMode == Engine.RenderingMode.Fixed) { // do a manual GUI layout with fixed widths

                    GUIStyle controlStyle = EditorStyles.toggle;
                    Rect controlRect = Engine.DrawFixedLabelAndGetControlRect(r.width, controlStyle);
                    result = EditorGUI.Toggle(controlRect, value, controlStyle);

                } else { // automatic layout

                    if(Engine.hasLabel) {
                        EditorGUILayout.PrefixLabel(Engine.labelContent);
                        Engine.DrawTooltip();
                    }
                    result = EditorGUILayout.Toggle(value);

                }

                EditorGUILayout.EndHorizontal();

                return result;
            }

            #endregion

            #region IntField

            public static int IntField(int value) {
                Engine.InitializeLabel();
                return ProcessIntField(value);
            }

            public static int IntField(int value, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                return ProcessIntField(value, options);
            }

            public static int IntField(GUIContent label, int value) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessIntField(value);
            }

            public static int IntField(GUIContent label, int value, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessIntField(value, options);
            }

            // internal processing

            private static int ProcessIntField(int value, GUILayoutOption[] options = null) {
                return LabeledControl.IntField(value, options);
            }

            #endregion

            #region FloatField

            public static float FloatField(float value) {
                Engine.InitializeLabel();
                return ProcessFloatField(value);
            }

            public static float FloatField(float value, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                return ProcessFloatField(value, options);
            }

            public static float FloatField(GUIContent label, float value) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessFloatField(value);
            }

            public static float FloatField(GUIContent label, float value, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessFloatField(value, options);
            }

            // internal processing

            private static float ProcessFloatField(float value, GUILayoutOption[] options = null) {
                return LabeledControl.FloatField(value, options);
            }

            #endregion

            #region TextField

            public static string TextField(string value) {
                Engine.InitializeLabel();
                return ProcessTextField(value);
            }

            public static string TextField(string value, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                return ProcessTextField(value, options);
            }

            public static string TextField(GUIContent label, string value) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessTextField(value);
            }

            public static string TextField(GUIContent label, string value, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessTextField(value, options);
            }

            // internal processing

            private static string ProcessTextField(string value, GUILayoutOption[] options = null) {
                Rect r = EditorGUILayout.BeginHorizontal(options);

                string result;

                if(Engine.renderingMode == Engine.RenderingMode.Fixed) { // do a manual GUI layout with fixed widths

                    GUIStyle controlStyle = EditorStyles.textField;
                    Rect controlRect = Engine.DrawFixedLabelAndGetControlRect(r.width, controlStyle);
                    result = EditorGUI.TextField(controlRect, value, controlStyle);

                } else { // automatic layout

                    if(Engine.hasLabel) {
                        EditorGUILayout.PrefixLabel(Engine.labelContent);
                        Engine.DrawTooltip();
                    }
                    result = EditorGUILayout.TextField(value);

                }

                EditorGUILayout.EndHorizontal();
                return result;
            }

            #endregion

            #region ColorField

            public static Color ColorField(Color value) {
                Engine.InitializeLabel();
                return ProcessColorField(value);
            }

            public static Color ColorField(Color value, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                return ProcessColorField(value, options);
            }

            public static Color ColorField(GUIContent label, Color value) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessColorField(value);
            }

            public static Color ColorField(GUIContent label, Color value, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessColorField(value, options);
            }

            // internal processing

            private static Color ProcessColorField(Color value, GUILayoutOption[] options = null) {
                Color result = new Color();

                if(Engine.renderingMode == Engine.RenderingMode.Fixed) { // do a manual GUI layout with fixed widths
                    Rect r = EditorGUILayout.BeginHorizontal(options);

                    GUIStyle controlStyle = EditorStyles.colorField;
                    Rect controlRect = Engine.DrawFixedLabelAndGetControlRect(r.width, controlStyle);

                    // REMOVED TRY / CATCH WRAPPER BECAUSE IT CAUSES ERRORS TO BE THROWN BY OBJECTFIELD PICKERS -- CANNOT BE SILENCED ON MAC
                    //try { // SERIOUS BUG with ObjectField and ColorField!
                        result = EditorGUI.ColorField(controlRect, value);
                    //} catch {
                    //    result = value; // reassign the original value
                    //}

                    EditorGUILayout.EndHorizontal();

                } else { // automatic layout

                    if(Engine.hasLabel) {
                        EditorGUILayout.PrefixLabel(Engine.labelContent);
                        Engine.DrawTooltip();
                    }

                    // Draw control
                    // SERIOUS BUG with ObjectField and ColorField!
                    // When you have them wrapped in try/catch, they throw an exception every time which kicks you out
                    // Wrap them in a try/catch and silently squelch the "error"
                    // This error doesn't seem to be real -- it's just an ExitGUI exception.
                    // REMOVED TRY / CATCH WRAPPER BECAUSE IT CAUSES ERRORS TO BE THROWN BY OBJECTFIELD PICKERS -- CANNOT BE SILENCED ON MAC
                    //try {
                        result = EditorGUILayout.ColorField(value);
                    //} catch {
                    //    result = value; // reassign the original value
                    //}
                }

                return result;
            }

            #endregion

            #region ObjectField

            public static Object ObjectField(Object value, System.Type type, bool allowSceneObjects) {
                Engine.InitializeLabel();
                return ProcessObjectField(value, type, allowSceneObjects);
            }

            public static Object ObjectField(Object value, System.Type type, bool allowSceneObjects, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                return ProcessObjectField(value, type, allowSceneObjects, options);
            }

            public static Object ObjectField(GUIContent label, Object value, System.Type type, bool allowSceneObjects) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessObjectField(value, type, allowSceneObjects);
            }

            public static Object ObjectField(GUIContent label, Object value, System.Type type, bool allowSceneObjects, params GUILayoutOption[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(label);
                return ProcessObjectField(value, type, allowSceneObjects, options);
            }

            // internal processing

            private static Object ProcessObjectField(Object value, System.Type type, bool allowSceneObjects, GUILayoutOption[] options = null) {
                Object result;

                if(Engine.renderingMode == Engine.RenderingMode.Fixed) { // do a manual GUI layout with fixed widths

                    Rect r = EditorGUILayout.BeginHorizontal(options);

                    GUIStyle controlStyle = EditorStyles.objectField;
                    Rect controlRect = Engine.DrawFixedLabelAndGetControlRect(r.width, controlStyle);

                    // REMOVED TRY / CATCH WRAPPER BECAUSE IT CAUSES ERRORS TO BE THROWN BY OBJECTFIELD PICKERS -- CANNOT BE SILENCED ON MAC
                    //try { // SERIOUS BUG with ObjectField and ColorField! Catch the error silently
                        result = EditorGUI.ObjectField(controlRect, value, type, allowSceneObjects);
                    //} catch {
                    //    result = value; // reassign the original value
                    //}

                    EditorGUILayout.EndHorizontal();

                } else { // automatic layout

                    // Draw control
                    // SERIOUS BUG with ObjectField and ColorField!
                    // When you have them wrapped in try/catch, they throw an exception every time which kicks you out
                    // Wrap them in a try/catch and silently squelch the "error"
                    // This error doesn't seem to be real -- it's just an ExitGUI exception.
                    // REMOVED TRY / CATCH WRAPPER BECAUSE IT CAUSES ERRORS TO BE THROWN BY OBJECTFIELD PICKERS -- CANNOT BE SILENCED ON MAC
                    //try {
                        if(Engine.hasLabel) result = EditorGUILayout.ObjectField(Engine.labelContent, value, type, allowSceneObjects, options);
                        else result = EditorGUILayout.ObjectField(value, type, allowSceneObjects, options);
                    //} catch {
                    //    result = value; // reassign the original value
                    //}

                    // Draw tooltip
                    Engine.DrawTooltip();

                    /* // This version fixes the hover tooltip problem but the image under frame list gets squashed!
                    EditorGUILayout.BeginHorizontal(options);

                    EditorGUILayout.BeginVertical();
                    if(hasLabel) {
                        EditorGUILayout.PrefixLabel(labelContent);
                        DrawTooltip();
                    }

                    Object result = EditorGUILayout.ObjectField(value, type, allowSceneObjects);
                    EditorGUILayout.EndHorizontal();
                    return result;
                    */
                }


                return result;
            }

            #endregion

            #region Popup

            public static int Popup(GUIContent content, int selectedIndex, GUIContent[] options) {
                Engine.InitializeLabel();
                Engine.SetLabel(content);
                return Popup(selectedIndex, options);
            }

            // internal processing
            private static int Popup(int selectedIndex, GUIContent[] options, GUILayoutOption[] layoutOptions = null) {
                Rect r = EditorGUILayout.BeginHorizontal(layoutOptions);
                int result;

                if(Engine.renderingMode == Engine.RenderingMode.Fixed) { // do a manual GUI layout with fixed widths

                    GUIStyle controlStyle = EditorStyles.popup;
                    Rect controlRect = Engine.DrawFixedLabelAndGetControlRect(r.width, controlStyle);
                    result = EditorGUI.Popup(controlRect, selectedIndex, options, controlStyle);

                } else { // automatic layout

                    if(Engine.hasLabel) {
                        EditorGUILayout.PrefixLabel(Engine.labelContent);
                        Engine.DrawTooltip();
                    }
                    if(Engine.labelStyle == null) result = EditorGUILayout.Popup(selectedIndex, options);
                    else result = EditorGUILayout.Popup(selectedIndex, options, Engine.labelStyle);

                }

                EditorGUILayout.EndHorizontal();
                return result;
            }

            #endregion

            #endregion

            #region Layout

            public static Rect BeginHorizontal() {
                return Engine.BeginHorizontal();
            }
            public static Rect BeginHorizontal(GUIStyle style) {
                return Engine.BeginHorizontal(style);
            }
            public static Rect BeginHorizontal(GUIStyle style, params GUILayoutOption[] options) {
                return Engine.BeginHorizontal(style, options);
            }
            public static Rect BeginHorizontal(params GUILayoutOption[] options) {
                return Engine.BeginHorizontal(options);
            }
            public static void EndHorizontal() {
                Engine.EndHorizontal();
            }

            public static Rect BeginVertical() {
                return Engine.BeginVertical();
            }
            public static Rect BeginVertical(GUIStyle style) {
                return Engine.BeginVertical(style);
            }
            public static Rect BeginVertical(GUIStyle style, params GUILayoutOption[] options) {
                return Engine.BeginVertical(style, options);
            }
            public static Rect BeginVertical(params GUILayoutOption[] options) {
                return Engine.BeginVertical(options);
            }
            public static void EndVertical() {
                Engine.EndVertical();
            }

            public static void BeginRegion(GUIStyle style = null) {
                Engine.BeginRegion(style);
            }
            public static void EndRegion() {
                Engine.EndRegion();
            }

            public static Vector2 BeginScrollView(Vector2 scrollPosition) {
                Vector2 result = EditorGUILayout.BeginScrollView(scrollPosition);
                Engine.BeginScrollView(scrollPosition);
                return result;
            }
            public static void EndScrollView() {
                Engine.EndScrollView();
                EditorGUILayout.EndScrollView();
            }

            public static void BeginWindow(GUIStyle style = null) {
                if(style == null) style = GUI.skin.window;
                BeginRegion(style);

            }
            public static void EndWindow() {
                EndRegion();
            }

            #endregion

            // Private Classes

            #region Labeled Control

            private static class LabeledControl {

                private static SpriteFactory.Utils.DataClasses.Pool<Control> prevControls;
                private static SpriteFactory.Utils.DataClasses.Pool<Control> currentControls;
                private static int currentControlId;
                private static bool controlsBuilt;
                private static bool hasPrevData;

                // Label control stuff
                private static bool clicked;
                private static int clickedControlId;

                private static bool rebuildControls {
                    get {
                        if(Event.current.type == EventType.Repaint) return false;
                        return true;
                    }
                }

                #region Main

                public static void Initialize() {
                    // Clear vars
                    currentControls = new SpriteFactory.Utils.DataClasses.Pool<Control>(20, true, 20);
                    prevControls = new SpriteFactory.Utils.DataClasses.Pool<Control>(20, true, 20);
                    currentControlId = -1;
                    controlsBuilt = false;
                    hasPrevData = false;
                    clicked = false;
                    clickedControlId = -1;
                }

                public static void Update() {
                    currentControlId = -1; // reset the count every event cycle

                    // Layout
                    // Unity figures out where controls go
                    // Mouse/key/drag/etc
                    // Some action takes place requiring layout to be rebuilt
                    // Layout again
                    // rebuilds controls
                    // Repaint
                    // Draws controls

                    // Rects from layout data is only available in REPAINT
                    // Otherwise rects are 0

                    // We need data from Repaint to get the label rect

                    // CONTROLS must be cleared every layout
                    // CHANGES to controls (add/remove) can happen on mouse events and other events
                    // this means controls really should be rebuilt on all events except repaint
                    // DATA must be cleared every repaint

                    // We are essentially getting rect data 1 frame behind
                    // If controls change before the rect is processed, data may not be good anymore
                    // this may happen is mouse or key triggers a change in controls and layout is rebuilt

                    // Layout, we build the controls
                    // If the number of controls changes, don't allow use of old data

                    Event e = Event.current;

                    // Set prev data state based on current event
                    if(e.type == EventType.Repaint) {
                        hasPrevData = true; // flag prev data valid every repaint cycle
                    } else if(prevControls.Length != currentControls.Length) { // clear prev data if the number of controls changed last cycle (this won't filter out if the controls change but the number stays the same though)
                        hasPrevData = false; // prevent anything from using this old data if number of controls changed
                    }

                    // Clear the controls at the beginning of every event except repaint
                    if(rebuildControls) {

                        // save existing controls as previous before clearing
                        if(e.type == EventType.Layout) { // only save over previous during layout because we need to keep the data from the previous repaint and not get written over by all the mouse events
                            // repaint data may be several cycles old, and if any controls are changed by other events, they won't be used anyway
                            // one possible flaw: if the number of controls changes from an other event BUT the number of controls stays the same, it will allow it to use that data because we only check
                            // that the number is equal. Result: we might use the data from the wrong control, say a click turns one control off and another on in some other location, the rect will be for the
                            // one that was turned off and it will use it. Should only be for 1 event frame so probably no big deal.
                            prevControls.Clear();
                            for(int i = 0; i < currentControls.Length; i++) {
                                prevControls.Add(currentControls[i]);
                            }
                        }

                        // clear the current controls
                        currentControls.Clear();
                        controlsBuilt = false;
                    }

                    // Clear click vars when mouse is released regardless
                    if(clicked) {
                        if(e.type == EventType.MouseUp && e.button == 0) {
                            clicked = false;
                            e.Use();
                        }
                    }
                }

                #endregion

                #region User Controls

                public static int IntField(int value, GUILayoutOption[] options = null) {
                    InitControl();

                    Rect r = EditorGUILayout.BeginHorizontal(options);
                    int result;

                    if(Engine.renderingMode == Engine.RenderingMode.Fixed) { // do a manual GUI layout with fixed widths

                        GUIStyle controlStyle = EditorStyles.textField;

                        // Draw label if necessary
                        float marginTop;
                        float labelWidth;
                        Rect reserveRect = Engine.ReserveControlAndLabelRect(r.width, controlStyle, out marginTop);
                        Rect labelRect = Engine.DrawFixedLabel(reserveRect, marginTop, out labelWidth);
                        Rect controlRect = Engine.FindControlRect(labelRect, labelWidth);

                        Control control = GetCurrentControl();
                        control.hasRect = true;
                        control.labelRect = labelRect;
                        control.controlRect = controlRect;

                        int delta = HandleControlLabel_Int(false); // handle mouse drag
                        if(delta != 0) value += delta;

                        EditorGUIUtility.AddCursorRect(labelRect, MouseCursor.SlideArrow);
                        result = EditorGUI.IntField(controlRect, value, controlStyle);

                    } else { // automatic layout

                        if(Engine.hasLabel) {
                            EditorGUILayout.PrefixLabel(Engine.labelContent);
                            int delta = HandleControlLabel_Int(); // handle mouse drag
                            Engine.DrawTooltip();

                            if(delta != 0) value += delta;
                            result = EditorGUILayout.IntField(value);
                            StoreControlRect(); // get the rect from the control for next cycle
                        } else {
                            result = EditorGUILayout.IntField(value);
                        }

                    }

                    EditorGUILayout.EndHorizontal();

                    return result;
                }

                public static float FloatField(float value, GUILayoutOption[] options = null) {
                    InitControl();

                    Rect r = EditorGUILayout.BeginHorizontal(options);
                    float result;

                    if(Engine.renderingMode == Engine.RenderingMode.Fixed) { // do a manual GUI layout with fixed widths

                        GUIStyle controlStyle = EditorStyles.textField;

                        // Draw label if necessary
                        float marginTop;
                        float labelWidth;
                        Rect reserveRect = Engine.ReserveControlAndLabelRect(r.width, controlStyle, out marginTop);
                        Rect labelRect = Engine.DrawFixedLabel(reserveRect, marginTop, out labelWidth);
                        Rect controlRect = Engine.FindControlRect(labelRect, labelWidth);

                        Control control = GetCurrentControl();
                        control.hasRect = true;
                        control.labelRect = labelRect;
                        control.controlRect = controlRect;

                        float delta = HandleControlLabel_Float(false); // handle mouse drag
                        if(delta != 0.0f) value += delta * 0.1f;

                        EditorGUIUtility.AddCursorRect(labelRect, MouseCursor.SlideArrow);
                        result = EditorGUI.FloatField(controlRect, value, controlStyle);

                    } else { // automatic layout

                        if(Engine.hasLabel) {
                            EditorGUILayout.PrefixLabel(Engine.labelContent);
                            float delta = HandleControlLabel_Float(); // handle mouse drag
                            Engine.DrawTooltip();

                            if(delta != 0) value += delta * 0.10f;
                            result = EditorGUILayout.FloatField(value);
                            StoreControlRect(); // get the rect from the control for next cycle
                        } else {
                            result = EditorGUILayout.FloatField(value);
                        }

                    }

                    EditorGUILayout.EndHorizontal();

                    return result;
                }

                #endregion

                #region Control Management

                private static void InitControl() {
                    currentControlId++; // advance the control counter
                    if(rebuildControls) // assign this control an id
                        AddControl(currentControlId); // create a control for this
                }

                private static int AddControl(int controlId) {
                    controlsBuilt = true;
                    int index = currentControls.Add(new Control());
                    currentControls[index].controlId = controlId;
                    return index;
                }

                private static Control GetCurrentControl() {
                    if(!controlsBuilt || currentControlId < 0 || currentControlId >= currentControls.Length) return null;
                    return currentControls[currentControlId];
                }

                private static Control GetCurrentControlLastCycle() {
                    if(currentControls.Length > prevControls.Length) hasPrevData = false; // A new control has been built so invalidate prev data. This only catches extra controls. Fewer is caught at beginning of Update.
                    if(!hasPrevData) return null;
                    if(!controlsBuilt || currentControlId < 0 || currentControlId >= currentControls.Length) return null;
                    return prevControls[currentControlId];
                }

                #endregion

                #region Int / Float Label Control Handling

                private static int HandleControlLabel_Int(bool autoLayout = true) {
                    return (int)HandleControlLabel_Float(autoLayout);
                }

                private static float HandleControlLabel_Float(bool autoLayout = true) {
                    if(!controlsBuilt) return 0.0f;
                    if(!GUI.enabled) return 0.0f;

                    Event e = Event.current;
                    if(e.type == EventType.Layout) return 0.0f;

                    if(e.type == EventType.Repaint) { // this is a repaint event

                        if(autoLayout) { // auto layout rendering mode
                            // Get rect from label and store in currentControl for use next cycle
                            LabeledControl.Control currentFrameControl = GetCurrentControl();
                            currentFrameControl.labelRect = GUILayoutUtility.GetLastRect(); // get the rect in the repaint event
                            currentFrameControl.hasRect = true;
                            EditorGUIUtility.AddCursorRect(currentFrameControl.labelRect, MouseCursor.SlideArrow);
                        }

                    } else { // any other event

                        LabeledControl.Control prevCycleControl = GetCurrentControlLastCycle(); // get the control from the previous frame because it has rect data from the Repaint event
                        if(prevCycleControl == null) return 0.0f; // control count may have changed since last cycle and this cycle, if that's the case, we cannot use this data

                        if(e.type == EventType.MouseDown) {
                            if(e.button == 0 && prevCycleControl.labelRect.Contains(e.mousePosition)) {
                                clicked = true;
                                clickedControlId = prevCycleControl.controlId;
                                int unityControlId = GUIUtility.GetControlID(prevCycleControl.controlRect.GetHashCode(), FocusType.Keyboard);
                                GUIUtility.keyboardControl = 0; // defocus keyboard
                                e.Use();
                            }
                        } else if(e.type == EventType.MouseDrag) {
                            if(clicked && clickedControlId == prevCycleControl.controlId) {
                                e.Use();
                                return e.delta.x;
                            }
                        }
                    }

                    return 0.0f;
                }

                private static void StoreControlRect() {
                    Control control = GetCurrentControl();
                    Event e = Event.current;

                    // Get the rect from the main control
                    if(controlsBuilt && e.type == EventType.repaint) {
                        control.controlRect = GUILayoutUtility.GetLastRect(); // get the rect in the repaint event
                        control.hasRect = true;
                    }
                }

                private static void StoreControlRect(Rect rect) {
                    Control control = GetCurrentControl();
                    if(control == null) return;
                    control.controlRect = rect;
                    control.hasRect = true;
                }

                #endregion

                #region Classes

                public class Control {
                    public int controlId;
                    public Rect labelRect;
                    public Rect controlRect;
                    public bool hasRect;
                }

                #endregion
            }

            #endregion

        }
    }

    internal static class SerializedObjectTools {

        public static void LogProperties(SerializedObject so, bool includeChilren = true) {
            so.Update();
            SerializedProperty propertyLogger = so.GetIterator();
            while(true) {
                Debug.Log("name = " + propertyLogger.name + " type = " + propertyLogger.type);
                if(!propertyLogger.Next(includeChilren)) break;
            }
        }

        public static void LogAllValues(SerializedProperty serializedProperty) {
            Debug.Log("PROPERTY: name = " + serializedProperty.name + " type = " + serializedProperty.type);
            Debug.Log("animationCurveValue = " + serializedProperty.animationCurveValue);
            Debug.Log("arraySize = " + serializedProperty.arraySize);
            Debug.Log("boolValue = " + serializedProperty.boolValue);
            Debug.Log("boundsValue = " + serializedProperty.boundsValue);
            Debug.Log("colorValue = " + serializedProperty.colorValue);
            Debug.Log("depth = " + serializedProperty.depth);
            Debug.Log("editable = " + serializedProperty.editable);
            Debug.Log("enumNames = " + serializedProperty.enumNames);
            Debug.Log("enumValueIndex = " + serializedProperty.enumValueIndex);
            Debug.Log("floatValue = " + serializedProperty.floatValue);
            Debug.Log("hasChildren = " + serializedProperty.hasChildren);
            Debug.Log("hasMultipleDifferentValues = " + serializedProperty.hasMultipleDifferentValues);
            Debug.Log("hasVisibleChildren = " + serializedProperty.hasVisibleChildren);
            Debug.Log("intValue = " + serializedProperty.intValue);
            Debug.Log("isAnimated = " + serializedProperty.isAnimated);
            Debug.Log("isArray = " + serializedProperty.isArray);
            Debug.Log("isExpanded = " + serializedProperty.isExpanded);
            Debug.Log("isInstantiatedPrefab = " + serializedProperty.isInstantiatedPrefab);
            Debug.Log("name = " + serializedProperty.name);
            Debug.Log("objectReferenceInstanceIDValue = " + serializedProperty.objectReferenceInstanceIDValue);
            Debug.Log("objectReferenceValue = " + serializedProperty.objectReferenceValue);
            Debug.Log("prefabOverride = " + serializedProperty.prefabOverride);
            Debug.Log("propertyPath = " + serializedProperty.propertyPath);
            Debug.Log("propertyType = " + serializedProperty.propertyType);
            Debug.Log("quaternionValue = " + serializedProperty.quaternionValue);
            Debug.Log("rectValue = " + serializedProperty.rectValue);
            Debug.Log("serializedObject = " + serializedProperty.serializedObject);
            Debug.Log("stringValue = " + serializedProperty.stringValue);
            Debug.Log("tooltip = " + serializedProperty.tooltip);
            Debug.Log("type = " + serializedProperty.type);
            Debug.Log("vector2Value = " + serializedProperty.vector2Value);
            Debug.Log("vector3Value = " + serializedProperty.vector3Value);
        }
    }

    internal static class UnityTools {
        /// <summary>
        /// Rename a file with Unity's AssetDatabase.
        /// You cannot change a file's extension with this method.
        /// </summary>
        /// <param name="oldFilePath">Path to the file to be renamed.</param>
        /// <param name="newFileNameNoExtension">New name of the file. File extensions will be stripped.</param>
        /// <param name="deleteConflicts">If a file exists with the new file name, delete it first before renaming.</param>
        public static void RenameFile(string oldFilePath, string newFileNameNoExtension, bool deleteConflicts = false) {
            if(oldFilePath == "" || oldFilePath == string.Empty || oldFilePath == null) throw new System.Exception("Invalid file path!");
            string path = Path.GetDirectoryName(oldFilePath);
            if(!Directory.Exists(path)) throw new System.Exception("Path does not exist!");

            string extension = Path.GetExtension(oldFilePath); // get the extension from the original file -- this function cannot change extensions
            string newFilePath = path + "/" + newFileNameNoExtension + extension;
            if(File.Exists(newFilePath)) { // there is a file that already exists with the new name we want to use, this should not happen and we can safely delete this
                if(!deleteConflicts) throw new System.Exception(newFilePath + " already exists! Trying to rename file to the same name. Failed.");
                bool result = AssetDatabase.DeleteAsset(newFilePath); // delete the conflicting file
                if(!result) throw new System.Exception("Error deleting file " + newFilePath);
                Debug.LogWarning(newFilePath + " already exists! Trying to rename file to the same name. The file was deleted.");
            }
            if(newFileNameNoExtension.Contains(".")) newFileNameNoExtension = Path.GetFileNameWithoutExtension(newFileNameNoExtension); // remove extension if any
            string renameResult = AssetDatabase.RenameAsset(oldFilePath, newFileNameNoExtension); // rename the file
            if(renameResult != "") throw new System.Exception(renameResult); // could not rename file
        }

        public static T[] FindAllComponents<T>(GameObject gameObject) where T : Component {
            if(gameObject == null) return null;
            Transform transform = gameObject.GetComponent<Transform>();
            return FindAllComponents<T>(transform);
        }

        public static T[] FindAllComponents<T>(Transform transform) where T : Component {
            if(transform == null) return null;
            T[] allComponents = null;

            // Get components in this transform
            T[] components = transform.GetComponents<T>();
            if(components != null && components.Length > 0) SpriteFactory.Utils.ArrayTools.Combine<T>(ref allComponents, components);

            // Get components in children
            foreach(Transform xform in transform) {
                components = FindAllComponents<T>(xform);
                if(components != null && components.Length > 0) SpriteFactory.Utils.ArrayTools.Combine<T>(ref allComponents, components);
            }
            return allComponents;
        }

        public static class Undo {

            public static void RegisterCreatedObjectUndo(Object objectToUndo, string name) {
                // CURRENTLY BUGGY SO NOT INCLUDING IN THIS RELEASE
                return;

                /*if(SpriteFactory.Utils.UnityTools.unityVersion < SpriteFactory.Utils.UnityTools.UnityVersion.UNITY_4_3) return;
                RegisterCreatedObjectUndo_U43(objectToUndo, name);
                */
            }

            public static void RegisterCompleteObjectUndo(Object objectToUndo, string name) {
                // CURRENTLY BUGGY SO NOT INCLUDING IN THIS RELEASE
                return;

                /*if(SpriteFactory.Utils.UnityTools.unityVersion < SpriteFactory.Utils.UnityTools.UnityVersion.UNITY_4_3) return;
                RegisterCompleteObjectUndo_U43(objectToUndo, name);
                */

            }

            public static Component AddComponent(GameObject gameObject, System.Type type) {
                // CURRENTLY BUGGY SO NOT INCLUDING IN THIS RELEASE
                return gameObject.AddComponent(type);
                /*
                if(SpriteFactory.Utils.UnityTools.unityVersion < SpriteFactory.Utils.UnityTools.UnityVersion.UNITY_4_3) {
                    return gameObject.AddComponent(type); // no undo support, just add component
                }
                return AddComponent_U43(gameObject, type);
                */
            }

            public static void DestroyObjectImmediate(Object objectToUndo) {
                // CURRENTLY BUGGY SO NOT INCLUDING IN THIS RELEASE
                UnityEngine.Object.DestroyImmediate(objectToUndo); // no undo support, just destroy

                /*
                if(SpriteFactory.Utils.UnityTools.unityVersion < SpriteFactory.Utils.UnityTools.UnityVersion.UNITY_4_3) {
                    UnityEngine.Object.DestroyImmediate(objectToUndo); // no undo support, just destroy
                    return;
                }
                DestroyObjectImmediate_U43(objectToUndo);
                */
            }

            public static void RecordObject(Object objectToUndo, string name) {
                // CURRENTLY BUGGY SO NOT INCLUDING IN THIS RELEASE
                //if(SpriteFactory.Utils.UnityTools.unityVersion < SpriteFactory.Utils.UnityTools.UnityVersion.UNITY_4_3) return;
                //RecordObject_U43(objectToUndo, name);
            }

            public static void CollapseUndoOperations(int groupIndex) {
                // CURRENTLY BUGGY SO NOT INCLUDING IN THIS RELEASE
                //if(SpriteFactory.Utils.UnityTools.unityVersion < SpriteFactory.Utils.UnityTools.UnityVersion.UNITY_4_3) return;
                //CollapseUndoOperations_U43(groupIndex);
            }

            public static int GetCurrentGroup() {
                return -1;
                // CURRENTLY BUGGY SO NOT INCLUDING IN THIS RELEASE
                //if(SpriteFactory.Utils.UnityTools.unityVersion < SpriteFactory.Utils.UnityTools.UnityVersion.UNITY_4_3) return -1;
                //return GetCurrentGroup_U43();
            }

            public static void CollapseCurrentGroupUndoOperations() {
                return;
                // CURRENTLY BUGGY SO NOT INCLUDING IN THIS RELEASE
                //CollapseUndoOperations(GetCurrentGroup());
            }

            // Do the actions
            private static void RegisterCreatedObjectUndo_U43(Object objectToUndo, string name) {
                UnityEditor.Undo.RegisterCreatedObjectUndo(objectToUndo, name);
            }

            private static void RegisterCompleteObjectUndo_U43(Object objectToUndo, string name) {
                UnityEditor.Undo.RegisterCompleteObjectUndo(objectToUndo, name);
            }

            private static Component AddComponent_U43(GameObject gameObject, System.Type type) {
                return UnityEditor.Undo.AddComponent(gameObject, type);
            }

            private static void DestroyObjectImmediate_U43(Object objectToUndo) {
                UnityEditor.Undo.DestroyObjectImmediate(objectToUndo);
            }

            private static void RecordObject_U43(Object objectToUndo, string name) {
                UnityEditor.Undo.RecordObject(objectToUndo, name);
            }

            private static void CollapseUndoOperations_U43(int groupIndex) {
                UnityEditor.Undo.CollapseUndoOperations(groupIndex);
            }

            private static int GetCurrentGroup_U43() {
                return UnityEditor.Undo.GetCurrentGroup();
            }
        }

    }

    internal static class FileTools {
        public static string ConvertBackslashes(string path) {
            if(path == null || path == "") return path;
            return path.Replace('\\', '/');
        }

        public static bool WriteBinaryFile(string pathAndFileName, byte[] bytes) {
            try {
                using(FileStream fs = new FileStream(pathAndFileName, FileMode.Create)) {
                    using(BinaryWriter bw = new BinaryWriter(fs)) {
                        bw.Write(bytes);
                    }
                }
            } catch {
                return false;
            }
            return true;
        }
    }

    internal static class AssetTools {

        public static T LoadAssetFromGUID<T>(string guid) where T : Object {
            string path = GetAssetPathFromGUID(guid);
            if(path == null) return null;

            return (T)AssetDatabase.LoadAssetAtPath(path, typeof(T));
        }

        public static string GetGUID(Object asset) {
            string path = GetAssetPath(asset);
            if(path == null) return null;

            return AssetDatabase.AssetPathToGUID(path);
        }

        public static string GetAssetPathFromGUID(string guid) {
            if(guid == null || guid == string.Empty) return null;

            string path = AssetDatabase.GUIDToAssetPath(guid);
            if(path == null || path == string.Empty) return null;

            return path;
        }

        public static string GetAssetPath(Object asset) {
            if(asset == null) return null;
            string path = AssetDatabase.GetAssetPath(asset);
            if(path == null || path == string.Empty) return null;
            return path;
        }

        public static void FixTextureImporterSettings(string[] textureGUIDs) {
            if(textureGUIDs == null || textureGUIDs.Length == 0) return;

            bool deselected = false;
            List<string> texturesToImportPaths = new List<string>();

            // Change all textures to be read/writeable
            for(int i = 0; i < textureGUIDs.Length; i++) {
                string path = AssetDatabase.GUIDToAssetPath(textureGUIDs[i]);
                if(path == null || path == string.Empty) continue;
                FixTextureImporterSettings(path, ref deselected, ref texturesToImportPaths);
            }

            // Save and re-import the changed textures
            if(texturesToImportPaths.Count > 0) { // we have some textures that were changed
                AssetDatabase.SaveAssets();
                for(int i = 0; i < texturesToImportPaths.Count; i++) {
                    AssetDatabase.ImportAsset(texturesToImportPaths[i], ImportAssetOptions.ForceUpdate); // force re-import textures
                }
            }
        }

        public static void FixTextureImporterSettings(Texture2D[] textures) {
            if(textures == null || textures.Length == 0) return;

            bool deselected = false;
            List<string> texturesToImportPaths = new List<string>();

            // Change all textures to be read/writeable
            for(int i = 0; i < textures.Length; i++) {
                if(textures[i] == null) continue;
                string path = AssetDatabase.GetAssetPath(textures[i]);
                FixTextureImporterSettings(path, ref deselected, ref texturesToImportPaths);
            }

            // Save and re-import the changed textures
            if(texturesToImportPaths.Count > 0) { // we have some textures that were changed
                AssetDatabase.SaveAssets();
                for(int i = 0; i < texturesToImportPaths.Count; i++) {
                    AssetDatabase.ImportAsset(texturesToImportPaths[i], ImportAssetOptions.ForceUpdate); // force re-import textures
                }
            }
        }

        public static void FixTextureImporterSettings(string pathToTexture, ref bool deselected, ref List<string> texturesToImportPaths) {
            EditorManager.externalEditorTools.FixTextureImporterSettings(pathToTexture, ref deselected, ref texturesToImportPaths);
        }

        public static ColorImage LoadTextureFromGUIDAsColorImage(string guid) {
            Texture2D texture = LoadAssetFromGUID<Texture2D>(guid);
            if(texture == null) return null;

            TextureLoader textureLoader = new TextureLoader(texture, false);
            texture = null; // don't hold it in a variable so it can be cleared

            return textureLoader.ConvertToColorImage(true); // convert and free up memory
        }

        public static void UnloadAsset(Object asset) {
            if(SpriteFactory.Utils.UnityTools.unityVersion < SpriteFactory.Utils.UnityTools.UnityVersion.UNITY_3_5_2) return; // not supported
            UnloadAssetNow(asset);
        }

        private static void UnloadAssetNow(Object asset) {
            Resources.UnloadAsset(asset);
        }
    }

    internal static class TextureTools {

        private enum RoundingPolicy { Floor, Ceil };
        private static RoundingPolicy scaleDimensionRoundingPolicy = RoundingPolicy.Floor;

        private static int RoundDimension(float value, int min) {
            if(scaleDimensionRoundingPolicy == RoundingPolicy.Ceil) return Mathf.CeilToInt(value);
            else if(scaleDimensionRoundingPolicy == RoundingPolicy.Floor) return Mathf.Max(Mathf.FloorToInt(value), min);
            else throw new System.NotImplementedException();
        }

        public static void ScaleResolution(int width, int height, float scale, out int newWidth, out int newHeight) {
            newWidth = RoundDimension(width * scale, 1);
            newHeight = RoundDimension(height * scale, 1);
        }

        public static Color[] GetPixels(Color[] pixels, int imageWidth, int imageHeight, int startX, int startY, int blockWidth, int blockHeight) {
            if(pixels == null) throw new System.ArgumentNullException("pixels");
            if(imageWidth <= 0 || imageHeight <= 0) throw new System.ArgumentOutOfRangeException("imageWidth and imageHeight must be > 0!");
            if(imageWidth * imageHeight != pixels.Length) throw new System.ArgumentOutOfRangeException("pixels.length must equal width * height!");
            if(startX < 0 || startX >= imageWidth || startY < 0 || startY >= imageHeight) throw new System.ArgumentOutOfRangeException("Starting position must be inside the pixel rect!");
            if(startX + blockWidth > imageWidth || startY + blockHeight > imageHeight) throw new System.ArgumentOutOfRangeException("Block must be within the pixel rect!");

            Color[] newPixels = new Color[blockWidth * blockHeight];
            int cols = imageWidth;
            int rows = imageHeight;
            int rowEnd = startY + blockHeight;
            int colEnd = startX + blockWidth;

            for(int row = startY; row < rowEnd; row++) {
                int targetRow = row - startY;
                for(int col = startX; col < colEnd; col++) {
                    int targetCol = col - startX;
                    int sourceIndex = row * cols + col;
                    int targetIndex = targetRow * blockWidth + targetCol;
                    newPixels[targetIndex] = pixels[sourceIndex];
                }
            }
            return newPixels;
        }

        public static Color[] GetRow(Color[] pixels, int width, int height, int row) {
            if(pixels == null || pixels.Length == 0) throw new System.ArgumentNullException("pixels");
            if(width <= 0 || height <= 0 || width * height != pixels.Length) throw new System.ArgumentOutOfRangeException("pixels.Length must equal width * height!");
            if(row < 0 || row >= height) throw new System.ArgumentOutOfRangeException();

            Color[] rowPixels = new Color[width];
            int cols = width;
            for(int col = 0; col < cols; col++) {
                int index = row * cols + col;
                rowPixels[col] = pixels[index];
            }
            return rowPixels;
        }

        public static Color[] GetColumn(Color[] pixels, int width, int height, int col) {
            if(pixels == null || width <= 0 || height <= 0 || width * height != pixels.Length) throw new System.ArgumentOutOfRangeException();
            if(col < 0 || col >= width) throw new System.ArgumentOutOfRangeException();

            Color[] colPixels = new Color[height];
            int cols = width;
            int rows = height;
            for(int row = 0; row < rows; row++) {
                int index = row * cols + col;
                colPixels[row] = pixels[index];
            }
            return colPixels;
        }

        public static void WriteRow(Color[] pixelsToWriteTo, int width, int height, Color[] pixelsToWrite, int row, int startCol) {
            if(pixelsToWriteTo == null || pixelsToWriteTo.Length == 0) throw new System.ArgumentNullException("pixelsToWriteTo");
            if(width <= 0 || height <= 0 || width * height != pixelsToWriteTo.Length) throw new System.ArgumentOutOfRangeException();
            if(pixelsToWrite == null || pixelsToWrite.Length == 0) throw new System.ArgumentNullException("pixelsToWrite");
            if(pixelsToWrite.Length + startCol > width) throw new System.ArgumentOutOfRangeException();
            
            if(row < 0 || row >= height) throw new System.ArgumentOutOfRangeException();
            if(startCol < 0 || startCol >= width) throw new System.ArgumentOutOfRangeException();

            int cols = width;
            int count = 0;
            for(int col = startCol; col < pixelsToWrite.Length + startCol; col++) {
                int index = row * cols + col;
                pixelsToWriteTo[index] = pixelsToWrite[count++];
            }
        }

        public static void WriteColumn(Color[] pixelsToWriteTo, int width, int height, Color[] pixelsToWrite, int col, int startRow) {
            if(pixelsToWriteTo == null || width <= 0 || height <= 0 || width * height != pixelsToWriteTo.Length) throw new System.ArgumentOutOfRangeException();
            if(pixelsToWrite == null || pixelsToWrite.Length + startRow > height) throw new System.ArgumentOutOfRangeException();
            if(col < 0 || col >= width) throw new System.ArgumentOutOfRangeException();
            if(startRow < 0 || startRow >= height) throw new System.ArgumentOutOfRangeException();

            int cols = width;
            int count = 0;
            for(int row = startRow; row < pixelsToWrite.Length + startRow; row++) {
                int index = row * cols + col;
                pixelsToWriteTo[index] = pixelsToWrite[count++];
            }
        }

        public static void FillRegion(Color[] pixelsToWriteTo, int width, int height, int startRow, int startCol, Color fillColor, int fillWidth, int fillHeight) {
            if(pixelsToWriteTo == null || width <= 0 || height <= 0 || width * height != pixelsToWriteTo.Length) throw new System.ArgumentOutOfRangeException();
            if(startCol < 0 || startCol >= width) throw new System.ArgumentOutOfRangeException();
            if(startRow < 0 || startRow >= height) throw new System.ArgumentOutOfRangeException();
            if(fillWidth <= 0 || fillHeight <= 0) throw new System.ArgumentOutOfRangeException();

            int cols = width;
            int endCol = startCol + fillWidth;
            for(int row = startRow; row < startRow + fillHeight; row++) {
                for(int col = startCol; col < endCol; col++) {
                    int index = row * cols + col;
                    pixelsToWriteTo[index] = fillColor;
                }
            }
        }

        public static ColorImage Scale(ColorImage colorImage, int newWidth, int newHeight, Enums.ImageResamplingMode resamplingMode) {
            if(colorImage == null || !colorImage.isValid) return null;
            
            Color[] colors;
            
            if(resamplingMode == Enums.ImageResamplingMode.Point || resamplingMode == Enums.ImageResamplingMode.Bilinear) colors = TextureScale.Scale(colorImage.colors, colorImage.width, colorImage.height, newWidth, newHeight, resamplingMode);
            else colors = Resampler.Resample(colorImage.colors, colorImage.width, colorImage.height, newWidth, newHeight, resamplingMode);

            if(colors == null) return null;

            return new ColorImage(colors, newWidth, newHeight, colorImage.format);
        }

        public static Color[] Scale(Color[] pixels, int oldWidth, int oldHeight, int newWidth, int newHeight, Enums.ImageResamplingMode resamplingMode) {
            if(resamplingMode == Enums.ImageResamplingMode.Point || resamplingMode == Enums.ImageResamplingMode.Bilinear) return TextureScale.Scale(pixels, oldWidth, oldHeight, newWidth, newHeight, resamplingMode);
            return Resampler.Resample(pixels, oldWidth, oldHeight, newWidth, newHeight, resamplingMode);
        }

        public static Color[] Scale(Texture2D texture, int newWidth, int newHeight, Enums.ImageResamplingMode resamplingMode) {
            if(resamplingMode == Enums.ImageResamplingMode.Point || resamplingMode == Enums.ImageResamplingMode.Bilinear) return TextureScale.Scale(texture, newWidth, newHeight, resamplingMode);
            return Resampler.Resample(texture, newWidth, newHeight, resamplingMode);
        }

        public class TextureScale {

            // Credit //
            // Source: http://wiki.unity3d.com/index.php?title=TextureScale
            // Author: Eric Haines (Eric5h5)
            //
            // Modified by Augie Maddox:
            //   Returns Color[] array instead of modifying Texture2D and to accept Color[] as input type
            //   Added Bicubic scaling mode
            //   Added non-threaded mode
            //   Optmized using refs to pass colors
            //   Added option to snap blended color values to 8-bits per channel

            // Only works on ARGB32, RGB24 and Alpha8 textures that are marked readable

            private class ThreadData {
                public int start;
                public int end;
                public ThreadData(int s, int e) {
                    start = s;
                    end = e;
                }
            }

            public static bool useThreading = false; // THREADING FAILS SOMETIMES DO NOT USE
            public static bool snapTo8BitsPerChannelValues = true;

            private static Color[] texColors;
            private static Color[] newColors;
            private static int oldWidth;
            private static int oldHeight;
            private static float ratioX;
            private static float ratioY;
            private static int newWidth;
            private static int newHeight;

            private const float snap8 = 1.0f / 255.0f;

            // Threading variables
            private static int finishCount;
            private static Mutex mutex;

            public static Color[] Scale(Texture2D tex, int newWidth, int newHeight, Enums.ImageResamplingMode scalingMode) {
                if(scalingMode == Enums.ImageResamplingMode.Bilinear) return Bilinear(tex, newWidth, newHeight);
                else if(scalingMode == Enums.ImageResamplingMode.Point) return Point(tex, newWidth, newHeight);
                else {
                    throw new System.NotImplementedException();
                }
            }

            public static Color[] Scale(Color[] pixels, int oldWidth, int oldHeight, int newWidth, int newHeight, Enums.ImageResamplingMode scalingMode) {
                if(scalingMode == Enums.ImageResamplingMode.Bilinear) return Bilinear(pixels, oldWidth, oldHeight, newWidth, newHeight);
                else if(scalingMode == Enums.ImageResamplingMode.Point) return Point(pixels, oldWidth, oldHeight, newWidth, newHeight);
                else {
                    throw new System.NotImplementedException();
                }
            }

            public static Color[] Point(Texture2D tex, int newWidth, int newHeight) {
                return Point(tex.GetPixels(), tex.width, tex.height, newWidth, newHeight);
            }

            public static Color[] Point(Color[] pixels, int oldWidth, int oldHeight, int newWidth, int newHeight) {
                if(useThreading) return ThreadedScale(pixels, oldWidth, oldHeight, newWidth, newHeight, false);
                return ScaleNow(pixels, oldWidth, oldHeight, newWidth, newHeight, Enums.ImageResamplingMode.Point);
            }

            public static Color[] Bilinear(Texture2D tex, int newWidth, int newHeight) {
                return Bilinear(tex.GetPixels(), tex.width, tex.height, newWidth, newHeight);
            }

            public static Color[] Bilinear(Color[] pixels, int oldWidth, int oldHeight, int newWidth, int newHeight) {
                if(useThreading) return ThreadedScale(pixels, oldWidth, oldHeight, newWidth, newHeight, true);
                return ScaleNow(pixels, oldWidth, oldHeight, newWidth, newHeight, Enums.ImageResamplingMode.Bilinear);
            }

            private static Color[] ThreadedScale(Color[] pixels, int oldWidth, int oldHeight, int newWidth, int newHeight, bool useBilinear) {
                TextureScale.oldWidth = oldWidth;
                TextureScale.oldHeight = oldHeight;
                TextureScale.newWidth = newWidth;
                TextureScale.newHeight = newHeight;

                texColors = pixels;
                newColors = new Color[newWidth * newHeight];
                if(useBilinear) {
                    ratioX = 1.0f / ((float)newWidth / (oldWidth - 1));
                    ratioY = 1.0f / ((float)newHeight / (oldHeight - 1));
                } else {
                    ratioX = ((float)oldWidth) / newWidth;
                    ratioY = ((float)oldHeight) / newHeight;
                }

                var cores = Mathf.Min(SystemInfo.processorCount, newHeight);
                var slice = newHeight / cores;

                finishCount = 0;
                if(mutex == null) {
                    mutex = new Mutex(false);
                }
                if(cores > 1) {
                    int i = 0;
                    ThreadData threadData;
                    for(i = 0; i < cores - 1; i++) {
                        threadData = new ThreadData(slice * i, slice * (i + 1));
                        ParameterizedThreadStart ts = useBilinear ? new ParameterizedThreadStart(BilinearScaleThreaded) : new ParameterizedThreadStart(PointScaleThreaded);
                        Thread thread = new Thread(ts);
                        thread.Start(threadData);
                    }
                    threadData = new ThreadData(slice * i, newHeight);
                    if(useBilinear) {
                        BilinearScaleThreaded(threadData);
                    } else {
                        PointScaleThreaded(threadData);
                    }
                    while(finishCount < cores) {
                        Thread.Sleep(1);
                    }
                } else {
                    ThreadData threadData = new ThreadData(0, newHeight);
                    if(useBilinear) {
                        BilinearScaleThreaded(threadData);
                    } else {
                        PointScaleThreaded(threadData);
                    }
                }

                return newColors;
            }

            private static void BilinearScaleThreaded(System.Object obj) {
                ThreadData threadData = (ThreadData)obj;
                for(int row = threadData.start; row < threadData.end; row++) {
                    int yFloor = (int)Mathf.Floor(row * ratioY);
                    int y1 = yFloor * oldWidth;
                    int y2 = (yFloor + 1) * oldWidth;
                    int yw = row * newWidth;

                    for(int col = 0; col < newWidth; col++) {
                        int xFloor = (int)Mathf.Floor(col * ratioX);
                        var xLerp = col * ratioX - xFloor;
                        int index = yw + col;
                        Color c1 = ColorLerpUnclamped(ref texColors[y1 + xFloor], ref texColors[y1 + xFloor + 1], xLerp);
                        Color c2 = ColorLerpUnclamped(ref texColors[y2 + xFloor], ref texColors[y2 + xFloor + 1], xLerp);
                        newColors[index] = ColorLerpUnclamped(ref c1, ref c2, row * ratioY - yFloor);

                        // Snap colors to 8-bits per channel so we clean up tiny values
                        if(snapTo8BitsPerChannelValues) SnapTo8BitColorValues(ref newColors[index]);
                    }
                }

                mutex.WaitOne();
                finishCount++;
                mutex.ReleaseMutex();
            }

            private static void PointScaleThreaded(System.Object obj) {
                ThreadData threadData = (ThreadData)obj;
                for(var y = threadData.start; y < threadData.end; y++) {
                    var thisY = (int)(ratioY * y) * oldWidth;
                    var yw = y * newWidth;
                    for(var x = 0; x < newWidth; x++) {
                        newColors[yw + x] = texColors[(int)(thisY + ratioX * x)];
                    }
                }

                mutex.WaitOne();
                finishCount++;
                mutex.ReleaseMutex();
            }

            private static Color[] ScaleNow(Color[] pixels, int oldWidth, int oldHeight, int newWidth, int newHeight, Enums.ImageResamplingMode mode) {
                TextureScale.oldWidth = oldWidth;
                TextureScale.oldHeight = oldHeight;
                TextureScale.newWidth = newWidth;
                TextureScale.newHeight = newHeight;

                texColors = pixels;

                if(mode == Enums.ImageResamplingMode.Bilinear) {
                    newColors = new Color[newWidth * newHeight];
                    ratioX = 1.0f / ((float)newWidth / (oldWidth - 1));
                    ratioY = 1.0f / ((float)newHeight / (oldHeight - 1));
                    BilinearScale();
                } else if(mode == Enums.ImageResamplingMode.Point) {
                    newColors = new Color[newWidth * newHeight];
                    ratioX = ((float)oldWidth) / newWidth;
                    ratioY = ((float)oldHeight) / newHeight;
                    PointScale();
                } else {
                    throw new System.NotImplementedException();
                }

                return newColors;
            }

            private static void BilinearScale() {
                for(int row = 0; row < newHeight; row++) {

                    int yFloor = (int)Mathf.Floor(row * ratioY);
                    int y1 = yFloor * oldWidth;
                    int y2 = (yFloor + 1) * oldWidth;
                    int newRowStartIndex = row * newWidth;

                    for(int col = 0; col < newWidth; col++) {
                        int xFloor = (int)Mathf.Floor(col * ratioX);
                        float xLerp = col * ratioX - xFloor;
                        int index = newRowStartIndex + col;
                        Color c1 = ColorLerpUnclamped(ref texColors[y1 + xFloor], ref texColors[y1 + xFloor + 1], xLerp);
                        Color c2 = ColorLerpUnclamped(ref texColors[y2 + xFloor], ref texColors[y2 + xFloor + 1], xLerp);
                        newColors[index] = ColorLerpUnclamped(ref c1, ref c2, row * ratioY - yFloor);

                        // Snap colors to 8-bits per channel so we clean up tiny values
                        if(snapTo8BitsPerChannelValues) SnapTo8BitColorValues(ref newColors[index]);
                    }
                }
            }

            private static void PointScale() {
                for(int row = 0; row < newHeight; row++) {
                    int oldRowStartIndex = (int)(ratioY * row) * oldWidth;
                    int newRowStartIndex = row * newWidth;
                    for(int col = 0; col < newWidth; col++) {
                        int oldCol = (int)(ratioX * col);
                        newColors[newRowStartIndex + col] = texColors[oldRowStartIndex + oldCol];
                    }
                }
            }

            private static Color ColorLerpUnclamped(ref Color c1, ref Color c2, float value) {
                return new Color(c1.r + (c2.r - c1.r) * value,
                                  c1.g + (c2.g - c1.g) * value,
                                  c1.b + (c2.b - c1.b) * value,
                                  c1.a + (c2.a - c1.a) * value);
            }

            private static void SnapTo8BitColorValues(ref Color color) {
                // Clean up colors
                for(int i = 0; i < 4; i++) {
                    if(color[i] <= 0.0f) continue;

                    int div = Mathf.RoundToInt(color[i] / snap8);
                    color[i] = snap8 * div;
                }
            }
        }

        public class TrimInfo {

            // Variables
            private int _width;
            private int _height;
            private int _trimLeft;
            private int _trimRight;
            private int _trimTop;
            private int _trimBottom;

            // Properties
            public int width { get { return _width; } }
            public int height { get { return _height; } }
            public int trimLeft { get { return _trimLeft; } }
            public int trimRight { get { return _trimRight; } }
            public int trimTop { get { return _trimTop; } }
            public int trimBottom { get { return _trimBottom; } }

            public TrimInfo(Texture2D texture, SpriteFactory.Enums.TransparencyChannel transparencyChannel, float transparencyCutoff) {
                if(texture == null) return;
                Trim(texture.GetPixels(), texture.width, texture.height, transparencyChannel, transparencyCutoff);
            }

            public TrimInfo(Color[] pixels, int width, int height, SpriteFactory.Enums.TransparencyChannel transparencyChannel, float transparencyCutoff) {
                if(pixels == null || pixels.Length == 0) return;
                if(width < 0 || height < 0 || width * height != pixels.Length) return;
                Trim(pixels, width, height, transparencyChannel, transparencyCutoff);
            }

            public TrimInfo(ColorImage colorImage, SpriteFactory.Enums.TransparencyChannel transparencyChannel, float transparencyCutoff) {
                if(colorImage == null || !colorImage.isValid) return;
                Trim(colorImage.colors, colorImage.width, colorImage.height, transparencyChannel, transparencyCutoff);
            }


            private void Trim(Color[] pixels, int width, int height, SpriteFactory.Enums.TransparencyChannel transparencyChannel, float transparencyCutoff) {
                int transIndex = SpriteFactory.Utils.EnumTools.GetColorChannelIndex(transparencyChannel);
                bool opaque = transIndex < 0 ? true : false;

                _width = width;
                _height = height;

                int minX = 0;
                int maxX = 0;
                int minY = 0;
                int maxY = 0;

                bool xMinFound = false;
                bool xMaxFound = false;
                bool yMinFound = false;
                bool yMaxFound = false;

                // Search for left / right pixels
                for(int row = 0; row < height; row++) {
                    bool found = false;
                    int rowStart = row * width;

                    // Search from left to right
                    for(int col = 0; col < width; col++) {
                        int index = rowStart + col;
                        if(opaque || pixels[index][transIndex] > transparencyCutoff) {
                            if(!xMinFound || col < minX) {
                                minX = col;
                                if(!xMinFound) xMinFound = true;
                            }
                            found = true;
                            break;
                        }
                    }
                    if(!found) continue; // don't bother checking backwards

                    // Search from right to left
                    for(int col = width - 1; col >= 0; col--) {
                        int index = rowStart + col;
                        if(opaque || pixels[index][transIndex] > transparencyCutoff) {
                            if(!xMaxFound || col > maxX) {
                                maxX = col;
                                if(!xMaxFound) xMaxFound = true;
                            }
                            break;
                        }
                    }
                }

                // Search for up / down pixels
                for(int col = 0; col < width; col++) {
                    bool found = false;

                    // Search from bottom to top
                    for(int row = 0; row < height; row++) {
                        int index = row * width + col;
                        if(opaque || pixels[index][transIndex] > transparencyCutoff) {
                            if(!yMinFound || row < minY) {
                                minY = row;
                                if(!yMinFound) yMinFound = true;
                            }
                            found = true;
                            break;
                        }
                    }
                    if(!found) continue; // don't bother checking backwards

                    // Search from top to bottom
                    for(int row = height - 1; row >= 0; row--) {
                        int index = row * width + col;
                        if(opaque || pixels[index][transIndex] > transparencyCutoff) {
                            if(!yMaxFound || row > maxY) {
                                maxY = row;
                                if(!yMaxFound) yMaxFound = true;
                            }
                            break;
                        }
                    }
                }

                if(!xMinFound && !yMinFound) return; // no pixels, this is empty

                // Calculate trims
                _trimLeft = minX;
                _trimRight = width - 1 - maxX;
                _trimTop = height - 1 - maxY;
                _trimBottom = minY;

                // Caclulate dimensions
                _width = maxX + 1 - minX;
                _height = maxY + 1 - minY;
            }
        }

        public static class Resampler {

            #region ResamplingService Main

            // Copyright � 2007  by Libor Tinka
            // Source: http://www.codeproject.com/Articles/11143/Image-Resizing-outperform-GDI
            // Author: Libor Tinka
            // License: CPOL - http://www.codeproject.com/info/cpol10.aspx
            
            // This version has been patched based on this message by Vexxxx in comments at http://www.codeproject.com/Articles/11143/Image-Resizing-outperform-GDI
            // Modified so classes are private. Interfacing will be done through Resampler.Resample instead of directly with the ResamplingService class

            #region ResamplingService class

            /// <summary>
            /// A class for image resampling with custom filters.
            /// </summary>
            private class ResamplingService {

                #region Properties

                /// <summary>
                /// Gets or sets the resampling filter.
                /// </summary>
                public ResamplingFilters Filter {

                    get {
                        return this.filter;
                    }
                    set {
                        this.filter = value;
                    }
                }

                /// <summary>
                /// Gets or sets wheter the resampling process is stopping.
                /// </summary>
                public bool Aborting {

                    get {
                        return this.aborting;
                    }
                    set {
                        this.aborting = value;
                    }
                }

                /// <summary>
                /// Covered units. Progress can be computed in combination with ResamplingService.Total property.
                /// </summary>
                public int Covered {

                    get {
                        return this.covered;
                    }
                }

                /// <summary>
                /// Total units. Progress can be computer in combination with ResamplingService.Covered property.
                /// </summary>
                public int Total {

                    get {
                        return this.total;
                    }
                }

                #endregion

                #region Structures

                internal struct Contributor {

                    public int pixel;
                    public double weight;
                }

                internal struct ContributorEntry {

                    public int n;
                    public Contributor[] p;
                    public double wsum;
                }

                #endregion

                #region Private Fields

                private bool aborting = false;
                private int covered = 0, total = 0;
                private ResamplingFilters filter = ResamplingFilters.Box;

                #endregion

                #region Public Methods

                /// <summary>
                /// Resamples input array to a new array using current resampling filter.
                /// </summary>
                /// <param name="input">Input array.</param>
                /// <param name="nWidth">Width of the output array.</param>
                /// <param name="nHeight">Height of the output array.</param>
                /// <returns>Output array.</returns>
                public ushort[][,] Resample(ushort[][,] input, int nWidth, int nHeight) {

                    if(input == null || input.Length == 0 || nWidth <= 1 || nHeight <= 1)
                        return null;

                    ResamplingFilter filter = ResamplingFilter.Create(this.filter);

                    int width = input[0].GetLength(0);
                    int height = input[0].GetLength(1);
                    int planes = input.Length;

                    this.covered = 0;
                    this.total = (nWidth + height);

                    // create bitmaps
                    ushort[][,] work = new ushort[planes][,];
                    ushort[][,] output = new ushort[planes][,];
                    int c = 0;

                    for(c = 0; c < planes; c++) {

                        work[c] = new ushort[nWidth, height];
                        output[c] = new ushort[nWidth, nHeight];
                    }

                    double xScale = ((double)nWidth / width);
                    double yScale = ((double)nHeight / height);

                    ContributorEntry[] contrib = new ContributorEntry[nWidth];

                    double wdth = 0, center = 0, weight = 0, intensity = 0;
                    int left = 0, right = 0, i = 0, j = 0, k = 0;

                    // horizontal downsampling
                    if(xScale < 1.0) {

                        // scales from bigger to smaller width
                        wdth = (filter.defaultFilterRadius / xScale);

                        for(i = 0; i < nWidth; i++) {

                            contrib[i].n = 0;
                            contrib[i].p = new Contributor[(int)System.Math.Floor(2 * wdth + 1)];
                            contrib[i].wsum = 0;
                            center = ((i + 0.5) / xScale);
                            left = (int)(center - wdth);
                            right = (int)(center + wdth);

                            for(j = left; j <= right; j++) {

                                weight = filter.GetValue((center - j - 0.5) * xScale);

                                if((weight == 0) || (j < 0) || (j >= width))
                                    continue;

                                contrib[i].p[contrib[i].n].pixel = j;
                                contrib[i].p[contrib[i].n].weight = weight;
                                contrib[i].wsum += weight;
                                contrib[i].n++;
                            }

                            if(aborting)
                                goto End;
                        }
                    } else {

                        // horizontal upsampling
                        // scales from smaller to bigger width
                        for(i = 0; i < nWidth; i++) {

                            contrib[i].n = 0;
                            contrib[i].p = new Contributor[(int)System.Math.Floor(2 * filter.defaultFilterRadius + 1)];
                            contrib[i].wsum = 0;
                            center = ((i + 0.5) / xScale);
                            left = (int)System.Math.Floor(center - filter.defaultFilterRadius);
                            right = (int)System.Math.Ceiling(center + filter.defaultFilterRadius);

                            for(j = left; j <= right; j++) {

                                weight = filter.GetValue(center - j - 0.5);

                                if((weight == 0) || (j < 0) || (j >= width))
                                    continue;

                                contrib[i].p[contrib[i].n].pixel = j;
                                contrib[i].p[contrib[i].n].weight = weight;
                                contrib[i].wsum += weight;
                                contrib[i].n++;
                            }

                            if(aborting)
                                goto End;
                        }
                    }

                    // filter horizontally from input to work
                    for(c = 0; c < planes; c++) {

                        for(k = 0; k < height; k++) {

                            for(i = 0; i < nWidth; i++) {

                                intensity = 0;

                                for(j = 0; j < contrib[i].n; j++) {

                                    weight = contrib[i].p[j].weight;

                                    if(weight == 0)
                                        continue;

                                    intensity += (input[c][contrib[i].p[j].pixel, k] * weight);
                                }

                                // CORRECTION - old line 213
                                //work[c][i, k] = (ushort)Math.Min(Math.Max(intensity / contrib[i].wsum, UInt16.MinValue), UInt16.MaxValue);
                                work[c][i, k] = (ushort)System.Math.Min(System.Math.Max(intensity / contrib[i].wsum + 0.5, System.UInt16.MinValue), System.UInt16.MaxValue);
                            }

                            if(aborting)
                                goto End;

                            this.covered++;
                        }
                    }

                    // pre-calculate filter contributions for a column
                    contrib = new ContributorEntry[nHeight];

                    // vertical downsampling
                    if(yScale < 1.0) {

                        // scales from bigger to smaller height
                        wdth = (filter.defaultFilterRadius / yScale);

                        for(i = 0; i < nHeight; i++) {

                            contrib[i].n = 0;
                            contrib[i].p = new Contributor[(int)System.Math.Floor(2 * wdth + 1)];
                            contrib[i].wsum = 0;
                            center = ((i + 0.5) / yScale);
                            left = (int)(center - wdth);
                            right = (int)(center + wdth);

                            for(j = left; j <= right; j++) {

                                weight = filter.GetValue((center - j - 0.5) * yScale);

                                if((weight == 0) || (j < 0) || (j >= height))
                                    continue;

                                contrib[i].p[contrib[i].n].pixel = j;
                                contrib[i].p[contrib[i].n].weight = weight;
                                contrib[i].wsum += weight;
                                contrib[i].n++;
                            }

                            if(aborting)
                                goto End;
                        }
                    } else {

                        // vertical upsampling
                        // scales from smaller to bigger height
                        for(i = 0; i < nHeight; i++) {

                            contrib[i].n = 0;
                            contrib[i].p = new Contributor[(int)System.Math.Floor(2 * filter.defaultFilterRadius + 1)];
                            contrib[i].wsum = 0;
                            center = ((i + 0.5) / yScale);
                            left = (int)(center - filter.defaultFilterRadius);
                            right = (int)(center + filter.defaultFilterRadius);

                            for(j = left; j <= right; j++) {

                                weight = filter.GetValue(center - j - 0.5);

                                if((weight == 0) || (j < 0) || (j >= height))
                                    continue;

                                contrib[i].p[contrib[i].n].pixel = j;
                                contrib[i].p[contrib[i].n].weight = weight;
                                contrib[i].wsum += weight;
                                contrib[i].n++;
                            }

                            if(aborting)
                                goto End;
                        }
                    }

                    // filter vertically from work to output
                    for(c = 0; c < planes; c++) {

                        for(k = 0; k < nWidth; k++) {

                            for(i = 0; i < nHeight; i++) {

                                intensity = 0;

                                for(j = 0; j < contrib[i].n; j++) {

                                    weight = contrib[i].p[j].weight;

                                    if(weight == 0)
                                        continue;

                                    intensity += (work[c][k, contrib[i].p[j].pixel] * weight);
                                }

                                // CORRECTION - OLD LINE 307
                                //output[c][k, i] = (ushort)Math.Min(Math.Max(intensity, UInt16.MinValue), UInt16.MaxValue);
                                output[c][k, i] = (ushort)System.Math.Min(System.Math.Max(intensity / contrib[i].wsum + 0.5, System.UInt16.MinValue), System.UInt16.MaxValue);
                            }

                            if(aborting)
                                goto End;

                            this.covered++;
                        }
                    }

                End: ;

                    work = null;

                    return output;
                }

                /// <summary>
                /// Resamples input array to a new array using current resampling filter.
                /// </summary>
                /// <param name="input">Input array.</param>
                /// <param name="nWidth">Width of the output array.</param>
                /// <param name="nHeight">Height of the output array.</param>
                /// <returns>Output array.</returns>
                public Color[] Resample(Color[] input, int oWidth, int oHeight, int nWidth, int nHeight) {

                    Debug.LogWarning("This version uses a LOT more memory!");

                    if(input == null || input.Length == 0 || nWidth <= 1 || nHeight <= 1)
                        return null;

                    ResamplingFilter filter = ResamplingFilter.Create(this.filter);

                    int width = oWidth;
                    int height = oHeight;
                    int planes = 4; // always do RGBA

                    this.covered = 0;
                    this.total = (nWidth + height);

                    // create bitmaps
                    Color[] work = new Color[nWidth * height];
                    Color[] output = new Color[nWidth * nHeight];
                    int c = 0;

                    double xScale = ((double)nWidth / width);
                    double yScale = ((double)nHeight / height);

                    ContributorEntry[] contrib = new ContributorEntry[nWidth];

                    double wdth = 0, center = 0, weight = 0, intensity = 0;
                    int left = 0, right = 0, x = 0, i = 0, y = 0;

                    // horizontal downsampling
                    if(xScale < 1.0) {

                        // scales from bigger to smaller width
                        wdth = (filter.defaultFilterRadius / xScale);

                        for(x = 0; x < nWidth; x++) {

                            contrib[x].n = 0;
                            contrib[x].p = new Contributor[(int)System.Math.Floor(2 * wdth + 1)];
                            contrib[x].wsum = 0;
                            center = ((x + 0.5) / xScale);
                            left = (int)(center - wdth);
                            right = (int)(center + wdth);

                            for(i = left; i <= right; i++) {

                                weight = filter.GetValue((center - i - 0.5) * xScale);

                                if((weight == 0) || (i < 0) || (i >= width))
                                    continue;

                                contrib[x].p[contrib[x].n].pixel = i;
                                contrib[x].p[contrib[x].n].weight = weight;
                                contrib[x].wsum += weight;
                                contrib[x].n++;
                            }

                            if(aborting)
                                goto End;
                        }
                    } else {

                        // horizontal upsampling
                        // scales from smaller to bigger width
                        for(x = 0; x < nWidth; x++) {

                            contrib[x].n = 0;
                            contrib[x].p = new Contributor[(int)System.Math.Floor(2 * filter.defaultFilterRadius + 1)];
                            contrib[x].wsum = 0;
                            center = ((x + 0.5) / xScale);
                            left = (int)System.Math.Floor(center - filter.defaultFilterRadius);
                            right = (int)System.Math.Ceiling(center + filter.defaultFilterRadius);

                            for(i = left; i <= right; i++) {

                                weight = filter.GetValue(center - i - 0.5);

                                if((weight == 0) || (i < 0) || (i >= width))
                                    continue;

                                contrib[x].p[contrib[x].n].pixel = i;
                                contrib[x].p[contrib[x].n].weight = weight;
                                contrib[x].wsum += weight;
                                contrib[x].n++;
                            }

                            if(aborting)
                                goto End;
                        }
                    }

                    // filter horizontally from input to work
                    for(c = 0; c < planes; c++) {

                        for(y = 0; y < height; y++) {

                            for(x = 0; x < nWidth; x++) {

                                intensity = 0;

                                for(i = 0; i < contrib[x].n; i++) {

                                    weight = contrib[x].p[i].weight;

                                    if(weight == 0)
                                        continue;

                                    intensity += (input[y * oWidth + contrib[x].p[i].pixel][c] * weight);
                                }

                                work[y * nWidth + x][c] = (ushort)System.Math.Min(System.Math.Max(intensity / contrib[x].wsum + 0.5, System.UInt16.MinValue), System.UInt16.MaxValue);
                            }

                            if(aborting)
                                goto End;

                            this.covered++;
                        }
                    }

                    // pre-calculate filter contributions for a column
                    contrib = new ContributorEntry[nHeight];

                    // vertical downsampling
                    if(yScale < 1.0) {

                        // scales from bigger to smaller height
                        wdth = (filter.defaultFilterRadius / yScale);

                        for(x = 0; x < nHeight; x++) {

                            contrib[x].n = 0;
                            contrib[x].p = new Contributor[(int)System.Math.Floor(2 * wdth + 1)];
                            contrib[x].wsum = 0;
                            center = ((x + 0.5) / yScale);
                            left = (int)(center - wdth);
                            right = (int)(center + wdth);

                            for(i = left; i <= right; i++) {

                                weight = filter.GetValue((center - i - 0.5) * yScale);

                                if((weight == 0) || (i < 0) || (i >= height))
                                    continue;

                                contrib[x].p[contrib[x].n].pixel = i;
                                contrib[x].p[contrib[x].n].weight = weight;
                                contrib[x].wsum += weight;
                                contrib[x].n++;
                            }

                            if(aborting)
                                goto End;
                        }
                    } else {

                        // vertical upsampling
                        // scales from smaller to bigger height
                        for(x = 0; x < nHeight; x++) {

                            contrib[x].n = 0;
                            contrib[x].p = new Contributor[(int)System.Math.Floor(2 * filter.defaultFilterRadius + 1)];
                            contrib[x].wsum = 0;
                            center = ((x + 0.5) / yScale);
                            left = (int)(center - filter.defaultFilterRadius);
                            right = (int)(center + filter.defaultFilterRadius);

                            for(i = left; i <= right; i++) {

                                weight = filter.GetValue(center - i - 0.5);

                                if((weight == 0) || (i < 0) || (i >= height))
                                    continue;

                                contrib[x].p[contrib[x].n].pixel = i;
                                contrib[x].p[contrib[x].n].weight = weight;
                                contrib[x].wsum += weight;
                                contrib[x].n++;
                            }

                            if(aborting)
                                goto End;
                        }
                    }

                    // filter vertically from work to output
                    for(c = 0; c < planes; c++) {

                        for(x = 0; x < nWidth; x++) {

                            for(y = 0; y < nHeight; y++) {

                                intensity = 0;

                                for(i = 0; i < contrib[y].n; i++) {

                                    weight = contrib[y].p[i].weight;

                                    if(weight == 0)
                                        continue;

                                    //intensity += (work[c][k, contrib[i].p[j].pixel] * weight);
                                    intensity += (work[y * nWidth + contrib[y].p[i].pixel][c] * weight);
                                }

                                output[y * nWidth + x][c] = (ushort)System.Math.Min(System.Math.Max(intensity / contrib[y].wsum + 0.5, System.UInt16.MinValue), System.UInt16.MaxValue);
                            }

                            if(aborting)
                                goto End;

                            this.covered++;
                        }
                    }

                End: ;

                    work = null;

                    return output;
                }

                #endregion
            }

            #endregion

            #region ResamplingFilters enum

            private enum ResamplingFilters {

                Box = 0,
                Triangle,
                Hermite,
                Bell,
                CubicBSpline,
                Lanczos3,
                Mitchell,
                Cosine,
                CatmullRom,
                Quadratic,
                QuadraticBSpline,
                CubicConvolution,
                Lanczos8
            }

            #endregion

            #region ResamplingFilter class

            private abstract class ResamplingFilter {

                public static ResamplingFilter Create(ResamplingFilters filter) {

                    ResamplingFilter resamplingFilter = null;

                    switch(filter) {
                        case ResamplingFilters.Box:
                            resamplingFilter = new BoxFilter();
                            break;
                        case ResamplingFilters.Triangle:
                            resamplingFilter = new TriangleFilter();
                            break;
                        case ResamplingFilters.Hermite:
                            resamplingFilter = new HermiteFilter();
                            break;
                        case ResamplingFilters.Bell:
                            resamplingFilter = new BellFilter();
                            break;
                        case ResamplingFilters.CubicBSpline:
                            resamplingFilter = new CubicBSplineFilter();
                            break;
                        case ResamplingFilters.Lanczos3:
                            resamplingFilter = new Lanczos3Filter();
                            break;
                        case ResamplingFilters.Mitchell:
                            resamplingFilter = new MitchellFilter();
                            break;
                        case ResamplingFilters.Cosine:
                            resamplingFilter = new CosineFilter();
                            break;
                        case ResamplingFilters.CatmullRom:
                            resamplingFilter = new CatmullRomFilter();
                            break;
                        case ResamplingFilters.Quadratic:
                            resamplingFilter = new QuadraticFilter();
                            break;
                        case ResamplingFilters.QuadraticBSpline:
                            resamplingFilter = new QuadraticBSplineFilter();
                            break;
                        case ResamplingFilters.CubicConvolution:
                            resamplingFilter = new CubicConvolutionFilter();
                            break;
                        case ResamplingFilters.Lanczos8:
                            resamplingFilter = new Lanczos8Filter();
                            break;
                    }

                    return resamplingFilter;
                }

                public double defaultFilterRadius;
                public abstract double GetValue(double x);
            }

            private class HermiteFilter : ResamplingFilter {

                public HermiteFilter() {

                    defaultFilterRadius = 1;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    if(x < 1) return ((2 * x - 3) * x * x + 1);
                    return 0;
                }
            }

            private class BoxFilter : ResamplingFilter {

                public BoxFilter() {

                    defaultFilterRadius = 0.5;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    if(x <= 0.5) return 1;
                    return 0;
                }
            }

            private class TriangleFilter : ResamplingFilter {

                public TriangleFilter() {

                    defaultFilterRadius = 1;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    if(x < 1) return (1 - x);
                    return 0;
                }
            }

            private class BellFilter : ResamplingFilter {

                public BellFilter() {

                    defaultFilterRadius = 1.5;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    if(x < 0.5) return (0.75 - x * x);
                    if(x < 1.5) return (0.5 * System.Math.Pow(x - 1.5, 2));
                    return 0;
                }
            }

            private class CubicBSplineFilter : ResamplingFilter {

                double temp;

                public CubicBSplineFilter() {

                    defaultFilterRadius = 2;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    if(x < 1) {

                        temp = x * x;
                        return (0.5 * temp * x - temp + 2f / 3f);
                    }
                    if(x < 2) {

                        x = 2f - x;
                        return (System.Math.Pow(x, 3) / 6f);
                    }
                    return 0;
                }
            }

            private class Lanczos3Filter : ResamplingFilter {

                public Lanczos3Filter() {

                    defaultFilterRadius = 3;
                }

                double SinC(double x) {

                    if(x != 0) {

                        x *= System.Math.PI;
                        return (System.Math.Sin(x) / x);
                    }
                    return 1;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    if(x < 3) return (SinC(x) * SinC(x / 3f));
                    return 0;
                }
            }

            private class MitchellFilter : ResamplingFilter {

                const double C = 1 / 3;
                double temp;

                public MitchellFilter() {

                    defaultFilterRadius = 2;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    temp = x * x;
                    if(x < 1) {

                        x = (((12 - 9 * C - 6 * C) * (x * temp)) + ((-18 + 12 * C + 6 * C) * temp) + (6 - 2 * C));
                        return (x / 6);
                    }
                    if(x < 2) {

                        x = (((-C - 6 * C) * (x * temp)) + ((6 * C + 30 * C) * temp) + ((-12 * C - 48 * C) * x) + (8 * C + 24 * C));
                        return (x / 6);
                    }
                    return 0;
                }
            }

            private class CosineFilter : ResamplingFilter {

                public CosineFilter() {

                    defaultFilterRadius = 1;
                }

                public override double GetValue(double x) {

                    if((x >= -1) && (x <= 1)) return ((System.Math.Cos(x * System.Math.PI) + 1) / 2f);
                    return 0;
                }
            }

            private class CatmullRomFilter : ResamplingFilter {

                const double C = 1 / 2;
                double temp;

                public CatmullRomFilter() {

                    defaultFilterRadius = 2;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    temp = x * x;
                    if(x <= 1) return (1.5 * temp * x - 2.5 * temp + 1);
                    if(x <= 2) return (-0.5 * temp * x + 2.5 * temp - 4 * x + 2);
                    return 0;
                }
            }

            private class QuadraticFilter : ResamplingFilter {

                public QuadraticFilter() {

                    defaultFilterRadius = 1.5;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    if(x <= 0.5) return (-2 * x * x + 1);
                    if(x <= 1.5) return (x * x - 2.5 * x + 1.5);
                    return 0;
                }
            }

            private class QuadraticBSplineFilter : ResamplingFilter {

                public QuadraticBSplineFilter() {

                    defaultFilterRadius = 1.5;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    if(x <= 0.5) return (-x * x + 0.75);
                    if(x <= 1.5) return (0.5 * x * x - 1.5 * x + 1.125);
                    return 0;
                }
            }

            private class CubicConvolutionFilter : ResamplingFilter {

                double temp;

                public CubicConvolutionFilter() {

                    defaultFilterRadius = 3;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    temp = x * x;
                    if(x <= 1) return ((4f / 3f) * temp * x - (7f / 3f) * temp + 1);
                    if(x <= 2) return (-(7f / 12f) * temp * x + 3 * temp - (59f / 12f) * x + 2.5);
                    if(x <= 3) return ((1f / 12f) * temp * x - (2f / 3f) * temp + 1.75 * x - 1.5);
                    return 0;
                }
            }

            private class Lanczos8Filter : ResamplingFilter {

                public Lanczos8Filter() {

                    defaultFilterRadius = 8;
                }

                double SinC(double x) {

                    if(x != 0) {

                        x *= System.Math.PI;
                        return (System.Math.Sin(x) / x);
                    }
                    return 1;
                }

                public override double GetValue(double x) {

                    if(x < 0) x = -x;
                    if(x < 8) return (SinC(x) * SinC(x / 8f));
                    return 0;
                }
            }

            #endregion

            #endregion

            #region Supporting Methods / Classes

            public static Color[] Resample(Texture2D texture, int newWidth, int newHeight, Enums.ImageResamplingMode resamplingMode, bool snapTo8BitColors = true) {
                return Resample(texture.GetPixels(), texture.width, texture.height, newWidth, newHeight, resamplingMode, snapTo8BitColors);
            }

            public static Color[] Resample(Color[] colors, int oldWidth, int oldHeight, int newWidth, int newHeight, Enums.ImageResamplingMode resamplingMode, bool snapTo8BitColors = true) {
                if(oldWidth == newWidth && oldHeight == newHeight) return colors;

                // Colors version -- uses a LOT more memory up faster than other. Crashes much quicker.
                //ResamplingService rx = new ResamplingService();
                //rx.Filter = GetFilter(resamplingMode);
                //return rx.Resample(colors, oldWidth, oldHeight, newWidth, newHeight);

                // Convert image to ushort array format
                ushort[][,] image = ImageConverter.GetUShortImage(colors, oldWidth, oldHeight, 4);
                if(image == null) return null;

                // Resample the image
                ResamplingService rs = new ResamplingService();
                rs.Filter = GetFilter(resamplingMode);
                image = rs.Resample(image, newWidth, newHeight);
                if(image == null) return null;

                // Convert to color image
                return ImageConverter.GetColorImage(image, snapTo8BitColors);
            }

            private static ResamplingFilters GetFilter(Enums.ImageResamplingMode mode) {
                if(mode == Enums.ImageResamplingMode.Bell) return ResamplingFilters.Bell;
                if(mode == Enums.ImageResamplingMode.Box) return ResamplingFilters.Box;
                if(mode == Enums.ImageResamplingMode.CatmullRom) return ResamplingFilters.CatmullRom;
                if(mode == Enums.ImageResamplingMode.Cosine) return ResamplingFilters.Cosine;
                if(mode == Enums.ImageResamplingMode.CubicBSpline) return ResamplingFilters.CubicBSpline;
                if(mode == Enums.ImageResamplingMode.CubicConvolution) return ResamplingFilters.CubicConvolution;
                if(mode == Enums.ImageResamplingMode.Hermite) return ResamplingFilters.Hermite;
                if(mode == Enums.ImageResamplingMode.Lanczos3) return ResamplingFilters.Lanczos3;
                if(mode == Enums.ImageResamplingMode.Lanczos8) return ResamplingFilters.Lanczos8;
                if(mode == Enums.ImageResamplingMode.Mitchell) return ResamplingFilters.Mitchell;
                if(mode == Enums.ImageResamplingMode.Quadratic) return ResamplingFilters.Quadratic;
                if(mode == Enums.ImageResamplingMode.QuadraticBSpline) return ResamplingFilters.QuadraticBSpline;
                if(mode == Enums.ImageResamplingMode.Triangle) return ResamplingFilters.Triangle;
                throw new System.NotImplementedException();
            }

            private static class ImageConverter {

                private const float snap8 = 1.0f / 255.0f;

                // ushort[][,] image format:
                // Array of 2D arrays
                    // each element contains a 2D array which repesents a plane of a color channel
                    // image[x] = plane
                    // image[x][width, height] = pixels of a channel in ushort

                public static ushort[][,] GetUShortImage(Color[] colors, int width, int height, int colorChannels) {
                    if(colors == null || colors.Length == 0) throw new System.ArgumentNullException("colors");
                    if(width <= 0 || height <= 0) throw new System.ArgumentOutOfRangeException("width and height must be > 0!");
                    if(colors.Length != width * height) throw new System.ArgumentOutOfRangeException("colors.Length must equal width * height!");
                    if(colorChannels <= 0 || colorChannels > 4) throw new System.ArgumentOutOfRangeException("colorChannels must be 1-4!");

                    // Initialize the arrays - one for each color channel (plane)
                    ushort[][,] image = new ushort[colorChannels][,];
                    for(int i = 0; i < colorChannels; i++) {
                        image[i] = new ushort[width, height];
                    }

                    // Copy the pixels
                    int heightMinusOne = height - 1;
                    for(int channelIndex = 0; channelIndex < colorChannels; channelIndex++) {
                        for(int y = 0; y < height; y++) {
                            for(int x = 0; x < width; x++) {
                                int pixelIndex = (heightMinusOne - y) * width + x; // get pixel index inverting y so texture will be top-down (non-Unity format)
                                image[channelIndex][x, y] = ConvertFloatColorToUShort(colors[pixelIndex][channelIndex]);
                            }
                        }
                    }

                    return image;
                }

                public static Color[] GetColorImage(ushort[][,] image, bool snapTo8BitColors = true) {
                    if(image == null || image.Length == 0) throw new System.ArgumentNullException("image");
                    int width = image[0].GetLength(0);
                    int height = image[0].GetLength(1);
                    int colorChannels = image.Length;
                    if(width <= 0 || height <= 0) throw new System.ArgumentOutOfRangeException("image width and image height must be > 0!");
                    if(colorChannels <= 0 || colorChannels > 4) throw new System.ArgumentOutOfRangeException("colorChannels must be 1-4!");

                    Color[] colors = new Color[width * height];

                    // Copy the pixels
                    int heightMinusOne = height - 1;
                    for(int channelIndex = 0; channelIndex < colorChannels; channelIndex++) {
                        for(int y = 0; y < height; y++) {
                            for(int x = 0; x < width; x++) {
                                int pixelIndex = (heightMinusOne - y) * width + x; // get pixel index inverting y so texture will be bottom-up (Unity format)
                                float color = ConvertUShortColorToFloat(image[channelIndex][x, y]);
                                if(snapTo8BitColors) color = SnapTo8BitColorValues(color);
                                colors[pixelIndex][channelIndex] = color;
                            }
                        }
                    }

                    return colors;
                }

                private static ushort ConvertFloatColorToUShort(float color) {
                    color = Mathf.Clamp01(color); // color should be clamped 0 - 1 ... HDR colors not support
                    return (ushort)(color * System.UInt16.MaxValue);
                }

                private static float ConvertUShortColorToFloat(ushort color) {
                    if(color == 0) return 0.0f;
                    return color / (float)System.UInt16.MaxValue;
                }

                private static float SnapTo8BitColorValues(float value) {
                    if(value <= 0.0f) return 0.0f;
                    int div = Mathf.RoundToInt(value / snap8);
                    return snap8 * div;
                }
            }

            #endregion
        }
    }

    internal static class ZlibHelper {

        public static byte[] DecompressBytes(byte[] compressedBytes, bool useZlibStream) {
            if(compressedBytes == null || compressedBytes.Length == 0) return null;

            int outputSize = 2048;
            byte[] output = new byte[outputSize];
            byte[] uncompressedBytes = null;

            using(MemoryStream ms = new MemoryStream()) {
                ZlibCodec compressor = new ZlibCodec();
                compressor.InitializeInflate(useZlibStream);

                compressor.InputBuffer = compressedBytes;
                compressor.AvailableBytesIn = compressedBytes.Length;
                compressor.NextIn = 0;
                compressor.OutputBuffer = output;

                foreach(var f in new FlushType[] { FlushType.None, FlushType.Finish }) {
                    int bytesToWrite = 0;
                    do {
                        compressor.AvailableBytesOut = outputSize;
                        compressor.NextOut = 0;
                        compressor.Inflate(f);

                        bytesToWrite = outputSize - compressor.AvailableBytesOut;
                        if(bytesToWrite > 0)
                            ms.Write(output, 0, bytesToWrite);
                    }
                    while((f == FlushType.None && (compressor.AvailableBytesIn != 0 || compressor.AvailableBytesOut == 0)) ||
                           (f == FlushType.Finish && bytesToWrite != 0));
                }

                compressor.EndInflate();
                uncompressedBytes = ms.ToArray();
            }
            return uncompressedBytes;
        }

        public static byte[] CompressBytes(byte[] uncompressedBytes, CompressionLevel compressionLevel, bool useZlibStream) {
            if(uncompressedBytes == null || uncompressedBytes.Length == 0) return null;

            int outputSize = 2048;
            byte[] output = new byte[outputSize];
            byte[] compressedBytes = null;

            using(MemoryStream ms = new MemoryStream()) {

                ZlibCodec compressor = new ZlibCodec();
                compressor.InitializeDeflate(compressionLevel, useZlibStream);

                compressor.InputBuffer = uncompressedBytes;
                compressor.AvailableBytesIn = uncompressedBytes.Length;
                compressor.NextIn = 0;
                compressor.OutputBuffer = output;

                foreach(FlushType f in new FlushType[] { FlushType.None, FlushType.Finish }) {
                    int bytesToWrite = 0;
                    do {
                        compressor.AvailableBytesOut = outputSize;
                        compressor.NextOut = 0;
                        compressor.Deflate(f);

                        bytesToWrite = outputSize - compressor.AvailableBytesOut;
                        if(bytesToWrite > 0)
                            ms.Write(output, 0, bytesToWrite);
                    }
                    while((f == FlushType.None && (compressor.AvailableBytesIn != 0 || compressor.AvailableBytesOut == 0)) ||
                           (f == FlushType.Finish && bytesToWrite != 0));
                }

                compressor.EndDeflate();

                ms.Flush();
                compressedBytes = ms.ToArray();
            }
            return compressedBytes;
        }

    }

#if DEBUG
    internal static class DebugTools {
            
        private static uint usedHeapSize;

        public static void CheckHeap(string label) {
                
            uint newSize = Profiler.usedHeapSize;
            string s = "";
            s += label + ":\nusedHeapSize = " + UintToMB(newSize) + " MB.  Change: " + IntToMB((int)newSize - (int)usedHeapSize) + "\n";
            s += "MonoHeapSize = " + UintToMB(Profiler.GetMonoHeapSize()) + "\n";
            s += "MonoUsedSize = " + UintToMB(Profiler.GetMonoUsedSize()) + "\n";
            s += "TotalAllocatedMemory = " + UintToMB(Profiler.GetTotalAllocatedMemory()) + "\n";
            s += "TotalReservedMemory = " + UintToMB(Profiler.GetTotalReservedMemory()) + "\n";
            s += "TotalUnusedReservedMemory = " + UintToMB(Profiler.GetTotalUnusedReservedMemory()) + "\n";
            Debug.Log(s);
                
            usedHeapSize = newSize;
        }

        private static string UintToMB(uint value) {
            return ((float)((float)value / (1048576.0f))).ToString();
        }

        private static string IntToMB(int value) {
            return ((value / (1048576.0f))).ToString();
        }
    }
#endif
}