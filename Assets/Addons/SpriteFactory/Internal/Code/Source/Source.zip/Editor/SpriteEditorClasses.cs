using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using SpriteFactory;
using SpriteFactory.Editor.DataClasses;
using SpriteFactory.Enums;
using Sprite = SpriteFactory.Sprite;
using Settings = SpriteFactory.Settings;

namespace SpriteFactory.Editor {

    public partial class SpriteEditor {

        #region ENUMS

        private enum AtlasSize { p128 = 128, p256 = 256, p512 = 512, p1024 = 1024, p2048 = 2048, p4096 = 4096 };
        private enum EditMode { None, Sprite, SpriteGroup }
        private enum GroupChangeStatus { None, AddedToGroup, RemovedFromGroup, ChangedGroup }
        private enum MasterSpriteType { Editor, Game };
        private enum ImportStatus { Started, Completed, Failed };
        [System.Flags] private enum EditorPropertyChangeType { None = 1, Atlases = 2, Materials = 4 }

        #endregion

        #region CONSTANTS

        // Symbols
        internal const string fileNameDelimiter = "~";
        internal const string directoryDelimiter = "/";

        // File extensions
        internal const string assetExtension = ".asset";
        internal const string atlasExtension = ".png";
        internal const string materialExtension = ".mat";
        internal const string exportTextExtensionNoDot = "sfex";
        internal const string exportTextExtension = "." + exportTextExtensionNoDot;

        // Folder names
        private const string topDirName = "SpriteFactory";
        private const string internalDirName = "Internal";
        private const string codeDirName = "Code";
        private const string editorDLLDirName = "Editor";
        private const string internalDataDirName = "Data";
        private const string saveAssetsDirName = "Assets";
        private const string saveDatsaveDataDBDirName = "Editor";
        private const string atlasSaveDirName = "Atlases";
        private const string spriteSaveDirName = "Sprites";
        private const string editorMasterSpriteSaveDirName = "Editor";
        private const string gameMasterSpriteSaveDirName = "Game";
        private const string spriteGroupSaveDirName = "Groups";
        private const string materialSaveDirName = "Materials";
        private const string meshSaveDirName = "Meshes";
        private const string failedRebuildDirName = "Failed";
        private const string cacheDirName = "Cache";
        private const string resolutionTargetTextureCacheDirName = "ResTargets";
        
        // Folder paths
        private const string unityAssetsPath = "Assets";
        internal const string editorDLLRelPath = spriteEditorInternalPath + directoryDelimiter + codeDirName + directoryDelimiter + editorDLLDirName;
        private const string spriteEditorRoot = topDirName;
        private const string spriteEditorInternalPath = spriteEditorRoot + directoryDelimiter + internalDirName;
        private const string internalDataPath = spriteEditorInternalPath + directoryDelimiter + internalDataDirName;
        private const string guiSkinsPath = spriteEditorInternalPath + directoryDelimiter + "GUI";
        private const string saveDataPath = spriteEditorRoot + directoryDelimiter + "SaveData";
        private const string saveDataDBDataPath = saveDataPath + directoryDelimiter + saveDatsaveDataDBDirName;
        private const string cacheObjectDirPath = saveDataDBDataPath;
        private const string cacheFileDirPath = "SpriteFactoryCache"; // saving cache outside Assets folder
        
        // Asset folder paths
        private const string saveDataAssetsPath = saveDataPath + directoryDelimiter + saveAssetsDirName;
        private const string atlasSavePath = saveDataAssetsPath + directoryDelimiter + atlasSaveDirName;
        private const string spriteSavePath = saveDataAssetsPath + directoryDelimiter + spriteSaveDirName;
        internal const string editorMasterSpriteSavePath = spriteSavePath + directoryDelimiter + editorMasterSpriteSaveDirName;
        internal const string gameMasterSpriteSavePath = spriteSavePath + directoryDelimiter + gameMasterSpriteSaveDirName;
        internal const string spriteGroupSavePath = saveDataAssetsPath + directoryDelimiter + spriteGroupSaveDirName;
        private const string materialSavePath = saveDataAssetsPath + directoryDelimiter + materialSaveDirName;
        private const string meshSavePath = saveDataAssetsPath + directoryDelimiter + meshSaveDirName;
        private const string resolutionTargetTextureCacheSavePath = cacheFileDirPath + directoryDelimiter + resolutionTargetTextureCacheDirName; //cacheDirPath + directoryDelimiter + resolutionTargetTextureCacheDirName;

        // Failed rebuild paths
        private const string failedRebuildPath = saveDataAssetsPath + directoryDelimiter + failedRebuildDirName;
        private const string failed_saveDataAssetsPath = failedRebuildPath + directoryDelimiter + saveAssetsDirName;
        private const string failed_atlasSavePath = failedRebuildPath + directoryDelimiter + atlasSaveDirName;
        private const string failed_spriteSavePath = failedRebuildPath + directoryDelimiter + spriteSaveDirName;
        private const string failed_editorMasterSpriteSavePath = failed_spriteSavePath + directoryDelimiter + editorMasterSpriteSaveDirName;
        private const string failed_gameMasterSpriteSavePath = failed_spriteSavePath + directoryDelimiter + gameMasterSpriteSaveDirName;
        private const string failed_spriteGroupSavePath = failedRebuildPath + directoryDelimiter + spriteGroupSaveDirName;
        private const string failed_materialSavePath = failedRebuildPath + directoryDelimiter + materialSaveDirName;
        private const string failed_meshSavePath = failedRebuildPath + directoryDelimiter + meshSaveDirName;
        
        // File type identifiers
        private const string editorMasterSpriteTypeCode = "MS";
        private const string editorMasterSpriteCoreTypeCode = "MSC";
        private const string gameMasterSpriteTypeCode = "GMS";
        private const string spriteGroupTypeCode = "SG";

        // File name prefixes
        internal const string editorMasterSpriteFileNamePrefix = editorMasterSpriteTypeCode + fileNameDelimiter;
        internal const string editorMasterSpriteCoreFileNamePrefix = editorMasterSpriteCoreTypeCode + fileNameDelimiter;
        internal const string gameMasterSpriteFileNamePrefix = gameMasterSpriteTypeCode + fileNameDelimiter;
        internal const string spriteGroupFileNamePrefix = spriteGroupTypeCode + fileNameDelimiter;
        internal const string atlasFileNamePrefix = "Atlas";
        internal const string materialSetFileNamePrefix = "MaterialSet";
        internal const string editorMaterialSuffix = "EditorMaterial";
        internal const string editorMeshSuffix = "Mesh";
        
        // File name type suffixes
        internal const string editorMasterSpriteFileNameSuffix = fileNameDelimiter + editorMasterSpriteTypeCode;
        internal const string editorMasterSpriteCoreFileNameSuffix = fileNameDelimiter + editorMasterSpriteCoreTypeCode;
        internal const string gameMasterSpriteFileNameSuffix = fileNameDelimiter + gameMasterSpriteTypeCode;
        internal const string spriteGroupFileNameSuffix = fileNameDelimiter + spriteGroupTypeCode;
        
        // File paths
        internal const string spriteEditorDataFile = saveDataDBDataPath + directoryDelimiter + "Data" + assetExtension;
        internal const string spriteEditorDataSettingsFile = saveDataDBDataPath + directoryDelimiter + "Settings" + assetExtension;
        internal const string gameSettingsFilePath = internalDataPath + directoryDelimiter + "GameSettings" + assetExtension;
        internal const string _guiSkinFilePath = guiSkinsPath + directoryDelimiter + "SpriteFactorySkin.guiskin";
        internal const string cacheDataObjectFilePath = cacheObjectDirPath + directoryDelimiter + "Cache" + assetExtension;
        
        // Default object names
        internal const string defaultSpriteName = "Sprite";
        internal const string defaultGroupName = "Group";
        internal const string defaultMaterialSetName = "Default";

        #endregion

        #region STATIC VARIABLES

        internal static string rootPath;

        #endregion

        #region STATIC METHODS

        #region RELATIVE FILE/PATH HANDLING

        internal static string GetAssetPathRel(Object obj) {
            string absPath = AssetDatabase.GetAssetPath(obj);
            return AbsToRelPath(absPath);
        }

        internal static T LoadAssetAtPathRel<T>(string relativePath) where T : Object {
            return (T)AssetDatabase.LoadAssetAtPath(RelToAbsPath(relativePath), typeof(T));
        }

        internal static T[] LoadAssetsAtPathRel<T>(string relativePath) where T : Object {
            Object[] objects = AssetDatabase.LoadAllAssetsAtPath(RelToAbsPath(relativePath));
            if(objects == null) return null;
            T[] assets = null;
            for(int i = 0; i < objects.Length; i++) {
                if(objects[i].GetType() != typeof(T)) continue; // skip objects of the wrong type
                SpriteFactory.Utils.ArrayTools.Add<T>(ref assets, (T)objects[i]);
            }
            return assets;
        }

        internal static string GetAssetGUIDAtPathRel(string relativePath) {
            return AssetDatabase.AssetPathToGUID(RelToAbsPath(relativePath));
        }

        internal static void ImportAssetRel(string relativePath, ImportAssetOptions importAssetOptions = ImportAssetOptions.Default) {
            AssetDatabase.ImportAsset(RelToAbsPath(relativePath), importAssetOptions);
        }

        internal static GameObject CreatePrefabRel(string relativePath, GameObject gameObject) {
            return PrefabUtility.CreatePrefab(RelToAbsPath(relativePath), gameObject);
        }

        internal static void CreateAssetRel(Object obj, string relativePath) {
            AssetDatabase.CreateAsset(obj, RelToAbsPath(relativePath));
        }

        internal static void CreateDirectoryRel(string relativePath, bool refreshAssetDatabase = true) {
            Directory.CreateDirectory(RelToAbsPath(relativePath));
            if(refreshAssetDatabase) AssetDatabase.Refresh();
        }

        internal static bool DirectoryExistsRel(string relativePath) {
            return Directory.Exists(RelToAbsPath(relativePath));
        }

        internal static bool FileExistsRel(string relativePath) {
            return File.Exists(RelToAbsPath(relativePath));
        }

        internal static string[] DirectoryGetFilesRel(string relativePath, string searchPattern, SearchOption searchOption) {
            return Directory.GetFiles(RelToAbsPath(relativePath), searchPattern, searchOption);
        }

        internal static string[] DirectoryGetFilesRel_FileNamesOnly(string relativePath, string searchPattern, SearchOption searchOption) {
            string[] files = DirectoryGetFilesRel(relativePath, searchPattern, searchOption);
            if(files == null) return null;
            string[] fileNames = new string[files.Length];
            for(int i = 0; i < files.Length; i++) {
                fileNames[i] = Path.GetFileName(files[i]);
            }
            return fileNames;
        }

        internal static void DeleteFileRel(string relativePath) {
            if(!AssetDatabase.DeleteAsset(RelToAbsPath(relativePath))) {
                Debug.LogWarning("Could not delete file \"" + relativePath + "\". File was either missing or locked.");
            }
        }

        internal static void DeleteFilesRel(string[] relativePaths) {
            if(relativePaths == null || relativePaths.Length == 0) return;
            for(int i = 0; i < relativePaths.Length; i++) {
                DeleteFileRel(relativePaths[i]);
            }
        }

        internal static void RenameFileRel(string oldFilePath, string newFileNameNoExt, bool deleteConflicts = false) {
            Utils.UnityTools.RenameFile(RelToAbsPath(oldFilePath), newFileNameNoExt, deleteConflicts);
        }

        internal static string MoveFileRel(string oldFilePath, string newFilePath, bool deleteExisting = false) {
            if(deleteExisting) {
                if(FileExistsRel(newFilePath)) {
                    DeleteFileRel(newFilePath); // delete existing file before move
                }
            }
            return AssetDatabase.MoveAsset(RelToAbsPath(oldFilePath), RelToAbsPath(newFilePath));
        }

        internal static string RelToAbsPath(string relativePath) {
            return rootPath + relativePath;
        }

        internal static string AbsToRelPath(string absPath) {
            if(absPath == null || absPath == "" || absPath == string.Empty) return null;
            // strip root path path from beginning
            
            if(!absPath.ToLower().StartsWith(rootPath.ToLower())) return absPath; // root not found in path

            string relPath = absPath.Substring(rootPath.Length, absPath.Length - rootPath.Length);
            if(relPath.StartsWith(directoryDelimiter)) relPath = relPath.Substring(1); // strip off starting /
            return relPath;
        }

        #endregion

        #region ASSET NAMING

        internal static string GetChildFilePrefix(string spriteName = null, string groupName = null) {
            if(spriteName == null && groupName == null) return null;
            if(spriteName != null) return GetSpriteChildFilePrefix(spriteName, groupName);
            else if(groupName != null) return GetSpriteGroupChildFilePrefix(groupName);
            return null;
        }

        internal static string GetSpriteChildFilePrefix(string spriteName, string groupName = null) {
            if(spriteName == "" || spriteName == null || spriteName == string.Empty) return "";
            return string.Format("{0}{1}{2}", GetEditorMasterSpriteFilePrefix(groupName), spriteName, fileNameDelimiter);
        }

        internal static string GetSpriteGroupChildFilePrefix(string groupName) {
            if(groupName == "" || groupName == null || groupName == string.Empty) return "";
            return string.Format("{0}{1}{2}", spriteGroupFileNamePrefix, groupName, fileNameDelimiter);
        }

        internal static string GetEditorMasterSpriteFilePrefix(string groupName = null) {
            if(groupName == null) { // ungrouped
                return editorMasterSpriteFileNamePrefix;
            } else { // in a group
                return string.Format("{0}{1}{2}{3}", spriteGroupFileNamePrefix, groupName, fileNameDelimiter, editorMasterSpriteFileNamePrefix);
            }
        }

        internal static string GetEditorMasterSpriteFilePath(string name, string groupName = null) {
            if(name == "" || name == null || name == string.Empty) return "";
            return string.Format("{0}{1}{2}", editorMasterSpriteSavePath, directoryDelimiter, GetEditorMasterSpriteFileNameOnly(name, groupName));
        }

        internal static string GetEditorMasterSpriteFileNameOnly(string name, string groupName = null) {
            if(name == "" || name == null || name == string.Empty) return "";
            return string.Format("{0}{1}{2}{3}", GetEditorMasterSpriteFilePrefix(groupName), name, editorMasterSpriteFileNameSuffix, assetExtension);
        }

        internal static string AddEditorMasterSpriteFilePath(string fileName) {
            return string.Format("{0}{1}{2}", editorMasterSpriteSavePath, directoryDelimiter, fileName);
        }

        internal static string GetEditorMasterSpriteCoreFilePrefix(string groupName = null) {
            if(groupName == null) { // ungrouped
                return editorMasterSpriteFileNamePrefix;
            } else { // in a group
                return string.Format("{0}{1}{2}{3}", spriteGroupFileNamePrefix, groupName, fileNameDelimiter, editorMasterSpriteCoreFileNamePrefix);
            }
        }

        internal static string GetEditorMasterSpriteCoreFilePath(string name, string groupName = null) {
            if(name == "" || name == null || name == string.Empty) return "";
            return string.Format("{0}{1}{2}", editorMasterSpriteSavePath, directoryDelimiter, GetEditorMasterSpriteCoreFileNameOnly(name, groupName));
        }

        internal static string GetEditorMasterSpriteCoreFileNameOnly(string name, string groupName = null) {
            if(name == "" || name == null || name == string.Empty) return "";
            return string.Format("{0}{1}{2}{3}", GetEditorMasterSpriteCoreFilePrefix(groupName), name, editorMasterSpriteCoreFileNameSuffix, assetExtension);
        }
        
        internal static string AddEditorMasterSpriteCoreFilePath(string fileName) {
            return string.Format("{0}{1}{2}", editorMasterSpriteSavePath, directoryDelimiter, fileName);
        }

        internal static string GetGameMasterSpriteFilePath(string name, string groupName = null) {
            if(name == "" || name == null || name == string.Empty) return "";
            return string.Format("{0}{1}{2}", gameMasterSpriteSavePath, directoryDelimiter, GetGameMasterSpriteFileNameOnly(name, groupName));
        }

        internal static string GetGameMasterSpriteFileNameOnly(string name, string groupName = null) {
            if(name == "" || name == null || name == string.Empty) return "";
            if(groupName == null) { // this is a sprite atlas
                return string.Format("{0}{1}{2}{3}", gameMasterSpriteFileNamePrefix, name, gameMasterSpriteFileNameSuffix, assetExtension);
            } else { // this is a group atlas
                return string.Format("{0}{1}{2}{3}{4}{5}{6}", spriteGroupFileNamePrefix, groupName, fileNameDelimiter, gameMasterSpriteFileNamePrefix, name, gameMasterSpriteFileNameSuffix, assetExtension);
            }
        }

        internal static string AddGameMasterSpriteFilePath(string fileName) {
            return string.Format("{0}{1}{2}", gameMasterSpriteSavePath, directoryDelimiter, fileName);
        }

        internal static string GetSpriteGroupFilePath(string groupName) {
            if(groupName == "" || groupName == null || groupName == string.Empty) return "";
            return string.Format("{0}{1}{2}", spriteGroupSavePath, directoryDelimiter, GetSpriteGroupFileNameOnly(groupName));
        }

        internal static string GetSpriteGroupFileNameOnly(string groupName) {
            if(groupName == "" || groupName == null || groupName == string.Empty) return "";
            return string.Format("{0}{1}{2}", GetSpriteGroupChildFilePrefix(groupName), spriteGroupTypeCode, assetExtension);
        }

        internal static string AddSpriteGroupFilePath(string fileName) {
            return string.Format("{0}{1}{2}", spriteGroupSavePath, directoryDelimiter, fileName);
        }

        internal static string GetAtlasFilePath(string atlasName, string spriteName = null, string groupName = null) {
            if(atlasName == "" || atlasName == null || atlasName == string.Empty) return "";
            return string.Format("{0}{1}{2}", atlasSavePath, directoryDelimiter, GetAtlasFileNameOnly(atlasName, spriteName, groupName));
        }

        internal static string GetAtlasFileNameOnly(string atlasName, string spriteName = null, string groupName = null) {
            if(atlasName == "" || atlasName == null || atlasName == string.Empty) return "";
            if(groupName == null) { // this is a sprite atlas
                return string.Format("{0}{1}{2}", GetSpriteChildFilePrefix(spriteName, groupName), atlasName, atlasExtension);
            } else { // this is a group atlas
                return string.Format("{0}{1}{2}", GetSpriteGroupChildFilePrefix(groupName), atlasName, atlasExtension);
            }
        }

        internal static string AddAtlasFilePath(string fileName) {
            return string.Format("{0}{1}{2}", atlasSavePath, directoryDelimiter, fileName);
        }

        internal static string GetMaterialFilePath(string materialName, string spriteName = null, string groupName = null) {
            if(materialName == "" || materialName == null || materialName == string.Empty) return "";
            return string.Format("{0}{1}{2}", materialSavePath, directoryDelimiter, GetMaterialFileNameOnly(materialName, spriteName, groupName));
        }

        internal static string GetMaterialFileNameOnly(string materialName, string spriteName = null, string groupName = null) {
            if(materialName == "" || materialName == null || materialName == string.Empty) return "";
            return string.Format("{0}{1}{2}", GetChildFilePrefix(spriteName, groupName), materialName, materialExtension);
        }

        internal static string AddMaterialFilePath(string fileName) {
            return string.Format("{0}{1}{2}", materialSavePath, directoryDelimiter, fileName);
        }

        internal static string GetEditorMaterialFilePath(string spriteName, string groupName = null) {
            if(spriteName == "" || spriteName == null || spriteName == string.Empty) return "";
            return GetMaterialFilePath(editorMaterialSuffix, spriteName, groupName);
        }

        internal static string GetEditorMaterialFileNameOnly(string spriteName, string groupName = null) {
            if(spriteName == "" || spriteName == null || spriteName == string.Empty) return "";
            return GetMaterialFileNameOnly(editorMaterialSuffix, spriteName, groupName);
        }

        internal static string GetEditorMeshFilePath(string spriteName, string groupName = null) {
            if(spriteName == "" || spriteName == null || spriteName == string.Empty) return "";
            return string.Format("{0}{1}{2}", meshSavePath, directoryDelimiter, GetEditorMeshFileNameOnly(spriteName, groupName));
        }

        internal static string GetEditorMeshFileNameOnly(string spriteName, string groupName = null) {
            if(spriteName == "" || spriteName == null || spriteName == string.Empty) return "";
            return string.Format("{0}{1}{2}", GetChildFilePrefix(spriteName, groupName), editorMeshSuffix, assetExtension);
        }

        internal static string AddEditorMeshFilePath(string fileName) {
            return string.Format("{0}{1}{2}", meshSavePath, directoryDelimiter, fileName);
        }

        #endregion

        #endregion

        #region PRIVATE CLASSES

        #region GUI CLASSES

        private abstract class SimpleGUIControl {
            private bool _isReady; public bool isReady { get { return _isReady; } protected set { _isReady = value; } }
            private bool _refresh = true; public bool refresh { get { return _refresh; } set { _refresh = value; if(_refresh) ClearChildren(); } } // call refresh if just a selection changes
            public bool refreshDontClearChildren { set { _refresh = value; if(_refresh) UpdateChildren(); } } // refresh children, but don't clear child controls
            private bool _changed;
            public bool changed { // call change when any data changes that would affect a changePartner
                get { return _changed; }
                set {
                    if(value) {
                        refresh = true; // set refresh in self and clear children
                        UpdateChangePartners(); // refresh any connected controls that get refreshed on data changes only
                    }
                    _changed = value;
                }
            }

            protected SimpleGUIControl _parent = null; public SimpleGUIControl parent { get { return _parent; } set { _parent = value; if(_parent != null) _parent.AddChild(this); } } // sets parent and adds reciprocal link as child in parent
            protected List<SimpleGUIControl> _children = new List<SimpleGUIControl>();
            protected List<SimpleGUIControl> _changePartners = new List<SimpleGUIControl>();


            private void UpdateAll() {
                bool isTopParent = _parent == null ? true : false;
                if(!isTopParent) {
                    _parent.UpdateAll(); // send update up the ladder
                    return;
                }
                //This is the top parent
                Update(); // update self and the children recursively
            }

            private void Update() {
                UpdateSelf();
                UpdateChildren();
            }

            private void UpdateSelf() {
                _refresh = true;
            }

            protected void UpdateChildren() {
                if(_children.Count > 0) {
                    for(int i = 0; i < _children.Count; i++) {
                        _children[i].Update();
                    }
                }
            }

            private void UpdateChangePartners() {
                if(_changePartners.Count > 0) {
                    for(int i = 0; i < _changePartners.Count; i++) {
                        _changePartners[i].Update();
                    }
                }
            }

            public void ClearChildren() {
                // Clear any controls that depend on the selection of this control
                if(_children.Count > 0) {
                    for(int i = 0; i < _children.Count; i++) {
                        _children[i].Clear();
                        _children[i].ClearChildren(); // clear children recursively
                    }
                }
            }

            public void AddChild(SimpleGUIControl child) {
                _children.Add(child);
            }

            public void AddChangePartner(SimpleGUIControl partner) {
                _changePartners.Add(partner);
            }

            protected void BeginNewCycle() {
                ClearMomentaryVars();
            }

            private void ClearMomentaryVars() {
                // clear momentary vars
                if(_changed) _changed = false;
            }

            // Stubs
            public abstract void Clear();
        }

        private class SimpleGUITextField : SimpleGUIControl {
            public string value;
            public GUIContent label = null;

            public SimpleGUITextField(string inLabel) {
                if(inLabel != null) label = new GUIContent(inLabel + ":");
                isReady = true;
            }

            public SimpleGUITextField(GUIContent inLabel) {
                label = inLabel;
                if(inLabel != null) label.text += ":";
                isReady = true;
            }

            public bool Draw(ref string storedValue) {
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(refresh) { // update the value from storage
                    value = storedValue;
                    refresh = false;
                }

                if(_parent != null && !_parent.isReady) return false; // has a parent, but parent isn't ready

                string origValue = value;
                value = Utils.GUITools.EditorLayout.TextField(label, value); // write description
                if(origValue != value) {
                    changed = true;
                    storedValue = value; // update the value in the target
                    return true;
                }
                return false;
            }

            public override void Clear() {
                value = "";
                changed = true;
            }
        }

        private class SimpleGUIToggle : SimpleGUIControl {
            public bool value;
            public GUIContent label = null;

            public SimpleGUIToggle() {
                label = null;
            }

            public SimpleGUIToggle(string inLabel) {
                if(inLabel != null) label = new GUIContent(inLabel + ":");
                isReady = true;
            }

            public SimpleGUIToggle(GUIContent inLabel) {
                label = inLabel;
                if(inLabel != null) label.text += ":";
                isReady = true;
            }

            public bool Draw(float fixedWidth = 0.0f, GUIStyle style = null) {
                return Draw(ref value, fixedWidth, style);
            }

            public bool Draw(ref bool storedValue, float fixedWidth = 0.0f, GUIStyle style = null) {
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(refresh) { // update the value from storage
                    value = storedValue;
                    refresh = false;
                }

                if(_parent != null && !_parent.isReady) return false; // has a parent, but parent isn't ready

                bool origValue = value;
                if(label != null) {
                    if(fixedWidth > 0.0f) value = Utils.GUITools.EditorLayout.Toggle(label, value, style, GUILayout.Width(fixedWidth)); // write description
                    else value = Utils.GUITools.EditorLayout.Toggle(label, value, style);
                } else {
                    if(fixedWidth > 0.0f) value = Utils.GUITools.EditorLayout.Toggle(value, style, GUILayout.Width(fixedWidth));
                    else value = Utils.GUITools.EditorLayout.Toggle(value, style);
                }
                if(origValue != value) {
                    changed = true;
                    storedValue = value; // update the value in the target
                    return true;
                }
                return false;
            }

            public override void Clear() {
                value = false;
                changed = true;
            }
        }

        private class SimpleGUIFloatField : SimpleGUIControl {
            public float value;
            public GUIContent label = null;

            private bool clamp;
            private float min;
            private float max;

            public SimpleGUIFloatField(string inLabel) {
                if(inLabel != null) label = new GUIContent(inLabel + ":");
                isReady = true;
            }

            public SimpleGUIFloatField(GUIContent inLabel) {
                label = inLabel;
                if(inLabel != null) label.text += ":";
                isReady = true;
            }

            public SimpleGUIFloatField(string inLabel, float inMin, float inMax) {
                if(inLabel != null) label = new GUIContent(inLabel + ":");
                label.text += ":";
                clamp = true;
                min = inMin;
                max = inMax;
                isReady = true;
            }

            public SimpleGUIFloatField(GUIContent inLabel, float inMin, float inMax) {
                label = inLabel;
                if(inLabel != null) label.text += ":";
                clamp = true;
                min = inMin;
                max = inMax;
                isReady = true;
            }

            public bool Draw(float storedValue, out float outValue, bool readOnly = false, float fixedWidth = 0.0f) { // overload that reports when a change has been made but doesn't record it in the object
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                bool result = Draw(ref storedValue, readOnly, fixedWidth);
                outValue = storedValue;
                return result;
            }

            public bool Draw(ref float storedValue, bool readOnly = false, float fixedWidth = 0.0f) {
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(refresh) { // update the value from storage
                    value = storedValue;
                    refresh = false;
                }

                if(_parent != null && !_parent.isReady) return false; // has a parent, but parent isn't ready

                if(!readOnly) {
                    
                        float origValue = value;
                        value = DrawField(fixedWidth); // Draw the field
                        if(clamp) { // clamp values
                            if(Event.current.type != EventType.layout) { // do not allow clamp to change values in layout or it will error if data fields are out of range and it clamps and changes the value in Layout!
                                if(value < min) value = min;
                                if(value > max) value = max;
                            }
                        }
                        if(origValue != value) {
                            changed = true;
                            storedValue = value; // update the value in the target
                            return true;
                        }
                } else { // this control is read only
                    bool guiState = GUI.enabled; // save orig state
                    GUI.enabled = false; // disable GUI input
                    value = DrawField(fixedWidth);
                    GUI.enabled = guiState; // restore GUI to original state
                }
                return false;
            }

            private float DrawField(float fixedWidth) {

                if(label != null) {
                    if(fixedWidth > 0.0f)
                        return Utils.GUITools.EditorLayout.FloatField(label, value, GUILayout.Width(fixedWidth)); // draw field
                    else
                        return Utils.GUITools.EditorLayout.FloatField(label, value); // draw field
                } else {
                    if(fixedWidth > 0.0f)
                        return Utils.GUITools.EditorLayout.FloatField(value, GUILayout.Width(fixedWidth)); // draw field
                    else
                        return Utils.GUITools.EditorLayout.FloatField(value); // draw field
                }
            }

            public override void Clear() {
                value = 0.0f;
                changed = true;
            }
        }

        private class SimpleGUIIntField : SimpleGUIControl {
            public int value;
            public GUIContent label = null;

            private bool clamp;
            private int min;
            private int max;

            public SimpleGUIIntField(string inLabel) {
                if(inLabel != null) label = new GUIContent(inLabel + ":");
                isReady = true;
            }

            public SimpleGUIIntField(GUIContent inLabel) {
                label = inLabel;
                if(inLabel != null) label.text += ":";
                isReady = true;
            }

            public SimpleGUIIntField(string inLabel, int inMin, int inMax)
                : this(inLabel) {
                clamp = true;
                min = inMin;
                max = inMax;
            }

            public SimpleGUIIntField(GUIContent inLabel, int inMin, int inMax)
                : this(inLabel) {
                clamp = true;
                min = inMin;
                max = inMax;
            }

            public bool Draw(int storedValue, out int outValue, float fixedWidth = 0.0f) { // overload that reports when a change has been made but doesn't record it in the object
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                bool result = Draw(ref storedValue, fixedWidth);
                outValue = storedValue;
                return result;
            }

            public bool Draw(ref int storedValue, float fixedWidth = 0.0f) {
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(refresh) { // update the value from storage
                    value = storedValue;
                    refresh = false;
                }

                if(_parent != null && !_parent.isReady) return false; // has a parent, but parent isn't ready

                int origValue = value;
                if(fixedWidth > 0.0f)
                    value = Utils.GUITools.EditorLayout.IntField(label, value, GUILayout.Width(fixedWidth)); // write description
                else
                    value = Utils.GUITools.EditorLayout.IntField(label, value); // write description
                if(clamp) { // clamp values
                    if(Event.current.type != EventType.layout) { // do not allow clamp to change values in layout or it will error if data fields are out of range and it clamps and changes the value in Layout!
                        if(value < min) value = min;
                        if(value > max) value = max;
                    }
                }
                if(origValue != value) {
                    changed = true;
                    storedValue = value; // update the value in the target
                    return true;
                }
                return false;
            }

            public override void Clear() {
                value = 0;
                changed = true;
            }
        }

        private class SimpleGUIPopup : SimpleGUIControl {
            public int selectionIndex { get; private set; }
            private GUIContent[] options;
            private GUIContent label = null;
            private int defaultSelection = 0;

            public SimpleGUIPopup() {
                InitializeVars();
                options = new GUIContent[0];
            }

            public SimpleGUIPopup(string inLabel) {
                InitializeVars();
                if(inLabel != null) label = new GUIContent(inLabel + ":");
                options = new GUIContent[0];
            }

            public SimpleGUIPopup(GUIContent inLabel) {
                InitializeVars();
                label = inLabel;
                if(inLabel != null) label.text += ":";
                options = new GUIContent[0];
            }

            public SimpleGUIPopup(string[] inOptions) {
                InitializeVars();
                options = ConvertStringsToGUIContents(inOptions);
            }

            public SimpleGUIPopup(string inLabel, string[] inOptions) {
                InitializeVars();
                if(inLabel != null) label = new GUIContent(inLabel + ":");
                options = ConvertStringsToGUIContents(inOptions);
            }

            public SimpleGUIPopup(GUIContent inLabel, string[] inOptions) {
                InitializeVars();
                label = inLabel;
                if(inLabel != null) label.text += ":";
                options = ConvertStringsToGUIContents(inOptions);
            }

            private void InitializeVars() {
                selectionIndex = 0;
                isReady = true;
            }

            public bool Draw(int storedSelection) {
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(refresh) { // update the value from storage
                    selectionIndex = storedSelection;
                    refresh = false;
                }

                if(_parent != null && !_parent.isReady) return false; // has a parent, but parent isn't ready

                int origSelection = selectionIndex;
                selectionIndex = Utils.GUITools.EditorLayout.Popup(label, selectionIndex, options); // write description

                if(origSelection != selectionIndex) {
                    changed = true;
                    return true;
                }
                return false;
            }

            public bool ChangeSelection(int index) {
                if(options == null || index >= options.Length) return false;
                if(selectionIndex == index) return false;
                selectionIndex = index; // change the selection
                changed = true; // refresh the control next cycle
                return true;
            }

            public void SetOptions(string[] inOptions) {
                options = ConvertStringsToGUIContents(inOptions);
                if(selectionIndex >= options.Length)
                    selectionIndex = -1;
            }

            private GUIContent[] ConvertStringsToGUIContents(string[] strings) {
                if(strings == null) return null;
                if(strings.Length == 0) return new GUIContent[0];
                GUIContent[] returnValue = new GUIContent[strings.Length];
                for(int i = 0; i < strings.Length; i++)
                    returnValue[i] = new GUIContent(strings[i]);
                return returnValue;
            }

            public void SetDefaultSelection(int index) {
                defaultSelection = index;
            }

            public override void Clear() {
                selectionIndex = defaultSelection;
                changed = true;
            }
        }

        private class SimpleGUIPopupEnum : SimpleGUIControl {
            public int selectionValue { get; private set; }
            private int selectionIndex;
            private GUIContent[] options;
            private int[] values;
            private GUIContent label = null;

            public SimpleGUIPopupEnum(string[] inOptions, int[] values) {
                InitializeVars();
                options = ConvertStringsToGUIContents(inOptions);
                this.values = SpriteFactory.Utils.ArrayTools.Clone<int>(values);
            }

            public SimpleGUIPopupEnum(string inLabel, string[] inOptions, int[] values) {
                InitializeVars();
                if(inLabel != null) label = new GUIContent(inLabel + ":");
                options = ConvertStringsToGUIContents(inOptions);
                this.values = SpriteFactory.Utils.ArrayTools.Clone<int>(values);
            }

            public SimpleGUIPopupEnum(GUIContent inLabel, string[] inOptions, int[] values) {
                InitializeVars();
                label = inLabel;
                if(inLabel != null) label.text += ":";
                options = ConvertStringsToGUIContents(inOptions);
                this.values = SpriteFactory.Utils.ArrayTools.Clone<int>(values);
            }

            private void InitializeVars() {
                selectionIndex = 0;
                selectionValue = 0;
                isReady = true;
            }

            public bool DrawByValue(int storedSelectionValue) { // draw by value, not index
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(refresh) { // update the value from storage
                    ChangeSelection_Go(FindValueIndex(storedSelectionValue), false);
                    refresh = false;
                }

                if(_parent != null && !_parent.isReady) return false; // has a parent, but parent isn't ready

                int origSelection = selectionIndex;
                int newSelection = Utils.GUITools.EditorLayout.Popup(label, selectionIndex, options); // write description

                if(origSelection != newSelection) {
                    ChangeSelection(newSelection);
                    return true;
                }
                return false;
            }

            private int FindValueIndex(int value) {
                if(values == null || values.Length == 0) return -1;
                for(int i = 0; i < values.Length; i++) {
                    if(values[i] == value) return i;
                }
                return -1;
            }

            public bool ChangeSelection(int index) {
                return ChangeSelection_Go(index, true);
            }

            private bool ChangeSelection_Go(int index, bool setChangeFlag) {
                if(options == null || index >= options.Length) return false;
                if(selectionIndex == index) return false;
                selectionIndex = index; // change the selection
                changed = true; // refresh the control next cycle
                if(values != null && selectionIndex < values.Length) {
                    selectionValue = values[selectionIndex]; // update selection value
                }
                return true;
            }

            public void SetOptions(string[] inOptions, int[] values) {
                options = ConvertStringsToGUIContents(inOptions);
                if(selectionIndex >= options.Length)
                    selectionIndex = -1;
                this.values = SpriteFactory.Utils.ArrayTools.Clone<int>(values);
            }

            private GUIContent[] ConvertStringsToGUIContents(string[] strings) {
                if(strings == null) return null;
                if(strings.Length == 0) return new GUIContent[0];
                GUIContent[] returnValue = new GUIContent[strings.Length];
                for(int i = 0; i < strings.Length; i++)
                    returnValue[i] = new GUIContent(strings[i]);
                return returnValue;
            }

            public override void Clear() {
                selectionIndex = 0;
                selectionValue = -1;
                changed = true;
            }
        }

        private class SimpleGUIColorField : SimpleGUIControl {
            public Color value;
            public GUIContent label = null;

            public SimpleGUIColorField(string inLabel) {
                if(inLabel != null) label = new GUIContent(inLabel + ":");
                isReady = true;
            }

            public SimpleGUIColorField(GUIContent inLabel) {
                label = inLabel;
                if(inLabel != null) label.text += ":";
                isReady = true;
            }

            public bool Draw(ref Color storedValue) {
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(refresh) { // update the value from storage
                    value = storedValue;
                    refresh = false;
                }

                if(_parent != null && !_parent.isReady) return false; // has a parent, but parent isn't ready

                Color origValue = value;
                value = Utils.GUITools.EditorLayout.ColorField(label, value); // write description
                if(origValue != value) {
                    changed = true;
                    storedValue = value; // update the value in the target
                    return true;
                }
                return false;
            }

            public override void Clear() {
                value = new Color(0.0f, 0.0f, 0.0f, 0.0f);
                changed = true;
            }
        }

        private class SimpleGUIObjectField : SimpleGUIControl {
            public Object value;
            public System.Type type;
            public GUIContent label = null;
            private bool _allowSceneObjects;

            public SimpleGUIObjectField(string inLabel, System.Type inType, bool allowSceneObjects) {
                if(inLabel != null) label = new GUIContent(inLabel + ":");
                type = inType;
                isReady = true;
                _allowSceneObjects = allowSceneObjects;
            }

            public SimpleGUIObjectField(GUIContent inLabel, System.Type inType, bool allowSceneObjects) {
                label = inLabel;
                if(inLabel != null) label.text += ":";
                type = inType;
                isReady = true;
                _allowSceneObjects = allowSceneObjects;
            }

            public bool Draw(ref Object storedValue) {
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(refresh) { // update the value from storage
                    value = storedValue;
                    refresh = false;
                }

                if(_parent != null && !_parent.isReady) return false; // has a parent, but parent isn't ready

                Object origValue = value;
                value = Utils.GUITools.EditorLayout.ObjectField(label, value, type, _allowSceneObjects); // write description
                if(origValue != value) {
                    changed = true;
                    storedValue = value; // update the value in the target
                    return true;
                }
                return false;
            }

            public override void Clear() {
                value = null;
                changed = true;
            }
        }

        private class SimpleGUIListBoxContainer<T> : SimpleGUIControl {
            private ListBox listBox;
            private GUISkin skin;
            private int _selectedIndex;
            public T selectedObject;
            private T[] objectList;
            private bool _selectionChanged;
            private bool _softRefresh;
            private bool autoSelectFirstEntry;
            private SelectionChangeDelegate selectionChangeDelegate;

            // Properties
            public bool hasSelection {
                get {
                    if(selectedIndex > -1) return true;
                    return false;
                }
            }
            public int selectedIndex {
                get {
                    return _selectedIndex;
                }
                set {
                    _selectedIndex = value;
                    if(_selectedIndex >= 0)
                        isReady = true;
                }
            }
            public bool selectionChanged {
                get {
                    return _selectionChanged;
                }
            }
            public bool softRefresh {
                set {
                    _softRefresh = value;
                }
            }
            public int itemCount {
                get {
                    if(listBox == null) return 0;
                    return listBox.entryCount;
                }
            }

            public SimpleGUIListBoxContainer(GUISkin inSkin, bool inAutoSelectFirstEntry = false) {
                skin = inSkin;
                autoSelectFirstEntry = inAutoSelectFirstEntry;
                ClearAll();
            }

            public SimpleGUIListBoxContainer(GUISkin inSkin, SelectionChangeDelegate selectionChangeDelegate, bool inAutoSelectFirstEntry = false) : this(inSkin, inAutoSelectFirstEntry) {
                this.selectionChangeDelegate = selectionChangeDelegate;
            }

            public void Draw(int itemCount, T[] itemList, string[] nameList, string emptyMsg, bool displayIndex, float width, float height, bool pushSelection, int pushedSelectionIndex) {
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(_selectionChanged) _selectionChanged = false;

                objectList = itemList; // store the objects every time we draw it

                // If no items, display an empty message
                if(itemCount == 0) {
                    listBox.Clear();
                    listBox.DrawEmpty(GUILayoutUtility.GetRect(width, height), emptyMsg);
                    ClearSelection();
                    return;
                }

                // Rebuild list of item names, ids only if necessary
                if(refresh || _softRefresh) {
                    listBox.Clear(); // clear the list first

                    // Create id : description string for each item in list
                    for(int i = 0; i < itemCount; i++) {
                        string name = nameList[i];
                        if(displayIndex) name = i + " : " + name; // insert index before name
                        listBox.AddEntry(name); // add the name to the listBox
                    }
                    if(refresh) refresh = false; // just refreshed, flag off
                    if(_softRefresh) softRefresh = false;
                }

                // Check if there are any entries at all and make sure we don't still have a selection, also make sure if last cell is deleted, we clear the selection
                if(listBox.entryCount <= 0 || selectedIndex >= listBox.entryCount) {
                    ClearSelection();
                }

                if(parent != null && !parent.isReady) return; // parent doesn't have anything selected, don't draw

                // Handle pushed selection
                bool pushed = false;
                if(pushSelection && pushedSelectionIndex >= 0 && pushedSelectionIndex < listBox.entryCount) { // pushed selection
                    selectedIndex = pushedSelectionIndex;
                    pushed = true;
                }
                if(listBox.GetSelectedId() != _selectedIndex) pushed = true; // detect implicit pushes from external controls

                // Automatically select the first entry
                bool autoSelected = false;
                if(autoSelectFirstEntry && _selectedIndex == -1) { // we have no selection
                    selectedIndex = 0;
                    autoSelected = true;
                }

                // Store original selected object for change detection
                T origSelectedObject = selectedObject;

                // Get rect where we will draw control
                listBox.ChangeSelection(_selectedIndex); // push possible changed selection into control
                Rect rect = GUILayoutUtility.GetRect(width, height);
                rect.width = width; // force rect to be correct width so padding doesn't make it wider than it should be
                rect.height = height;

                // Draw the list box control
                _selectionChanged = listBox.Draw(rect, pushed);
                int newVal = listBox.GetSelectedId(); // get changed selection id

                // Check for changes in value both with selection index and objects
                if(!_selectionChanged) {
                    if(newVal == -1 && object.Equals(selectedObject, default(T))) return; // nothing is selected
                    // account for updating after add/delete/move actions change the selection - allow selection to fall through and select whatever entry is next in line
                    if(newVal >= itemCount) newVal = -1; // selection no longer valid, set no selection
                    if(newVal >= 0 && object.Equals(selectedObject, itemList[newVal])) // objects match so they're the same
                        return; // no change, return
                    // objects that do not match will fall through and new selection will be made on element in same location
                }

                // Selection changed
                refresh = true; // refresh this and all child controls
                if(selectionChangeDelegate != null) selectionChangeDelegate(false, origSelectedObject); // call delegate on selection

                // Set final vars based on change
                selectedIndex = newVal;
                if(selectedIndex >= 0) { // an object was selected
                    selectedObject = itemList[selectedIndex]; // find the object to return
                    if(selectionChangeDelegate != null) selectionChangeDelegate(true, selectedObject); // call delegate on selection
                }

                // Flag changed if we autoselected something or a new selection was pushed in
                if(pushed || autoSelected) {
                    _selectionChanged = true;
                }
            }

            public void DeleteSelected() { // call when deleting an item from the list
                // if there is only one entry left, just clear the selection
                if(listBox.entryCount == 1) { // there is only one entry left
                    Clear(); // just clear the container
                } else { // not the last entry, update the selected object with the next object in the list

                    // Remove entry from object list and listbox
                    if(objectList != null && selectedIndex >= 0 && selectedIndex < objectList.Length) { // we have a valid object to select for the index
                        SpriteFactory.Utils.ArrayTools.RemoveAt<T>(ref objectList, selectedIndex); // remove the object from the object list
                        listBox.RemoveAt(selectedIndex); // remove the entry from the listbox
                    }

                    // Select previous entry if deleting the last one in the list
                    if(selectedIndex >= listBox.entryCount) { // selection is beyond list limit
                        selectedIndex = listBox.entryCount - 1; // select the new last entry
                    }

                    // Refresh selected object and index
                    if(objectList != null && selectedIndex >= 0 && selectedIndex < listBox.entryCount) { // we have a valid object to select for the index
                        selectedObject = objectList[selectedIndex]; // get the proper selected object at the index
                        listBox.ChangeSelection(selectedIndex); // set the selected entry in the listBox
                    } else // something went wrong and there's no object below to select
                        ClearSelection(); // just clear the selection
                }
            }

            public void ClearAll() {
                //listBox = new ListBox(skin); // make a new listbox
                Clear();
            }

            public override void Clear() {
                objectList = null; // clear the object list
                // Selected choices
                ClearSelection();
                listBox = new ListBox(skin); // make a new listbox -- I SUSPECT THIS has something to do with a problem with refreshing the top-most parent of nested lists, but my change didn't work so we'll leave this to future sleuthing
                // DO NOT clear the list box here because when a child control drives a refresh, we can't have the list box cleared immediately or we'll get errors
                // listbox will be cleared when refresh rolls around
                refresh = true;
            }

            public void ClearSelection() {
                if(selectionChangeDelegate != null) selectionChangeDelegate(false, selectedObject); // call delegate before deselection
                
                _selectedIndex = -1;
                selectedObject = default(T);
                isReady = false;
                refresh = true; // clear all children

                // autoselect the first entry immediately
                if(autoSelectFirstEntry && listBox != null && listBox.entryCount > 0 && objectList != null && objectList.Length > 0) {
                    selectedIndex = 0;
                    selectedObject = objectList[selectedIndex];
                    listBox.ChangeSelection(selectedIndex); // push changed selection
                    if(selectionChangeDelegate != null) selectionChangeDelegate(true, selectedObject); // call delegate on selection
                }
            }

            public void ChangeSelection(int index, bool force = false) {
                if(index < 0) { // clear selection
                    ClearSelection();
                    return;
                }
                if(index >= listBox.entryCount) return;
                if(!force && index == _selectedIndex) return; // same

                if(selectionChangeDelegate != null) selectionChangeDelegate(false, selectedObject); // call delegate before deselection
                _selectedIndex = index;
                selectedObject = default(T); // wait until Draw to actually select the new object
                refresh = true;
            }

            public void SelectPrevious(bool wrap = false) {
                if(listBox.entryCount == 0) return;

                int newIndex = _selectedIndex - 1; // move up in list
                
                if(!wrap) {
                    if(newIndex < 0) return;
                } else {
                    if(newIndex < 0) // wrap
                        newIndex = listBox.entryCount - 1; // select last in list
                }

                _selectedIndex = newIndex;
                selectedObject = default(T);
            }

            public void SelectNext(bool wrap = false) {
                if(listBox.entryCount == 0) return;

                int newIndex = _selectedIndex + 1; // move down in list

                if(!wrap) {
                    if(newIndex >= listBox.entryCount) return;
                } else {
                    if(newIndex >= listBox.entryCount) // wrap
                        newIndex = 0;
                }

                _selectedIndex = newIndex;
                selectedObject = default(T);
            }

            // Delegates

            public delegate void SelectionChangeDelegate(bool selected, T selectedObject);

            // Private Classes

            private class ListBox {

                // Consts

                // Use fixed width for now
                private const int vScrollBarWidth = 15;
                private const int hScrollBarHeight = 15;
                private float itemHeight = 18.0f; // may change this to dynamic at some point but for now its fine static
                // calculated height doesn't seem to come out right. we get 13 when it should be 18...
                
                // Variables
                private List<ListBoxEntry> entryList = new List<ListBoxEntry>();
                private int selected = -1;
                private Vector2 scrollPos;
                private float maxItemWidth;
                private GUISkin skin;
                private GUIStyle origStyle;
                private GUIStyle style;
                private GUIStyle style_on;
                public int entryCount { get { if(entryList == null) return 0; return entryList.Count; } }
                private bool stylesCreated;
                private Controller lastControlledBy;

                // Vars to prevent updating selection until right event point to avoid errors
                private bool setSelectedDeferred;
                private int selectedDeferred;

                //.Enums
                private enum Controller { None, External, Keyboard, Mouse }

                public ListBox(GUISkin inSkin) {
                    skin = inSkin;
                    // CreateStyles(); // can no longer create styles on instantiation because of bug requiring us to use GUI.skin instead of getting the editor skin
                }

                public ListBox(float inItemHeight, GUISkin inSkin) {
                    itemHeight = inItemHeight;
                    skin = inSkin;
                    // CreateStyles(); // can no longer create styles on instantiation because of bug requiring us to use GUI.skin instead of getting the editor skin
                }

                //Public functions ////

                public void AddEntry(string Name) {
                    entryList.Add(new ListBoxEntry(Name));
                    CalculateItemWidth(Name);
                }

                public void RemoveAt(int index) {
                    if(index < 0 || index >= entryCount) return; // bad index
                    entryList.RemoveAt(index); // remove entry from list
                }

                public int GetSelectedId() {
                    return selected;
                }

                public void ChangeSelection(int index) {
                    if(index >= entryList.Count || index < -1) return;
                    selected = index; // save selection id
                }

                public void ShowSelected(Rect area) {
                    if(selected < 0 || selected >= entryCount) return;
                    if(IsSelectedVisible(area)) return; // already visible

                    scrollPos.y = selected * itemHeight;
                    scrollPos.x = 0.0f;
                }

                public bool IsSelectedVisible(Rect area) {
                    if(selected < 0) return false;
                    
                    float totalContentsHeight;
                    float visibleWidth;
                    float visibleHeight;
                    bool vScrollBarVisible;
                    bool hScrollBarVisible;

                    GetDimensions(area, maxItemWidth, out totalContentsHeight, out visibleWidth, out visibleHeight, out vScrollBarVisible, out hScrollBarVisible);

                    Rect localViewArea = area; // start with the scroll box rect (world coords)
                    localViewArea.x = scrollPos.x;
                    localViewArea.y = scrollPos.y;

                    if(vScrollBarVisible) localViewArea.width -= vScrollBarWidth; // prevent clicks in the scroller from selecting other elements
                    if(hScrollBarVisible) localViewArea.height -= hScrollBarHeight; // prevent clicks in the scroller from selecting other elements

                    float yPos = selected * itemHeight;
                    if(yPos < localViewArea.y || yPos > localViewArea.y + visibleHeight) return false;
                    return true;
                }

                public void Clear() {
                    entryList.Clear();
                    maxItemWidth = 0.0f; // we will be recalculating contents width
                    setSelectedDeferred = false;
                }

                public void DrawEmpty(Rect area, string emptyMsg) {
                    if(!stylesCreated) CreateStyles();

                    // Make the scroll view
                    GUI.Box(area, string.Empty); // draw box behind entire scroll view
                    Rect viewRect = new Rect(0.0f, 0.0f, area.width, itemHeight);
                    scrollPos = GUI.BeginScrollView(area, scrollPos, viewRect); // make a scroll view
                    GUI.Label(viewRect, emptyMsg); // show empty message
                    GUI.EndScrollView();
                }

                public bool Draw(Rect area, bool pushed) {
                    if(!stylesCreated) CreateStyles();

                    float y = 0.0f;
                    string entryText = "";
                    int tempSelected = selected; // working selected
                    Event ev = Event.current;
                    bool mouseEvent = false;
                    bool keyboardEvent = false;
                    bool layoutEvent = false;
                    Vector2 mpos;
                    Rect localViewArea;
                    float totalContentsHeight;
                    float visibleWidth;
                    float visibleHeight;
                    bool vScrollBarVisible;
                    bool hScrollBarVisible;
                    GUIStyle curStyle;
                    float modifiedMaxItemWidth = maxItemWidth;

                    // Detect event type
                    if(ev.type == EventType.MouseDown && Event.current.button == 0)
                        mouseEvent = true; // this is a mouse event cycle
                    else if(ev.type == EventType.Layout)
                        layoutEvent = true; // this is a layout event cycle

                    // Get final dimensions
                    GetDimensions(area, modifiedMaxItemWidth, out totalContentsHeight, out visibleWidth, out visibleHeight, out vScrollBarVisible, out hScrollBarVisible);

                    // Adjust width of elements to fill visible area accounting for scroll bar
                    if(modifiedMaxItemWidth < visibleWidth) {
                        modifiedMaxItemWidth = visibleWidth; // make items at least as wide as the scroll box (or we get weird error if horiz scrollbar is forced on)
                    }

                    // Make the scroll view
                    GUI.Box(area, string.Empty); // draw box behind entire scroll view
                    Rect viewRect = new Rect(0.0f, 0.0f, modifiedMaxItemWidth, totalContentsHeight);
                    scrollPos = GUI.BeginScrollView(area, scrollPos, viewRect); // make a scroll view with inner height of entries * height
                    // Offset view area by scroll pos to find relative view area in local coords
                    localViewArea = area; // start with the scroll box rect (world coords)
                    localViewArea.x = scrollPos.x;
                    localViewArea.y = scrollPos.y;

                    if(vScrollBarVisible) localViewArea.width -= vScrollBarWidth; // prevent clicks in the scroller from selecting other elements
                    if(hScrollBarVisible) localViewArea.height -= hScrollBarHeight; // prevent clicks in the scroller from selecting other elements

                    //Get mouse pos for hover and click detection
                    mpos = ev.mousePosition;

                    //Loop through to draw the entries and check for selection.
                    for(int i = 0; i < entryList.Count; i++) {
                        //bool hover = false;

                        // DRAW CULLING - important for speed of large lists
                        // Quickly determine if text would be visible in the scroll area
                        if(y > scrollPos.y + area.height || y + itemHeight < scrollPos.y) { // top pixel of this entry is scrolled off the bottom, or bottom pixel of this entry is scrolled off the top
                            y += itemHeight; // increment y for next round
                            continue; // skip this entry
                        }

                        entryText = entryList[i].name; // Get the list entry's name
                        Rect entryBox = new Rect(0.0f, y, modifiedMaxItemWidth, itemHeight); //Get the selection's area.

                        //Check for hover and selection
                        if(entryBox.Contains(mpos) && localViewArea.Contains(mpos)) { // mouse was in selection box region AND within visiable area when clicked
                            if(mouseEvent) {// this is a mouse click event cycle
                                tempSelected = i;
                                lastControlledBy = Controller.Mouse;
                            }
                        }

                        //Draw a box if it's selected
                        if(tempSelected == i) { // selected entry
                            //GUI.Box(entryBox, "", skin.box);
                            curStyle = style_on;
                            //} else if(hover){ // not selected but mouse hovering
                            //GUI.Box(entryBox, "", skin.box);
                        } else { // not selected entry
                            curStyle = style;
                        }

                        // Draw the text
                        if(GUI.Button(entryBox, entryText, curStyle)) { // use button because label doesn't support hover styles
                            GUIUtility.keyboardControl = 0; // clear keyboard focus when selection is made
                        }
                        y += itemHeight; // increment y position
                    }
                    GUI.EndScrollView();


                     // Check for keyboard input
                    if(area.Contains(Event.current.mousePosition) && Event.current.isKey) {
                        if(Event.current.type == EventType.KeyDown) {
                            if(Event.current.keyCode == KeyCode.UpArrow) {
                                // move up in list
                                if(selected > 0) {
                                    tempSelected = selected - 1; // move up in list
                                    keyboardEvent = true;
                                    lastControlledBy = Controller.Keyboard;
                                }
                            } else if(Event.current.keyCode == KeyCode.DownArrow) {
                                if(selected < entryCount - 1) {
                                    tempSelected = selected + 1; // move down in list
                                    keyboardEvent = true;
                                    lastControlledBy = Controller.Keyboard;
                                }
                            }
                        }
                    }

                    // Detect change in selection
                    bool changed = false;

                    if(setSelectedDeferred) { // we are finished with deferred selection (should not be a mouse event cycle)
                        if(layoutEvent) {
                            // Time to make the deferred selection permanent
                            ChangeSelection(selectedDeferred); // commit the selection change
                            changed = true;
                            setSelectedDeferred = false;
                            if(lastControlledBy == Controller.Keyboard) {
                                ShowSelected(area); // show current selection if keyboard controlled
                            }
                        }
                    } else if(tempSelected != selected) { // change was detected
                        if(mouseEvent || keyboardEvent) { // mouse event / keyboard event was this cycle
                            setSelectedDeferred = true; // set the deferred selection so it will set the next non-mouse/keyboard cycle
                            selectedDeferred = tempSelected; // save value to set selection to later when we come around
                        } else { // normal or push cycle
                            ChangeSelection(tempSelected); // commit the selection change
                            lastControlledBy = Controller.None; // clear
                            changed = true;
                            //ShowSelected(area); // show current selection if controlled externally
                        }
                    } else if(pushed) {
                        ShowSelected(area); // scroll to new selection of object-pushed
                    }
                    return changed;
                }

                private void GetDimensions(Rect area, float maxItemWidth, out float totalContentsHeight, out float visibleWidth, out float visibleHeight, out bool vScrollBarVisible, out bool hScrollBarVisible) {

                    totalContentsHeight = itemHeight * entryList.Count;

                    visibleWidth = area.width;
                    visibleHeight = area.height;

                    // Determine if auto scroll bars would be generated
                    vScrollBarVisible = false;
                    hScrollBarVisible = false;

                    // Check against total area first
                    if(totalContentsHeight > visibleHeight) { // v scroll bar is visible
                        vScrollBarVisible = true;
                        visibleWidth -= vScrollBarWidth; // reduce visible width if v scroll bar is displayed. Prevents it from wanting to add horiz scroll bar even when entries are short (makes view area smaller to fit scroll bar).
                    }
                    if(maxItemWidth > visibleWidth) { // h scroll bar is visible
                        hScrollBarVisible = true;
                        visibleHeight -= vScrollBarWidth; // reduce visible height for h scroll bar
                    }

                    // If either v or h scroll bar was activated, the other may have been also since the viewing area became smaller
                    // We have to re-evaluate both H and V
                    if(vScrollBarVisible) { // V is visible, see if H became visible too
                        if(!hScrollBarVisible && maxItemWidth > visibleWidth) { // H became visible because it is wider than the new smaller width
                            hScrollBarVisible = true;
                            visibleHeight -= vScrollBarWidth; // reduce visible height for h scroll bar
                        }
                    }
                    if(hScrollBarVisible) { // H is visible, see if V becane visible too
                        if(!vScrollBarVisible && totalContentsHeight > visibleHeight) { // v scroll bar became visible because it was taller than the new smaller height
                            vScrollBarVisible = true;
                            visibleWidth -= vScrollBarWidth; // reduce visible width
                        }
                    }

                    // BUGS: Doesn't work well with forced scrollbars.
                }

                // Private functions ////
                private void CalculateItemWidth(string s) {
                    if(!stylesCreated) CreateStyles();

                    Vector2 size = origStyle.CalcSize(new GUIContent(s));
                    if(size.x > maxItemWidth)
                        maxItemWidth = size.x; // save size of biggest entry
                }

                private void CreateStyles() {
                    stylesCreated = true;
                    //GUISkin editorSkin = EditorGUIUtility.GetBuiltinSkin(EditorSkin.Inspector); // Cannot use... Bugged in Unity 4.3
                    GUISkin editorSkin = GUI.skin; // just use current skin instead
                    origStyle = skin.FindStyle("listbox");
                    // Get listbox style from skin or substitute default label
                    if(origStyle == null) {
                        Debug.Log("No \"listbox\" style found in GUI skin! Substituting label style...");
                        style = new GUIStyle(editorSkin.label); // clone editor skin label style
                    } else
                        style = new GUIStyle(origStyle); // clone orig style so we don't change it

                    // Copy colors from current editor skin so users can change between light and dark skin in unity
                    style.normal.textColor = editorSkin.button.normal.textColor;
                    style.hover.textColor = editorSkin.button.hover.textColor;
                    style.active.textColor = editorSkin.button.active.textColor;
                    style.focused.textColor = editorSkin.button.focused.textColor;

                    // Copy style for manual ON style setting
                    // Since buttons and labels don't leave the ON state active like selection grid's, we have to use
                    // two separate styles breaking out the ON states to the normal state
                    style_on = new GUIStyle(style); // copy main style
                    // Set up normal style based on main style's onNormal state
                    style_on.normal.background = style.onNormal.background;
                    style_on.normal.textColor = style.onNormal.textColor;
                    // hover = onHover
                    style_on.hover.background = style.onHover.background;
                    style_on.hover.textColor = style.onHover.textColor;
                    // active = onActive
                    style_on.active.background = style.onActive.background;
                    style_on.active.textColor = style.onActive.textColor;
                    // focused = onFocused
                    style_on.focused.background = style.onFocused.background;
                    style_on.focused.textColor = style.onFocused.textColor;
                }

                private class ListBoxEntry {
                    public string name = "";

                    public ListBoxEntry(string inName) {
                        name = inName;
                    }
                }
            }
        }

        private class SimpleGUIDrawSpriteAnimation : SimpleGUIControl {
            private EditorMasterSprite.Frame[] frames;
            private int frameCount;

            private float playbackSpeed;
            private Sprite.WrapMode _wrapMode; private Sprite.WrapMode wrapMode {
                get {
                    return _wrapMode;
                }
                set {
                    if(value != wrapMode) changed = true;
                    _wrapMode = value;
                }
            }
            private int loopCount = 0; // <= 0 = infinite
            private Rect viewingRect;
            private Rect spriteBounds;
            private GUISkin skin;
            private Rect areaRect;
            private Texture2D imageMissingTexture;

            // Working
            private bool firstFrame;
            private int currentFrame;
            private int currentLoop;
            private int loopRestartFrame;
            private GUITimer frameTimer = new GUITimer();
            private bool playForward = true;
            private bool isPlaying = false;
            private Rect absPositionRect = new Rect();
            private bool holdingBeforeFinish;
            private Color gridCenterLineColor;
            private Color gridBkgColor;

            // Properties
            private Texture2D currentImage {
                get {
                    Texture2D texture = frames[currentFrame].GetTexture();
                    if(texture == null) return imageMissingTexture;
                    return texture;
                }
            }
            private Rect frameCoords { get { return frames[currentFrame].uvCoords; } }
            private float frameDuration { get { return frames[currentFrame].duration; } }

            public SimpleGUIDrawSpriteAnimation(GUISkin inSkin, int areaWidth, int areaHeight) {
                skin = inSkin;
                GUIStyle style = skin.GetStyle("FrameEditor");
                areaRect = new Rect(0, 0, areaWidth, areaHeight); // get image size from it
                imageMissingTexture = style.onHover.background;
                gridCenterLineColor = style.normal.textColor; // use the grey line instead of the yellow one
                gridBkgColor = style.active.textColor;
                Clear();
            }

            public void Draw(EditorMasterSprite.Animation anim, float inPlayBackSpeed, Rect inScreenRect, Rect inSpriteBounds) {
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(anim == null) return;

                // Update some properties every frame so changes show up directly during animation
                viewingRect = inScreenRect;
                spriteBounds = inSpriteBounds;
                playbackSpeed = inPlayBackSpeed;
                wrapMode = anim.wrapMode;
                loopCount = anim.loopCount;
                loopRestartFrame = anim.loopRestartFrame;

                if(loopRestartFrame > 0 && loopCount == 0) loopCount = 4; // loop only a few times if we have a loop restart frame so user can see the restart point happen

                if(refresh) {
                    ResetWorkingVars();
                    frames = anim.editorFrames;
                    frameCount = frames == null ? 0 : frames.Length;
                    refresh = false;
                }
                if(frames == null || frames.Length == 0) return;
                if(!GUI.enabled) { // if GUI is disabled, just show current frame and don't animate
                    Display();
                    return;
                }

                // Catch mouse clicks
                Event e = Event.current;
                if(!firstFrame && e.isMouse && e.type == EventType.MouseDown && e.button == 0) {
                    if(absPositionRect.Contains(e.mousePosition)) {
                        ResetWorkingVars();
                        return;
                    }
                }

                // Play the animation
                if(!isPlaying) { // not playing yet
                    Play(); // start it

                } else { // currently playing
                    // Play the frame and advance to next when duration is finished
                    if(frameTimer.Update()) { // frame just finished
                        NextFrame(); // advance to next frame, loop, ping-pong, or finish
                    }
                }
                Display();
            }

            public void Play() {
                ResetWorkingVars();
                isPlaying = true;
                PlayFrame(); // play the frame
            }

            private void NextFrame() {
                // Advance to next frame
                if(playForward) {
                    int lastFrame = frameCount - 1;
                    if(currentFrame < lastFrame) { // still have frames left to play
                        currentFrame++; // advance frame
                        PlayFrame(); // play the frame
                        return;
                    }
                } else { // playing in reverse
                    if(currentFrame > 0) { // still have frames left to play
                        currentFrame--; // advance frame
                        PlayFrame(); // play the frame
                        return;
                    }
                }

                // We've played the last frame, so finish or continue playing based on wrap mode
                if(wrapMode == Sprite.WrapMode.Once) {
                    if(holdingBeforeFinish) Finished(); // done playing
                    else HoldLastFrame(1.0f);  // need to hold the last frame for a while before we finish

                } else if(wrapMode == Sprite.WrapMode.Clamp) {
                    if(holdingBeforeFinish) Finished(); // done playing
                    else HoldLastFrame(2.0f);  // need to hold the last frame for a while before we finish

                } else if(wrapMode == Sprite.WrapMode.Loop) {
                    // Check for loop end
                    if(loopCount > 0) { // this is a finite loop
                        currentLoop++; // increment loop counter if not infinite
                        if(currentLoop >= loopCount) { // finished last loop
                            if(holdingBeforeFinish) Finished(); // done playing
                            else HoldLastFrame(1.0f);  // need to hold the last frame for a while before we finish
                            return;
                        }
                    }
                    currentFrame = loopRestartFrame; // start animation over
                    PlayFrame(); // play the frame
                    return;

                } else if(wrapMode == Sprite.WrapMode.PingPong) {
                    // Check for loop end
                    if(loopCount > 0) { // this is a finite loop
                        currentLoop++; // increment loop counter if not infinite
                        if(currentLoop >= loopCount) { // finished last loop
                            Finished(); // done playing
                            return;
                        }
                    }

                    playForward = !playForward; // toggle play direction
                    // Start on next frame in the proper direction
                    if(playForward) // now moving forward
                        currentFrame++;
                    else // now moving backwards
                        currentFrame--;
                    PlayFrame(); // play the frame
                    return;
                }
            }

            private void PlayFrame() {
                // Start frame display timer
                frameTimer.SetLength(frameDuration / playbackSpeed);
                frameTimer.Start(); // start the timer
            }

            private void Finished() {
                isPlaying = false;
                frameTimer.Clear();
            }

            private void HoldLastFrame(float time) {
                holdingBeforeFinish = true;
                currentFrame = frameCount - 1; // set to last frame
                frameTimer.SetLength(time); // start a hold timer
                frameTimer.Start(); // start the timer
            }

            private void Display() {
                Texture2D image = currentImage;

                // In order to scale this image to properly see the sprite, we'd have to know the total bounds of all frames in all animations
                // with the bounds we could determine the scale and offset required to actually see the sprite animating.
                // if we did it on a per-animation basis, they might scale differently
                float maxWidth = spriteBounds.width;
                float maxHeight = spriteBounds.height;
                Vector2 boundsCenter = spriteBounds.center;

                // Scale if bounding volume won't fit in rect
                // ASSUME screen rect is square!
                float scale = 1.0f;
                if(maxWidth > viewingRect.width || maxHeight > viewingRect.height) {
                    // Determine scale based on shape of total bounding volume
                    if(maxWidth > maxHeight) { // horizontal
                        scale = viewingRect.width / maxWidth;
                    } else { // vertical or square
                        scale = viewingRect.height / maxHeight;
                    }
                }

                // Scale the image based on total bounding volume so all animations would fit within the window
                Rect scaledImageRect = new Rect(0, 0, image.width, image.height); // start with the real image dimensions
                Rect scaledBkgRect = areaRect;
                if(scale != 1.0f) {
                    scaledImageRect.width *= scale; // scale to fit into viewing rect
                    scaledImageRect.height *= scale;
                    scaledBkgRect.width *= scale;
                    scaledBkgRect.height *= scale;
                }

                // Center the scaled image in the frame
                float trueCenterX = viewingRect.width * 0.5f - scaledImageRect.width * 0.5f;
                float trueCenterY = viewingRect.height * 0.5f - scaledImageRect.height * 0.5f;
                //int pixelCenterX = Mathf.FloorToInt(trueCenterX); // Snap center to pixel. Use this for all image alignments.
                //int pixelCenterY = Mathf.CeilToInt(trueCenterY);
                scaledImageRect.x = trueCenterX;
                scaledImageRect.y = trueCenterY;

                // Add frame offset, scaled
                EditorMasterSprite.Frame frame = frames[currentFrame];
                scaledImageRect.x += frame.framePixelOffset.x * scale;
                scaledImageRect.y -= frame.framePixelOffset.y * scale; // reverse y because we want +y to be up

                // Center bkg in frame
                trueCenterX = viewingRect.width * 0.5f - scaledBkgRect.width * 0.5f;
                trueCenterY = viewingRect.height * 0.5f - scaledBkgRect.height * 0.5f;
                scaledBkgRect.x = trueCenterX;
                scaledBkgRect.y = trueCenterY;

                // Pan to fit the important area
                // keep center of bounds at center of frame
                scaledBkgRect.x -= boundsCenter.x * scale;
                scaledImageRect.x -= boundsCenter.x * scale;
                scaledBkgRect.y -= boundsCenter.y * scale;
                scaledImageRect.y -= boundsCenter.y * scale;

                // Snap to nearest pixel to help with scaling ugliness
                scaledImageRect.x = Mathf.Floor(scaledImageRect.x);
                scaledImageRect.y = Mathf.Floor(scaledImageRect.y);
                scaledBkgRect.x = Mathf.Floor(scaledBkgRect.x);
                scaledBkgRect.y = Mathf.Floor(scaledBkgRect.y);

                // WORKAROUND for the fact that there is NO GUILayout.DrawTexture()
                Rect r = GUILayoutUtility.GetRect(viewingRect.width, viewingRect.height); // reserve a rect in the layout the size of the viewing rect
                if(Event.current.type == EventType.repaint) { // only record the rect in a repaint because in Layout it is ALWAYS 0,0 !
                    absPositionRect = r; // store it in a persistent variable
                }
                // offset the viewing rect position to be in the proper place in the layout. It will always be 1 frame behind the real position because of the Layout/Repaint
                viewingRect.x = absPositionRect.x;
                viewingRect.y = absPositionRect.y;

                // Draw background solid
                SpriteFactory.Utils.GUITools.Solid.Draw(viewingRect, gridBkgColor); // fill the background

                GUILayout.BeginArea(viewingRect); // the outer window

                if(!firstFrame) { // skip drawing on first frame so we avoid the pop to 0,0
                    // Draw grid lines
                    SpriteFactory.Utils.GUITools.Solid.BeginDrawSet();
                    SpriteFactory.Utils.GUITools.Solid.color = gridCenterLineColor;
                    SpriteFactory.Utils.GUITools.Solid.Draw(new Rect(scaledBkgRect.center.x, 0, 1.0f, viewingRect.height)); // vertical line
                    SpriteFactory.Utils.GUITools.Solid.Draw(new Rect(0.0f, scaledBkgRect.center.y, viewingRect.width, 1.0f)); // horiz line
                    SpriteFactory.Utils.GUITools.Solid.EndDrawSet();

                    // Draw the sprite image, scaled if necessary
                    GUI.DrawTexture(scaledImageRect, image, ScaleMode.StretchToFill);
                } else
                    firstFrame = false;

                GUILayout.EndArea();
            }

            private void ResetWorkingVars() {
                frameTimer.Clear();
                currentFrame = 0;
                currentLoop = 0; // reset loop counter
                playForward = true; // reset play direction
                isPlaying = false;
                holdingBeforeFinish = false;
            }

            public override void Clear() {
                frames = null;
                ResetWorkingVars();
                changed = true;
                firstFrame = true;
            }
        }

        private class SimpleGUIDrawImage : SimpleGUIControl {
            public Texture2D image;
            public Rect screenRect;

            public SimpleGUIDrawImage() {
                isReady = true;
            }

            public void Draw(Texture2D inImage, Rect inScreenRect) {
                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(_parent != null && !_parent.isReady) return; // has a parent, but parent isn't ready
                if(inImage == null) return;

                screenRect = inScreenRect;
                image = inImage;

                Display();
            }

            private void Display() {
                // Make sure image doesn't render bigger than the available area
                if(screenRect.width > image.width)
                    screenRect.width = image.width;
                if(screenRect.height > image.height)
                    screenRect.height = image.height;

                GUI.DrawTexture(screenRect, image, ScaleMode.ScaleToFit);
            }

            public override void Clear() {
                image = null;
                changed = true;
            }
        }

        private class SimpleGUIFrameEditor : SimpleGUIControl {
           
            public Texture2D image;
            public Rect screenRect;
            private GUISkin skin;
            private Vector2 scrollPos;
            private Vector2 viewCenter;

            // Zoom
            private int _minZoomInt;
            private int _maxZoomInt;
            private int startingZoomInt;
            private int zoomInt;
            private float zoomLevel;
            
            // Lines
            private int gridSpacing;
            private Color gridLineColor;
            private Color gridCenterLineColor;
            private Color gridBkgColor;

            private EditorMasterSprite.Frame frame;
            private Rect areaRect;
            private int areaWidth;
            private int areaHeight;
            private Texture2D cornerDotTexture;
            private Texture2D locatorCenterTexture;
            private Texture2D locatorHandleTexture;
            private Texture2D locatorUpVectorTexture;
            private Texture2D imageMissingTexture;
            private Texture2D rotateHandleTexture;
            private Rect absPositionRect = new Rect();
            private EditorMasterSprite.Frame lightboxFrame;
            private bool isDragging;
            private int mouseButtonId = -1;
            private int dragCornerId = -1;
            private Vector2 dragBuffer;

            // Colliders
            private Sprite.ColliderSet[] allColliderSets;
            private Sprite.ColliderFrame[] allColliderFrames;
            private Sprite.ColliderSet editColliderSet;
            private Sprite.ColliderFrame editColliderFrame;
            private SpriteFactory.Utils.GUITools.RotatableGUIFillBox editColliderFrameImage;
            private SpriteFactory.Utils.GUITools.RotatableGUIFillBox[] allColliderFrameImages;
            private bool[] showCollidersMask;
            
            // Locators
            private Sprite.LocatorSet editLocatorSet;
            private Sprite.LocatorFrame editLocatorFrame;

            // External controls
            SimpleGUIListBoxContainer<EditorMasterSprite.Frame> frameListBoxContainer;
            FrameClipboard clipboard;

            // Cache variables
            Texture2D lightboxImage;
            string lightboxImageGUID;

            // Properties
            public int minZoomInt {
                get { return _minZoomInt; }
            }
            public int maxZoomInt {
                get { return _maxZoomInt; }
            }
            public int zoomPercentInt {
                get {
                    return zoomInt;
                }
                set {
                    value = Mathf.Clamp(value, _minZoomInt, _maxZoomInt);
                    if(value == zoomInt) return; // no change
                    zoomInt = value;
                    zoomLevel = zoomInt * 0.01f;
                    
                    // adjust scroll position to keep zoom centered
                    scrollPos.x = (viewCenter.x * areaRect.width * zoomLevel) - (screenRect.width * 0.5f);
                    scrollPos.y = (viewCenter.y * areaRect.height * zoomLevel) - (screenRect.height * 0.5f);
                }
            }


            public SimpleGUIFrameEditor(SimpleGUIListBoxContainer<EditorMasterSprite.Frame> frameListBoxContainer, FrameClipboard clipboard, GUISkin inSkin, Rect screenRect, int areaWidth, int areaHeight, int gridSpacing, int minZoom, int maxZoom, int startingZoom) {
                skin = inSkin;
                isReady = true;

                // Store external controls
                this.frameListBoxContainer = frameListBoxContainer;
                this.clipboard = clipboard;

                // Colors and images
                GUIStyle style = skin.GetStyle("FrameEditor");
                cornerDotTexture = style.hover.background;
                locatorCenterTexture = style.active.background;
                locatorHandleTexture = style.focused.background;
                locatorUpVectorTexture = style.onNormal.background;
                imageMissingTexture = style.onHover.background;
                rotateHandleTexture = style.onActive.background;
                gridLineColor = style.normal.textColor;
                gridCenterLineColor = style.hover.textColor;
                gridBkgColor = style.active.textColor;

                // Zoom settings
                this._minZoomInt = minZoom;
                this._maxZoomInt = maxZoom;
                this.startingZoomInt = startingZoom;

                // Positioning and space
                areaRect = new Rect(0, 0, areaWidth, areaHeight); // get image size from it
                this.areaWidth = areaWidth;
                this.areaHeight = areaHeight;
                this.gridSpacing = gridSpacing;
                this.screenRect = screenRect;

                editColliderFrameImage = new SpriteFactory.Utils.GUITools.RotatableGUIFillBox();
                
                ResetView(startingZoom); // set initial zoom level and scroll bar positions
            }

            public bool Draw(EditorMasterSprite.Frame frame, EditorMasterSprite.Frame lightboxFrame, Sprite.ColliderSet colliderSet, Sprite.ColliderFrame colliderFrame,
                Sprite.ColliderSet[] allColliderSets, Sprite.ColliderFrame[] allColliderFrames, bool[] showCollidersMask, out int newSelectedColliderId)
            {
                Vector2 waste = new Vector2();
                return Draw(frame, lightboxFrame, ref waste, colliderSet, colliderFrame, allColliderSets, allColliderFrames, showCollidersMask, null, null, out newSelectedColliderId);
            }

            public bool Draw(EditorMasterSprite.Frame frame, EditorMasterSprite.Frame lightboxFrame, Sprite.LocatorSet locatorSet, Sprite.LocatorFrame locatorFrame) {
                Vector2 waste = new Vector2();
                int waste2;
                return Draw(frame, lightboxFrame, ref waste, null, null, null, null, null, locatorSet, locatorFrame, out waste2);
            }

            public bool Draw(EditorMasterSprite.Frame frame, EditorMasterSprite.Frame lightboxFrame, ref Vector2 outOffset) {
                int waste;
                return Draw(frame, lightboxFrame, ref outOffset, null, null, null, null, null, null, null, out waste);
            }

            public bool Draw(EditorMasterSprite.Frame frame, EditorMasterSprite.Frame lightboxFrame, ref Vector2 outOffset, Sprite.ColliderSet colliderSet, Sprite.ColliderFrame colliderFrame,
                Sprite.ColliderSet[] allColliderSets, Sprite.ColliderFrame[] allColliderFrames, bool[] showCollidersMask, Sprite.LocatorSet locatorSet, Sprite.LocatorFrame locatorFrame, out int newSelectedColliderId)
            {
                newSelectedColliderId = -1; // no change

                BeginNewCycle(); // clear vars and such at beginning of new cycle
                if(_parent != null && !_parent.isReady) return false; // has a parent, but parent isn't ready

                // update variables
                this.frame = frame;

                // Update lightbox cache
                this.lightboxFrame = lightboxFrame;
                if(lightboxFrame == null) { // no lightbox image, clear it
                    if(lightboxImage != null) lightboxImage = null;
                    if(lightboxImageGUID != string.Empty) lightboxImageGUID = string.Empty;
                } else {
                    if(lightboxFrame.hasTexture) {
                        if(lightboxImageGUID != lightboxFrame.textureGUID) { // this is not the same image from before, load
                            lightboxImage = lightboxFrame.GetTexture(); // load the texture
                            lightboxImageGUID = lightboxFrame.textureGUID;
                        }
                    } else { // no texture in lightbox image
                        if(lightboxImage != null) lightboxImage = null;
                        if(lightboxImageGUID != string.Empty) lightboxImageGUID = string.Empty;
                    }
                }

                // Set up sprite image
                Texture2D texture = frame.GetTexture();
                if(texture == null) image = imageMissingTexture; // texture is missing!
                else image = texture;
                
                // Initialize collider frame image handlers
                if(colliderSet != null) {
                    if(this.allColliderSets == null || this.allColliderSets.Length == 0 ||
                        (allColliderSets != null && allColliderSets.Length != this.allColliderSets.Length))
                    {

                        // Destroy textures first if exist
                        if(allColliderFrameImages != null) {
                            foreach(SpriteFactory.Utils.GUITools.RotatableGUIFillBox f in allColliderFrameImages) {
                                f.Destroy();
                            }
                        }
                        
                        // Initialize the image handlers
                        allColliderFrameImages = new SpriteFactory.Utils.GUITools.RotatableGUIFillBox[allColliderSets.Length];
                        for(int i = 0; i < allColliderSets.Length; i++) {
                            allColliderFrameImages[i] = new SpriteFactory.Utils.GUITools.RotatableGUIFillBox();
                        }
                    }
                }
                
                this.allColliderSets = allColliderSets;
                this.allColliderFrames = allColliderFrames;
                this.showCollidersMask = showCollidersMask;

                editColliderSet = colliderSet;
                editColliderFrame = colliderFrame;
                editLocatorSet = locatorSet;
                editLocatorFrame = locatorFrame;
                
                if(image == null) return false;

                return Display(ref outOffset, out newSelectedColliderId);
            }

            private bool Display(ref Vector2 outOffset, out int newSelectedColliderId) {
                newSelectedColliderId = -1; // no change
                bool valueChanged = false;

                // Variables for various modes
                Rect[] displayColliderRects;
                Rect editColliderRect;
                Rect[] editColliderCornerRects;
                Rect editLocatorRect;
                Rect editLocatorHandleRect;
                Rect editLocatorUpVectorRect;
                Vector2 editLocatorCenter;
                Rect editColliderRotateHandleRect;

                // Find center of grid
                float trueGridCenterX = areaWidth * 0.5f; // this is the actual center, may be 1/2 pixel. Don't use this for image alignment.
                float trueGridCenterY = areaHeight * 0.5f;
                int pixelGridCenterX = Mathf.FloorToInt(trueGridCenterX); // Snap center to pixel. Use this for all image alignments.
                int pixelGridCenterY = Mathf.CeilToInt(trueGridCenterY); // Ceil here because ^ is inverted, so Ceil actually pushes pixel down if half

                // Get the pixel rect for drawing the sprite image
                Rect spriteRect = GetPixelAlignedImageRect(image, trueGridCenterX, trueGridCenterY, frame.framePixelOffset);

                // Determine what is being edited
                int editMode; // 0 = sprite, 1 = collider, 2 = locator
                if(editColliderSet != null && editColliderFrame != null) editMode = 1;
                else if(editLocatorSet != null && editLocatorFrame != null && editLocatorFrame.enabled) editMode = 2;
                else editMode = 0;

                // Lightbox frame
                bool showLightbox = false;
                Rect lightboxRect = new Rect();
                if(lightboxFrame != null) {
                    if(lightboxImage != null) {
                        lightboxRect = GetPixelAlignedImageRect(lightboxImage, trueGridCenterX, trueGridCenterY, lightboxFrame.framePixelOffset);
                        showLightbox = true;
                    }
                }

                // Calculate rects as necessary
                CalculateColliderRects(editMode, trueGridCenterX, trueGridCenterY, out editColliderRect, out editColliderCornerRects, out displayColliderRects, out editColliderRotateHandleRect); // caluclate edit dollider
                CalculateLocatorRects(editMode, pixelGridCenterX, pixelGridCenterY, out editLocatorRect, out editLocatorHandleRect, out editLocatorUpVectorRect, out editLocatorCenter); // calculate edit locator

                // WORKAROUND for the fact that there is NO GUILayout.DrawTexture()
                Rect r = GUILayoutUtility.GetRect(screenRect.width, screenRect.height); // reserve a rect in the layout the size of the viewing rect
                if(Event.current.type == EventType.repaint) { // only record the rect in a repaint because in Layout it is ALWAYS 0,0 !
                    absPositionRect = r; // store it in a persistent variable
                }
                // offset the viewing rect position to be in the proper place in the layout. It will always be 1 frame behind the real position because of the Layout/Repaint
                screenRect.x = absPositionRect.x;
                screenRect.y = absPositionRect.y;

                Rect viewingRectMinusScrollbars = screenRect; // get viewing rect without scroll bar area so clicks don't go through the scroll bars
                if(zoomInt > _minZoomInt) { // scroll bars will disappear at min zoom, so don't bother offsetting
                    viewingRectMinusScrollbars.width -= 15.0f;
                    viewingRectMinusScrollbars.height -= 15.0f;
                }

                // Handle Zoom and Pan controls
                // get the mouse position OUTSIDE the scroll pos so it doesn't get offset by its internal scroll position
                bool panning = HandlePan(viewingRectMinusScrollbars, ref scrollPos);
                HandleWheelZoom(screenRect);

                // Handle mouse and keyboard controls
                if(!panning) { // only allow movement while still
                    if(editMode == 0) { // editing sprite
                        HandleControls_Sprite(spriteRect, viewingRectMinusScrollbars, ref outOffset, ref valueChanged);
                    } else if(editMode == 1) { // Editing collider
                        HandleControls_Collider(editColliderRect, editColliderCornerRects, editColliderRotateHandleRect, viewingRectMinusScrollbars, editColliderFrame, ref outOffset, ref valueChanged, displayColliderRects, allColliderFrames, out newSelectedColliderId);
                    } else { // Editing locator
                        HandleControls_Locator(editLocatorRect, editLocatorCenter, editLocatorFrame.flipForwardVector, viewingRectMinusScrollbars, ref outOffset, ref valueChanged);
                    }
                }

                // Frame next/prev keyboard control
                HandleControls_Animation(viewingRectMinusScrollbars);

                // Copy/Paste
                HandleControls_CopyPaste(editMode, viewingRectMinusScrollbars, ref valueChanged);

                // Create scroll view
                BeginScrollView(screenRect, scrollPos, areaRect, panning);

                #region Draw Graphics

                // Draw background grid
                DrawGrid(screenRect, scrollPos, areaRect);

                // Draw lightbox image
                if(showLightbox) {
                    Color oldGUIColor = GUI.color; // save gui color
                    Color newColor = oldGUIColor;
                    newColor.a = 0.4f; // make lightbox transparent
                    GUI.color = newColor;
                    DrawScaledTexture(lightboxRect, lightboxImage);
                    GUI.color = oldGUIColor; // restore gui color
                }

                // Draw main sprite image
                DrawScaledTexture(spriteRect, image);

                // Draw collider or locator
                if(editMode == 1) { // draw collider

                    SpriteFactory.Utils.GUITools.Solid.BeginDrawSet(); // save gui color
                    
                    // Draw reference display colliders
                    if(displayColliderRects != null) {
                        for(int i = 0; i < displayColliderRects.Length; i++) {
                            if(showCollidersMask != null && !showCollidersMask[i]) continue; // this collider is not shown due to filtering

                            Sprite.ColliderSet colliderSet = allColliderSets[i];
                            Sprite.ColliderFrame colliderFrame = allColliderFrames[i];
                            if(colliderFrame == null) continue;
                            if(!colliderFrame.enabled) continue; // collider is disabled, skip
                            if(colliderFrame == editColliderFrame) continue; // don't draw the editing one twice
                            
                            //SpriteFactory.Utils.GUITools.Solid.color = new Color(colliderSet.previewColor.r, colliderSet.previewColor.g, colliderSet.previewColor.b, 0.5f);
                            //SpriteFactory.Utils.GUITools.Solid.DrawBoxRotated(displayColliderRects[i], colliderFrame.rotation, 1.0f); // draw main collider, rects are pre-zoomed

                            SpriteFactory.Utils.GUITools.Solid.color = new Color(colliderSet.previewColor.r, colliderSet.previewColor.g, colliderSet.previewColor.b, 0.4f);
                            allColliderFrameImages[i].Draw(displayColliderRects[i], colliderFrame.rotation);
                        }
                    }
                    
                    // Draw main collider box
                    if(editColliderFrame.enabled) {
                        SpriteFactory.Utils.GUITools.Solid.color = new Color(editColliderSet.previewColor.r, editColliderSet.previewColor.g, editColliderSet.previewColor.b, 0.6f);
                        editColliderFrameImage.Draw(editColliderRect, editColliderFrame.rotation);

                        // Draw rotation handle
                        if(!editColliderSet.isParent) {
                            Color origColor = GUI.color;
                            GUI.color = Color.white;
                            GUI.DrawTexture(editColliderRotateHandleRect, rotateHandleTexture);
                            GUI.color = origColor;
                        }

                        // Draw the corner dots -- the rects are pre-zoomed
                        bool rotate = editColliderFrame.rotation != 0.0f ? true : false;
                        if(rotate) {
                            // Rotate the corner dots into place by rotating the position. Rect will still be unrotated.
                            for(int i = 0; i < editColliderCornerRects.Length; i++) {
                                editColliderCornerRects[i].center = SpriteFactory.Utils.MathTools.RotateWorldPoint(editColliderCornerRects[i].center, editColliderRect.center, -editColliderFrame.rotation); // reverse direction so GUI rotation matches scene counterclockwise = +
                            }
                        }

                        SpriteFactory.Utils.GUITools.Solid.colorA = 0.75f; // make more opaque for corner dots
                        for(int i = 0; i < editColliderCornerRects.Length; i++)
                            GUI.DrawTexture(editColliderCornerRects[i], cornerDotTexture);

                        /* // GUI ROTATION DOES NOT WORK WITH AREAS! CLIPPING IS TOTALLY WRONG!
                        SpriteFactory.Utils.GUITools.Solid.color = new Color(editColliderSet.previewColor.r, editColliderSet.previewColor.g, editColliderSet.previewColor.b, 0.5f);
                        SpriteFactory.Utils.GUITools.Solid.DrawRotated(editColliderRect, editColliderFrame.rotation); // draw main collider, rects are pre-zoomed
                          
                        // Draw the corner dots -- the rects are pre-zoomed
                        bool rotate = editColliderFrame.rotation != 0.0f ? true : false;
                        Matrix4x4 guiMatrix = GUI.matrix; // store matrix before rotation
                        if(rotate) GUIUtility.RotateAroundPivot(360.0f - editColliderFrame.rotation, editColliderRect.center); // reverse direction so GUI rotation matches scene counterclockwise = +
                        
                        SpriteFactory.Utils.GUITools.Solid.colorA = 0.75f; // make more opaque for corner dots
                        for(int i = 0; i < editColliderCornerRects.Length; i++)
                            GUI.DrawTexture(editColliderCornerRects[i], cornerDotTexture);

                        // Restore original GUI state if rotated
                        if(rotate) GUI.matrix = guiMatrix; // restore matrix
                        */
                    }

                    SpriteFactory.Utils.GUITools.Solid.EndDrawSet();

                } else if(editMode == 2) { // draw locator

                    SpriteFactory.Utils.GUITools.Solid.BeginDrawSet(); // save gui color
                    Color locatorColor = new Color(editLocatorSet.previewColor.r, editLocatorSet.previewColor.g, editLocatorSet.previewColor.b, 1.0f);
                    SpriteFactory.Utils.GUITools.Solid.color = locatorColor;
                    
                    // Draw rotating locator parts -- rects are all pre-scaled
                    Matrix4x4 guiMatrix = GUI.matrix; // store matrix before rotation
                    if(!editLocatorFrame.flipForwardVector) GUIUtility.RotateAroundPivot(360.0f - editLocatorFrame.facing, editLocatorCenter * zoomLevel); // reverse direction so GUI rotation matches scene counterclockwise = +
                    else GUIUtility.RotateAroundPivot(editLocatorFrame.facing, editLocatorCenter * zoomLevel); // use clockwise = + for flipped version
                    GUI.DrawTexture(editLocatorHandleRect, locatorHandleTexture); // draw handle
                    GUI.DrawTexture(editLocatorUpVectorRect, locatorUpVectorTexture); // draw up vector
                    GUI.matrix = guiMatrix; // restore matrix

                    // Draw center of locator
                    GUI.DrawTexture(editLocatorRect, locatorCenterTexture);

                    SpriteFactory.Utils.GUITools.Solid.EndDrawSet();
                }

                #endregion

                EndScrollView();

                return valueChanged;
            }

            private void CalculateColliderRects(int editMode, float gridCenterX, float gridCenterY, out Rect editColliderRect, out Rect[] editColliderCornerRects, out Rect[] allColliderRects, out Rect editColliderRotateHandleRect) {
                allColliderRects = null;
                if(editMode != 1) {
                    editColliderCornerRects = null;
                    editColliderRect = new Rect();
                    editColliderRotateHandleRect = new Rect();
                    return;
                }
                
                // Clamp to minimum size
                const float minSize = 5.0f;
                if(editColliderFrame.size2D.x < minSize) editColliderFrame.size2D.x = minSize;
                if(editColliderFrame.size2D.y < minSize) editColliderFrame.size2D.y = minSize;

                // Find starting position of rect
                float startPosX = gridCenterX + editColliderFrame.center2D.x - (editColliderFrame.size2D.x * 0.5f);
                float startPosY = gridCenterY - editColliderFrame.center2D.y - (editColliderFrame.size2D.y * 0.5f); // reverse

                // Create rect
                float width = editColliderFrame.size2D.x;
                float height = editColliderFrame.size2D.y;
                editColliderRect = new Rect(startPosX, startPosY, width, height); // do not zoom scale yet because we need this unscaled for corner points

                // Find rects for other reference display colliders
                if(allColliderSets != null && allColliderSets.Length > 0 && allColliderFrames != null && allColliderFrames.Length == allColliderSets.Length) {
                    allColliderRects = new Rect[allColliderSets.Length];
                    for(int i = 0; i < allColliderSets.Length; i++) {
                        if(allColliderFrames[i] == null) continue;
                        Sprite.ColliderFrame colliderFrame = allColliderFrames[i];
                        startPosX = gridCenterX + colliderFrame.center2D.x - (colliderFrame.size2D.x * 0.5f);
                        startPosY = gridCenterY - colliderFrame.center2D.y - (colliderFrame.size2D.y * 0.5f); // reverse
                        width = colliderFrame.size2D.x;
                        height = colliderFrame.size2D.y;
                        allColliderRects[i] = new Rect(startPosX, startPosY, width, height);
                        ZoomRect(ref allColliderRects[i]); // zoom now since we don't need the corners
                    }
                }

                // Find rects for corners
                editColliderCornerRects = new Rect[4];
                float dotSize = cornerDotTexture.width;
                float halfDot = dotSize * 0.5f;
                float xMin, xMax, yMin, yMax;

                // Calculate corner rects differently if scaled smaller than 100% so corner dots stay the same size when zoomed out
                if(zoomInt <= 100) { // 100% or zoomed out
                    Rect scaledColliderRect = editColliderRect;
                    ZoomRect(ref scaledColliderRect); // zoom the collider rect now before we calculate corner offsets
                    xMin = scaledColliderRect.xMin;
                    xMax = scaledColliderRect.xMax;
                    yMin = scaledColliderRect.yMin;
                    yMax = scaledColliderRect.yMax;
                } else { // zoomed in
                    // use the unscaled collider rect values
                    xMin = editColliderRect.xMin;
                    xMax = editColliderRect.xMax;
                    yMin = editColliderRect.yMin;
                    yMax = editColliderRect.yMax;
                }

                editColliderCornerRects[0] = new Rect(xMin - halfDot, yMin - halfDot, dotSize, dotSize); // UL
                editColliderCornerRects[1] = new Rect(xMax - halfDot, yMin - halfDot, dotSize, dotSize); // UR
                editColliderCornerRects[2] = new Rect(xMin - halfDot, yMax - halfDot, dotSize, dotSize); // LL
                editColliderCornerRects[3] = new Rect(xMax - halfDot, yMax - halfDot, dotSize, dotSize); // LR

                // Scale corner points if zoomed in
                if(zoomInt > 100) { // zoomed in
                    for(int i = 0; i < editColliderCornerRects.Length; i++)
                        ZoomRect(ref editColliderCornerRects[i]);
                }

                // Find rotate handle rect
                editColliderRotateHandleRect = new Rect(0, 0, rotateHandleTexture.width, rotateHandleTexture.height);

                // Scale the main collider rect
                ZoomRect(ref editColliderRect);

                editColliderRotateHandleRect.center = editColliderRect.center; // adjust center after main rect has been scaled
            }

            private void CalculateLocatorRects(int editMode, float gridCenterX, float gridCenterY, out Rect editLocatorRect, out Rect editLocatorHandleRect, out Rect editLocatorUpVectorRect, out Vector2 editLocatorCenter) {
                if(editMode != 2) {
                    editLocatorRect = new Rect();
                    editLocatorHandleRect = new Rect();
                    editLocatorUpVectorRect = new Rect();
                    editLocatorCenter = new Vector2();
                    return;
                }

                // Center
                editLocatorCenter.x = gridCenterX + editLocatorFrame.pixelPosition.x;
                editLocatorCenter.y = gridCenterY - editLocatorFrame.pixelPosition.y;
                editLocatorRect = new Rect(editLocatorCenter.x, editLocatorCenter.y, locatorCenterTexture.width, locatorCenterTexture.height);
                
                float flip = 1.0f;
                if(editLocatorFrame.flipForwardVector) flip = -1.0f;

                // Handle
                float posX;
                float posY;
                float width = locatorHandleTexture.width;
                float height = locatorHandleTexture.height;
                posX = gridCenterX + editLocatorFrame.pixelPosition.x;
                posY = gridCenterY - editLocatorFrame.pixelPosition.y;
                editLocatorHandleRect = new Rect(posX, posY, width * flip, height);

                // Up Vector
                posX = gridCenterX + editLocatorFrame.pixelPosition.x;
                posY = gridCenterY - editLocatorFrame.pixelPosition.y;
                editLocatorUpVectorRect = new Rect(posX, posY, locatorUpVectorTexture.width, locatorUpVectorTexture.height);

                // Zoom scale the rects
                if(zoomInt <= 100) { // zoomed out
                    // scale before offset, only the position so locator stays same size
                    ZoomRectPosOnly(ref editLocatorRect);
                    ZoomRectPosOnly(ref editLocatorHandleRect);
                    ZoomRectPosOnly(ref editLocatorUpVectorRect);
                }

                // Appy center offset to center circle
                editLocatorRect.x -= locatorCenterTexture.width * 0.5f;
                editLocatorRect.y -= locatorCenterTexture.height * 0.5f;

                // Appy center offset to handle
                if(flip == 1.0f) editLocatorHandleRect.x += locatorCenterTexture.width * 0.5f;
                else editLocatorHandleRect.x -= locatorCenterTexture.width * 0.5f;
                editLocatorHandleRect.y -= locatorHandleTexture.height * 0.5f;

                // Appy center offset to up vector
                editLocatorUpVectorRect.x -= locatorUpVectorTexture.width * 0.5f;
                editLocatorUpVectorRect.y -= locatorUpVectorTexture.height + (locatorCenterTexture.height * 0.5f);

                // Zoom scale the rect
                if(zoomInt > 100) { // 100% or bigger
                    // scale after offset
                    ZoomRect(ref editLocatorRect);
                    ZoomRect(ref editLocatorHandleRect);
                    ZoomRect(ref editLocatorUpVectorRect);
                }
            }

            private void BeginScrollView(Rect position, Vector2 scrollPosition, Rect viewRect, bool panning) {
                ZoomRect(ref viewRect); // zoom rect if necessary
                Vector2 newScrollPos = ScrollView.Begin(position, scrollPos, viewRect, false); // draw the scroll view
                if(!panning && scrollPos == newScrollPos) return; // position was the same, do nothing, always update if panning

                // update the scroll pos
                scrollPos.x = newScrollPos.x;
                scrollPos.y = newScrollPos.y;

                // update the view center
                viewCenter.x = (scrollPos.x + (screenRect.width * 0.5f)) / (areaRect.width * zoomLevel);
                viewCenter.y = (scrollPos.y + (screenRect.height * 0.5f)) / (areaRect.height * zoomLevel);
            }

            private void EndScrollView() {
                ScrollView.End();
            }

            private void HandleControls_Sprite(Rect textureRect, Rect viewingRectMinusScrollbars, ref Vector2 outOffset, ref bool valueChanged) {
                // Handle dragging sprite around for offset
                Event e = Event.current;
                if(e.isMouse) {
                    bool inViewRect = viewingRectMinusScrollbars.Contains(e.mousePosition);

                    // Initial click
                    if(e.type == EventType.mouseDown) { // button was pressed
                        if(e.button == 0 && inViewRect) { // left click
                            if(GUIUtility.keyboardControl > 0) GUIUtility.keyboardControl = 0; // clear keyboard focus when clicked to make sure if user had offset highlighted it will update properly

                            // How do we get the onscreen texture position when its inside the scroll view
                            ZoomRect(ref textureRect); // zoom if necessary
                            Rect absTexRect = new Rect();
                            absTexRect.x = screenRect.x + textureRect.x - scrollPos.x;
                            absTexRect.y = screenRect.y + textureRect.y - scrollPos.y;
                            absTexRect.width = textureRect.width;
                            absTexRect.height = textureRect.height;

                            if(absTexRect.Contains(e.mousePosition)) { // clicked on sprite
                                StartMouseDrag(0);
                            }
                        }
                    } else if(e.type == EventType.mouseUp) {
                        if(isDragging && e.button == 0) { // left click
                            EndMouseDrag();
                        }
                    } else if(e.type == EventType.mouseDrag) {
                        if(isDragging && mouseButtonId == 0) {
                            Vector2 delta = HandleMouseDrag(e.delta);
                            outOffset.x += (int)delta.x;
                            outOffset.y -= (int)delta.y;
                        }
                    }
                }

                // Handle keyboard controls
                if(e.type == EventType.keyDown && e.isKey) {
                    bool inViewRect = viewingRectMinusScrollbars.Contains(e.mousePosition);
                    if(inViewRect) {
                        int value = e.shift ? 5 : 1; // move image 5 units if shift is held down, 1 if not

                        if(e.keyCode == KeyCode.UpArrow) {
                            outOffset.y += value;
                        } else if(e.keyCode == KeyCode.DownArrow) {
                            outOffset.y -= value;
                        }

                        if(e.keyCode == KeyCode.LeftArrow) {
                            outOffset.x -= value;
                        } else if(e.keyCode == KeyCode.RightArrow) {
                            outOffset.x += value;
                        }
                    }
                }
                if(outOffset.x != 0.0f || outOffset.y != 0.0f) valueChanged = true;
            }

            private void HandleControls_Collider(Rect editColliderRect, Rect[] editColliderCornerRects, Rect rotationHandleRect, Rect viewingRectMinusScrollbars, Sprite.ColliderFrame colliderFrame, ref Vector2 outOffset, ref bool valueChanged, Rect[] displayColliderRects, Sprite.ColliderFrame[] displayColliderFrames, out int newSelectedColliderId) {
                newSelectedColliderId = -1; // no change

                // Handle dragging sprite around for offset
                int moveX = 0;
                int moveY = 0;
                Event e = Event.current;
                if(e.isMouse) {
                    bool inViewRect = viewingRectMinusScrollbars.Contains(e.mousePosition);
                    // Initial click
                    if(e.type == EventType.mouseDown) { // button was pressed
                        if(e.button == 0 && inViewRect) { // left click
                            if(GUIUtility.keyboardControl > 0) GUIUtility.keyboardControl = 0; // clear keyboard focus when clicked to make sure if user had offset highlighted it will update properly

                            if(editColliderFrame.enabled) {

                                // Convert local to absolute coords including scroll view
                                Rect[] absCornerRects = new Rect[4];
                                absCornerRects[0] = new Rect(
                                    screenRect.x + editColliderCornerRects[0].x - scrollPos.x,
                                    screenRect.y + editColliderCornerRects[0].y - scrollPos.y,
                                    editColliderCornerRects[0].width,
                                    editColliderCornerRects[0].height
                                );
                                absCornerRects[1] = new Rect(
                                    screenRect.x + editColliderCornerRects[1].x - scrollPos.x,
                                    screenRect.y + editColliderCornerRects[1].y - scrollPos.y,
                                    editColliderCornerRects[1].width,
                                    editColliderCornerRects[1].height
                                );
                                absCornerRects[2] = new Rect(
                                    screenRect.x + editColliderCornerRects[2].x - scrollPos.x,
                                    screenRect.y + editColliderCornerRects[2].y - scrollPos.y,
                                    editColliderCornerRects[2].width,
                                    editColliderCornerRects[2].height
                                );
                                absCornerRects[3] = new Rect(
                                    screenRect.x + editColliderCornerRects[3].x - scrollPos.x,
                                    screenRect.y + editColliderCornerRects[3].y - scrollPos.y,
                                    editColliderCornerRects[3].width,
                                    editColliderCornerRects[3].height
                                );

                                // Calculate onscreen rect position when its inside the scroll view
                                Rect absColliderRect = new Rect();
                                absColliderRect.x = screenRect.x + editColliderRect.x - scrollPos.x;
                                absColliderRect.y = screenRect.y + editColliderRect.y - scrollPos.y;
                                absColliderRect.width = editColliderRect.width;
                                absColliderRect.height = editColliderRect.height;

                                // Check if clicked on corner or main body of collider or rotation handle
                                float reverseRotation = -colliderFrame.rotation; // reverse so GUI clockwise is same as scene
                                
                                // Rotate the corner point hotspots to align. The rects themselves are not rotated, just the center point is moved to match the visual points.
                                if(reverseRotation != 0.0f) {
                                    absCornerRects[0].center = SpriteFactory.Utils.MathTools.RotateWorldPoint(absCornerRects[0].center, absColliderRect.center, reverseRotation);
                                    absCornerRects[1].center = SpriteFactory.Utils.MathTools.RotateWorldPoint(absCornerRects[1].center, absColliderRect.center, reverseRotation);
                                    absCornerRects[2].center = SpriteFactory.Utils.MathTools.RotateWorldPoint(absCornerRects[2].center, absColliderRect.center, reverseRotation);
                                    absCornerRects[3].center = SpriteFactory.Utils.MathTools.RotateWorldPoint(absCornerRects[3].center, absColliderRect.center, reverseRotation);
                                }

                                // Caclulate onscreen rect for rotation handle
                                Rect absRotationHandleRect = new Rect();
                                absRotationHandleRect.x = screenRect.x + rotationHandleRect.x - scrollPos.x;
                                absRotationHandleRect.y = screenRect.y + rotationHandleRect.y - scrollPos.y;
                                absRotationHandleRect.width = rotationHandleRect.width;
                                absRotationHandleRect.height = rotationHandleRect.height;

                                // Check for clicks
                                if(SpriteFactory.Utils.MathTools.RectContains(absCornerRects[0], e.mousePosition, reverseRotation)) { // corner clicked
                                    StartMouseDrag(0);
                                    dragCornerId = 0;
                                    e.Use();
                                } else if(SpriteFactory.Utils.MathTools.RectContains(absCornerRects[1], e.mousePosition, reverseRotation)) { // corner clicked
                                    StartMouseDrag(0);
                                    dragCornerId = 1;
                                    e.Use();
                                } else if(SpriteFactory.Utils.MathTools.RectContains(absCornerRects[2], e.mousePosition, reverseRotation)) { // corner clicked
                                    StartMouseDrag(0);
                                    dragCornerId = 2;
                                    e.Use();
                                } else if(SpriteFactory.Utils.MathTools.RectContains(absCornerRects[3], e.mousePosition, reverseRotation)) { // corner clicked
                                    StartMouseDrag(0);
                                    dragCornerId = 3;
                                    e.Use();
                                } else if(!editColliderSet.isParent && SpriteFactory.Utils.MathTools.RectContains(absRotationHandleRect, e.mousePosition, reverseRotation)) { // rotation handle clicked
                                    StartMouseDrag(0);
                                    dragCornerId = 4;
                                    e.Use();
                                } else { // main body clicked
                                    if(SpriteFactory.Utils.MathTools.RectContains(absColliderRect, e.mousePosition, reverseRotation)) { // clicked on collider rect
                                        StartMouseDrag(0);
                                        dragCornerId = -1;
                                        e.Use();
                                    }
                                }
                            }

                            // Check for selection of other colliders
                            if(displayColliderRects != null && e.type != EventType.Used) {
                                Rect absColliderRect = new Rect();
                                for(int i = 0; i < displayColliderRects.Length; i++) {
                                    if(!displayColliderFrames[i].enabled) continue;
                                    if(showCollidersMask != null && !showCollidersMask[i]) continue; // this collider is not shown due to filtering
                                    
                                    // get absolute rect
                                    absColliderRect.x = screenRect.x + displayColliderRects[i].x - scrollPos.x;
                                    absColliderRect.y = screenRect.y + displayColliderRects[i].y - scrollPos.y;
                                    absColliderRect.width = displayColliderRects[i].width;
                                    absColliderRect.height = displayColliderRects[i].height;
                                    
                                    if(SpriteFactory.Utils.MathTools.RectContains(absColliderRect, e.mousePosition, -displayColliderFrames[i].rotation)) { // clicked on collider rect
                                        newSelectedColliderId = i;
                                        e.Use();
                                        break;
                                    }
                                }
                            }
                        }
                    } else if(e.type == EventType.mouseUp) {
                        if(isDragging && e.button == 0) { // left click
                            EndMouseDrag();
                            e.Use();
                        }
                    } else if(e.type == EventType.mouseDrag) {
                        if(isDragging && mouseButtonId == 0) {
                            Vector2 delta = HandleMouseDrag(e.delta);
                            if(dragCornerId == 0) { // upper left corner
                                Vector2 thisPointRel = new Vector2((colliderFrame.size2D.x * 0.5f) * -1.0f, colliderFrame.size2D.y * 0.5f);
                                Vector2 oppPointRel = new Vector2(colliderFrame.size2D.x * 0.5f, (colliderFrame.size2D.y * 0.5f) * -1.0f);
                                OffsetRectCorner(colliderFrame, delta, thisPointRel, oppPointRel);
                                if(delta.x != 0.0f || delta.y != 0.0f) valueChanged = true;
                            } else if(dragCornerId == 1) { // upper right corner
                                Vector2 thisPointRel = new Vector2(colliderFrame.size2D.x * 0.5f, colliderFrame.size2D.y * 0.5f);
                                Vector2 oppPointRel = new Vector2((colliderFrame.size2D.x * 0.5f) * -1.0f, (colliderFrame.size2D.y * 0.5f) * -1.0f);
                                OffsetRectCorner(colliderFrame, delta, thisPointRel, oppPointRel);
                                if(delta.x != 0.0f || delta.y != 0.0f) valueChanged = true;
                            } else if(dragCornerId == 2) {
                                Vector2 thisPointRel = new Vector2((colliderFrame.size2D.x * 0.5f) * -1.0f, (colliderFrame.size2D.y * 0.5f) * -1.0f);
                                Vector2 oppPointRel = new Vector2(colliderFrame.size2D.x * 0.5f, colliderFrame.size2D.y * 0.5f);
                                OffsetRectCorner(colliderFrame, delta, thisPointRel, oppPointRel);
                                if(delta.x != 0.0f || delta.y != 0.0f) valueChanged = true;
                            } else if(dragCornerId == 3) {
                                Vector2 thisPointRel = new Vector2(colliderFrame.size2D.x * 0.5f, (colliderFrame.size2D.y * 0.5f) * -1.0f);
                                Vector2 oppPointRel = new Vector2((colliderFrame.size2D.x * 0.5f) * -1.0f, colliderFrame.size2D.y * 0.5f);
                                OffsetRectCorner(colliderFrame, delta, thisPointRel, oppPointRel);
                                if(delta.x != 0.0f || delta.y != 0.0f) valueChanged = true;
                            } else if(dragCornerId == 4) { // not really corner, rotation handle
                                editColliderFrame.rotation += delta.x * 0.5f;
                                if(delta.x != 0.0f || delta.y != 0.0f) valueChanged = true;
                            } else { // not corner, main collider
                                moveX = (int)delta.x;
                                moveY = -(int)delta.y;
                            }
                            e.Use();
                        }
                    }
                }

                // Handle keyboard controls
                if(e.type == EventType.keyDown && e.isKey) {
                    bool inViewRect = viewingRectMinusScrollbars.Contains(e.mousePosition);
                    if(inViewRect) {
                        int value = e.shift ? 5 : 1; // move image 5 units if shift is held down, 1 if not

                        if(e.keyCode == KeyCode.UpArrow) {
                            moveY = value;
                            e.Use();
                        } else if(e.keyCode == KeyCode.DownArrow) {
                            moveY = -value;
                            e.Use();
                        }

                        if(e.keyCode == KeyCode.LeftArrow) {
                            moveX = -value;
                            e.Use();
                        } else if(e.keyCode == KeyCode.RightArrow) {
                            moveX = value;
                            e.Use();
                        }
                    }
                }

                // Apply movement
                if(moveX != 0 || moveY != 0) {
                    editColliderFrame.center2D.x += moveX;
                    editColliderFrame.center2D.y += moveY;
                    valueChanged = true;
                }
            }

            private void OffsetRectCorner(Sprite.ColliderFrame colliderFrame, Vector2 delta, Vector2 pointRelPos, Vector2 anchorPointRelPos) {
                // rect should try to move this point
                // all others should just adjust
                
                Vector2 origPoint = new Vector2(pointRelPos.x, pointRelPos.y);
                Vector2 rotatedPoint = SpriteFactory.Utils.MathTools.RotateLocalPoint(origPoint, colliderFrame.rotation);
                Vector2 finalPoint = new Vector2(rotatedPoint.x + (int)delta.x, rotatedPoint.y - (int)delta.y);

                // Find new final point back in original 0 rotation
                Vector2 finalPointNoRotation = SpriteFactory.Utils.MathTools.RotateLocalPoint(finalPoint, -colliderFrame.rotation);

                // adjust the rest of the box to allow this point to be in the position we want at the rotation
                // find a size, center that makes finalPoint and anchorPoint be in the right positions
                Vector2 oppositeAnchorPoint = new Vector2(anchorPointRelPos.x, anchorPointRelPos.y);
                Vector2 newTentativeCenter = new Vector2((finalPointNoRotation.x + oppositeAnchorPoint.x) * 0.5f, (finalPointNoRotation.y + oppositeAnchorPoint.y) * 0.5f);

                Vector2 oppositeAnchorPointRotatedWantedPos = SpriteFactory.Utils.MathTools.RotateLocalPoint(oppositeAnchorPoint, colliderFrame.rotation);
                Vector2 oppositeAnchorPointRotatedResultingPos = SpriteFactory.Utils.MathTools.RotateWorldPoint(oppositeAnchorPoint, newTentativeCenter, colliderFrame.rotation);

                Vector2 diff = oppositeAnchorPointRotatedWantedPos - oppositeAnchorPointRotatedResultingPos;

                // Find new center
                editColliderFrame.center2D.x += newTentativeCenter.x + diff.x;
                editColliderFrame.center2D.y += newTentativeCenter.y + diff.y;

                // Find new size
                editColliderFrame.size2D.x = Mathf.Abs(oppositeAnchorPoint.x - finalPointNoRotation.x);
                editColliderFrame.size2D.y = Mathf.Abs(finalPointNoRotation.y - oppositeAnchorPoint.y);
            }

            private void HandleControls_Locator(Rect editLocatorRect, Vector3 editLocatorCenter, bool flipForwardVector, Rect viewingRectMinusScrollbars, ref Vector2 outOffset, ref bool valueChanged) {
                // Handle dragging locator around for offset
                int moveX = 0;
                int moveY = 0;
                Event e = Event.current;
                if(e.isMouse) {
                    bool inViewRect = viewingRectMinusScrollbars.Contains(e.mousePosition);

                    // Initial click
                    if(e.type == EventType.mouseDown) { // button was pressed
                        if(e.button == 0 && inViewRect) { // left click
                            if(GUIUtility.keyboardControl > 0) GUIUtility.keyboardControl = 0; // clear keyboard focus when clicked to make sure if user had offset highlighted it will update properly

                            // Convert local to absolute coords including scroll view
                            Rect absMainCircleRect = new Rect(
                                screenRect.x + editLocatorRect.x - scrollPos.x,
                                screenRect.y + editLocatorRect.y - scrollPos.y,
                                editLocatorRect.width, // width of the main circle
                                editLocatorRect.height // height of the main circle
                            );

                            // Check if clicked on corner or main body of collider
                            if(absMainCircleRect.Contains(e.mousePosition)) {
                                StartMouseDrag(0);
                                dragCornerId = 0;
                            } else {
                                Rect absAngleAdjustRect = new Rect();
                                // rotate handle position based on facing angle
                                // x,y pos will always lie on a circle
                                // x = center.x + radius * cos(angleRad)
                                // y = center.y + radius * sin(angleRad)

                                float radius = 34.0f; // distance from center of locator to center of handle tip
                                float boxSize = 20.0f; // width of the angle adjuster handle rect

                                // Zoom the hit boxes
                                if(zoomInt > 100) { // we are zooming in
                                    radius *= zoomLevel;
                                    boxSize *= zoomLevel;
                                }
                                editLocatorCenter *= zoomLevel; // zoom center location
                                float centerX = screenRect.x + editLocatorCenter.x - scrollPos.x;
                                float centerY = screenRect.y + editLocatorCenter.y - scrollPos.y;
                                
                                float facingRad;
                                if(!flipForwardVector) facingRad = Mathf.Deg2Rad * (360.0f - editLocatorFrame.facing); // reverse rotation so GUI rotation matches scene counterclockwise = +
                                else facingRad = Mathf.Deg2Rad * SpriteFactory.Utils.MathTools.ClampAngle360((editLocatorFrame.facing) + 180.0f);
                                float rotatedX = centerX + radius * Mathf.Cos(facingRad);
                                float rotatedY = centerY + radius * Mathf.Sin(facingRad);

                                absAngleAdjustRect.x = rotatedX;
                                absAngleAdjustRect.y = rotatedY;
                                absAngleAdjustRect.width = boxSize;
                                absAngleAdjustRect.height = boxSize;

                                // Offset the rect to center it on the handle tip
                                absAngleAdjustRect.x -= boxSize * 0.5f;
                                absAngleAdjustRect.y -= boxSize * 0.5f;

                                if(absAngleAdjustRect.Contains(e.mousePosition)) { // clicked on handle
                                    StartMouseDrag(0);
                                    dragCornerId = 1;
                                }
                            }
                        }
                    } else if(e.type == EventType.mouseUp) {
                        if(isDragging && e.button == 0) { // left click
                            EndMouseDrag();
                        }
                    } else if(e.type == EventType.mouseDrag) {
                        if(isDragging && mouseButtonId == 0) {
                            if(dragCornerId == 0) { // main circle
                                Vector2 delta = HandleMouseDrag(e.delta);
                                moveX = (int)delta.x;
                                moveY = -(int)delta.y;
                            } else if(dragCornerId == 1) { // angle adjuster
                                // Find angle toward mouse pointer from center of locator
                                editLocatorCenter *= zoomLevel; // scale center point
                                Vector2 mousePos = e.mousePosition;
                                Vector2 center = new Vector2(screenRect.x + editLocatorCenter.x - scrollPos.x, screenRect.y + editLocatorCenter.y - scrollPos.y);
                                Vector2 dirToMouse = mousePos - center;
                                float angle;
                                if(!flipForwardVector) {
                                    angle = 360.0f - Vector2.Angle(Vector2.right, dirToMouse); // adjust to counterclockwise = + direction
                                } else {
                                    angle = Vector2.Angle(Vector2.right, dirToMouse); // adjust to counterclockwise = + direction
                                    angle = SpriteFactory.Utils.MathTools.ClampAngle360(angle + 180.0f);
                                }
                                if(dirToMouse.y < 0.0f) angle = 360.0f - angle; // adjust for the fact that V2.angle always gives abs value of angle

                                // Snap to 45 degree angles if holding shift
                                if(e.shift) {
                                    float div = angle / 45.0f;
                                    float whole = Mathf.Floor(div);
                                    float frac = div - whole;
                                    if(frac >= 0.5f) { // round up to nearest 45
                                        angle = SpriteFactory.Utils.MathTools.ClampAngle360((whole + 1.0f) * 45.0f);
                                    } else { // round down
                                        angle = SpriteFactory.Utils.MathTools.ClampAngle360(whole * 45.0f);
                                    }
                                }

                                if(angle != editLocatorFrame.facing) {
                                    editLocatorFrame.facing = angle;
                                    valueChanged = true;
                                }
                            }
                        }
                    }
                }

                // Handle keyboard controls
                if(e.type == EventType.keyDown && e.isKey) {
                    bool inViewRect = viewingRectMinusScrollbars.Contains(e.mousePosition);
                    if(inViewRect) {
                        int value = e.shift ? 5 : 1; // move image 5 units if shift is held down, 1 if not

                        if(e.keyCode == KeyCode.UpArrow) {
                            moveY = value;
                        } else if(e.keyCode == KeyCode.DownArrow) {
                            moveY = -value;
                        }

                        if(e.keyCode == KeyCode.LeftArrow) {
                            moveX = -value;
                        } else if(e.keyCode == KeyCode.RightArrow) {
                            moveX = value;
                        }
                    }
                }

                // Apply movement
                if(moveX != 0 || moveY != 0) {
                    editLocatorFrame.pixelPosition.x += moveX;
                    editLocatorFrame.pixelPosition.y += moveY;
                    valueChanged = true;
                }
            }

            private void HandleControls_Animation(Rect viewingRectMinusScrollbars) {
                Event e = Event.current;
                if(e.isKey) {
                    bool inViewRect = viewingRectMinusScrollbars.Contains(e.mousePosition);
                    if(inViewRect) {
                        if(e.type == EventType.KeyDown) {
                            if(e.keyCode == KeyCode.Comma || e.keyCode == KeyCode.Q) { // previous
                                frameListBoxContainer.SelectPrevious(true); // allow wrapping
                            } else if(e.keyCode == KeyCode.Period || e.keyCode == KeyCode.W) { // next
                                frameListBoxContainer.SelectNext(true); // allow wrapping
                            }
                        }
                    }
                }
            }

            private void HandleControls_CopyPaste(int editMode, Rect viewingRectMinusScrollbars, ref bool valueChanged) {
                if(editMode != 1 && editMode != 2) return; // only copy/paste for colliders and locators
                
                Event e = Event.current;

                // bool inViewRect = viewingRectMinusScrollbars.Contains(e.mousePosition);
                // can't use view rect, mouse event doesn't seem to be sent during these validation/execution commands
                // I could store it, but its not worth it. Usage may be better just allowing copy/paste anywhere

                if(e.type == EventType.ValidateCommand) { // Validate the command

                    if(e.commandName == "Copy" || e.commandName == "Paste") {
                        e.Use(); // without this line we won't get ExecuteCommand
                    }
                    
                } else if(e.type == EventType.ExecuteCommand) { // Execute the command

                    if(e.commandName == "Copy") {
                        if(editMode == 1) { // collider
                            if(editColliderFrame != null) {
                                clipboard.Copy(editColliderFrame);
                            }
                        } else if(editMode == 2) { // locator
                            if(editLocatorFrame != null) {
                                clipboard.Copy(editLocatorFrame);
                            }
                        }
                    } else if(e.commandName == "Paste") {
                        if(editMode == 1) { // collider
                            if(clipboard.hasColliderFrame) {
                                int index = SpriteFactory.Utils.ArrayTools.IndexOf<Sprite.ColliderFrame>(frame.colliderFrames, editColliderFrame);
                                if(index >= 0) {
                                    frame.colliderFrames[index] = clipboard.PasteColliderFrame(); // paste the frame
                                    valueChanged = true;
                                }
                            }
                        } else if(editMode == 2) { // locator
                            if(clipboard.hasLocatorFrame) {
                                int index = SpriteFactory.Utils.ArrayTools.IndexOf<Sprite.LocatorFrame>(frame.locatorFrames, editLocatorFrame);
                                if(index >= 0) {
                                    frame.locatorFrames[index] = clipboard.PasteLocatorFrame(); // paste the frame
                                    valueChanged = true;
                                }
                            }
                        }
                    }
                }
            }

            private bool HandlePan(Rect viewingRectMinusScrollbars, ref Vector2 scrollPos) {
                // Right mouse button was clicked inside window
                // mouse is being dragged
                Vector2 offset = new Vector2();
                Event e = Event.current;
                if(e.isMouse) {
                    bool inViewRect = viewingRectMinusScrollbars.Contains(e.mousePosition);

                    // Initial click
                    if(e.type == EventType.mouseDown) { // button was pressed
                        if(e.button == 1 && inViewRect) { // right click
                            if(GUIUtility.keyboardControl > 0) GUIUtility.keyboardControl = 0; // clear keyboard focus when clicked to make sure if user had offset highlighted it will update properly
                            StartMouseDrag(1);
                        }
                    } else if(e.type == EventType.mouseUp) {
                        if(isDragging && e.button == 1) { // right click
                            EndMouseDrag();
                        }
                    } else if(e.type == EventType.mouseDrag) {
                        if(isDragging && mouseButtonId == 1) {
                            Vector2 delta = HandleMouseDrag(e.delta);
                            offset.x -= (int)delta.x;
                            offset.y -= (int)delta.y;
                        }
                    }
                }

                if(offset.x != 0.0f || offset.y != 0.0f) {
                    scrollPos += offset * zoomLevel;
                    return true;
                }
                return false;
            }

            private void HandleWheelZoom(Rect viewRect) {
                Event e = Event.current;
                if(e.type != EventType.ScrollWheel) return; // not right event
                if(!viewRect.Contains(e.mousePosition)) return; // scroll zoom if mouse is over scroll view
                
                float delta = e.delta.y;
                
                int tick;
                int newZoomInt;
                float signDelta = Mathf.Sign(delta);
                bool zoomOut = signDelta > 0.0f ? true : false;

                // Set different tick sizes for different zoom ranges
                if(zoomInt <= 100) {
                    if(zoomInt == 100 && !zoomOut) tick = 10;
                    else tick = 5;
                } else if(zoomInt <= 150) {
                    if(zoomInt == 150 && !zoomOut) tick = 25;
                    else tick = 10;
                } else {
                    tick = 25;
                }
                
                // find closest tick to current position
                if(zoomInt % tick > 0) {
                    int nextTick = zoomInt / tick * tick;
                    if(signDelta < 0.0f) // zooming in
                        nextTick += tick; // round up
                    newZoomInt = nextTick;
                } else {
                    newZoomInt = zoomInt - (int)(signDelta * tick);
                }
                zoomPercentInt = newZoomInt;
            }

            private void StartMouseDrag(int button) {
                isDragging = true;
                mouseButtonId = button;
                ClearDragBuffer();
            }

            private void EndMouseDrag() {
                isDragging = false;
                mouseButtonId = -1;
                ClearDragBuffer();
            }

            private Vector2 HandleMouseDrag(Vector2 delta) {
                delta.x = GetDragDelta(delta.x, ref dragBuffer.x);
                delta.y = GetDragDelta(delta.y, ref dragBuffer.y);
                return delta;
            }

            private float GetDragDelta(float delta, ref float buffer) {
                float pixelSize = zoomLevel;

                // Add delta to buffer
                buffer += delta;

                // Apply buffer to get scaled delta
                float scaledDelta = 0.0f;
                int wholeScaledPixelsInBuffer = Mathf.FloorToInt(Mathf.Abs(buffer) / pixelSize); // determine how many whole scaled pixels are in the buffer
                if(wholeScaledPixelsInBuffer >= 1) { // we've built up enough drag to apply it
                    float amount = wholeScaledPixelsInBuffer * Mathf.Sign(buffer); // apply sign back to pixel amount
                    scaledDelta = amount; // apply the pixels to the delta
                    buffer -= amount * pixelSize; // take the unscaled applied amount out of the buffer
                }

                return scaledDelta;
            }

            private void ClearDragBuffer() {
                dragBuffer.x = 0.0f;
                dragBuffer.y = 0.0f;
            }

            private void ZoomRect(ref Rect rect) {
                if(zoomInt == 100) return; // no zoom
                rect.x *= zoomLevel;
                rect.y *= zoomLevel;
                rect.width *= zoomLevel;
                rect.height *= zoomLevel;
            }

            private void ZoomRectPosOnly(ref Rect rect) {
                if(zoomInt == 100) return; // no zoom
                rect.x *= zoomLevel;
                rect.y *= zoomLevel;
            }

            private void DrawScaledTexture(Rect position, Texture image) {
                ZoomRect(ref position); // zoom the rect if necessary
                GUI.DrawTexture(position, image);
            }

            private void DrawGrid(Rect screenRect, Vector2 scrollPos, Rect viewRect) {
                Rect gridRect = areaRect;
                ZoomRect(ref gridRect); // zoom if necessary

                // Find the rect of visible area inside this scroll view
                //ZoomRect(ref textureRect); // zoom if necessary
                Rect visibleRect = new Rect();
                visibleRect.x = areaRect.x + scrollPos.x;
                visibleRect.y = areaRect.y + scrollPos.y;
                visibleRect.width = screenRect.width;
                visibleRect.height = screenRect.height;

                // Fill the background
                SpriteFactory.Utils.GUITools.Solid.BeginDrawSet();
                SpriteFactory.Utils.GUITools.Solid.Draw(visibleRect, gridBkgColor); // fill entire background
                
                // Draw the grid out from the center
                float fGridSpacingZ = this.gridSpacing * zoomLevel; // zoom the grid spacing
                int gridCellsX = (int)(areaRect.width / gridSpacing); // zoom doesn't affect the number of cells
                int gridCellsY = (int)(areaRect.height / gridSpacing);

                // Make sure we always have an even number of cells
                if(gridCellsX % 2 > 0) gridCellsX++;
                if(gridCellsY % 2 > 0) gridCellsY++;
                
                float halfWidth;
                int middle;
                Rect rect = new Rect();
                SpriteFactory.Utils.GUITools.Solid.color = gridLineColor;

                // Draw vertical grid lines
                halfWidth = gridRect.width * 0.5f;
                middle = gridCellsX / 2;
                rect.y = visibleRect.y;
                rect.width = 1.0f;
                rect.height = visibleRect.height;
                for(int i = 0; i < gridCellsX; i++) {
                    if(i < middle) rect.x = halfWidth - (i * fGridSpacingZ);
                    else if(i > middle) rect.x = halfWidth + (i - middle) * fGridSpacingZ;
                    else continue; // skip mid line
                    if(rect.x + rect.width < visibleRect.x || rect.x > visibleRect.x + visibleRect.width) continue; // don't draw if out of viewable area
                    SpriteFactory.Utils.GUITools.Solid.Draw(rect);
                }

                float halfHeight = gridRect.height * 0.5f;
                middle = gridCellsY / 2;
                rect.x = visibleRect.x;
                rect.height = 1.0f;
                rect.width = visibleRect.width;
                for(int i = 0; i < gridCellsY; i++) {
                    if(i < middle) rect.y = halfHeight - i * fGridSpacingZ;
                    else if(i > middle) rect.y = halfHeight + (i - middle) * fGridSpacingZ;
                    else continue; // skip mid line
                    if(rect.y + rect.height < visibleRect.y || rect.y > visibleRect.y + visibleRect.height) continue; // don't draw if out of viewable area
                    SpriteFactory.Utils.GUITools.Solid.Draw(rect);
                }

                // Draw center line
                SpriteFactory.Utils.GUITools.Solid.color = gridCenterLineColor;
                
                // Vertical
                rect.x = halfWidth;
                rect.y = visibleRect.y;
                rect.width = 1.0f;
                rect.height = visibleRect.width;
                if(rect.x + rect.width >= visibleRect.x && rect.x < visibleRect.x + visibleRect.width) // falls within visible area
                    SpriteFactory.Utils.GUITools.Solid.Draw(rect);

                // Horizontal
                rect.x = visibleRect.x;
                rect.y = halfHeight;
                rect.width = visibleRect.width;
                rect.height = 1.0f;
                if(rect.y + rect.height >= visibleRect.y && rect.y < visibleRect.y + visibleRect.height) // falls within visible area
                    SpriteFactory.Utils.GUITools.Solid.Draw(rect);

                SpriteFactory.Utils.GUITools.Solid.EndDrawSet(); // restore GUI color
            }

            private Rect GetPixelAlignedImageRect(Texture2D texture, float trueAreaCenterX, float trueAreaCenterY, SpriteFactory.Utils.DataClasses.IntVector2 pixelOffset) {
                // Find actual center of image texture
                float trueImageCenterX = texture.width * 0.5f;
                float trueImageCenterY = texture.height * 0.5f;

                // Find actual starting position of texture in grid area
                float imagePosLeft = trueAreaCenterX - trueImageCenterX;
                float imagePosTop = trueAreaCenterY - trueImageCenterY;

                // Round off to pixel positions to whole in case NEAR but not exact, will not round 0.5fs, only VERY near
                imagePosLeft = SpriteFactory.Utils.MathTools.RoundOffIfNearWholeNumber(imagePosLeft);
                imagePosTop = SpriteFactory.Utils.MathTools.RoundOffIfNearWholeNumber(imagePosTop);
                
                // Round position to nearest pixel in final area
                imagePosLeft = Mathf.Floor(imagePosLeft); // Floor offsets 1/2 pixels to the left in the area
                imagePosTop = Mathf.Ceil(imagePosTop); // Ceil offsets 1/2 pixels DOWN in the area (0,0 is upper left of area)

                // Find final offset position of image in the area
                float finalPosX = imagePosLeft + pixelOffset.x;
                float finalPosY = imagePosTop - pixelOffset.y; // invert because world +Y = up, area +Y = down

                return new Rect(finalPosX, finalPosY, texture.width, texture.height);
            }

            // Public
            
            public void ResetZoom(int zoom = -1) {
                if(zoom < 0) zoom = startingZoomInt;
                zoomPercentInt = zoom;
            }

            public void CenterView() {
                viewCenter = new Vector2(0.5f, 0.5f);
                scrollPos = new Vector2((areaWidth * 0.5f) - (screenRect.width * 0.5f), (areaHeight * 0.5f) - (screenRect.height * 0.5f));
            }

            public void ResetView(int zoom = -1) {
                CenterView();
                ResetZoom(zoom);
            }

            public override void Clear() {
                image = null;
                changed = true;
                isDragging = false;
                mouseButtonId = -1;
                dragCornerId = -1; // clear last corner selection id
            }
        }
     
        private static class ScrollView {

            static public Vector2 Begin(Rect position, Vector2 scrollPosition, Rect viewRect, bool enableScrollWheel = true) {
                return Begin(position, scrollPosition, viewRect, false, false, null, null, enableScrollWheel);
            }

            static public Vector2 Begin(Rect position, Vector2 scrollPosition, Rect viewRect, bool alwaysShowHorizontal, bool alwaysShowVertical, bool enableScrollWheel = true) {
                return Begin(position, scrollPosition, viewRect, alwaysShowHorizontal, alwaysShowVertical, null, null, enableScrollWheel);
            }
            
            static public Vector2 Begin(Rect position, Vector2 scrollPosition, Rect viewRect, GUIStyle horizontalScrollbar, GUIStyle verticalScrollbar, bool enableScrollWheel = true) {
                return Begin(position, scrollPosition, viewRect, false, false, horizontalScrollbar, verticalScrollbar, enableScrollWheel);
            }

            static public Vector2 Begin(Rect position, Vector2 scrollPosition, Rect viewRect, bool alwaysShowHorizontal, bool alwaysShowVertical, GUIStyle horizontalScrollbar, GUIStyle verticalScrollbar, bool enableScrollWheel = true) {

                // Capture the wheel event -- having the event here would probably prevent any child objects of this scroll view from having wheel events, this is fine for my purposes but if reusing this control will have to change
                HandleWheelEvent(enableScrollWheel, ref position, ref scrollPosition);

                // Draw scroll bars
                bool hasScrollBars = DrawScrollBars(ref position, ref scrollPosition, ref viewRect, alwaysShowHorizontal, alwaysShowVertical, horizontalScrollbar, verticalScrollbar);

                // Draw the outer box
                GUI.BeginGroup(position); // outer box

                // Offset the content rect for scroll position
                if(hasScrollBars) {
                    viewRect.x -= scrollPosition.x;
                    viewRect.y -= scrollPosition.y;
                }

                // Draw contents
                GUI.BeginGroup(viewRect); // inner contents

                // Should add something to make it use the scroll view styles

                return scrollPosition;
            }

            static bool DrawScrollBars(ref Rect position, ref Vector2 scrollPosition, ref Rect viewRect, bool alwaysShowHorizontal, bool alwaysShowVertical, GUIStyle horizontalScrollbar, GUIStyle verticalScrollbar) {
                // Determine which scroll bars to show
                bool showHorizontal = false;
                if(alwaysShowHorizontal || viewRect.width > position.width) showHorizontal = true;
                bool showVertical = false;
                if(alwaysShowVertical || viewRect.height > position.height) showVertical = true;
                
                // Determine scroll bar thickness
                float hBarWidth = 0.0f;
                float vBarWidth = 0.0f;
                if(showHorizontal) {
                    if(horizontalScrollbar == null) { // no horiz skin set
                        hBarWidth = GUI.skin.horizontalScrollbar.normal.background.height; // get scroll bar thickness from current GUI skin
                    } else { // we have a horizontal scroll bar skin
                        hBarWidth = horizontalScrollbar.normal.background.height; // get thickness from incoming style
                    }
                }
                if(showVertical) {
                    if(verticalScrollbar == null) { // no vert skin set
                        vBarWidth = GUI.skin.verticalScrollbar.normal.background.width; // get scroll bar thickness from current GUI skin
                    } else { // we have a vertical scroll bar skin
                        vBarWidth = verticalScrollbar.normal.background.width; // get thickness from incoming style
                    }
                }

                // Draw scroll bars
                float clipHeight = 0.0f;
                float clipWidth = 0.0f;
                
                // Horizontal scroll bar
                if(showHorizontal) {   
                    Rect hBarRect = new Rect(position.x, position.y + position.height - hBarWidth, position.width - vBarWidth, hBarWidth);
                    if(horizontalScrollbar != null) scrollPosition.x = GUI.HorizontalScrollbar(hBarRect, scrollPosition.x, position.width, 0, viewRect.width, horizontalScrollbar);
                    else  scrollPosition.x = GUI.HorizontalScrollbar(hBarRect, scrollPosition.x, position.width, 0, viewRect.width);
                    clipHeight = hBarWidth; // clip outer box so it reveals the scroll bar
                }

                // Vertical scroll bar
                if(showVertical) {
                    Rect vBarRect = new Rect(position.x + position.width - vBarWidth, position.y, vBarWidth, position.height - hBarWidth);    
                    if(verticalScrollbar != null) scrollPosition.y = GUI.VerticalScrollbar(vBarRect, scrollPosition.y, position.height, 0, viewRect.height, verticalScrollbar);
                    else scrollPosition.y = GUI.VerticalScrollbar(vBarRect, scrollPosition.y, position.height, 0, viewRect.height);
                    clipWidth = vBarWidth; // clip outer box so it reveals the scroll bar
                }

                // Clip the position rect to reveal the scroll bars
                if(showHorizontal) position.height -= clipHeight;
                if(showVertical) position.width -= clipWidth;

                return showHorizontal || showVertical; // return true if either bar is drawn
            }

            static public void End() {
                GUI.EndGroup();
                GUI.EndGroup();
            }

            static public void HandleWheelEvent(bool enableScrollWheel, ref Rect position, ref Vector2 scrollPosition) {
                Event e = Event.current;
                if(enableScrollWheel) {
                    if(e.type == EventType.ScrollWheel && position.Contains(e.mousePosition)) { // wheel event and mouse is within rect
                        scrollPosition.y += GUI.skin.scrollView.lineHeight * 2 * e.delta.y; // add wheel scroll to scroll position
                    }
                } else {
                    if(e.type == EventType.ScrollWheel && position.Contains(e.mousePosition)) { // wheel event and mouse is within rect
                        e.delta = new Vector2(); // clear the wheel scroll
                    }
                }
            }
        }

        #endregion

        #region MISC CLASSES

        private class EditorProperties {
            public int pixelsPerUnit;
            public bool trimSprites;
            public int framePadding;
            public int maxAtlasSize;
            public bool forceSquareAtlases;
            public bool useMipMaps;
            public bool useTextureCompression;
            //public AtlasPackingMethod atlasPackingMethod;
            public ResolutionTarget resolutionTarget;
            public ImageResamplingMode resolutionTargetResamplingMode;
            public Material defaultMaterial;
            public FilterMode defaultFilterMode;
            public int defaultAnisoLevel;
            public bool defaultUseTwoSidedMesh;
            public Enums.SpriteMeshType defaultMeshType;
            public TransparencyChannel defaultAutoMeshTransparencyChannel = TransparencyChannel.Alpha; // force alpha for now
            public int defaultAutoMeshEdgeExtrude;
            public int defaultAutoMeshVertexReductionDistance;
            public bool defaultUse2DColliders;
            public AutomaticActionPolicy rebuildSpriteGroupOnSave;
            public AutomaticActionPolicy rebuildSpriteOnSave;
        }

        private class ListboxAction {
            public enum Action { None, Add, Insert, Delete, Reorder, Duplicate, ChangeSelection }

            public SimpleGUIListBoxContainer<int> container;

            public bool pending {
                get {
                    return _pending;
                }
            }
            public Action action {
                get {
                    return _action;
                }
                set {
                    _pending = true;
                    _action = value;
                }
            }
            public int listIndex {
                get {
                    return _listIndex;
                }
                set {
                    _pending = true;
                    _listIndex = value;
                }
            }
            public int objectIndex {
                get {
                    return _objectIndex;
                }
                set {
                    _pending = true;
                    _objectIndex = value;
                }
            }
            public int groupIndex {
                get {
                    return _groupIndex;
                }
                set {
                    _pending = true;
                    _groupIndex = value;
                }
            }
            public int groupId {
                get {
                    return _groupId;
                }
                set {
                    _pending = true;
                    _groupId = value;
                }
            }
            public int offset {
                get {
                    return _offset;
                }
                set {
                    _pending = true;
                    _offset = value;
                }
            }

            private bool _pending;
            private Action _action;
            private int _listIndex;
            private int _objectIndex;
            private int _groupIndex;
            private int _groupId;
            private int _offset;


            public ListboxAction(SimpleGUIListBoxContainer<int> inContainer) {
                container = inContainer;
            }

            public void Finish() {
                container.refresh = true;
                Clear();
            }

            public void Clear() {
                _pending = false;
                _action = Action.None;
                _listIndex = -1;
                _objectIndex = -1;
                _groupIndex = -1;
                _groupId = -1;
                _offset = 0;
            }
        }

        private class MaterialSetContainer {
            public EditorMasterSprite.MaterialSet[] materialSets;
            private DB db;

            public int materialSetCount {
                get {
                    if(materialSets == null) return 0;
                    return materialSets.Length;
                }
            }

            public MaterialSetContainer(DB inDB) {
                db = inDB;
            }

            public MaterialSetContainer(DB inDB, EditorMasterSprite.MaterialSet[] inMaterialSets)
                : this(inDB) {
                materialSets = CloneMaterialSets(inMaterialSets);
            }

            public MaterialSetContainer(DB inDB, EditorMasterSprite.Data inMasterSpriteData)
                : this(inDB) {
                materialSets = CloneMaterialSets(inMasterSpriteData.editorMaterialSets);
            }

            public MaterialSetContainer(DB inDB, EditorMasterSprite.SpriteGroup inMasterSpriteGroup)
                : this(inDB) {
                materialSets = CloneMaterialSets(inMasterSpriteGroup.editorMaterialSets);
            }

            #region // Editor Controls

            public void AddNewMaterialSet() {
                EditorMasterSprite.MaterialSet newSet = new EditorMasterSprite.MaterialSet("MaterialSet0", true, db.userDefaultMaterial);
                newSet.name = VerifyName(newSet.name, -1); // make sure name isn't used
                SpriteFactory.Utils.ArrayTools.Add<EditorMasterSprite.MaterialSet>(ref materialSets, newSet);
            }

            public void InsertNewMaterialSet(int index) {
                EditorMasterSprite.MaterialSet newSet = new EditorMasterSprite.MaterialSet("MaterialSet0", true, db.userDefaultMaterial);
                newSet.name = VerifyName(newSet.name, -1); // make sure name isn't used
                SpriteFactory.Utils.ArrayTools.Insert<EditorMasterSprite.MaterialSet>(ref materialSets, index, newSet);
            }

            public void DeleteMaterialSet(int index) {
                SpriteFactory.Utils.ArrayTools.RemoveAt<EditorMasterSprite.MaterialSet>(ref materialSets, index);
            }

            public void DuplicateMaterialSet(int index) {
                EditorMasterSprite.MaterialSet newSet = materialSets[index].DeepCopy();
                if(!newSet.name.EndsWith("_copy")) newSet.name += "_copy"; // append copy
                newSet.name = VerifyName(newSet.name, -1); // make sure name isn't used
                SpriteFactory.Utils.ArrayTools.Insert<EditorMasterSprite.MaterialSet>(ref materialSets, index + 1, newSet);
            }

            public bool ReorderMaterialSet(int index, int offset, bool reorderNow = true) {
                if(offset == 0) return false;
                if(index == materialSets.Length - 1 && offset > 0) return false; // at end of list trying to move down
                if(index == 0 && offset < 0) return false; // at beginning of list trying to move up
                if(!reorderNow) return true; // just testing to see if we can reorder, passed

                // Does not handle offsets other than +/- 1
                if(offset > 1) offset = 1;
                if(offset < -1) offset = -1;

                EditorMasterSprite.MaterialSet entry = materialSets[index]; // get the entry
                SpriteFactory.Utils.ArrayTools.RemoveAt<EditorMasterSprite.MaterialSet>(ref materialSets, index); // remove entry first

                if(offset > 0) {
                    if(index + offset >= materialSets.Length) { // would be at the end of the list
                        SpriteFactory.Utils.ArrayTools.Add<EditorMasterSprite.MaterialSet>(ref materialSets, entry); // add to end of the list
                        return true;
                    }
                }
                SpriteFactory.Utils.ArrayTools.Insert<EditorMasterSprite.MaterialSet>(ref materialSets, index + offset, entry); // insert the entry back
                return true;
            }

            #endregion

            #region // Name Verification

            public string VerifyName(string name, int thisIndex) {
                return SpriteFactory.Utils.StringTools.VerifyName(name, thisIndex, GetSetNames());
            }

            private string[] GetSetNames() {
                if(materialSets == null) return null;
                string[] names = new string[materialSets.Length];
                for(int i = 0; i < materialSets.Length; i++) {
                    names[i] = materialSets[i].name;
                }
                return names;
            }

            #endregion

            #region // Import / Export

            public void ExportData(EditorMasterSprite.Data masterSpriteData) {
                // copy data to master sprite
                masterSpriteData.editorMaterialSets = CloneMaterialSets(materialSets);
            }

            public void ExportData(EditorMasterSprite.SpriteGroup spriteGroup) {
                // copy data to sprite group
                spriteGroup.editorMaterialSets = CloneMaterialSets(materialSets);
            }

            private EditorMasterSprite.MaterialSet[] CloneMaterialSets(EditorMasterSprite.MaterialSet[] inMaterialSets) {
                if(inMaterialSets == null) return null;

                EditorMasterSprite.MaterialSet[] newMaterialSets = new EditorMasterSprite.MaterialSet[inMaterialSets.Length];
                for(int i = 0; i < inMaterialSets.Length; i++) {
                    newMaterialSets[i] = inMaterialSets[i].DeepCopy();
                }
                return newMaterialSets;
            }

            #endregion
        }

        private class GUITimer {
            public bool running;
            private float timer;
            public float length;
            public float remaining { get { return timer; } }

            public GUITimer() { }

            public GUITimer(float inLength) {
                length = inLength;
            }

            public void Start() {
                running = true;
                timer = Time.realtimeSinceStartup + length;
            }

            public bool Update() {
                if(!running) return false;
                if(Time.realtimeSinceStartup >= timer) { // timer has finished
                    running = false;
                    return true;
                }
                return false;
            }

            public void Clear() {
                running = false;
                timer = 0.0f;
            }

            public void SetLength(float inLength) {
                length = inLength;
            }
        }

        private class Exporter {
            public bool exportPrefabs;
            public string savePath;

            public int[] groupIndices;
            public string[] groupNames;
            public int[] spriteIndices;
            public string[] spriteNames;

            public int[] groupIndicesToExport;
            public string[] groupNamesToExport;
            public int[] spriteIndicesToExport;
            public string[] spriteNamesToExport;

            public void AddGroupToExportList(int index) {
                MoveFromList<int>(ref groupIndices, ref groupIndicesToExport, index); // move index
                MoveFromList<string>(ref groupNames, ref groupNamesToExport, index); // move name
            }

            public void AddSpriteToExportList(int index) {
                MoveFromList<int>(ref spriteIndices, ref spriteIndicesToExport, index); // move index
                MoveFromList<string>(ref spriteNames, ref spriteNamesToExport, index); // move name
            }

            public void RemoveGroupFromExportList(int index) {
                MoveFromList<int>(ref groupIndicesToExport, ref groupIndices, index); // move index
                MoveFromList<string>(ref groupNamesToExport, ref groupNames, index); // move name
            }

            public void RemoveSpriteFromExportList(int index) {
                MoveFromList<int>(ref spriteIndicesToExport, ref spriteIndices, index); // move index
                MoveFromList<string>(ref spriteNamesToExport, ref spriteNames, index); // move name
            }
            
            public void AddAllGroupsToExportList() {
                int count = groupIndices.Length;
                while(count > 0) {
                    AddGroupToExportList(0);
                    count--;
                }
            }

            public void AddAllSpritesToExportList() {
                int count = spriteIndices.Length;
                while(count > 0) {
                    AddSpriteToExportList(0);
                    count--;
                }
            }

            public void RemoveAllGroupsFromExportList() {
                int count = groupIndicesToExport.Length;
                while(count > 0) {
                    RemoveGroupFromExportList(0);
                    count--;
                }
            }
            
            public void RemoveAllSpritesFromExportList() {
                int count = spriteIndicesToExport.Length;
                while(count > 0) {
                    RemoveSpriteFromExportList(0);
                    count--;
                }
            }

            private void MoveFromList<T>(ref T[] fromList, ref T[] toList, int index) {
                if(index < 0 || index >= fromList.Length) throw new System.Exception("Invalid index!");

                SpriteFactory.Utils.ArrayTools.Add<T>(ref toList, fromList[index]); // add index to toList
                SpriteFactory.Utils.ArrayTools.RemoveAt<T>(ref fromList, index); // remove from fromList
            }

            public void Clear() {
                exportPrefabs = true;
                savePath = "";

                groupIndices = null;
                groupNames = null;
                spriteIndices = null;
                spriteNames = null;

                groupIndicesToExport = null;
                groupNamesToExport = null;
                spriteIndicesToExport = null;
                spriteNamesToExport = null;
            }
        }

        private class Importer {
            private string _importPath;

            // Imported data
            private string sfRootPath;
            public AssetData[] assetData;
            public string[] uniqueAssetPaths;

            private int _status;
            public string[] errors;
            public int[] errorLevels;

            // Properties
            public string importPath {
                get {
                    return _importPath;
                }
            }
            public string unitypackagePath {
                get {
                    if(_importPath == null) return null;
                    return _importPath + ".unitypackage";
                }
            }
            public int status {
                get {
                    return _status;
                }
            }
            public int errorCount {
                get {
                    if(errors == null) return 0;
                    return errors.Length;
                }
            }
            public int fileCount {
                get {
                    if(assetData == null) return 0;
                    return assetData.Length;
                }
            }
            public int uniqueAssetCount {
                get {
                    if(uniqueAssetPaths == null) return 0;
                    return uniqueAssetPaths.Length;
                }
            }

            public Importer() {
                Clear();
            }

            public void ImportFile() {
                // Check for missing files
                if(!File.Exists(_importPath)) {
                    AddError("File not found! Import aborted.", 2);
                    _status = -1;
                    return;
                }

                if(!_importPath.ToLower().EndsWith(exportTextExtension)) {
                    AddError("Invalid import file! Must be a " + exportTextExtension + " file. Import aborted.", 2);
                    _status = -1;
                    return;
                }

                if(!File.Exists(unitypackagePath)) {
                    AddError("Companion .unitypackage was not found! Import aborted.", 2);
                    _status = -1;
                    return;
                }

                // Read the file
                try {
                    using(StreamReader sr = new StreamReader(_importPath, System.Text.Encoding.UTF8)) {
                        if(!sr.EndOfStream) SetRootPath(sr.ReadLine());
                        while(!sr.EndOfStream) {
                            string GUID = sr.ReadLine();
                            string path = sr.ReadLine();
                            AssetData.AssetType type = (AssetData.AssetType)System.Enum.Parse(typeof(AssetData.AssetType), sr.ReadLine(), true);
                            Add(GUID, path, type); // add to importer
                        }
                    }
                } catch(System.Exception e) {
                    AddError("Could not load " + exportTextExtension + " file! " + e.Message, 2);
                    _status = -1;
                    return;
                }

                FindUniqueAssetPaths();

                // Validate the file
                int result = Validate();
                if(result == -1) { // critical error
                    _status = -1;
                    return;
                } else if(result == 0) { // warning
                    _status = 0; // warning
                    return;
                }

                _status = 1; // okay
            }

            public void Add(string guid, string path, AssetData.AssetType type) {
                SpriteFactory.Utils.ArrayTools.Add<AssetData>(ref assetData, new AssetData(path, guid, type));
            }

            public void SetRootPath(string path) {
                sfRootPath = path;
            }

            public void SetImportPath(string path) {
                _importPath = path;
            }

            private void AddError(string text, int level) {
                SpriteFactory.Utils.ArrayTools.Add<string>(ref errors, text);
                SpriteFactory.Utils.ArrayTools.Add<int>(ref errorLevels, level);
            }

            public int Validate() {
                // Look through project for potential problems

                // Check sprite factory root path
                if(sfRootPath.ToLower() != SpriteEditor.rootPath.ToLower()) {
                    AddError("Sprite Factory root path does not match! The SpriteFactory root directory must be in the same relative location in the Assets directory in both projects!", 2);
                }

                // Check if GUID is found in project but path/filenames don't match
                for(int i = 0; i < assetData.Length; i++) {
                    AssetData asset = assetData[i];
                    if(asset.type == AssetData.AssetType.PrefabDependency) continue; // skip checking prefab dependencies, these are unrelated to sprite factory

                    string guid = asset.guid;
                    string projectPathAtGUID = AssetDatabase.GUIDToAssetPath(guid);

                    // Check if asset is in trash or is a "ghost" file that unity thinks is there but is not
                    if(projectPathAtGUID != null && projectPathAtGUID != "") {
                        if(projectPathAtGUID.ToLower().Contains("__deleted_guid_trash") ||
                           !File.Exists(projectPathAtGUID)) { // sometimes when a file is deleted, unity will still think its there and give a non-trash path to it. This check filters those out.
                            projectPathAtGUID = ""; // asset existed but is in trash
                            // Even when asset is in trash, Unity will return a GUID for the old path even though no file is really at that path. "Ghost" file.
                        }
                    }

                    // Check if the GUID is new or exists
                    if(projectPathAtGUID == "") { // this guid is new

                        // check if the path is in use, filtering out "ghost" files from trashed assets
                        string projectGUID = "";
                        if(File.Exists(asset.path)) // check exists to filter out "ghost" files who are really in trash
                            projectGUID = AssetDatabase.AssetPathToGUID(asset.path); // get the GUID of the asset at the path if any
                        
                        if(projectGUID != "") { // there is a file already at this path with a different GUID.

                            string errorText = string.Format("GUID mismatch on {0} replacement! Imported asset cannot replace the existing one. ", asset.type.ToString());
                            
                            if(asset.type == AssetData.AssetType.SourceImage) {
                                errorText += "Any imported Master Sprites that reference this image will have the affected frames missing. Your source images on both ends should have identical names and GUIDs.";
                            } else if(asset.type == AssetData.AssetType.SourceMaterial) {
                                errorText += "However, the material shader and data will be copied over to the existing material. The link to this source material will be lost in the imported sprites/groups and will be replaced with the default material."
                                + "Source Materials should have the same GUID on both ends for best results.";
                            } else if(asset.type == AssetData.AssetType.EditorMasterSprite || asset.type == AssetData.AssetType.EditorMasterSpriteCore) {
                                errorText += string.Format("However, the component data will be copied over to the existing {0}.", asset.type.ToString());
                            } else if(asset.type == AssetData.AssetType.GameMasterSprite) {
                                errorText += string.Format("However, the component data will be copied over to the existing {0}. " +
                                "Be aware that any imported prefabs using this Master Sprite will be broken! You will have to reassign the MasterSprites to the prefabs in the editor. Master Sprites should have the same GUID on both ends for best results.", asset.type.ToString());
                            } else if(asset.type == AssetData.AssetType.SpriteGroup) {
                                errorText += string.Format("However, the component data will be copied over to the existing {0}.", asset.type.ToString());
                            } else if(asset.type == AssetData.AssetType.SpriteMesh) {
                                errorText += "However, the meshes will be copied to the existing asset. Be aware that any imported sprite prefabs using this mesh will be broken! You will have to reassign the MasterSprites to the prefabs in the editor. Sprite Meshes should have the same GUID on both ends for best results.";
                            } else if(asset.type == AssetData.AssetType.EditorPreviewMaterial) {
                                errorText += "Be aware that any imported sprite prefabs using this material will be broken! You will have to reassign the MasterSprites to the prefabs in the editor. Editor Preview Materials should have the same GUID on both ends for best results.";
                            } else if(asset.type == AssetData.AssetType.Prefab) {
                                errorText += "However, the contents of the imported prefab will be copied over to the existing prefab. " +
                                "Be aware that any links in other imported assets to this prefab will be broken! This is important if you are importing other prefabs that rely on this asset.";
                            } else {
                                errorText += "However, if there are identical components on both assets, the data will be copied over. Be aware that any links in other imported assets to this incoming asset will be broken! This is important if you are importing prefabs that rely on this asset.";
                            }
                            
                            errorText += "\nPath: " + asset.path;

                            AddError(errorText, 1); // add the error

                        } else { // path is not in use and GUID is new, so all is good
                            // nothing required
                        }

                    } else { // this guid is already in use

                        // Check if file names are different
                        bool fileNameMismatch = Path.GetFileName(asset.path) != Path.GetFileName(projectPathAtGUID) ? true : false;
                        if(fileNameMismatch) { // filenames do not match

                            // Check if this name mismatch is on a critical file
                            if((int)asset.type > 0 && (int)asset.type < 10) { // this is a critical file

                                // Show different help based on the type of object
                                string helpText;
                                if(asset.type == AssetData.AssetType.EditorMasterSprite || asset.type == AssetData.AssetType.EditorMasterSpriteCore || asset.type == AssetData.AssetType.GameMasterSprite)
                                    helpText = "Master Sprites must have identical names in source and destination to be replaced. If inside a Sprite Group, the groups must have identical names as well.";
                                else if(asset.type == AssetData.AssetType.SpriteGroup)
                                    helpText = "Sprite Groups must have identical names in source and destination to be replaced.";
                                else
                                    helpText = "";

                                AddError(string.Format("Filename mismatch {0} on replacement! GUID of imported asset matches a file in the project, but the filenames are different. This is not allowed for this asset type! {4}\n" +
                                "Path in import file: {1}\nPath in project: {2}\nGUID: {3}", asset.type.ToString(), asset.path, projectPathAtGUID, guid, helpText), 2);

                            } else {

                                AddError(string.Format("Filename mismatch on {0} replacement! GUID of imported asset matches a file in the project, but the filenames are different. " +
                                "The asset will be replaced, but at the filename and path of the asset in this project.\n" +
                                "Path in import file: {1}\nPath in project: {2}\nGUID: {3}", asset.type.ToString(), asset.path, projectPathAtGUID, guid), 1);
                            }
                        } else { // filenames and GUIDs match
                            // path may be different, but we don't need to worry about that right now
                        }
                    }
                }

                // Check for critical errors
                bool criticalError = false;
                for(int i = 0; i < errorCount; i++) {
                    if(errorLevels[i] == 2) {
                        criticalError = true;
                        break;
                    }
                }

                if(criticalError) return -1; // critical errors
                else if(errorCount > 0) return 0; // non-critical errors
                return 1; // no errors
            }

            private void FindUniqueAssetPaths() {
                for(int i = 0; i < fileCount; i++) {
                    SpriteFactory.Utils.ArrayTools.AddIfUnique(ref uniqueAssetPaths, assetData[i].path, true);
                }
            }

            public void Clear() {
                _importPath = "";
                sfRootPath = "";
                assetData = null;
                uniqueAssetPaths = null;
                _status = 1;
                errors = null;
                errorLevels = null;
            }
        }

        private class FrameClipboard {

            private Sprite.ColliderFrame colliderFrame;
            private Sprite.LocatorFrame locatorFrame;

            public bool hasColliderFrame { get { return colliderFrame == null ? false : true; } }
            public bool hasLocatorFrame { get { return locatorFrame == null ? false : true; } }

            public void Copy(Sprite.ColliderFrame colliderFrame) {
                if(colliderFrame == null) {
                    this.colliderFrame = null;
                    return;
                }
                this.colliderFrame = colliderFrame.DeepCopy();
            }

            public void Copy(Sprite.LocatorFrame locatorFrame) {
                if(locatorFrame == null) {
                    this.locatorFrame = null;
                    return;
                }
                this.locatorFrame = locatorFrame.DeepCopy();
            }

            public Sprite.ColliderFrame PasteColliderFrame() {
                if(colliderFrame == null) return null;
                return colliderFrame.DeepCopy();
            }

            public Sprite.LocatorFrame PasteLocatorFrame() {
                if(locatorFrame == null) return null;
                return locatorFrame.DeepCopy();
            }

            public void Clear() {
                colliderFrame = null;
                locatorFrame = null;
            }

        }

        #endregion

        #region TRIAL VERSION CLASSES

        #if TRIALVERSION

        internal static class Watermark {

            private const int width = 64;
            private const int height = 64;
            private const float opacity = 0.25f;
            private static float[] pixels = null;

            static Watermark() {
                MakeWatermark();
            }

            private static void MakeWatermark() {
                pixels = new float[width * height];
                char[] oneByte = new char[8];
                byte[] fourByte = new byte[4];

                int count = 0;
                for(int i = 0; i < watermarkString.Length; i += 32) {

                    for(int x = 0; x < 4; x++) {
                        for(int j = 0; j < 8; j++) {
                            oneByte[j] = watermarkString[i + (x*8) + j];
                        }
                        string oneByteS = new string(oneByte);
                        fourByte[x] = System.Convert.ToByte(oneByteS, 2);
                    }
                    float value = System.BitConverter.ToSingle(fourByte, 0);
                    pixels[count] = value;
                    count++;
                }
            }

            public static void ApplyToTexture(Color[] texPixels, int texWidth, int texHeight) {
                if(pixels == null) MakeWatermark();

                int wCol = 0;
                int wRow = 0;

                for(int row = 0; row < texHeight; row++) {
                    if(wRow >= Watermark.height) wRow = 0; // reset row
                    wCol = 0; // reset col every time we start a new row

                    for(int col = 0; col < texWidth; col++) {
                        if(wCol >= Watermark.width) wCol = 0; // reset col
                        
                        int texIndex = row * texWidth + col;
                        int wIndex = wRow * Watermark.width + wCol;
                        float a = texPixels[texIndex].a;
                        float value = pixels[wIndex] * a * opacity;
                        texPixels[texIndex].r += value;
                        texPixels[texIndex].g += value;
                        texPixels[texIndex].b += value;
                        wCol++;
                    }
                    wRow++;
                }
            }
        }

        #endif

        #endregion

        #endregion

    }

    
}